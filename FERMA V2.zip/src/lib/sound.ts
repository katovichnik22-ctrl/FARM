// ===== Процедурный звук: Web Audio API, ноль аудио-файлов =====

type MusicMood = "calm" | "night" | "war" | "victory" | "deep" | "space";
type SoundParams = { night: boolean; rain: number; snow: boolean; windAmt: number; nearFire: boolean; mood?: MusicMood };

class SoundEngine {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  muted = false;
  private noiseBuf: AudioBuffer | null = null;
  private windGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private lastStep = 0;
  private lastThud = 0;
  private lastMusic = 0;
  private musicPlaying = false;
  private musicEnd = 0;
  private birdT = 0;
  private crackleT = 0;
  private cricketT = 0;
  private mood: MusicMood = "calm";
  private pendingMood: MusicMood | null = null;

  ensure() {
    if (!this.ctx) {
      try {
        this.ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      } catch { return; }
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.55;
      this.master.connect(this.ctx.destination);
      this.startWind();
    }
    if (this.ctx.state === "suspended") this.ctx.resume().catch(() => {});
  }

  /** Немедленно сменить тему (победа, начало войны) */
  setMood(m: MusicMood, force = false) {
    if (this.mood === m && !force) return;
    this.mood = m;
    if (force && !this.musicPlaying) this.playMusic();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.linearRampToValueAtTime(m ? 0 : 0.55, (this.ctx?.currentTime ?? 0) + 0.15);
  }

  private noise(): AudioBuffer {
    if (!this.noiseBuf) {
      const len = this.ctx!.sampleRate * 2;
      this.noiseBuf = this.ctx!.createBuffer(1, len, this.ctx!.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    return this.noiseBuf;
  }

  private burst(opts: { type: OscillatorType | "noise"; freq?: number; freqEnd?: number; dur: number; vol: number; filter?: number; attack?: number; when?: number }) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + (opts.when ?? 0);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(opts.vol, t + (opts.attack ?? 0.008));
    g.gain.exponentialRampToValueAtTime(0.0001, t + opts.dur);
    g.connect(this.master);
    if (opts.type === "noise") {
      const src = this.ctx.createBufferSource();
      src.buffer = this.noise();
      src.loop = true;
      const f = this.ctx.createBiquadFilter();
      f.type = "bandpass";
      f.frequency.setValueAtTime(opts.freq ?? 800, t);
      if (opts.freqEnd) f.frequency.linearRampToValueAtTime(opts.freqEnd, t + opts.dur);
      f.Q.value = 1.1;
      src.connect(f); f.connect(g);
      src.start(t); src.stop(t + opts.dur + 0.05);
    } else {
      const o = this.ctx.createOscillator();
      o.type = opts.type;
      o.frequency.setValueAtTime(opts.freq ?? 220, t);
      if (opts.freqEnd) o.frequency.exponentialRampToValueAtTime(Math.max(20, opts.freqEnd), t + opts.dur);
      o.connect(g);
      o.start(t); o.stop(t + opts.dur + 0.05);
    }
  }

  private startWind() {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noise(); src.loop = true;
    const f = ctx.createBiquadFilter();
    f.type = "lowpass"; f.frequency.value = 380; f.Q.value = 0.6;
    this.windGain = ctx.createGain();
    this.windGain.gain.value = 0.028;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.13;
    const lfoG = ctx.createGain(); lfoG.gain.value = 0.015;
    lfo.connect(lfoG); lfoG.connect(this.windGain.gain);
    src.connect(f); f.connect(this.windGain); this.windGain.connect(this.master!);
    src.start(); lfo.start();
    // дождь
    const rain = ctx.createBufferSource();
    rain.buffer = this.noise(); rain.loop = true; rain.playbackRate.value = 1.31;
    const rf = ctx.createBiquadFilter();
    rf.type = "bandpass"; rf.frequency.value = 2600; rf.Q.value = 0.4;
    this.rainGain = ctx.createGain(); this.rainGain.gain.value = 0;
    rain.connect(rf); rf.connect(this.rainGain); this.rainGain.connect(this.master!);
    rain.start();
  }

  // ---- Постоянный фон: вызывается каждый кадр ----
  update(dt: number, p: SoundParams) {
    if (!this.ctx || !this.master) return;
    const now = this.ctx.currentTime;
    if (this.windGain) {
      const target = 0.02 + p.windAmt * 0.03 + (p.snow ? 0.02 : 0);
      this.windGain.gain.setTargetAtTime(target, now, 0.6);
    }
    if (this.rainGain) this.rainGain.gain.setTargetAtTime(p.rain * 0.05, now, 0.8);
    // птицы днём
    this.birdT -= dt;
    if (!p.night && p.rain < 0.4 && this.birdT <= 0) {
      this.birdT = 4 + Math.random() * 9;
      const base = 2200 + Math.random() * 1400;
      for (let i = 0; i < 2 + Math.random() * 3; i++) {
        this.burst({ type: "sine", freq: base + Math.random() * 500, freqEnd: base - 300 - Math.random() * 400, dur: 0.09 + Math.random() * 0.08, vol: 0.028, when: i * (0.11 + Math.random() * 0.07) });
      }
    }
    // сверчки ночью
    this.cricketT -= dt;
    if (p.night && this.cricketT <= 0) {
      this.cricketT = 1.2 + Math.random() * 2.5;
      for (let i = 0; i < 3; i++) {
        this.burst({ type: "sine", freq: 4200 + Math.random() * 300, dur: 0.04, vol: 0.012, when: i * 0.09 });
      }
    }
    // потрескивание костра
    this.crackleT -= dt;
    if (p.nearFire && this.crackleT <= 0) {
      this.crackleT = 0.12 + Math.random() * 0.5;
      this.burst({ type: "noise", freq: 900 + Math.random() * 2400, dur: 0.03 + Math.random() * 0.04, vol: 0.02 + Math.random() * 0.02 });
    }
    // музыка: редкая, тема под настроение
    if (p.mood && p.mood !== this.mood) {
      this.pendingMood = p.mood;
      // важные перемены (война, победа) обрывают тишину
      if ((p.mood === "war" || p.mood === "victory") && !this.musicPlaying) {
        this.mood = p.mood; this.pendingMood = null;
        this.playMusic();
      }
    }
    if (!this.musicPlaying && performance.now() / 1000 - this.lastMusic > 300 + Math.random() * 280) {
      if (this.pendingMood) { this.mood = this.pendingMood; this.pendingMood = null; }
      this.playMusic();
    }
    if (this.musicPlaying && performance.now() / 1000 > this.musicEnd) {
      this.musicPlaying = false;
      this.lastMusic = performance.now() / 1000;
    }
  }

  playMusic(mood?: MusicMood) {
    if (mood) this.mood = mood;
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    this.musicPlaying = true;
    this.musicEnd = performance.now() / 1000 + 75;
    this.musicGain = ctx.createGain();
    this.musicGain.gain.value = 0;
    this.musicGain.gain.linearRampToValueAtTime(this.mood === "victory" ? 0.1 : 0.075, ctx.currentTime + 6);
    this.musicGain.gain.setValueAtTime(0.075, ctx.currentTime + 62);
    this.musicGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 75);
    const flt = ctx.createBiquadFilter();
    flt.type = "lowpass";
    flt.frequency.value = this.mood === "war" ? 1400 : this.mood === "victory" ? 1800 : this.mood === "space" ? 2200 : 900;
    this.musicGain.connect(flt); flt.connect(this.master);
    // лады под настроение
    const SCALES: Record<MusicMood, number[]> = {
      calm: [220, 246.94, 261.63, 293.66, 329.63, 369.99, 392],        // дорийский — покой
      night: [220, 233.08, 261.63, 293.66, 311.13, 349.23, 392],       // фригийский — тревога ночи
      war: [220, 233.08, 277.18, 293.66, 311.13, 349.23, 415.30],      // локрийский оттенок — война
      victory: [261.63, 293.66, 329.63, 349.23, 392, 440, 493.88],     // ионийский — торжество
      deep: [174.61, 196, 207.65, 233.08, 261.63, 277.18, 311.13],     // низкий, гулкий
      space: [261.63, 311.13, 349.23, 392, 466.16, 523.25, 587.33],    // открытый, парящий
    };
    const scale = SCALES[this.mood] ?? SCALES.calm;
    const chords = this.mood === "victory"
      ? [[0, 2, 4], [3, 5, 0], [4, 6, 1], [0, 2, 4], [5, 0, 2], [0, 2, 4], [3, 5, 0], [0, 2, 4]]
      : this.mood === "war"
        ? [[0, 2, 4], [1, 3, 5], [0, 2, 4], [4, 6, 1], [2, 4, 6], [0, 2, 4], [5, 0, 2], [1, 3, 5]]
        : [[0, 2, 4], [3, 5, 0], [1, 3, 5], [4, 6, 1], [0, 2, 4], [5, 0, 2], [3, 5, 0], [2, 4, 6]];
    let t = ctx.currentTime + 0.5;
    for (let i = 0; i < chords.length; i++) {
      for (const idx of chords[i]) {
        for (const det of [-2.5, 2.5]) {
          const o = ctx.createOscillator();
          o.type = this.mood === "war" ? "sawtooth" : this.mood === "space" ? "sine" : "triangle";
          o.frequency.value = scale[idx % scale.length] * (this.mood === "deep" ? 0.4 : 0.5);
          o.detune.value = det;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0, t);
          g.gain.linearRampToValueAtTime(0.3, t + 3.4);
          g.gain.linearRampToValueAtTime(0, t + 9.2);
          o.connect(g); g.connect(this.musicGain);
          o.start(t); o.stop(t + 9.4);
        }
      }
      t += 8.9;
    }
  }

  // ---- Эффекты ----
  step() {
    const now = performance.now();
    if (now - this.lastStep < 340) return;
    this.lastStep = now;
    this.burst({ type: "noise", freq: 300 + Math.random() * 150, dur: 0.055, vol: 0.022 });
  }
  chop() {
    this.burst({ type: "noise", freq: 1500, freqEnd: 400, dur: 0.09, vol: 0.1 });
    this.burst({ type: "triangle", freq: 190, freqEnd: 90, dur: 0.12, vol: 0.12 });
  }
  mine() {
    this.burst({ type: "noise", freq: 3400, freqEnd: 1500, dur: 0.07, vol: 0.1 });
    this.burst({ type: "square", freq: 620 + Math.random() * 300, freqEnd: 300, dur: 0.06, vol: 0.05 });
  }
  dig() { this.burst({ type: "noise", freq: 500, freqEnd: 180, dur: 0.14, vol: 0.09 }); }
  hit() {
    this.burst({ type: "triangle", freq: 160, freqEnd: 70, dur: 0.13, vol: 0.14 });
    this.burst({ type: "noise", freq: 900, freqEnd: 300, dur: 0.08, vol: 0.07 });
  }
  crit() {
    this.hit();
    this.burst({ type: "sine", freq: 880, freqEnd: 440, dur: 0.16, vol: 0.08, when: 0.02 });
  }
  hurt() { this.burst({ type: "sawtooth", freq: 130, freqEnd: 60, dur: 0.2, vol: 0.1 }); }
  /** «тук» — глухой упор в ствол дерева */
  thud() {
    const now = performance.now();
    if (now - this.lastThud < 240) return;
    this.lastThud = now;
    this.burst({ type: "triangle", freq: 115, freqEnd: 55, dur: 0.07, vol: 0.1 });
    this.burst({ type: "noise", freq: 620, freqEnd: 260, dur: 0.04, vol: 0.04 });
  }
  mobDie() { this.burst({ type: "sawtooth", freq: 200, freqEnd: 40, dur: 0.35, vol: 0.09 }); }
  pickup() { this.burst({ type: "sine", freq: 660, freqEnd: 990, dur: 0.1, vol: 0.06 }); }
  eat() {
    this.burst({ type: "noise", freq: 700, dur: 0.07, vol: 0.05 });
    this.burst({ type: "noise", freq: 550, dur: 0.07, vol: 0.05, when: 0.12 });
  }
  drink() {
    this.burst({ type: "sine", freq: 340, freqEnd: 520, dur: 0.12, vol: 0.05 });
    this.burst({ type: "sine", freq: 420, freqEnd: 640, dur: 0.1, vol: 0.04, when: 0.11 });
  }
  craft() { this.burst({ type: "triangle", freq: 440, freqEnd: 660, dur: 0.14, vol: 0.07 }); this.burst({ type: "triangle", freq: 660, freqEnd: 880, dur: 0.12, vol: 0.05, when: 0.1 }); }
  buildHammer() { this.burst({ type: "triangle", freq: 240, freqEnd: 120, dur: 0.1, vol: 0.12 }); this.burst({ type: "noise", freq: 1200, dur: 0.05, vol: 0.05 }); }
  place() { this.burst({ type: "triangle", freq: 300, freqEnd: 180, dur: 0.12, vol: 0.1 }); }
  levelup() {
    [523, 659, 784, 1047].forEach((f, i) => this.burst({ type: "sine", freq: f, dur: 0.3, vol: 0.07, when: i * 0.09 }));
  }
  ui() { this.burst({ type: "sine", freq: 740, dur: 0.045, vol: 0.035 }); }
  uiOpen() { this.burst({ type: "sine", freq: 520, freqEnd: 780, dur: 0.09, vol: 0.045 }); }
  splash() { this.burst({ type: "noise", freq: 1100, freqEnd: 500, dur: 0.18, vol: 0.08 }); }
  thunder() { this.burst({ type: "noise", freq: 200, freqEnd: 40, dur: 1.6, vol: 0.14, attack: 0.06 }); }
  monster() { this.burst({ type: "sawtooth", freq: 90, freqEnd: 55, dur: 0.45, vol: 0.07 }); }
  sleep() { [392, 330, 262].forEach((f, i) => this.burst({ type: "sine", freq: f, dur: 0.4, vol: 0.05, when: i * 0.22 })); }
  death() { this.burst({ type: "sawtooth", freq: 180, freqEnd: 30, dur: 1.2, vol: 0.12 }); }
  chest() {
    this.burst({ type: "triangle", freq: 330, freqEnd: 500, dur: 0.15, vol: 0.08 });
    this.burst({ type: "sine", freq: 990, dur: 0.25, vol: 0.05, when: 0.12 });
  }
  explosion() {
    this.burst({ type: "noise", freq: 400, freqEnd: 60, dur: 0.7, vol: 0.22 });
    this.burst({ type: "sine", freq: 120, freqEnd: 30, dur: 0.8, vol: 0.2 });
  }
  fireball() { this.burst({ type: "noise", freq: 2000, freqEnd: 700, dur: 0.3, vol: 0.1 }); }
}

export const snd = new SoundEngine();
