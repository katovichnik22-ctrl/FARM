import { useEffect, useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";

export function useEngineSnap(engine: Engine | null): UiSnapshot | null {
  const [snap, setSnap] = useState<UiSnapshot | null>(null);
  useEffect(() => {
    if (!engine) { setSnap(null); return; }
    const f = () => setSnap(engine.ui());
    f();
    return engine.subscribe(f);
  }, [engine]);
  return snap;
}
