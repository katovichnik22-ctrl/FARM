import type { SaveData, SlotMeta } from "../types";

// ===== Сохранения: localStorage + зеркало в IndexedDB, 3 слота =====

const PREFIX = "tihoe-plamya";
const key = (slot: number) => `${PREFIX}:slot${slot}`;
const MUTE_KEY = `${PREFIX}:muted`;

export function saveSlot(data: SaveData): boolean {
  try {
    const json = JSON.stringify(data);
    localStorage.setItem(key(data.slot), json);
    idbPut(data.slot, json);
    return true;
  } catch { return false; }
}

export function loadSlotSync(slot: number): SaveData | null {
  try {
    const s = localStorage.getItem(key(slot));
    if (!s) return null;
    const d = JSON.parse(s) as SaveData;
    if (!d || d.version !== 1) return null;
    return d;
  } catch { return null; }
}

export function slotMetas(): (SlotMeta | null)[] {
  const out: (SlotMeta | null)[] = [];
  for (let i = 1; i <= 3; i++) {
    const d = loadSlotSync(i);
    out.push(d ? { slot: i, name: d.meta.name, day: d.day, level: d.player.level, ts: d.meta.savedAt, seed: d.seed } : null);
  }
  return out;
}

export function deleteSlot(slot: number) {
  localStorage.removeItem(key(slot));
  idbDel(slot);
}

// ---- IndexedDB (зеркало / резерв) ----
function idb(): Promise<IDBDatabase | null> {
  return new Promise((res) => {
    try {
      const req = indexedDB.open("tihoe-plamya", 1);
      req.onupgradeneeded = () => req.result.createObjectStore("saves");
      req.onsuccess = () => res(req.result);
      req.onerror = () => res(null);
    } catch { res(null); }
  });
}
async function idbPut(slot: number, json: string) {
  const db = await idb();
  if (!db) return;
  try { db.transaction("saves", "readwrite").objectStore("saves").put(json, slot); } catch { /* ок */ }
}
async function idbDel(slot: number) {
  const db = await idb();
  if (!db) return;
  try { db.transaction("saves", "readwrite").objectStore("saves").delete(slot); } catch { /* ок */ }
}
export async function loadSlotAsync(slot: number): Promise<SaveData | null> {
  const sync = loadSlotSync(slot);
  if (sync) return sync;
  const db = await idb();
  if (!db) return null;
  return new Promise((res) => {
    try {
      const req = db.transaction("saves").objectStore("saves").get(slot);
      req.onsuccess = () => {
        try {
          const d = JSON.parse(req.result as string) as SaveData;
          res(d && d.version === 1 ? d : null);
        } catch { res(null); }
      };
      req.onerror = () => res(null);
    } catch { res(null); }
  });
}

// ---- Экспорт / импорт ----
export function exportSave(data: SaveData) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `tihoe-plamya_slot${data.slot}_day${data.day}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

export function importSave(file: File): Promise<SaveData> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(String(r.result)) as SaveData;
        if (!d || d.version !== 1 || !d.player) throw new Error("bad");
        res(d);
      } catch { rej(new Error("Файл не похож на сохранение «Тихого Пламени»")); }
    };
    r.onerror = () => rej(new Error("Не удалось прочитать файл"));
    r.readAsText(file);
  });
}

export function getMuted(): boolean { return localStorage.getItem(MUTE_KEY) === "1"; }
export function setMutedFlag(m: boolean) { localStorage.setItem(MUTE_KEY, m ? "1" : "0"); }
