import type { CSSProperties } from "react";
import {
  Logs, Wand, AlignJustify, Mountain, Flame, Zap, Layers, Waves, Snowflake,
  Shield, Bone, Cable, Feather, Gem, Inbox, Coins, Shell, Beef, Cherry,
  Shapes, Drumstick, FlameKindling, CookingPot, Candy, Cross, Milk,
  GlassWater, Droplets, Axe, Pickaxe, Shovel, Sword, Swords, HardHat,
  Shirt, Scissors, Footprints, VenetianMask, Crown, ShieldHalf, Tent,
  Home, Lamp, Hammer, Sprout, Droplet, Fence, BrickWall, DoorOpen,
  TowerControl, Slice, HelpCircle, Landmark, Route, Castle, Scale,
  Warehouse, Sparkle, Building, Building2, Armchair, Beer, Factory,
  Wheat, Fan, UtensilsCrossed, Anchor, Target, Crosshair, BookOpen,
  GraduationCap, FlaskConical, Telescope, School, Sparkles, CircleDot,
  Store, TrendingUp, Ship, Church, Drama, PawPrint, Trees, Wrench,
  Package, PartyPopper, TrendingDown, Moon, Ban, Users, Gift, Handshake,
  ShieldCheck, ScrollText, Eye, Bomb, BookLock, HandCoins, Rabbit,
  PersonStanding, Lightbulb, Library, Clock, Infinity, Cpu, Rocket,
  Palette, Music, Globe2, Gavel, HeartPulse, Wind, Sun, Skull, Baby,
  type LucideIcon,
} from "lucide-react";

const MAP: Record<string, LucideIcon> = {
  Log: Logs, Wand, AlignJustify, Mountain, Flame, Zap, Layers, Waves, Snowflake,
  Shield, Bone, Cable, Feather, Gem, Inbox, Coins, Shell, Beef, Cherry,
  Shapes, Drumstick, FlameKindling, CookingPot, Candy, Cross, Milk,
  GlassWater, Droplets, Axe, Pickaxe, Shovel, Sword, Swords, HardHat,
  Shirt, Scissors, Footprints, VenetianMask, Crown, ShieldHalf, Tent,
  Home, Candle: Lamp, Hammer, Sprout, Droplet, Fence, BrickWall, DoorOpen,
  TowerControl, Saw: Slice, Slice, Landmark, Route, Castle, Scale,
  Warehouse, Sparkle, Building, Building2, Armchair, Beer, Factory,
  Wheat, Fan, UtensilsCrossed, Anchor, Target, Crosshair, BookOpen,
  GraduationCap, FlaskConical, Telescope, School, Sparkles, CircleDot,
  Store, TrendingUp, Ship, Church, Drama, PawPrint, Trees, Wrench,
  Package, PartyPopper, TrendingDown, Moon, Ban, Users, Gift, Handshake,
  ShieldCheck, ScrollText, Eye, Bomb, BookLock, HandCoins, Rabbit,
  PersonStanding, Lightbulb, Library, Clock, Infinity, Cpu, Rocket,
  Palette, Music, Globe2, Gavel, HeartPulse, Wind, Sun, Skull, Baby,
};

export function ItemIcon({ icon, size = 22, className, style }: {
  icon: string; size?: number; className?: string; style?: CSSProperties;
}) {
  const I = MAP[icon] ?? HelpCircle;
  return <I size={size} className={className} style={style} strokeWidth={1.8} />;
}
