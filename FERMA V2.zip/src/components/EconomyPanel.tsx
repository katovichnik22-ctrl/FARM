import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row, Spark } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { GOODS, GOOD_CATS } from "../data/citydata";
import { ITEMS } from "../data/items";
import { BUILDINGS } from "../data/buildings";
import { ROUTE_NAMES } from "../game/economy";
import type { RouteKind } from "../types";
import {
  TrendingUp, TrendingDown, Landmark, Ship, Truck, Train, ArrowRight,
  Banknote, PiggyBank, HandCoins, Sparkles, AlertTriangle,
} from "lucide-react";

const TABS = ["Биржа", "Банк", "Цепочки", "Пути"];

export function EconomyPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const [tab, setTab] = useState("Биржа");
  const [cat, setCat] = useState("Всё");
  const [amount, setAmount] = useState(10);
  const [bankAmt, setBankAmt] = useState(100);
  const [routeTown, setRouteTown] = useState<string>(engine.economy.towns[0]?.id ?? "");
  const [routeGood, setRouteGood] = useState("doska");
  const [routeKind, setRouteKind] = useState<RouteKind>("caravan");
  const [routeN, setRouteN] = useState(10);
  const [fromCity, setFromCity] = useState(true);
  const ec = engine.economy;

  const list = GOODS.filter((g) => cat === "Всё" || g.cat === cat);

  return (
    <Sheet
      title="Торговая палата"
      sub={`Казна ${engine.player.gold} зол. · вклад ${Math.floor(ec.bank.deposit)} · долгов ${ec.bank.loans.reduce((a, l) => a + l.left, 0)}`}
      onClose={onClose}
    >
      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "60vh" }}>

        {tab === "Биржа" && (
          <div className="space-y-1.5">
            <div className="flex gap-1 overflow-x-auto pb-1" style={{ touchAction: "pan-x" }}>
              {GOOD_CATS.map((c) => (
                <button key={c} onClick={() => setCat(c)}
                  className={`shrink-0 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${cat === c ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-white/50"}`}>
                  {c}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1.5 rounded-xl border border-white/8 bg-black/25 px-2 py-1.5">
              <span className="text-[11px] font-bold uppercase text-white/45">Объём</span>
              {[1, 5, 10, 50].map((n) => (
                <button key={n} onClick={() => setAmount(n)}
                  className={`flex-1 rounded-lg border py-1 text-[12px] font-bold ${amount === n ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 text-white/50"}`}>
                  {n}
                </button>
              ))}
            </div>
            {list.map((g) => {
              const m = ec.market[g.id];
              if (!m) return null;
              const up = m.trend >= 0;
              const have = engine.count(g.id);
              const cityHave = engine.city.stockOf(g.id);
              return (
                <div key={g.id} className="rounded-xl border border-white/8 bg-black/25 p-2">
                  <div className="flex items-center gap-2">
                    <ItemIcon icon={ITEMS[g.id]?.icon ?? "Package"} size={18} className="shrink-0 text-amber-200" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[13px] font-bold text-amber-50">{g.name}</div>
                      <div className="text-[10px] text-white/40">у вас {have}{cityHave > 0 ? ` · склад ${cityHave}` : ""}</div>
                    </div>
                    <div className="w-14 shrink-0"><Spark data={m.hist} color={up ? "#7ae68a" : "#e05a5a"} h={22} /></div>
                    <div className="w-16 shrink-0 text-right">
                      <div className="font-display text-[15px] font-bold text-amber-200">{m.price.toFixed(1)}</div>
                      <div className={`flex items-center justify-end gap-0.5 text-[10px] font-bold ${up ? "text-emerald-400" : "text-rose-400"}`}>
                        {up ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                        {Math.abs((m.price / g.base - 1) * 100).toFixed(0)}%
                      </div>
                    </div>
                  </div>
                  <div className="mt-1.5 flex gap-1.5">
                    <button className="btn flex-1 !py-1.5 text-[11.5px]" onClick={() => ec.buy(engine, g.id, amount)}>
                      Купить {Math.ceil(m.price * amount * 1.04)}
                    </button>
                    <button className="btn-ghost flex-1 !py-1.5 text-[11.5px]" disabled={have < 1} onClick={() => ec.sell(engine, g.id, amount)}>
                      Продать {Math.floor(m.price * Math.min(amount, have) * 0.96)}
                    </button>
                    {cityHave > 0 && (
                      <button className="btn-ghost !px-2 !py-1.5 text-[11px]" title="Продать со склада города"
                        onClick={() => ec.sell(engine, g.id, amount, true)}>
                        склад
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Банк" && (
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 rounded-xl border border-white/8 bg-black/25 px-2 py-1.5">
              <span className="text-[11px] font-bold uppercase text-white/45">Сумма</span>
              {[50, 100, 500, 2000].map((n) => (
                <button key={n} onClick={() => setBankAmt(n)}
                  className={`flex-1 rounded-lg border py-1 text-[11.5px] font-bold ${bankAmt === n ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 text-white/50"}`}>
                  {n}
                </button>
              ))}
            </div>

            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[12px] font-bold text-amber-100"><PiggyBank size={14} /> Вклад</div>
              <Row k="На счету" v={`${Math.floor(ec.bank.deposit)} зол.`} color="#7ae68a" />
              <Row k="Ставка" v={`${ec.bank.depRate.toFixed(1)}% в день`} />
              <div className="mt-1.5 flex gap-1.5">
                <button className="btn flex-1 !py-2 text-[12px]" onClick={() => ec.deposit(engine, bankAmt)}>Внести</button>
                <button className="btn-ghost flex-1 !py-2 text-[12px]" onClick={() => ec.withdraw(engine, bankAmt)}>Снять</button>
              </div>
            </div>

            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[12px] font-bold text-amber-100"><HandCoins size={14} /> Ссуды</div>
              <Row k="Кредит доверия" v={`${Math.round(ec.bank.credit)}/100`} color={ec.bank.credit > 55 ? "#7ae68a" : "#f2b45c"} />
              <Row k="Доступно" v={`${ec.maxLoan(engine)} зол.`} />
              {ec.bank.loans.map((l) => (
                <div key={l.id} className="mt-1 flex items-center gap-2 rounded-lg border border-amber-400/20 bg-black/30 p-1.5">
                  <AlertTriangle size={13} className="shrink-0 text-amber-300" />
                  <span className="flex-1 text-[11.5px] text-white/65">Долг {l.left} зол. до дня {l.dueDay}</span>
                  <button className="btn !px-2 !py-1 text-[11px]" onClick={() => ec.repay(engine, l.id)}>Погасить</button>
                </div>
              ))}
              <button className="btn mt-1.5 w-full !py-2 text-[12px]" onClick={() => ec.takeLoan(engine, bankAmt)}>
                <Banknote size={14} /> Взять ссуду {bankAmt}
              </button>
            </div>

            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[12px] font-bold text-amber-100"><Sparkles size={14} /> Вложения</div>
              <Row k="В деле" v={`${ec.bank.invested} зол.`} color="#c98ae0" />
              {ec.bank.invested > 0 && <Row k="Итог на день" v={ec.bank.investDay} />}
              <button className="btn mt-1.5 w-full !py-2 text-[12px]" disabled={ec.bank.invested > 0} onClick={() => ec.invest(engine, bankAmt)}>
                Вложить {bankAmt} на 5 дней
              </button>
              <p className="mt-1 text-[10.5px] leading-snug text-white/35">Риск и удача: вернётся от 65% до 180%. Торговый район повышает шанс.</p>
            </div>
          </div>
        )}

        {tab === "Цепочки" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11.5px] leading-snug text-white/45">
              Сырьё → передел → товар. Мастерские берут сырьё с городского склада и кладут туда готовое.
            </p>
            {Object.values(BUILDINGS).filter((d) => d.chain).map((d) => {
              const built = engine.buildings.filter((b) => b.done && b.def === d.id);
              const lvlSum = built.reduce((a, b) => a + (b.lvl ?? 1), 0);
              return (
                <div key={d.id} className={`rounded-xl border p-2 ${built.length ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-70"}`}>
                  <div className="flex items-center gap-2">
                    <ItemIcon icon={d.icon} size={17} className="text-amber-200" />
                    <span className="flex-1 truncate text-[13px] font-bold text-amber-50">{d.name}</span>
                    <span className="text-[10.5px] font-bold text-white/45">{built.length ? `×${built.length} (ур. ${lvlSum})` : "не построено"}</span>
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-1 text-[11px]">
                    {d.chain!.in.map(([id, n]) => (
                      <span key={id} className={engine.city.stockOf(id) >= n ? "text-emerald-300" : "text-rose-300/80"}>
                        {ITEMS[id]?.name ?? id} ×{n}
                      </span>
                    ))}
                    <ArrowRight size={12} className="text-white/35" />
                    <span className="font-bold text-amber-200">{ITEMS[d.chain!.out[0]]?.name} ×{d.chain!.out[1]}</span>
                    <span className="text-white/35">/ {d.chain!.every}с</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Пути" && (
          <div className="space-y-2">
            {ec.routes.length > 0 && (
              <div className="rounded-xl border border-emerald-400/25 bg-emerald-400/8 p-2">
                <div className="mb-1 text-[11px] font-bold uppercase tracking-wide text-emerald-200/80">В дороге</div>
                {ec.routes.map((r) => {
                  const t = ec.towns.find((x) => x.id === r.town);
                  const frac = Math.min(1, r.progress / r.dur);
                  return (
                    <div key={r.id} className="mb-1 last:mb-0">
                      <div className="flex justify-between text-[11.5px]">
                        <span className="text-amber-50">{ROUTE_NAMES[r.kind]} → {t?.name}</span>
                        <span className="font-bold text-emerald-300">+{r.profit}</span>
                      </div>
                      <div className="bar-track !h-1.5"><div className="bar-fill" style={{ width: `${frac * 100}%`, background: "#7ae68a" }} /></div>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">Снарядить обоз</div>
              <div className="mb-1.5 flex gap-1">
                {(["caravan", "ship", "train"] as RouteKind[]).map((k) => (
                  <button key={k} onClick={() => setRouteKind(k)}
                    className={`flex flex-1 items-center justify-center gap-1 rounded-lg border py-1.5 text-[11px] font-bold ${routeKind === k ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 text-white/50"}`}>
                    {k === "caravan" ? <Truck size={12} /> : k === "ship" ? <Ship size={12} /> : <Train size={12} />}
                    {ROUTE_NAMES[k].split("-")[0]}
                  </button>
                ))}
              </div>
              <select value={routeTown} onChange={(e) => setRouteTown(e.target.value)}
                className="mb-1.5 w-full rounded-lg border border-white/10 bg-black/50 px-2 py-2 text-[12.5px] text-amber-50 outline-none">
                {ec.towns.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} · {t.dist} вёрст · отн. {Math.round(t.relation)}{t.embargo ? " · ЭМБАРГО" : ""} · берут {ITEMS[t.wants]?.name}
                  </option>
                ))}
              </select>
              <div className="mb-1.5 flex gap-1.5">
                <select value={routeGood} onChange={(e) => setRouteGood(e.target.value)}
                  className="flex-1 rounded-lg border border-white/10 bg-black/50 px-2 py-2 text-[12.5px] text-amber-50 outline-none">
                  {GOODS.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
                <input type="number" min={1} max={160} value={routeN} onChange={(e) => setRouteN(Math.max(1, Number(e.target.value)))}
                  className="w-20 rounded-lg border border-white/10 bg-black/50 px-2 py-2 text-center text-[12.5px] text-amber-50 outline-none" />
              </div>
              <div className="mb-1.5 flex gap-1">
                <button onClick={() => setFromCity(true)} className={`flex-1 rounded-lg border py-1 text-[11px] font-bold ${fromCity ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 text-white/50"}`}>
                  Со склада ({engine.city.stockOf(routeGood)})
                </button>
                <button onClick={() => setFromCity(false)} className={`flex-1 rounded-lg border py-1 text-[11px] font-bold ${!fromCity ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 text-white/50"}`}>
                  Из сумки ({engine.count(routeGood)})
                </button>
              </div>
              <button className="btn w-full !py-2.5 text-[12.5px]" onClick={() => ec.startRoute(engine, routeTown, routeGood, routeN, routeKind, fromCity)}>
                <Truck size={15} /> Отправить
              </button>
            </div>

            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                <Landmark size={12} /> Соседи
              </div>
              {ec.towns.map((t) => (
                <Row key={t.id} k={`${t.name}${t.embargo ? " (эмбарго)" : ""}`}
                  v={`${Math.round(t.relation)}% · везут ${ITEMS[t.gives]?.name}`}
                  color={t.embargo ? "#e05a5a" : t.relation > 60 ? "#7ae68a" : "#f2b45c"} />
              ))}
              <p className="mt-1 text-[10.5px] leading-snug text-white/35">
                Чужие обозы иногда проходят рядом — их можно ограбить, но соседи этого не простят.
              </p>
            </div>
          </div>
        )}
      </div>
      <div className="mt-2 flex items-center justify-between rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5 text-[11.5px]">
        <span className="text-white/45">Казна</span>
        <span className="font-display text-[15px] font-bold text-amber-200">{engine.player.gold} зол.</span>
      </div>
      <div className="hidden">{snap.uiTick}</div>
    </Sheet>
  );
}
