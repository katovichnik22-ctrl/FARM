import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { ITEMS } from "../data/items";
import type { EquipSlot } from "../types";
import { ItemIcon } from "./ItemIcon";
import { X, Trash2, Hand, UtensilsCrossed } from "lucide-react";

const SLOT_META: { slot: EquipSlot; label: string; icon: string }[] = [
  { slot: "head", label: "Голова", icon: "HardHat" },
  { slot: "body", label: "Тело", icon: "Shirt" },
  { slot: "legs", label: "Ноги", icon: "Scissors" },
  { slot: "feet", label: "Ступни", icon: "Footprints" },
  { slot: "weapon", label: "Оружие", icon: "Sword" },
];

export function Inventory({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const [sel, setSel] = useState<number | null>(null);
  const selItem = sel !== null ? snap.inv[sel] : null;
  const selDef = selItem ? ITEMS[selItem.id] : null;
  const equipped = selItem ? Object.values(snap.equip).includes(selItem.id) : false;

  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" />
      <div
        className="glass relative mb-0 flex max-h-[78vh] w-full max-w-md flex-col rounded-b-none p-3 safe-bottom"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-amber-100">Сумка путника</h2>
          <button className="btn-ghost !p-2" onClick={onClose}><X size={17} /></button>
        </div>

        {/* Экипировка */}
        <div className="mb-2 grid grid-cols-5 gap-1.5">
          {SLOT_META.map((sm) => {
            const id = snap.equip[sm.slot];
            return (
              <button
                key={sm.slot}
                className={`item-cell !aspect-auto flex-col gap-0.5 py-1.5 ${id ? "border-amber-400/40" : "opacity-70"}`}
                onClick={() => id && engine.unequip(sm.slot)}
                title={id ? "Снять" : sm.label}
              >
                <ItemIcon icon={id ? ITEMS[id].icon : sm.icon} size={19} className={id ? "text-amber-200" : "text-white/30"} />
                <span className="text-[8px] font-bold text-white/45">{sm.label}</span>
              </button>
            );
          })}
        </div>

        {/* Сетка */}
        <div className="scroll-area grid flex-1 grid-cols-6 content-start gap-1.5">
          {snap.inv.map((s, i) => {
            const def = ITEMS[s.id];
            if (!def) return null;
            const isEq = Object.values(snap.equip).includes(s.id);
            return (
              <button
                key={`${s.id}_${i}`}
                className={`item-cell ${sel === i ? "selected" : ""}`}
                onClick={() => setSel(sel === i ? null : i)}
              >
                <ItemIcon icon={def.icon} size={21} className={isEq ? "text-amber-300" : "text-amber-50/85"} />
                <span className="absolute bottom-0.5 right-1 text-[10px] font-bold text-white/80" style={{ textShadow: "0 1px 2px #000" }}>{s.n > 1 ? s.n : ""}</span>
                {isEq && <span className="absolute left-0.5 top-0.5 h-1.5 w-1.5 rounded-full bg-amber-400" />}
              </button>
            );
          })}
          {snap.inv.length === 0 && (
            <div className="col-span-6 py-6 text-center text-sm text-white/40">Сумка пуста. Добывайте ресурсы!</div>
          )}
        </div>

        {/* Действия с выбранным */}
        {selItem && selDef && (
          <div className="mt-2 rounded-xl border border-amber-400/20 bg-black/30 p-2.5">
            <div className="flex items-start gap-2.5">
              <div className="item-cell !h-12 !w-12 shrink-0"><ItemIcon icon={selDef.icon} size={24} /></div>
              <div className="min-w-0 flex-1">
                <div className="font-display text-[15px] font-bold text-amber-50">{selDef.name} <span className="text-white/40">×{selItem.n}</span></div>
                <div className="text-[12px] leading-snug text-white/55">{selDef.desc}</div>
                <div className="mt-0.5 flex flex-wrap gap-1 text-[10px] font-semibold text-white/60">
                  {selDef.food ? <span className="rounded bg-orange-400/15 px-1.5 py-0.5 text-orange-200">+{selDef.food} сытость</span> : null}
                  {selDef.drink ? <span className="rounded bg-sky-400/15 px-1.5 py-0.5 text-sky-200">+{selDef.drink} вода</span> : null}
                  {selDef.heal ? <span className="rounded bg-emerald-400/15 px-1.5 py-0.5 text-emerald-200">+{selDef.heal} HP</span> : null}
                  {selDef.dmg ? <span className="rounded bg-rose-400/15 px-1.5 py-0.5 text-rose-200">урон {selDef.dmg}</span> : null}
                  {selDef.armor ? <span className="rounded bg-indigo-400/15 px-1.5 py-0.5 text-indigo-200">броня {selDef.armor}</span> : null}
                  {selDef.warmth ? <span className="rounded bg-amber-400/15 px-1.5 py-0.5 text-amber-200">тепло +{selDef.warmth}</span> : null}
                  {selDef.poisonChance ? <span className="rounded bg-lime-400/15 px-1.5 py-0.5 text-lime-300">риск отравления</span> : null}
                </div>
              </div>
            </div>
            <div className="mt-2 flex gap-1.5">
              {(selDef.food || selDef.drink || selDef.heal) && (
                <button className="btn flex-1 !py-2 text-[13px]" onClick={() => { engine.useItem(sel!); setSel(null); }}>
                  <UtensilsCrossed size={15} /> Использовать
                </button>
              )}
              {(selDef.type === "equip" || selDef.type === "weapon" || selDef.type === "tool") && !equipped && (
                <button className="btn flex-1 !py-2 text-[13px]" onClick={() => { engine.equipItem(sel!); setSel(null); }}>
                  <Hand size={15} /> {selDef.slot ? "Надеть" : "В руки"}
                </button>
              )}
              {selDef.type === "place" && (
                <button className="btn flex-1 !py-2 text-[13px]" onClick={() => { engine.useItem(sel!); setSel(null); onClose(); }}>
                  <Hand size={15} /> Поставить
                </button>
              )}
              <button className="btn-ghost !py-2 text-[13px]" onClick={() => { engine.dropItem(sel!); setSel(null); }}>
                <Trash2 size={15} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
