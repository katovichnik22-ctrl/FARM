import type { ReactNode } from "react";
import { X } from "lucide-react";
import { snd } from "../lib/sound";

/** Нижний «стеклянный» лист-модал */
export function Sheet({ title, sub, onClose, children, footer }: {
  title: string; sub?: string; onClose: () => void; children: ReactNode; footer?: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" />
      <div
        className="glass relative flex max-h-[86vh] w-full max-w-md flex-col rounded-b-none p-3 safe-bottom"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-2 flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h2 className="font-display truncate text-lg font-bold text-amber-100">{title}</h2>
            {sub && <p className="truncate text-[11px] text-white/45">{sub}</p>}
          </div>
          <button className="btn-ghost !p-2" onClick={onClose}><X size={17} /></button>
        </div>
        {children}
        {footer}
      </div>
    </div>
  );
}

export function Tabs({ tabs, active, onPick }: { tabs: string[]; active: string; onPick: (t: string) => void }) {
  return (
    <div className="mb-2 flex gap-1 overflow-x-auto pb-1" style={{ touchAction: "pan-x" }}>
      {tabs.map((t) => (
        <button
          key={t}
          className={`shrink-0 rounded-full border px-3 py-1.5 text-[12px] font-semibold transition ${active === t ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-white/55"}`}
          onClick={() => { snd.ui(); onPick(t); }}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

/** Метрика с полоской */
export function Stat({ label, value, max = 100, color, suffix = "", hint }: {
  label: string; value: number; max?: number; color: string; suffix?: string; hint?: string;
}) {
  const frac = Math.max(0, Math.min(1, value / max));
  return (
    <div className="rounded-xl border border-white/8 bg-black/25 p-2">
      <div className="flex items-baseline justify-between gap-1">
        <span className="truncate text-[10.5px] font-semibold uppercase tracking-wide text-white/45">{label}</span>
        <span className="text-[13px] font-bold" style={{ color }}>{Math.round(value)}{suffix}</span>
      </div>
      <div className="bar-track mt-1 !h-1.5">
        <div className="bar-fill" style={{ width: `${frac * 100}%`, background: color }} />
      </div>
      {hint && <div className="mt-0.5 truncate text-[9.5px] text-white/35">{hint}</div>}
    </div>
  );
}

/** Строка «ключ — значение» */
export function Row({ k, v, color }: { k: string; v: string | number; color?: string }) {
  return (
    <div className="flex items-center justify-between gap-2 border-b border-white/5 py-1 text-[12.5px] last:border-0">
      <span className="text-white/50">{k}</span>
      <span className="font-semibold" style={{ color: color ?? "#efe6d5" }}>{v}</span>
    </div>
  );
}

/** Ползунок с подписью */
export function Slider({ label, value, min, max, step = 1, suffix = "", onChange }: {
  label: string; value: number; min: number; max: number; step?: number; suffix?: string; onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between">
        <span className="text-[11px] font-bold uppercase tracking-wide text-white/45">{label}</span>
        <span className="font-display text-[15px] font-bold text-amber-200">{value}{suffix}</span>
      </div>
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-amber-400"
        style={{ touchAction: "pan-x" }}
      />
    </div>
  );
}

/** Простой график-спарклайн */
export function Spark({ data, color = "#fbbf24", h = 38 }: { data: number[]; color?: string; h?: number }) {
  if (data.length < 2) return <div className="py-3 text-center text-[11px] text-white/30">Данных пока мало</div>;
  const max = Math.max(...data), min = Math.min(...data);
  const rng = Math.max(0.001, max - min);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * 100},${h - ((v - min) / rng) * (h - 4) - 2}`).join(" ");
  return (
    <svg viewBox={`0 0 100 ${h}`} className="w-full" preserveAspectRatio="none" style={{ height: h }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.6" vectorEffect="non-scaling-stroke" />
      <polyline points={`0,${h} ${pts} 100,${h}`} fill={color} opacity="0.12" />
    </svg>
  );
}

export function happyColor(h: number) {
  return h > 70 ? "#7ae68a" : h > 50 ? "#a8e68a" : h > 35 ? "#f2b45c" : "#e05a5a";
}
