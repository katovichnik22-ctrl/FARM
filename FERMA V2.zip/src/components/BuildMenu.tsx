import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { BUILDINGS, BUILD_CATS } from "../data/buildings";
import { ITEMS } from "../data/items";
import { ItemIcon } from "./ItemIcon";
import { X, Check, Ban, Clock, Lock, Sparkle } from "lucide-react";
import { fmt } from "../lib/noise";

export function BuildMenu({ engine, onClose }: { engine: Engine; onClose: () => void }) {
  const [cat, setCat] = useState("Всё");
  const list = Object.values(BUILDINGS).filter((b) => cat === "Всё" || b.cat === cat);

  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" />
      <div
        className="glass relative flex max-h-[80vh] w-full max-w-md flex-col rounded-b-none p-3 safe-bottom"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-amber-100">Строительство</h2>
          <button className="btn-ghost !p-2" onClick={onClose}><X size={17} /></button>
        </div>

        <div className="mb-2 flex gap-1 overflow-x-auto pb-1" style={{ touchAction: "pan-x" }}>
          {BUILD_CATS.map((c) => (
            <button
              key={c}
              className={`shrink-0 rounded-full border px-3 py-1.5 text-[12px] font-semibold transition ${cat === c ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-white/55"}`}
              onClick={() => setCat(c)}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="scroll-area grid flex-1 grid-cols-2 content-start gap-1.5 overflow-y-auto">
          {list.map((b) => {
            const afford = b.cost.every(([id, n]) => engine.count(id) >= n);
            const locked = (b.needsCity && !engine.city.s.founded) ||
              (b.wonder && engine.buildings.some((x) => x.def === b.id)) ||
              (b.townhall && engine.buildings.some((x) => BUILDINGS[x.def]?.townhall));
            return (
              <button
                key={b.id}
                className={`flex flex-col gap-1 rounded-xl border p-2 text-left transition active:scale-[0.97] ${locked ? "border-white/8 bg-black/10 opacity-50" : afford ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-65"}`}
                onClick={() => {
                  if (locked) {
                    engine.toast(b.needsCity && !engine.city.s.founded ? "Сначала основайте город" : "Такое здание уже есть", "warn");
                    return;
                  }
                  if (!afford) { engine.toast("Не хватает материалов", "warn"); return; }
                  engine.startBuild(b.id);
                  onClose();
                }}
              >
                <div className="flex items-center gap-2">
                  <div className="item-cell !h-10 !w-10 shrink-0">
                    <ItemIcon icon={b.icon} size={20} className={afford ? "text-amber-200" : "text-white/40"} />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="font-display truncate text-[13px] font-bold leading-tight text-amber-50">{b.name}</span>
                      {b.wonder && <Sparkle size={11} className="shrink-0 text-amber-300" />}
                      {locked && <Lock size={10} className="shrink-0 text-white/40" />}
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-white/40">
                      <Clock size={9} /> {fmt(b.buildTime)}с · {b.w}×{b.h}
                      {b.jobs ? ` · ${b.jobs} мест` : ""}{b.housing ? ` · ${b.housing} жит.` : ""}
                    </div>
                  </div>
                </div>
                <div className="text-[10.5px] leading-snug text-white/50">{b.desc}</div>
                <div className="mt-auto flex flex-wrap gap-x-2">
                  {b.cost.map(([id, n]) => {
                    const have = engine.count(id);
                    return (
                      <span key={id} className={`text-[10.5px] font-semibold ${have >= n ? "text-emerald-300/90" : "text-rose-300/90"}`}>
                        {ITEMS[id]?.name.split(" ")[0]} {have}/{n}
                      </span>
                    );
                  })}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// Панель подтверждения во время размещения
export function BuildBar({ engine, snap }: { engine: Engine; snap: UiSnapshot }) {
  if (!snap.buildDef) return null;
  const def = BUILDINGS[snap.buildDef];
  return (
    <div className="absolute bottom-[calc(92px+env(safe-area-inset-bottom))] left-1/2 z-40 w-full max-w-sm -translate-x-1/2 px-3">
      <div className="glass flex items-center gap-2 px-3 py-2.5">
        <ItemIcon icon={def.icon} size={22} className="shrink-0 text-amber-200" />
        <div className="min-w-0 flex-1">
          <div className="font-display text-[13px] font-bold text-amber-50">{def.name}</div>
          <div className={`text-[10.5px] font-semibold ${snap.buildValid ? "text-emerald-300/90" : "text-amber-300/80"}`}>
            {snap.buildValid ? "Ведите пальцем и жмите «Поставить»" : snap.buildReason || "Тапните по свободному месту"}
          </div>
        </div>
        <button
          className="btn !px-3.5 !py-2"
          disabled={!snap.buildValid}
          onClick={() => engine.confirmBuild()}
        >
          <Check size={16} />
        </button>
        <button className="btn-ghost !px-3 !py-2" onClick={() => engine.cancelBuild()}>
          <Ban size={16} />
        </button>
      </div>
    </div>
  );
}
