import type { Engine } from "../game/engine";
import { Footprints, Pickaxe, Sword, GlassWater, Shovel, Eye, Hammer, Trash2, X } from "lucide-react";

const ACT_ICON: Record<string, typeof Footprints> = {
  go: Footprints, harvest: Pickaxe, attack: Sword, drink: GlassWater,
  dig: Shovel, inspect: Eye, interact: Hammer, demolish: Trash2,
};

export function ContextMenu({ engine, opts, onClose }: { engine: Engine; opts: { label: string; act: string }[]; onClose: () => void }) {
  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center pb-24" onClick={onClose}>
      <div className="absolute inset-0 bg-black/35" />
      <div className="glass relative w-full max-w-[290px] p-2" onClick={(e) => e.stopPropagation()}>
        <div className="mb-1 flex items-center justify-between px-1.5">
          <span className="font-display text-[13px] font-bold text-amber-100/90">Что прикажете?</span>
          <button className="btn-ghost !p-1.5" onClick={onClose}><X size={14} /></button>
        </div>
        <div className="flex flex-col gap-1">
          {opts.map((o) => {
            const I = ACT_ICON[o.act] ?? Eye;
            return (
              <button
                key={o.act + o.label}
                className="btn-ghost !justify-start !gap-2.5 !py-2.5 text-[13.5px]"
                onClick={() => { engine.contextAction(o.act); onClose(); }}
              >
                <I size={16} className="text-amber-300/90" />
                {o.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
