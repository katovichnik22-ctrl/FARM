import { useEffect } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { GraduationCap, ChevronRight, X } from "lucide-react";
import { snd } from "../lib/sound";

interface Step {
  title: string;
  text: string;
  check: (s: UiSnapshot, e: Engine) => boolean;
}

export const TUTORIAL_STEPS: Step[] = [
  { title: "Первые шаги", text: "Коснитесь земли — герой пойдёт. Долгое нажатие — меню действий. Щипок — зум. Сделайте пару шагов.", check: (s) => (s.stats.moved ?? 0) > 1 },
  { title: "Лес даёт", text: "Тапните по дереву — герой подойдёт и срубит. Соберите 3 брёвна.", check: (_s, e) => e.count("brevno") >= 3 },
  { title: "Кремень и камень", text: "Добудьте 3 камня из валунов — можно и голыми руками.", check: (_s, e) => e.count("kamen") >= 3 },
  { title: "Первое ремесло", text: "Откройте «Крафт» внизу и сделайте палки из брёвен.", check: (s) => (s.stats.crafted ?? 0) >= 1 },
  { title: "Каменный топор", text: "Скрафтите каменный топор — рубка пойдёт вдвое веселее.", check: (s) => (s.stats.topor ?? 0) >= 1 },
  { title: "Вода — жизнь", text: "Тапните по озеру поблизости, чтобы напиться. Сырая вода иногда горчит…", check: (s) => (s.stats.drank ?? 0) >= 1 },
  { title: "Тихое пламя", text: "Через «Стройку» поставьте костёр и закончите стройку, постучав по ней.", check: (s) => (s.stats.fire ?? 0) >= 1 },
  { title: "Ужин героя", text: "Съешьте что-нибудь: ягоды с куста или жаркое из окна крафта у костра.", check: (s) => (s.stats.ate ?? 0) >= 1 },
  { title: "Крыша над головой", text: "Постройте шалаш. С первой ночью придут чудища — свет их отпугнёт.", check: (_s, e) => e.buildings.some((b) => b.def === "shalash" && b.done) },
  { title: "До рассвета", text: "Переживите ночь: поспите в шалаше тапом по нему или сражайтесь. Удачи, путник!", check: (s) => (s.stats.slept ?? 0) >= 1 || s.day >= 2 },
  // ---- Городская глава ----
  { title: "Место для ратуши", text: "Пора думать о городе. В «Стройке» найдите раздел «Город» и заложите Ратушу.", check: (_s, e) => e.buildings.some((b) => b.def === "ratusha") },
  { title: "Соседи у площади", text: "Вокруг ратуши нужно 4 достроенных здания: дома, ферма, колодец — что угодно.", check: (_s, e) => e.city.canFound(e).ok || e.city.s.founded },
  { title: "Город наречён", text: "Жмите слева кнопку «Город» и основайте поселение. Дайте ему имя!", check: (s) => s.cityFounded },
  { title: "Крыши и работа", text: "Стройте дома и мастерские: жителям нужны кров и ремесло. Доведите население до 15.", check: (s) => s.cityPop >= 15 },
  { title: "Слово мэра", text: "В окне города во вкладке «Указы» издайте любой указ — хоть народный праздник.", check: (s) => (s.stats.edict ?? 0) >= 1 },
  { title: "Дорога серебром", text: "Откройте «Торг» и отправьте первый караван к соседям. Прибыль сама придёт в казну.", check: (s) => (s.stats.route ?? 0) >= 1 },
  // ---- Военная глава ----
  { title: "Соседи по свету", text: "Откройте «Посольство»: вокруг десятки держав. Узнайте, кто дружелюбен, а кто точит меч.", check: (s) => (s.stats.diplo ?? 0) >= 1 },
  { title: "Казармы и сталь", text: "Постройте Казармы (Стройка → Оборона) — без них войска не набрать.", check: (_s, e) => e.buildings.some((b) => b.done && b.def === "kazarmy") },
  { title: "Первая рать", text: "Во вкладке «Войско» → «Найм» наберите копейщиков. Помните о содержании.", check: (s) => s.armyMen >= 3 },
  { title: "Воевода", text: "Наймите воеводу и поставьте его во главе отряда: его черта усилит всё войско.", check: (s) => s.generalCount >= 1 },
  { title: "Огнём и словом", text: "Победите в битве — или дайте отпор вторжению, или сами идите войной с поводом.", check: (s) => (s.stats.battleWin ?? 0) >= 1 },
  // ---- Глава знания и веры ----
  { title: "Первое знание", text: "Откройте «Знание» и изучите первую технологию. Наука копится от библиотек и академий.", check: (s) => s.techCount >= 1 },
  { title: "Смена эпох", text: "Стройте библиотеку и академию, копите науку — и мир шагнёт в следующую эпоху.", check: (_s, e) => e.lore.eraIndex() >= 1 },
  { title: "Лей-линии", text: "Изучите «Чтение лей-линий», поставьте алтарь и встаньте на путь мага: выберите школу.", check: (s) => s.isMage },
  { title: "Слово веры", text: "Постройте храм, накопите веру и основайте свою религию в окне «Вера».", check: (s) => s.religionFounded },
  { title: "Великий человек", text: "Театры, храмы и парки притягивают великих людей. Дождитесь одного и примите его дар.", check: (_s, e) => e.lore.culture.greats.some((g) => g.used) },
  // ---- Глава миров ----
  { title: "Вглубь земли", text: "Откройте «Врата миров» и постройте шахтный лифт — путь в подземелья станет надёжным.", check: (_s, e) => e.layers.hasGate("g_shaft") || e.layers.visits[1] > 0 },
  { title: "Иные небеса", text: "Откройте новый слой: небо, океан или глубины. Не забудьте снаряжение!", check: (s) => s.unlockedLayers >= 3 },
  { title: "Владыка слоя", text: "Победите босса любого слоя: короля нежити, кракена или ледяную королеву.", check: (_s, e) => e.layers.bossesKilled.size >= 1 },
  { title: "К звёздам", text: "Изучите ракетное дело, постройте космодром и ступите на Луну.", check: (_s, e) => (e.layers.visits[5] ?? 0) > 0 },
];

export function Tutorial({ engine, snap }: { engine: Engine; snap: UiSnapshot }) {
  const step = engine.tutorialStep;

  useEffect(() => {
    const cur = TUTORIAL_STEPS[engine.tutorialStep];
    if (cur && cur.check(snap, engine)) {
      engine.tutorialStep = engine.tutorialStep + 1;
      snd.levelup();
      engine.toast(`Наставление ${engine.tutorialStep}/${TUTORIAL_STEPS.length} пройдено!`, "good");
      engine.addXp(12);
      engine.poke();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [snap, engine]);

  if (step >= TUTORIAL_STEPS.length) return null;
  if (snap.buildDef) return null; // не мешаем размещению постройки
  const cur = TUTORIAL_STEPS[step];
  if (!cur) return null;

  return (
    <div className="pointer-events-none absolute bottom-[calc(134px+env(safe-area-inset-bottom))] left-2 z-30 w-[min(310px,86vw)]">
      <div className="glass relative p-3">
        <div className="flex items-start gap-2">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-amber-400/20 text-amber-300">
            <GraduationCap size={17} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="font-display text-[13.5px] font-bold text-amber-100">{cur.title}</span>
              <span className="rounded-full bg-white/10 px-1.5 text-[9.5px] font-bold text-white/60">{step + 1}/{TUTORIAL_STEPS.length}</span>
            </div>
            <p className="mt-0.5 text-[12px] leading-snug text-white/65">{cur.text}</p>
          </div>
        </div>
        <div className="pointer-events-auto mt-1.5 flex items-center justify-between">
          <div className="flex gap-1">
            {TUTORIAL_STEPS.map((_, i) => (
              <span key={i} className={`h-1 w-3.5 rounded-full ${i < step ? "bg-emerald-400" : i === step ? "bg-amber-400" : "bg-white/15"}`} />
            ))}
          </div>
          <button
            className="flex items-center gap-0.5 text-[11px] font-semibold text-white/40"
            onClick={() => { engine.tutorialStep = 99; engine.poke(); }}
          >
            Пропустить <X size={11} />
          </button>
        </div>
      </div>
      <ChevronRight className="absolute -right-2 top-1/2 -translate-y-1/2 animate-pulse text-amber-400/70" size={22} />
    </div>
  );
}
