import { useEffect, useState } from "react";
import type { Engine } from "../game/engine";
import type { Toast } from "../types";
import { Info, CheckCircle2, AlertTriangle, Skull } from "lucide-react";

const ICONS = { info: Info, good: CheckCircle2, warn: AlertTriangle, bad: Skull } as const;
const COLORS = {
  info: "border-sky-300/25 text-sky-100",
  good: "border-emerald-300/30 text-emerald-100",
  warn: "border-amber-300/35 text-amber-100",
  bad: "border-rose-400/40 text-rose-100",
} as const;

export function Toasts({ engine }: { engine: Engine }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  useEffect(() => {
    return engine.onToast((t) => {
      setToasts((prev) => [...prev.slice(-3), t]);
      setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== t.id)), 3400);
    });
  }, [engine]);

  return (
    <div className="pointer-events-none absolute left-1/2 top-[calc(76px+env(safe-area-inset-top))] z-40 flex w-full max-w-sm -translate-x-1/2 flex-col items-center gap-1.5 px-4">
      {toasts.map((t) => {
        const I = ICONS[t.kind];
        return (
          <div key={t.id} className={`glass-soft toast-anim flex items-center gap-2 border px-3 py-1.5 text-[13px] font-medium ${COLORS[t.kind]}`}>
            <I size={15} className="shrink-0 opacity-80" />
            <span className="font-display">{t.text}</span>
          </div>
        );
      })}
    </div>
  );
}
