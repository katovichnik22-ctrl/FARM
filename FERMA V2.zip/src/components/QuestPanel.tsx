import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { ACTS, STORY_CHARS, CHAR_BY_ID, QUEST_BY_ID } from "../data/story";
import { ITEMS } from "../data/items";
import {
  ScrollText, Check, Trash2, BookOpen, Users, MessageCircle, Star, Coins, Sparkle,
} from "lucide-react";

const TABS = ["Задания", "Летопись", "Лица", "Дневник"];

export function QuestPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const m = engine.meta;
  const [tab, setTab] = useState("Задания");
  const active = m.activeQuests();
  const story = active.filter((q) => q.act !== undefined);
  const side = active.filter((q) => q.act === undefined);
  const act = ACTS[Math.min(ACTS.length - 1, m.act - 1)];

  return (
    <Sheet
      title="Летопись дел"
      sub={`Акт ${act.n}: ${act.name} · заданий ${active.length} · выполнено ${snap.questsDone}`}
      onClose={onClose}
    >
      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "62vh" }}>

        {tab === "Задания" && (
          <div className="space-y-1.5">
            {story.map((q) => {
              const ch = CHAR_BY_ID[q.giver];
              return (
                <div key={q.uid} className="rounded-xl border border-amber-400/40 bg-amber-400/8 p-2.5">
                  <div className="flex items-start gap-2">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full"
                      style={{ background: `${ch?.color ?? "#f2c14e"}22`, color: ch?.color ?? "#f2c14e" }}>
                      <ItemIcon icon={ch?.icon ?? "ScrollText"} size={18} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="rounded-full bg-amber-400/25 px-1.5 text-[9px] font-bold text-amber-200">АКТ {q.act}</span>
                        <span className="truncate font-display text-[14px] font-bold text-amber-50">{q.title}</span>
                      </div>
                      <div className="text-[10.5px] text-white/40">{ch?.name ?? q.giver}</div>
                      <p className="mt-1 font-display text-[12px] italic leading-snug text-white/65">{q.text}</p>
                    </div>
                  </div>
                  <div className="mt-1.5 space-y-1">
                    {q.goals.map((g, i) => (
                      <div key={i}>
                        <div className="flex justify-between text-[11px]">
                          <span className={g.have >= g.need ? "text-emerald-300" : "text-white/60"}>
                            {g.have >= g.need && <Check size={10} className="mr-1 inline" />}{g.label}
                          </span>
                          <span className="font-bold text-white/45">{g.have}/{g.need}</span>
                        </div>
                        <div className="bar-track !h-1"><div className="bar-fill" style={{ width: `${(g.have / g.need) * 100}%`, background: g.have >= g.need ? "#7ae68a" : "#f2c14e" }} /></div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-1.5 flex flex-wrap gap-1.5 text-[10px] font-semibold">
                    <span className="rounded bg-amber-400/15 px-1.5 py-0.5 text-amber-200">{q.reward.gold} зол.</span>
                    <span className="rounded bg-sky-400/15 px-1.5 py-0.5 text-sky-200">{q.reward.xp} опыта</span>
                    {q.reward.stars ? <span className="rounded bg-yellow-400/15 px-1.5 py-0.5 text-yellow-200">{q.reward.stars} ★</span> : null}
                    {q.reward.items.map(([id, n]) => (
                      <span key={id} className="rounded bg-white/8 px-1.5 py-0.5 text-white/60">{ITEMS[id]?.name ?? id} ×{n}</span>
                    ))}
                  </div>
                </div>
              );
            })}

            {side.length > 0 && <div className="pt-1 text-[11px] font-bold uppercase tracking-wide text-white/40">Поручения</div>}
            {side.map((q) => (
              <div key={q.uid} className="rounded-xl border border-white/8 bg-black/25 p-2">
                <div className="flex items-start gap-2">
                  <ScrollText size={16} className="mt-0.5 shrink-0 text-amber-200/70" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12.5px] font-bold text-amber-50">{q.title}</div>
                    <div className="text-[10px] text-white/40">{q.giver}{q.deadline ? ` · до дня ${q.deadline}` : ""}</div>
                    <p className="text-[11px] italic leading-snug text-white/50">{q.text}</p>
                    {q.goals.map((g, i) => (
                      <div key={i} className="mt-1">
                        <div className="flex justify-between text-[10.5px]">
                          <span className={g.have >= g.need ? "text-emerald-300" : "text-white/55"}>{g.label}</span>
                          <span className="font-bold text-white/40">{g.have}/{g.need}</span>
                        </div>
                        <div className="bar-track !h-1"><div className="bar-fill" style={{ width: `${(g.have / g.need) * 100}%`, background: "#8fa2f2" }} /></div>
                      </div>
                    ))}
                    <div className="mt-1 flex gap-1.5 text-[10px] font-semibold">
                      <span className="text-amber-300">{q.reward.gold} зол.</span>
                      <span className="text-sky-300">{q.reward.xp} опыта</span>
                    </div>
                  </div>
                  <button className="btn-ghost !px-2 !py-1.5" onClick={() => m.abandon(engine, q.uid)}>
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            ))}
            {active.length === 0 && (
              <div className="py-8 text-center text-[12.5px] text-white/40">
                Заданий нет. Поручения приходят от жителей сами — стройте город и ждите.
              </div>
            )}
          </div>
        )}

        {tab === "Летопись" && (
          <div className="space-y-1.5">
            {ACTS.map((a) => {
              const cur = a.n === m.act;
              const past = a.n < m.act;
              const questsOfAct = Object.values(QUEST_BY_ID).filter((q) => q.act === a.n);
              const doneOfAct = questsOfAct.filter((q) => m.questsDone.has(q.id)).length;
              return (
                <div key={a.n} className={`rounded-xl border p-2.5 ${cur ? "border-amber-400/50 bg-amber-400/8" : past ? "border-emerald-400/25 bg-emerald-400/5" : "border-white/8 bg-black/20 opacity-70"}`}>
                  <div className="flex items-center gap-2">
                    <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full font-display text-[14px] font-bold ${cur ? "bg-amber-400/25 text-amber-200" : past ? "bg-emerald-400/20 text-emerald-300" : "bg-white/8 text-white/40"}`}>
                      {a.n}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-display text-[13.5px] font-bold text-amber-50">{a.name}</div>
                      <div className="text-[10.5px] leading-snug text-white/45">{a.desc}</div>
                    </div>
                    <span className="text-[11px] font-bold text-white/45">{doneOfAct}/{questsOfAct.length}</span>
                  </div>
                  <div className="bar-track mt-1 !h-1">
                    <div className="bar-fill" style={{ width: `${(doneOfAct / Math.max(1, questsOfAct.length)) * 100}%`, background: past ? "#7ae68a" : "#f2c14e" }} />
                  </div>
                </div>
              );
            })}
            {Object.keys(m.choices).length > 0 && (
              <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
                <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                  <Sparkle size={12} /> Ваши решения
                </div>
                {Object.entries(m.choices).map(([qid, cid]) => {
                  const def = QUEST_BY_ID[qid];
                  const ch = def?.choices?.find((c) => c.id === cid);
                  return <Row key={qid} k={def?.title ?? qid} v={ch?.label ?? cid} color="#e08ac9" />;
                })}
              </div>
            )}
            {m.finaleEnding && (
              <div className="rounded-xl border border-amber-400/45 bg-amber-400/10 p-3 text-center">
                <div className="font-display text-[15px] font-bold text-amber-100">
                  {m.finaleEnding === "ascend" ? "Вы вознеслись" : m.finaleEnding === "rule" ? "Вы правите галактикой" : "Вы вернулись к тихому огню"}
                </div>
                <div className="mt-1 text-[11.5px] text-white/55">Кампания завершена. Мир продолжает жить.</div>
              </div>
            )}
          </div>
        )}

        {tab === "Лица" && (
          <div className="space-y-1.5">
            {STORY_CHARS.map((c) => {
              const met = m.charMet.has(c.id);
              return (
                <div key={c.id} className={`rounded-xl border p-2 ${met ? "border-white/10 bg-black/28" : "border-white/8 bg-black/15 opacity-55"}`}>
                  <div className="flex items-start gap-2">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full"
                      style={{ background: met ? `${c.color}22` : "rgba(255,255,255,0.05)", color: met ? c.color : "#5a5a5a" }}>
                      <ItemIcon icon={met ? c.icon : "HelpCircle"} size={18} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline gap-1.5">
                        <span className="truncate text-[13px] font-bold text-amber-50">{met ? c.name : "Неизвестный"}</span>
                        <span className="text-[10px] uppercase tracking-wide" style={{ color: met ? c.color : "#666" }}>{met ? c.title : `акт ${c.act}`}</span>
                      </div>
                      {met ? (
                        <>
                          <div className="text-[10.5px] italic leading-snug text-white/45">{c.bio}</div>
                          <div className="text-[10.5px] leading-snug text-amber-200/70">{c.arc}</div>
                        </>
                      ) : (
                        <div className="text-[10.5px] text-white/35">Вы ещё не встречались</div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Дневник" && (
          <div className="space-y-2">
            {m.rumors.length > 0 && (
              <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
                <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                  <MessageCircle size={12} /> Слухи
                </div>
                {m.rumors.slice(0, 6).map((r, i) => (
                  <p key={i} className="border-b border-white/5 py-1 text-[11.5px] italic text-white/55 last:border-0">«{r}»</p>
                ))}
              </div>
            )}
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                <BookOpen size={12} /> Дневник мира
              </div>
              {m.journal.length === 0 && <div className="py-2 text-center text-[11.5px] text-white/35">Летопись пока пуста</div>}
              {m.journal.slice(0, 30).map((j, i) => (
                <div key={i} className="border-b border-white/5 py-1 text-[11.5px] last:border-0">
                  <span className="text-white/30">День {j.day}: </span>
                  <span className={
                    j.kind === "story" ? "text-amber-200" : j.kind === "choice" ? "text-pink-300"
                      : j.kind === "discovery" ? "text-emerald-300" : j.kind === "quest" ? "text-sky-300" : "text-white/65"
                  }>{j.text}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="mt-2 flex items-center justify-between rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5 text-[11px]">
        <span className="flex items-center gap-1 text-white/45"><Users size={11} /> Знакомых: {m.charMet.size}/{STORY_CHARS.length}</span>
        <span className="flex items-center gap-1 text-amber-200"><Star size={11} /> {snap.stars} ★</span>
        <span className="flex items-center gap-1 text-white/45"><Coins size={11} /> {engine.player.gold}</span>
      </div>
    </Sheet>
  );
}

// ---------- Модал выбора ----------
export function ChoiceModal({ engine, onClose }: { engine: Engine; onClose: () => void }) {
  const q = engine.meta.pendingChoice;
  if (!q) return null;
  const def = QUEST_BY_ID[q.id];
  if (!def?.choices) return null;
  const ch = CHAR_BY_ID[q.giver];
  return (
    <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black/72 p-4">
      <div className="glass w-full max-w-sm p-4">
        <div className="mb-2 flex items-center gap-2">
          <div className="flex h-11 w-11 items-center justify-center rounded-full"
            style={{ background: `${ch?.color ?? "#f2c14e"}22`, color: ch?.color ?? "#f2c14e" }}>
            <ItemIcon icon={ch?.icon ?? "Sparkle"} size={21} />
          </div>
          <div className="min-w-0">
            <h2 className="font-display text-lg font-bold text-amber-100">Выбор</h2>
            <p className="truncate text-[11.5px] text-white/50">{q.title} · {ch?.name ?? q.giver}</p>
          </div>
        </div>
        <p className="font-display text-[12.5px] italic leading-snug text-white/65">{q.text}</p>
        <div className="mt-3 space-y-1.5">
          {def.choices.map((c) => (
            <button key={c.id} className="btn-ghost w-full !justify-start !py-2.5 !text-left !text-[12.5px]"
              onClick={() => { engine.meta.makeChoice(engine, q, c.id); onClose(); }}>
              {c.label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-center text-[10.5px] text-white/35">Решение изменит мир. Обратного пути не будет.</p>
      </div>
    </div>
  );
}
