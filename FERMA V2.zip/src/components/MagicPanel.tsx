import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { SCHOOLS } from "../types/lore";
import type { SchoolId } from "../types/lore";
import { SPELLS, SPELL_BY_ID, RITUALS, ARTIFACTS, BEASTS } from "../data/magic";
import { ITEMS } from "../data/items";
import { Sparkles, Hourglass, Lock, Wand2, ShoppingBag, Star, Check } from "lucide-react";

const TABS = ["Чары", "Ритуалы", "Артефакты", "Твари"];

export function MagicPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const l = engine.lore;
  const m = l.magic;
  const [tab, setTab] = useState("Чары");
  const [picking, setPicking] = useState(false);

  // --- Путь мага ---
  if (!m.school) {
    const c = l.canBecomeMage(engine);
    return (
      <Sheet title="Путь чародея" sub="Лей-линии гудят под ногами — нужно лишь услышать" onClose={onClose}>
        <div className="scroll-area space-y-2" style={{ maxHeight: "64vh" }}>
          <div className="flex items-start gap-3 rounded-xl border border-purple-400/25 bg-purple-500/8 p-3">
            <Sparkles size={30} className="shrink-0 text-purple-300" />
            <p className="text-[12.5px] leading-snug text-white/65">
              Избрав школу, вы получите ману, заклинания в мире и в бою, ритуалы, артефакты и власть над мифическими тварями.
              Позже можно изучить и другие школы.
            </p>
          </div>
          <div className={`rounded-xl border p-2.5 text-[12.5px] font-semibold ${c.ok ? "border-emerald-400/30 bg-emerald-400/8 text-emerald-200" : "border-amber-400/25 bg-amber-400/6 text-amber-200/80"}`}>
            {c.ok ? "Всё готово — выберите школу" : c.reason}
          </div>
          {c.ok && (
            <div className="grid grid-cols-2 gap-1.5">
              {SCHOOLS.map((s) => (
                <button key={s.id} className="flex flex-col gap-1 rounded-xl border border-white/10 bg-black/30 p-2 text-left transition active:scale-[0.97]"
                  style={{ borderColor: `${s.color}44` }}
                  onClick={() => l.becomeMage(engine, s.id)}>
                  <div className="flex items-center gap-1.5">
                    <ItemIcon icon={s.icon} size={17} style={{ color: s.color }} />
                    <span className="text-[13px] font-bold text-amber-50">{s.name}</span>
                  </div>
                  <span className="text-[10.5px] leading-snug text-white/45">{s.desc}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </Sheet>
    );
  }

  const schoolDef = SCHOOLS.find((s) => s.id === m.school)!;

  return (
    <Sheet
      title={`Чародей школы «${schoolDef.name}»`}
      sub={`Уровень ${m.lvl} · мана ${snap.mana}/${snap.manaMax} · школ ${m.schools.length} · артефактов ${m.artifacts.length}`}
      onClose={onClose}
    >
      {/* Мана */}
      <div className="mb-2 rounded-xl border p-2.5" style={{ borderColor: `${schoolDef.color}44`, background: "rgba(0,0,0,0.3)" }}>
        <div className="flex items-center gap-1.5">
          <ItemIcon icon={schoolDef.icon} size={15} style={{ color: schoolDef.color }} />
          <span className="flex-1 text-[11px] font-bold uppercase tracking-wide text-white/45">Мана</span>
          <span className="font-display text-[15px] font-bold" style={{ color: schoolDef.color }}>{snap.mana}/{snap.manaMax}</span>
        </div>
        <div className="bar-track mt-1 !h-2">
          <div className="bar-fill" style={{ width: `${(snap.mana / Math.max(1, snap.manaMax)) * 100}%`, background: schoolDef.color }} />
        </div>
        {m.ritual && (
          <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-purple-200">
            <Hourglass size={11} /> Идёт ритуал «{snap.ritualName}» — осталось {snap.ritualLeft} дн.
          </div>
        )}
      </div>

      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "50vh" }}>

        {tab === "Чары" && (
          <div className="space-y-1.5">
            {SPELLS.filter((s) => l.knowsSpell(s.id)).map((s) => {
              const sd = SCHOOLS.find((x) => x.id === s.school)!;
              const cd = m.cds[s.id] ?? 0;
              const canWorld = s.world && cd <= 0 && m.mana >= s.mana;
              return (
                <div key={s.id} className="rounded-xl border border-white/8 bg-black/25 p-2">
                  <div className="flex items-start gap-2">
                    <div className="item-cell !h-10 !w-10 shrink-0" style={{ borderColor: `${sd.color}55` }}>
                      <ItemIcon icon={s.icon} size={18} style={{ color: sd.color }} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[13px] font-bold text-amber-50">{s.name}</span>
                        <span className="text-[10px] font-bold" style={{ color: sd.color }}>{sd.name}</span>
                      </div>
                      <div className="text-[10.5px] leading-snug text-white/45">{s.desc}</div>
                      <div className="mt-0.5 flex flex-wrap gap-1 text-[10px] font-semibold">
                        <span className="rounded bg-purple-400/15 px-1.5 py-0.5 text-purple-200">{s.mana} маны</span>
                        {s.battle && <span className="rounded bg-rose-400/12 px-1.5 py-0.5 text-rose-200">в бою</span>}
                        {s.world && <span className="rounded bg-emerald-400/12 px-1.5 py-0.5 text-emerald-200">в мире</span>}
                        {cd > 0 && <span className="rounded bg-white/8 px-1.5 py-0.5 text-white/50">ждать {Math.ceil(cd)}</span>}
                      </div>
                    </div>
                    {s.world && (
                      <button className="btn !px-2.5 !py-2 !text-[11px]" disabled={!canWorld}
                        onClick={() => l.castWorld(engine, s.id)}>
                        <Wand2 size={13} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
            {/* Другие школы */}
            <div className="mt-2 text-[11px] font-bold uppercase tracking-wide text-white/40">Иные школы ({l.learnSchoolCost()} зол.)</div>
            <div className="grid grid-cols-3 gap-1.5">
              {SCHOOLS.map((s) => {
                const known = m.schools.includes(s.id);
                return (
                  <button key={s.id} disabled={known}
                    className={`flex flex-col items-center gap-0.5 rounded-xl border p-1.5 ${known ? "border-emerald-400/35 bg-emerald-400/8" : "border-white/10 bg-black/25"}`}
                    onClick={() => l.learnSchool(engine, s.id as SchoolId)}>
                    <ItemIcon icon={s.icon} size={15} style={{ color: known ? "#7ae68a" : s.color }} />
                    <span className="text-[9.5px] font-bold text-white/60">{s.name}</span>
                    {known && <Check size={9} className="text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {tab === "Ритуалы" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11px] leading-snug text-white/45">
              Долгие обряды требуют маны, золота и составов. Зато их дар чувствует вся держава.
            </p>
            {RITUALS.map((r) => {
              const sd = SCHOOLS.find((x) => x.id === r.school)!;
              const c = l.canRitual(engine, r.id);
              return (
                <div key={r.id} className={`rounded-xl border p-2 ${c.ok ? "border-purple-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-70"}`}>
                  <div className="flex items-start gap-2">
                    <div className="item-cell !h-10 !w-10 shrink-0" style={{ borderColor: `${sd.color}55` }}>
                      <ItemIcon icon={r.icon} size={18} style={{ color: sd.color }} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-[13px] font-bold text-amber-50">{r.name}</div>
                      <div className="text-[10.5px] italic leading-snug text-white/45">{r.desc}</div>
                      <div className="mt-0.5 text-[10.5px] font-semibold text-amber-200/85">{r.bonusText}</div>
                      <div className="mt-0.5 flex flex-wrap gap-x-2 text-[10px]">
                        <span className={engine.lore.magic.mana >= r.mana ? "text-purple-300" : "text-rose-300"}>{r.mana} маны</span>
                        <span className={engine.player.gold >= r.gold ? "text-amber-300" : "text-rose-300"}>{r.gold} зол.</span>
                        {r.comps.map(([id, n]) => {
                          const have = engine.count(id) + engine.city.stockOf(id);
                          return <span key={id} className={have >= n ? "text-emerald-300" : "text-rose-300"}>{ITEMS[id]?.name ?? id} {have}/{n}</span>;
                        })}
                        <span className="text-white/40">{r.days} дн.</span>
                      </div>
                    </div>
                    <button className="btn !px-2.5 !py-2 !text-[11px]" disabled={!c.ok} onClick={() => l.startRitual(engine, r.id)}>
                      <Sparkles size={13} />
                    </button>
                  </div>
                  {!c.ok && c.reason && <div className="mt-1 text-[10px] text-amber-300/70">{c.reason}</div>}
                </div>
              );
            })}
          </div>
        )}

        {tab === "Артефакты" && (
          <div className="space-y-1.5">
            <button className="btn w-full !py-2.5 !text-[12.5px]" onClick={() => l.buyArtifact(engine)}>
              <ShoppingBag size={15} /> Купить у странствующего мага ({900 + m.artifacts.length * 700} зол.)
            </button>
            <p className="px-1 text-[10.5px] leading-snug text-white/40">
              Артефакты также находят в дальних землях и сундуках подземелий — чем дальше от дома, тем ценнее находка.
            </p>
            {ARTIFACTS.map((a) => {
              const owned = l.hasArtifact(a.id);
              const sd = SCHOOLS.find((x) => x.id === a.school)!;
              return (
                <div key={a.id} className={`rounded-xl border p-2 ${owned ? "border-amber-400/40 bg-amber-400/8" : "border-white/8 bg-black/15 opacity-60"}`}>
                  <div className="flex items-start gap-2">
                    <div className="item-cell !h-10 !w-10 shrink-0" style={{ borderColor: owned ? "#ffd97a66" : undefined }}>
                      {owned ? <ItemIcon icon={a.icon} size={18} style={{ color: sd.color }} /> : <Lock size={15} className="text-white/30" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1">
                        <span className="truncate text-[13px] font-bold text-amber-50">{owned ? a.name : "Неведомый артефакт"}</span>
                        {[...Array(a.rarity)].map((_, i) => <Star key={i} size={9} className="text-amber-300" fill="currentColor" />)}
                      </div>
                      {owned ? (
                        <>
                          <div className="text-[10.5px] italic leading-snug text-white/45">{a.desc}</div>
                          <div className="text-[10.5px] font-semibold text-amber-200/85">{a.bonusText}</div>
                        </>
                      ) : (
                        <div className="text-[10.5px] text-white/35">Скрыт в дальних землях или у чужих магов</div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Твари" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11px] leading-snug text-white/45">
              Мифических существ можно приручить дарами и чарами. Успех зависит от школы, уровня мага и силы войска.
            </p>
            {BEASTS.map((b) => {
              const tamed = m.beasts.includes(b.id);
              const sd = SCHOOLS.find((x) => x.id === b.school)!;
              const affinity = m.schools.includes(b.school);
              return (
                <div key={b.id} className={`rounded-xl border p-2 ${tamed ? "border-emerald-400/35 bg-emerald-400/8" : "border-white/8 bg-black/25"}`}>
                  <div className="flex items-start gap-2">
                    <div className="item-cell !h-11 !w-11 shrink-0" style={{ borderColor: `${sd.color}55` }}>
                      <ItemIcon icon={b.icon} size={20} style={{ color: sd.color }} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[13px] font-bold text-amber-50">{b.name}</span>
                        {tamed && <Check size={12} className="text-emerald-400" />}
                        {affinity && !tamed && <span className="text-[9.5px] font-bold" style={{ color: sd.color }}>родная школа</span>}
                      </div>
                      <div className="text-[10.5px] italic leading-snug text-white/45">{b.desc}</div>
                      <div className="text-[10.5px] font-semibold text-amber-200/85">{b.bonusText}</div>
                      {!tamed && (
                        <div className="mt-0.5 flex gap-2 text-[10px]">
                          <span className={engine.player.gold >= b.tameCost ? "text-amber-300" : "text-rose-300"}>{b.tameCost} зол.</span>
                          <span className={m.mana >= b.tameMana ? "text-purple-300" : "text-rose-300"}>{b.tameMana} маны</span>
                        </div>
                      )}
                    </div>
                    {!tamed && (
                      <button className="btn !px-2.5 !py-2 !text-[11px]" onClick={() => l.tame(engine, b.id)}>
                        Приручить
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="mt-2 rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5">
        <Row k="Сила чар" v={`×${l.spellPower().toFixed(2)}`} color={schoolDef.color} />
        <Row k="Известно заклинаний" v={`${m.spells.length}/${SPELLS.length}`} />
        <Row k="Опыт мага" v={`${m.xp}/${60 + m.lvl * 70}`} />
      </div>
      {picking && <div className="hidden">{SPELL_BY_ID ? "" : ""}</div>}
      <button className="hidden" onClick={() => setPicking(false)} />
    </Sheet>
  );
}
