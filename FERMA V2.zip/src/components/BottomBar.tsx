import type { Engine, UiSnapshot } from "../game/engine";
import { TILE, SOLID_OBJ, O } from "../types";
import { Backpack, Hammer, Building2, Menu, Apple, GlassWater, Swords, Landmark, TrendingUp, Crown, Scale, Globe2, FlaskConical, Sparkles, Church, Layers3, ScrollText, Star } from "lucide-react";
import { snd } from "../lib/sound";

export type PanelId =
  | "inv" | "craft" | "build" | "menu" | "city" | "econ" | "dyn" | "parl" | "npc" | "binfo"
  | "army" | "diplo" | "battle" | "battleStart"
  | "tech" | "magic" | "faith" | "layers" | "quests" | "legacy" | "choice" | null;

interface Props {
  engine: Engine;
  snap: UiSnapshot;
  panel: PanelId;
  setPanel: (p: PanelId) => void;
}

export function BottomBar({ engine, snap, panel, setPanel }: Props) {
  const toggle = (p: PanelId) => {
    snd.ensure(); snd.uiOpen();
    setPanel(panel === p ? null : p);
  };

  const smartAction = () => {
    snd.ensure();
    // ближайший враг
    let bestM: import("../types").Mob | null = null;
    let bestD = 2.6;
    for (const m of engine.mobs) {
      const d = engine.distTo(m.x, m.y);
      if (d < bestD) { bestD = d; bestM = m; }
    }
    if (bestM) {
      engine.doAction({ kind: "attack", tx: 0, ty: 0, mobUid: bestM.uid });
      return;
    }
    // ближайший добываемый объект
    const ptx = Math.floor(engine.player.x / TILE);
    const pty = Math.floor(engine.player.y / TILE);
    let bx = -1, by = -1, bd = 99;
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        const t = engine.tileOf(ptx + dx, pty + dy);
        if (t.o !== O.None) {
          const d = Math.hypot(dx, dy);
          if (d < bd && (SOLID_OBJ.has(t.o) || t.o !== O.CaveIn)) { bd = d; bx = ptx + dx; by = pty + dy; }
        }
      }
    }
    if (bx >= 0) { engine.tap(bx * TILE + 20, by * TILE + 20); return; }
    engine.toast("Подойдите к дереву, камню или воде", "info");
  };

  const danger = snap.enemiesNear > 0;

  return (
    <div className="safe-bottom pointer-events-none absolute bottom-0 left-0 right-0 z-40">
      {/* городские окна: появляются, когда есть ратуша или основан город */}
      {!snap.buildDef && (
        <div className="pointer-events-auto absolute bottom-[78px] left-2 right-[68px] flex gap-1.5 overflow-x-auto pb-0.5" style={{ touchAction: "pan-x" }}>
          <button
            className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "city" ? "active" : ""} ${snap.cityRioting ? "pulse-soft !border-rose-400/60 !text-rose-200" : snap.canFoundCity ? "pulse-soft !border-emerald-400/60 !text-emerald-200" : ""}`}
            onClick={() => toggle("city")}
          >
            <Landmark size={15} />
            <span>{snap.cityFounded ? `${snap.cityName} · ${snap.cityPop}` : "Основать город"}</span>
          </button>
          {snap.cityFounded && (
            <>
              <button className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "econ" ? "active" : ""}`} onClick={() => toggle("econ")}>
                <TrendingUp size={15} /><span>Торг</span>
              </button>
              <button className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "dyn" ? "active" : ""}`} onClick={() => toggle("dyn")}>
                <Crown size={15} /><span>Род</span>
              </button>
              <button className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "parl" ? "active" : ""}`} onClick={() => toggle("parl")}>
                <Scale size={15} /><span>Палата</span>
              </button>
            </>
          )}
          {(snap.cityFounded || snap.warCount > 0 || snap.envoyCount > 0) && (
            <>
              <button
                className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "army" ? "active" : ""} ${snap.incomingWar ? "pulse-soft !border-rose-400/60 !text-rose-200" : ""}`}
                onClick={() => toggle("army")}
              >
                <Swords size={15} /><span>Войско {snap.armyMen > 0 ? snap.armyMen : ""}</span>
              </button>
              <button
                className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "diplo" ? "active" : ""} ${snap.envoyCount > 0 ? "pulse-soft !border-amber-400/60 !text-amber-200" : ""}`}
                onClick={() => toggle("diplo")}
              >
                <Globe2 size={15} /><span>Посольство{snap.envoyCount > 0 ? ` (${snap.envoyCount})` : ""}</span>
              </button>
            </>
          )}
          <button
            className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "tech" ? "active" : ""} ${!snap.researching ? "pulse-soft !border-sky-400/50 !text-sky-200" : ""}`}
            onClick={() => toggle("tech")}
          >
            <FlaskConical size={15} /><span>Знание {snap.techCount}</span>
          </button>
          {(snap.magicUnlocked || snap.isMage) && (
            <button
              className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "magic" ? "active" : ""}`}
              onClick={() => toggle("magic")}
            >
              <Sparkles size={15} /><span>{snap.isMage ? `Чары ${snap.mana}` : "Магия"}</span>
            </button>
          )}
          <button
            className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "quests" ? "active" : ""} ${snap.storyTitle ? "!border-amber-400/50 !text-amber-200" : ""}`}
            onClick={() => toggle("quests")}
          >
            <ScrollText size={15} /><span>Дела {snap.questCount > 0 ? snap.questCount : ""}</span>
          </button>
          <button
            className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "legacy" ? "active" : ""} ${snap.dailyReady ? "pulse-soft !border-amber-400/60 !text-amber-200" : ""}`}
            onClick={() => toggle("legacy")}
          >
            <Star size={15} /><span>★ {snap.stars}</span>
          </button>
          <button
            className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "layers" ? "active" : ""} ${!snap.hasGearForLayer ? "pulse-soft !border-rose-400/60 !text-rose-200" : ""}`}
            onClick={() => toggle("layers")}
          >
            <Layers3 size={15} /><span>{snap.layerShort}</span>
          </button>
          {snap.cityFounded && (
            <button
              className={`btn-icon shrink-0 !min-w-0 !flex-row !gap-1.5 !px-2.5 !py-1.5 !text-[11px] ${panel === "faith" ? "active" : ""} ${snap.greatsReady > 0 ? "pulse-soft !border-pink-400/60 !text-pink-200" : ""}`}
              onClick={() => toggle("faith")}
            >
              <Church size={15} />
              <span>{snap.religionFounded ? `${snap.religionSymbol} ${snap.followers}%` : "Вера"}{snap.greatsReady > 0 ? ` ★${snap.greatsReady}` : ""}</span>
            </button>
          )}
        </div>
      )}

      {/* быстрые еда/вода */}
      <div className="pointer-events-auto absolute bottom-[76px] right-2 flex flex-col gap-1.5">
        <button
          className={`btn-icon !min-w-[52px] ${snap.food < 30 ? "pulse-soft border-orange-400/50 text-orange-200" : ""}`}
          onClick={() => { snd.ensure(); engine.quickEat(); }}
        >
          <Apple size={18} />
          <span>Еда</span>
        </button>
        <button
          className={`btn-icon !min-w-[52px] ${snap.water < 30 ? "pulse-soft border-sky-400/50 text-sky-200" : ""}`}
          onClick={() => { snd.ensure(); engine.quickDrink(); }}
        >
          <GlassWater size={18} />
          <span>Вода</span>
        </button>
      </div>

      <div className="pointer-events-auto mx-auto flex max-w-md items-stretch justify-center gap-1.5 px-3 pb-1.5">
        <button
          className={`btn-icon flex-1 !py-2.5 ${panel ? "" : ""} ${danger ? "!border-rose-400/60 !bg-rose-400/15 !text-rose-200" : "!border-emerald-400/40 !bg-emerald-400/10 !text-emerald-200"}`}
          onClick={smartAction}
        >
          <Swords size={20} />
          <span>{danger ? "Бой!" : "Действие"}</span>
        </button>
        <button className={`btn-icon flex-1 !py-2.5 ${panel === "inv" ? "active" : ""}`} onClick={() => toggle("inv")}>
          <Backpack size={20} />
          <span>Сумка</span>
        </button>
        <button className={`btn-icon flex-1 !py-2.5 ${panel === "craft" ? "active" : ""}`} onClick={() => toggle("craft")}>
          <Hammer size={20} />
          <span>Крафт</span>
        </button>
        <button className={`btn-icon flex-1 !py-2.5 ${panel === "build" ? "active" : ""}`} onClick={() => toggle("build")}>
          <Building2 size={20} />
          <span>Стройка</span>
        </button>
        <button className={`btn-icon flex-1 !py-2.5 ${panel === "menu" ? "active" : ""}`} onClick={() => toggle("menu")}>
          <Menu size={20} />
          <span>Меню</span>
        </button>
      </div>
    </div>
  );
}
