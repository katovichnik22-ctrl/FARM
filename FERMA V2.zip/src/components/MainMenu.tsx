import { useRef, useState } from "react";
import { slotMetas, deleteSlot, importSave, getMuted, setMutedFlag } from "../lib/save";
import type { SlotMeta, SaveData } from "../types";
import { Play, Plus, Trash2, Upload, Volume2, VolumeX, Dice5, Flame, Star, Trophy } from "lucide-react";
import { MODES } from "../types/meta";
import type { GameMode } from "../types/meta";
import { loadGlobalMeta } from "../game/meta";
import { ItemIcon } from "./ItemIcon";
import { snd } from "../lib/sound";
import { mulberry32 } from "../lib/noise";

interface Props {
  onStart: (slot: number, seed: number, name: string, mode: GameMode) => void;
  onContinue: (slot: number) => void;
  onImport: (data: SaveData) => void;
}

export function MainMenu({ onStart, onContinue, onImport }: Props) {
  const [metas, setMetas] = useState<(SlotMeta | null)[]>(() => slotMetas());
  const [newSlot, setNewSlot] = useState<number | null>(null);
  const [seedStr, setSeedStr] = useState("");
  const [name, setName] = useState("");
  const [muted, setMuted] = useState(getMuted());
  const [mode, setMode] = useState<GameMode>("normal");
  const [err, setErr] = useState("");
  const g = loadGlobalMeta();
  const fileRef = useRef<HTMLInputElement>(null);

  const refresh = () => setMetas(slotMetas());

  const begin = () => {
    const seed = seedStr.trim()
      ? [...seedStr].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7)
      : Math.floor(mulberry32(Date.now())() * 1e9);
    snd.ensure();
    onStart(newSlot!, seed >>> 0, name.trim() || ["Заповедный край", "Тихие перелески", "Долина костров", "Край восьми ветров"][seed % 4], mode);
    setNewSlot(null);
  };

  return (
    <div className="relative flex h-full flex-col items-center justify-center overflow-hidden">
      {/* Фон: ночное небо и дальние холмы */}
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, #171226 0%, #2a1e33 38%, #3d2a33 62%, #171219 100%)" }} />
      <Stars />
      <div className="absolute bottom-0 left-0 right-0 h-[38%]" style={{ background: "linear-gradient(180deg, transparent, #0f0b12 88%)" }} />
      <svg className="absolute bottom-[18%] h-auto w-full opacity-70" viewBox="0 0 100 30" preserveAspectRatio="none">
        <path d="M0 30 L0 22 Q15 14 28 20 T55 18 T82 22 L100 19 L100 30 Z" fill="#241c28" />
        <path d="M0 30 L0 26 Q20 20 40 24 T75 25 L100 23 L100 30 Z" fill="#171119" />
      </svg>

      <div className="relative z-10 flex w-full max-w-sm flex-col items-center gap-5 px-5 py-8">
        <div className="flex flex-col items-center">
          <div className="float-y relative mb-1">
            <div className="absolute inset-0 scale-[2.6] rounded-full bg-orange-500/25 blur-2xl" />
            <Flame size={64} className="relative text-orange-400" fill="#f2762e" strokeWidth={1.2} />
          </div>
          <h1 className="font-display text-center text-[44px] font-bold leading-none tracking-wide text-amber-100" style={{ textShadow: "0 2px 24px rgba(242,118,46,0.45)" }}>
            Тихое Пламя
          </h1>
          <p className="mt-2 text-center text-[13px] font-medium tracking-widest text-amber-200/60">
            ВЫЖИВАНИЕ · СТРОИТЕЛЬСТВО · ВОСЕМЬ ЗЕМЕЛЬ
          </p>
        </div>

        {(g.stars > 0 || g.achievements.length > 0 || g.prestige > 0) && (
          <div className="glass flex w-full items-center justify-around px-3 py-2 text-[11.5px]">
            <span className="flex items-center gap-1 font-bold text-amber-200"><Star size={12} fill="currentColor" /> {g.stars} ★</span>
            <span className="flex items-center gap-1 text-white/55"><Trophy size={12} /> {g.achievements.length}</span>
            <span className="flex items-center gap-1 text-white/55">Перерождений: {g.prestige}</span>
          </div>
        )}

        <div className="w-full space-y-2">
          {metas.map((m, i) => (
            <div key={i} className="glass flex items-center gap-3 p-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-400/15 font-display text-lg font-bold text-amber-300">
                {i + 1}
              </div>
              {m ? (
                <>
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-display text-[15px] font-bold text-amber-50">{m.name}</div>
                    <div className="text-[11px] text-white/45">
                      День {m.day} · ур. {m.level} · {new Date(m.ts).toLocaleDateString("ru-RU")}
                    </div>
                  </div>
                  <button className="btn !px-3.5 !py-2" onClick={() => { snd.ensure(); onContinue(i + 1); }}>
                    <Play size={16} />
                  </button>
                  <button
                    className="btn-ghost !px-2.5 !py-2"
                    onClick={() => {
                      if (confirm("Удалить этот мир навсегда?")) { deleteSlot(i + 1); refresh(); }
                    }}
                  >
                    <Trash2 size={15} />
                  </button>
                </>
              ) : (
                <>
                  <div className="flex-1 text-[13px] text-white/40">Пустой слот — ждёт героя</div>
                  <button
                    className="btn !px-3.5 !py-2"
                    onClick={() => { setNewSlot(i + 1); setSeedStr(""); setName(""); setErr(""); snd.ensure(); snd.uiOpen(); }}
                  >
                    <Plus size={16} />
                  </button>
                </>
              )}
            </div>
          ))}
        </div>

        <div className="flex w-full gap-2">
          <button className="btn-ghost flex-1" onClick={() => fileRef.current?.click()}>
            <Upload size={15} /> Импорт JSON
          </button>
          <button
            className="btn-ghost"
            onClick={() => {
              const m = !muted;
              setMuted(m); setMutedFlag(m); snd.setMuted(m);
            }}
          >
            {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
        </div>
        {err && <div className="text-[12px] text-rose-300">{err}</div>}
        <input
          ref={fileRef}
          type="file"
          accept=".json,application/json"
          className="hidden"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            try {
              const d = await importSave(f);
              snd.ensure();
              onImport(d);
            } catch (ex) {
              setErr(ex instanceof Error ? ex.message : "Ошибка импорта");
            }
            e.target.value = "";
          }}
        />
        <p className="text-center text-[11px] leading-relaxed text-white/30">
          Мир бесконечен и один для одного сида. Чем дальше от дома —<br />тем опаснее земли и богаче добыча.
        </p>
      </div>

      {/* Модал новой игры */}
      {newSlot !== null && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/60 p-5" onClick={() => setNewSlot(null)}>
          <div className="glass w-full max-w-xs p-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-display text-lg font-bold text-amber-100">Новый мир</h3>
            <label className="mt-3 block text-[11px] font-bold uppercase tracking-wider text-white/40">Название земли</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Тихие перелески"
              className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-[14px] text-amber-50 outline-none focus:border-amber-400/50"
            />
            <label className="mt-3 block text-[11px] font-bold uppercase tracking-wider text-white/40">Сид (пусто — случайный)</label>
            <div className="mt-1 flex gap-1.5">
              <input
                value={seedStr}
                onChange={(e) => setSeedStr(e.target.value)}
                placeholder="например, волхв"
                className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-[14px] text-amber-50 outline-none focus:border-amber-400/50"
              />
              <button className="btn-ghost" onClick={() => setSeedStr(String(Math.floor(Math.random() * 999999)))}>
                <Dice5 size={17} />
              </button>
            </div>
            <label className="mt-3 block text-[11px] font-bold uppercase tracking-wider text-white/40">Режим игры</label>
            <div className="scroll-area mt-1 max-h-[24vh] space-y-1">
              {MODES.map((md) => (
                <button key={md.id}
                  className={`flex w-full items-start gap-2 rounded-xl border p-2 text-left transition ${mode === md.id ? "border-amber-400/60 bg-amber-400/10" : "border-white/10 bg-black/25"}`}
                  onClick={() => setMode(md.id)}>
                  <ItemIcon icon={md.icon} size={16} className="mt-0.5 shrink-0" style={{ color: md.color }} />
                  <div className="min-w-0 flex-1">
                    <div className="text-[12.5px] font-bold text-amber-50">{md.name}</div>
                    <div className="text-[10.5px] leading-snug text-white/45">{md.desc}</div>
                    {md.warn && <div className="text-[10px] font-bold text-rose-300">{md.warn}</div>}
                  </div>
                </button>
              ))}
            </div>
            <button className="btn mt-3 w-full" onClick={begin}>
              <Flame size={16} /> Разжечь пламя
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Stars() {
  const stars = useRef(
    Array.from({ length: 42 }, (_, i) => ({
      x: (i * 37.3) % 100, y: ((i * 61.7) % 45), s: 0.6 + ((i * 13) % 10) / 8, d: (i % 7) * 0.5,
    }))
  );
  return (
    <>
      {stars.current.map((s, i) => (
        <span
          key={i}
          className="pulse-soft absolute rounded-full bg-amber-50"
          style={{ left: `${s.x}%`, top: `${s.y}%`, width: s.s, height: s.s, animationDelay: `${s.d}s`, opacity: 0.75 }}
        />
      ))}
    </>
  );
}
