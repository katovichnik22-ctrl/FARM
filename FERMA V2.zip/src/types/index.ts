// ===== Общие типы «Тихого Пламени» =====
import type { CityEff, CitySave } from "./city";
import type { WarSave } from "./war";
import type { LoreSave } from "./lore";
export * from "./city";
export * from "./war";
export * from "./lore";

export const TILE = 40;
export const CHUNK = 32;

export interface Vec { x: number; y: number }

// ---- Грунты ----
export const G = {
  DeepWater: 0, Water: 1, Sand: 2, Grass: 3, Meadow: 4, Dirt: 5,
  Desert: 6, Snow: 7, Stone: 8, Swamp: 9, SnowRock: 10, Ash: 11,
  CaveFloor: 12, CaveWall: 13, FarmSoil: 14,
  // --- слои 5-го этапа ---
  Lava: 15, Obsidian: 16, HellRock: 17, Cloud: 18, SkyGrass: 19,
  SeaFloor: 20, CoralBed: 21, MoonDust: 22, MarsSand: 23, VoidFloor: 24,
  ShadowGround: 25, DreamGround: 26, ChaosGround: 27, MetalFloor: 28, DeepWaterCol: 29,
} as const;
export type GroundId = (typeof G)[keyof typeof G];
/** Слой мира: 0 поверхность, 1 пещеры, 2 глубины, 3 небо, 4 океан, 5 Луна, 6 Марс, 7 тени, 8 сны, 9 хаос */
export type LayerId = number;
export const WALK_BLOCK_GROUND = new Set<number>([G.DeepWater, G.Water, G.CaveWall, G.Lava]);
export const SOLID_GROUND = new Set<number>([G.DeepWater, G.Water, G.CaveWall, G.Lava]);
export const DIGGABLE = new Set<number>([G.Sand, G.Desert, G.Snow, G.Dirt]);

// ---- Объекты на тайлах ----
export const O = {
  None: 0, Oak: 1, Pine: 2, Birch: 3, Bush: 4, Rock: 5, Coal: 6,
  Copper: 7, Iron: 8, Mushroom: 9, Clay: 10, FlowerR: 11, FlowerY: 12,
  GrassTuft: 13, CaveIn: 14, CaveOut: 15, Chest: 16, Gold: 17,
  GlowShroom: 18, Bones: 19, DeadBush: 20, Cactus: 21, Reeds: 22, Stump: 23,
  // --- слои 5-го этапа ---
  Mithril: 24, Adamant: 25, Crystal: 26, LavaVent: 27, SkyCrystal: 28,
  CloudTree: 29, Pearl: 30, CoralObj: 31, Seaweed: 32, Wreck: 33,
  MoonOre: 34, MarsOre: 35, AlienRelic: 36, ShadowTree: 37, DreamFlower: 38,
  ChaosOrb: 39, Trap: 40, Mechanism: 41, RuinChest: 42, Gate: 43,
} as const;
export type ObjId = (typeof O)[keyof typeof O];
/** Непроходимые объекты тайла. Дерево блокирует только тайл со стволом —
 *  крона (графически вылезает за соседние тайлы) прохода не держит.
 *  Куст и вся мягкая растительность ходьбы не преграждают. */
export const SOLID_OBJ = new Set<number>([
  O.Oak, O.Pine, O.Birch, O.Rock, O.Coal, O.Copper, O.Iron, O.Gold,
  O.CaveIn, O.Chest, O.Cactus,
  O.Mithril, O.Adamant, O.Crystal, O.SkyCrystal, O.CloudTree,
  O.MoonOre, O.MarsOre, O.AlienRelic, O.ShadowTree, O.RuinChest, O.Wreck, O.Mechanism,
]);

// ---- Биомы ----
export enum Biome { Ocean = 0, Beach, Meadow, Forest, Desert, Tundra, SnowMount, Swamp, Cave }
export const BIOME_NAMES: Record<Biome, string> = {
  [Biome.Ocean]: "Море", [Biome.Beach]: "Берег", [Biome.Meadow]: "Цветущий луг",
  [Biome.Forest]: "Шумный лес", [Biome.Desert]: "Рыжая пустыня", [Biome.Tundra]: "Седая тундра",
  [Biome.SnowMount]: "Белые горы", [Biome.Swamp]: "Топь", [Biome.Cave]: "Чрево земли",
};

// ---- Предметы ----
export type EquipSlot = "head" | "body" | "legs" | "feet" | "weapon";
export type ItemType = "res" | "food" | "drink" | "tool" | "weapon" | "equip" | "misc" | "place";

export interface ItemDef {
  id: string;
  name: string;
  desc: string;
  icon: string; // ключ из ItemIcon
  type: ItemType;
  stack: number;
  food?: number; drink?: number; heal?: number; poisonChance?: number;
  dmg?: number; tool?: "axe" | "pick" | "shovel"; power?: number; atkSpd?: number;
  slot?: EquipSlot; armor?: number; warmth?: number;
  xp?: number;
}

export interface InvSlot { id: string; n: number }
export type Equip = Partial<Record<EquipSlot, string>>;

// ---- Рецепты ----
export interface RecipeDef {
  id: string; name: string; icon: string; cat: string;
  out: string; outN: number; needs: [string, number][];
  fire?: boolean; xp: number;
}

// ---- Здания ----
export interface BuildingDef {
  id: string; name: string; desc: string; icon: string; cat: string;
  w: number; h: number; cost: [string, number][];
  buildTime: number; hp: number; blocks: boolean;
  light?: number; warmth?: number; sleep?: boolean; cook?: boolean;
  well?: boolean; produce?: { id: string; every: number; max: number };
  door?: boolean;
  // --- городская надстройка (2-й этап) ---
  jobs?: number;                 // рабочие места
  housing?: number;              // жителей помещается
  eff?: CityEff;                 // вклад в метрики города
  chain?: { in: [string, number][]; out: [string, number]; every: number }; // производственная цепочка
  needsCity?: boolean;           // требует основанного города
  wonder?: boolean;              // чудо света
  maxLvl?: number;               // до какого уровня улучшается
  upkeep?: number;               // содержание, золота в день
  townhall?: boolean;            // ратуша
  road?: boolean;                // дорога
  tavern?: boolean;              // жители ходят отдыхать
  bonus?: string;                // описание уникального бонуса (чудеса)
}

export interface Building {
  uid: number; def: string; tx: number; ty: number;
  progress: number; done: boolean; store: number; prodT: number; open?: boolean;
  lvl?: number;                  // уровень постройки (1..maxLvl)
  chainT?: number;               // таймер цепочки
  smoke?: number;
}

// ---- Мобы ----
export type MobAI = "flee" | "neutral" | "aggro" | "ranged" | "explode" | "ghost" | "boss" | "guard";

export interface MobDef {
  id: string; name: string; hp: number; dmg: number; speed: number;
  xp: number; ai: MobAI; night?: boolean; cave?: boolean;
  scale: number; aggroR: number; atkR: number; atkCd: number;
  flying?: boolean;
  drops: { id: string; n: number; ch: number }[];
  /** id базового спрайта из drawMobBody/drawBossBody (если отличается от id моба) */
  spriteBase?: string;
  /** тонировка спрайта (CSS-цвет, накладывается поверх) */
  tint?: string;
  /** элитная («древняя») версия: аура и имя над головой */
  elite?: boolean;
}

export interface Mob {
  uid: number; def: string; x: number; y: number; hp: number; maxHp: number;
  state: "idle" | "wander" | "chase" | "flee" | "attack" | "boom";
  t: number; // таймер состояния
  cd: number; // перезарядка атаки
  flash: number; lvl: number; tx: number; ty: number; // цель блуждания
  breathe: number; fuse?: number; hitT: number;
}

export interface Projectile { x: number; y: number; vx: number; vy: number; dmg: number; t: number; kind: "arrow" | "fire" }

export interface Particle {
  x: number; y: number; vx: number; vy: number;
  age: number; life: number; color: string; size: number;
  grav: number; kind: "chip" | "leaf" | "spark" | "drop" | "puff" | "star" | "snow" | "ember";
}

export interface Floater {
  x: number; y: number; text: string; color: string; age: number; big: boolean;
}

// ---- Игрок ----
export interface PlayerState {
  x: number; y: number; dir: number; moving: boolean;
  hp: number; maxHp: number; food: number; water: number; stamina: number; temp: number;
  xp: number; level: number; gold: number;
  inv: InvSlot[]; equip: Equip;
  dead: boolean; swing: number; swingDir: number; poisonT: number;
}

// ---- Погода / сезоны ----
export type WeatherId = "clear" | "rain" | "storm" | "snow" | "fog";
export const WEATHER_NAMES: Record<WeatherId, string> = {
  clear: "Ясно", rain: "Дождь", storm: "Гроза", snow: "Снег", fog: "Туман",
};
export const SEASON_NAMES = ["Весна", "Лето", "Осень", "Зима"];

// ---- Сохранение ----
export interface TileMod { o?: number; g?: number; hp?: number }
export interface SaveData {
  version: number; seed: number; slot: number;
  time: number; day: number; season: number; weather: WeatherId;
  z: LayerId;
  player: PlayerState;
  mods: [string, TileMod][];
  buildings: Building[];
  dragonDead: boolean;
  stats: Record<string, number>;
  tutorial: number;
  meta: { savedAt: number; name: string };
  cityData?: CitySave;   // блок 2-го этапа (необязателен для старых сохранений)
  warData?: WarSave;     // блок 3-го этапа (необязателен)
  loreData?: LoreSave;   // блок 4-го этапа (необязателен)
  layerData?: unknown;   // блок 5-го этапа (слои мира)
  metaData?: unknown;    // блок 6-го этапа (квесты, достижения)
  mode?: string;
}

export interface SlotMeta { slot: number; name: string; day: number; level: number; ts: number; seed: number }

export interface Toast { id: number; text: string; kind: "info" | "good" | "warn" | "bad" }
