// ===== Армия, битвы, нации, дипломатия =====

// ---- Рода войск ----
export type UnitKind = "infantry" | "archer" | "cavalry" | "catapult" | "mage" | "dragon" | "siege" | "fleet";

export interface UnitDef {
  id: UnitKind;
  name: string; plural: string; icon: string;
  hp: number; atk: number; def: number; rng: number; move: number;
  cost: { gold: number; res: [string, number][] };
  upkeepGold: number; upkeepFood: number;
  need?: string;                 // требуемое здание
  desc: string;
  siege?: number;                // урон стенам
  strongVs?: UnitKind[]; weakVs?: UnitKind[];
  ability?: string;              // ключ способности
  water?: boolean;               // ходит по воде
}

/** Отряд игрока или ИИ */
export interface Squad {
  uid: number; kind: UnitKind; n: number;      // численность
  hp: number;                                   // хп первого ряда (0..100 %)
  xp: number; lvl: number;
  morale: number; fatigue: number;
  general: number;                              // uid генерала или 0
  name: string;
  wounded: number;                              // в госпитале
}

export type GenTrait =
  | "taran" | "lis" | "stena" | "sokol" | "kuznec" | "yarost" | "terpenie" | "volhv";

export interface General {
  uid: number; name: string; title: string;
  lvl: number; xp: number;
  trait: GenTrait; bio: string;
  atkBonus: number; defBonus: number; moralBonus: number;
  battles: number; wins: number; alive: boolean;
  wage: number;
}

export const GEN_TRAITS: Record<GenTrait, { name: string; desc: string; atk: number; def: number; mor: number }> = {
  taran: { name: "Таран", desc: "Атака войск +18%", atk: 0.18, def: 0, mor: 0 },
  lis: { name: "Лис", desc: "Обходные манёвры: инициатива и +10% атаки", atk: 0.1, def: 0.04, mor: 0.05 },
  stena: { name: "Стена", desc: "Оборона +22%", atk: 0, def: 0.22, mor: 0.05 },
  sokol: { name: "Сокол", desc: "Стрелки бьют дальше и точнее", atk: 0.12, def: 0.05, mor: 0 },
  kuznec: { name: "Кузнец", desc: "Осадные орудия вдвое злее", atk: 0.08, def: 0.08, mor: 0 },
  yarost: { name: "Ярость", desc: "Атака +25%, оборона −10%", atk: 0.25, def: -0.1, mor: 0.1 },
  terpenie: { name: "Терпение", desc: "Усталость копится вдвое медленнее", atk: 0, def: 0.12, mor: 0.12 },
  volhv: { name: "Волхв", desc: "Магия и мораль войска", atk: 0.1, def: 0.06, mor: 0.2 },
};

// ---- Гексовое поле ----
export type HexTerrain = "grass" | "forest" | "hill" | "water" | "wall" | "gate" | "tower" | "road" | "rubble";

export interface HexCell { q: number; r: number; t: HexTerrain; hp?: number }

export interface BattleUnit {
  uid: number; squadUid: number; side: 0 | 1;     // 0 — игрок, 1 — враг
  kind: UnitKind; n: number; maxN: number;
  hp: number; morale: number; fatigue: number;
  q: number; r: number;
  moved: boolean; acted: boolean;
  general: number; lvl: number;
  flash: number; shake: number;
}

export type BattleKind = "field" | "siege" | "defense";

export interface BattleLog { t: number; text: string; kind: "hit" | "kill" | "move" | "info" | "spell" | "siege" }

export interface BattleState {
  active: boolean;
  kind: BattleKind;
  nationId: string;
  cells: HexCell[];
  units: BattleUnit[];
  turn: number; side: 0 | 1;
  sel: number;                    // выбранный юнит
  log: BattleLog[];
  wallHp: number; wallMax: number;
  gateHp: number; gateMax: number;
  sapper: number;                 // прогресс подкопа
  weather: string; night: boolean;
  over: null | { win: boolean; loot: number; text: string };
  reward: { gold: number; xp: number; annex: boolean };
  spellCd: number;
  ap: number;                     // очки приказов на ход
}

// ---- Нации ----
export type NationChar = "agro" | "mir" | "torg" | "vera" | "hitr" | "bezum" | "mudr";
export const NATION_CHARS: Record<NationChar, { name: string; desc: string }> = {
  agro: { name: "Агрессивный", desc: "Часто объявляет войны" },
  mir: { name: "Мирный", desc: "Ищет союзов и покоя" },
  torg: { name: "Торговый", desc: "Ценит договоры и золото" },
  vera: { name: "Религиозный", desc: "Зовёт в походы за веру" },
  hitr: { name: "Хитрый", desc: "Шпионы, подкупы, интриги" },
  bezum: { name: "Безумный", desc: "Непредсказуем во всём" },
  mudr: { name: "Мудрый", desc: "Развивается и выжидает" },
};

export type WarState = "peace" | "war" | "truce" | "ally" | "vassal" | "overlord";

export interface Nation {
  id: string; name: string; adj: string;
  flag: { bg: string; fg: string; sym: string };
  capital: string; ruler: string; religion: string; culture: string; gov: string;
  char: NationChar;
  x: number; y: number;            // положение на карте мира (тайлы)
  pop: number; gold: number; tech: number; magic: number;
  army: number; fleet: number;     // сила в «полках»
  cities: number;
  rel: number;                     // отношение к игроку −100..100
  state: WarState;
  truceUntil: number;
  tribute: number;                 // платит игроку в день
  league: boolean;
  spyKnown: number;                // уровень разведданных 0..3
  wars: string[];                  // с кем воюет (id других наций)
  allies: string[];
  aggression: number;
  lastAction: string;
  warScore: number;                // счёт войны с игроком −100..100
  siegeOf: string | null;
  marchT: number;                  // таймер марша на игрока
  incoming: boolean;               // войско идёт на игрока
}

export interface Envoy { id: number; nation: string; text: string; kind: "demand" | "offer" | "warn" | "gift"; day: number; gold: number; act: string }

export interface WarSave {
  squads: Squad[]; generals: General[];
  nations: Nation[];
  league: { member: boolean; influence: number; founded: boolean };
  envoys: Envoy[];
  warLog: { day: number; text: string; kind: string }[];
  genUid: number; squadUid: number;
  cb: Record<string, number>;      // casus belli: nationId -> день истечения
  hospital: { kind: UnitKind; n: number; t: number }[];
  guerrilla: boolean;
  fame: number;
}

// ---- Дипломатические действия ----
export interface DiploAct {
  id: string; name: string; desc: string; icon: string;
  gold: number; minRel: number; needWar?: boolean; needPeace?: boolean;
}

export const DIPLO_ACTS: DiploAct[] = [
  { id: "gift", name: "Дары", desc: "Сундук золота смягчает даже злые сердца. +15 к отношениям.", icon: "Gift", gold: 200, minRel: -100, needPeace: true },
  { id: "trade", name: "Торговый договор", desc: "Пошлины прочь: доход в казну каждый день.", icon: "Handshake", gold: 350, minRel: 20, needPeace: true },
  { id: "alliance", name: "Союз", desc: "Братья навек: помогут в войне, поделятся славой.", icon: "Users", gold: 600, minRel: 55, needPeace: true },
  { id: "marriage", name: "Династический брак", desc: "Породниться с правящим домом. +25 отношений, мир надолго.", icon: "Heart", gold: 800, minRel: 35, needPeace: true },
  { id: "vassal", name: "Потребовать вассалитет", desc: "Слабый склонит голову и станет платить дань.", icon: "Crown", gold: 0, minRel: -100, needPeace: true },
  { id: "submit", name: "Признать сюзерена", desc: "Склониться самому: защита в обмен на дань.", icon: "ShieldCheck", gold: 0, minRel: -100, needPeace: true },
  { id: "tribute", name: "Потребовать дань", desc: "Золото за спокойствие. Гордые откажут.", icon: "Coins", gold: 0, minRel: -100, needPeace: true },
  { id: "embargo", name: "Санкции", desc: "Закрыть торг: их казна худеет, отношения тоже.", icon: "Ban", gold: 0, minRel: -100, needPeace: true },
  { id: "cb", name: "Найти casus belli", desc: "Старая грамота, обида, спорная межа — повод для войны.", icon: "ScrollText", gold: 250, minRel: -100, needPeace: true },
  { id: "war", name: "Объявить войну", desc: "Без повода — бесчестье и гнев фракций.", icon: "Swords", gold: 0, minRel: -100, needPeace: true },
  { id: "peace", name: "Предложить мир", desc: "Закончить войну. Условия зависят от счёта войны.", icon: "Dove", gold: 0, minRel: -100, needWar: true },
];

export const SPY_ACTS: DiploAct[] = [
  { id: "recon", name: "Разведка", desc: "Узнать истинную силу армии и казны.", icon: "Eye", gold: 120, minRel: -100 },
  { id: "sabotage", name: "Диверсия", desc: "Поджечь склады: минус войскам и золоту.", icon: "Bomb", gold: 300, minRel: -100 },
  { id: "steal", name: "Кража знаний", desc: "Выкрасть чертежи: +технологии вам, −им.", icon: "BookLock", gold: 350, minRel: -100 },
  { id: "bribe", name: "Подкуп генерала", desc: "Золото развязывает языки и опускает мечи.", icon: "HandCoins", gold: 500, minRel: -100 },
  { id: "revolt", name: "Разжечь восстание", desc: "Смута в чужих землях ослабит их надолго.", icon: "Flame", gold: 700, minRel: -100 },
];
