// ===== Квесты, кампания, достижения, престиж, режимы =====

// ---------- Режимы игры ----------
export type GameMode = "peaceful" | "normal" | "hardcore" | "sandbox" | "creative";

export interface ModeDef {
  id: GameMode; name: string; icon: string; color: string;
  desc: string; warn?: string;
  monsters: boolean; wars: boolean; hunger: boolean; autosave: boolean;
  permadeath: boolean; freeBuild: boolean; startGold: number;
  xpMul: number; ratingMul: number;
}

export const MODES: ModeDef[] = [
  { id: "peaceful", name: "Мирный", icon: "Sprout", color: "#7ae68a", desc: "Ни чудищ, ни войн. Только ферма, стройка и дороги в иные миры.", monsters: false, wars: false, hunger: true, autosave: true, permadeath: false, freeBuild: false, startGold: 150, xpMul: 0.8, ratingMul: 0.6 },
  { id: "normal", name: "Обычный", icon: "Swords", color: "#f2c14e", desc: "Полная игра, как задумано: выживание, держава, войны и звёзды.", monsters: true, wars: true, hunger: true, autosave: true, permadeath: false, freeBuild: false, startGold: 0, xpMul: 1, ratingMul: 1 },
  { id: "hardcore", name: "Хардкор", icon: "Skull", color: "#e05a5a", desc: "Одна жизнь. Смерть стирает мир навсегда. Автосейв выключен.", warn: "Погибнете — мир будет удалён", monsters: true, wars: true, hunger: true, autosave: false, permadeath: true, freeBuild: false, startGold: 0, xpMul: 1.6, ratingMul: 2 },
  { id: "sandbox", name: "Песочница", icon: "Boxes", color: "#8fa2f2", desc: "Богатая казна, открытые пути. Стройте и пробуйте что угодно.", monsters: true, wars: true, hunger: true, autosave: true, permadeath: false, freeBuild: true, startGold: 25000, xpMul: 0.5, ratingMul: 0.3 },
  { id: "creative", name: "Творческий", icon: "Palette", color: "#e08ac9", desc: "Без голода, без смерти, без цены. Мир — ваш холст.", monsters: false, wars: false, hunger: false, autosave: true, permadeath: false, freeBuild: true, startGold: 999999, xpMul: 0, ratingMul: 0 },
];
export const MODE_BY_ID: Record<GameMode, ModeDef> = Object.fromEntries(MODES.map((m) => [m.id, m])) as Record<GameMode, ModeDef>;

// ---------- Квесты ----------
export type QuestKind = "gather" | "kill" | "build" | "reach" | "craft" | "explore" | "talk" | "story";
export type QuestState = "offered" | "active" | "done" | "failed";

export interface QuestGoal { kind: QuestKind; target: string; need: number; have: number; label: string }

export interface Quest {
  uid: number;
  id: string;
  title: string; text: string; giver: string;
  goals: QuestGoal[];
  reward: { gold: number; xp: number; items: [string, number][]; stars?: number; fame?: number };
  state: QuestState;
  act?: number;
  choiceId?: string;
  day: number; deadline?: number;
  chain?: string;
}

export interface QuestDef {
  id: string; title: string; text: string; giver: string;
  goals: { kind: QuestKind; target: string; need: number; label: string }[];
  reward: { gold: number; xp: number; items?: [string, number][]; stars?: number; fame?: number };
  act?: number;
  next?: string;
  choices?: { id: string; label: string; text: string; effect: string }[];
  need?: string;
}

// ---------- Персонажи истории ----------
export interface StoryChar {
  id: string; name: string; title: string; icon: string; color: string;
  bio: string; arc: string;
  act: number;
}

// ---------- Дневник мира ----------
export interface JournalEntry { day: number; text: string; kind: "story" | "world" | "quest" | "choice" | "battle" | "discovery" }

// ---------- Достижения ----------
export type AchCat = "survive" | "city" | "war" | "lore" | "worlds" | "meta";
export interface AchDef {
  id: string; name: string; desc: string; icon: string; cat: AchCat;
  tier: 1 | 2 | 3;
  stars: number;
  check: (s: AchCtx) => boolean;
}
export interface AchCtx {
  day: number; level: number; gold: number;
  cityPop: number; cityFounded: boolean;
  techs: number; era: number;
  mage: boolean; spells: number; artifacts: number; beasts: number;
  religion: boolean; followers: number;
  culture: number; greats: number;
  armyMen: number; battlesWon: number; nationsVassal: number; nationsAlly: number;
  layers: number; bosses: number; spaceBuilds: number;
  questsDone: number; collection: number; prestige: number;
  killed: number; crafted: number; built: number;
  dragonDead: boolean; wondersBuilt: number;
}

// ---------- Коллекция ----------
export type CollectCat = "flora" | "fauna" | "monster" | "artifact" | "boss" | "resource";
export interface CollectEntry { id: string; name: string; cat: CollectCat; icon: string; desc: string }

// ---------- Ежедневные ----------
export interface DailyTask { id: string; text: string; target: number; have: number; reward: number; kind: string; done: boolean }

export interface MetaSave {
  mode: GameMode;
  quests: Quest[];
  questsDone: string[];
  act: number;
  choices: Record<string, string>;
  journal: JournalEntry[];
  achievements: string[];
  collection: string[];
  stars: number; starUpgrades: Record<string, number>;
  prestige: number; prestigePoints: number;
  daily: { lastDay: string; streak: number; claimed: boolean; tasks: DailyTask[] };
  rating: number;
  questUid: number;
  rumors: string[];
  notifications: boolean;
  charMet: string[];
  battlesWon: number;
}

// ---------- Звёздные апгрейды ----------
export interface StarUpgrade {
  id: string; name: string; desc: string; icon: string;
  max: number; cost: number;
  effect: string;
}
export const STAR_UPGRADES: StarUpgrade[] = [
  { id: "su_hp", name: "Крепкое тело", desc: "+20 к пределу здоровья за уровень.", icon: "Heart", max: 5, cost: 2, effect: "hp" },
  { id: "su_gather", name: "Лёгкая рука", desc: "+25% к добыче ресурсов за уровень.", icon: "Pickaxe", max: 4, cost: 3, effect: "gather" },
  { id: "su_gold", name: "Золотая жила", desc: "+20% дохода казны за уровень.", icon: "Coins", max: 5, cost: 3, effect: "gold" },
  { id: "su_sci", name: "Ясный ум", desc: "+25% науки за уровень.", icon: "FlaskConical", max: 4, cost: 4, effect: "sci" },
  { id: "su_mana", name: "Глубокий источник", desc: "+40 маны и быстрее её ток.", icon: "Sparkles", max: 4, cost: 4, effect: "mana" },
  { id: "su_army", name: "Воинская слава", desc: "+15% силы войска за уровень.", icon: "Swords", max: 4, cost: 5, effect: "army" },
  { id: "su_start", name: "Наследство", desc: "+2000 золота в начале нового мира.", icon: "Gift", max: 5, cost: 3, effect: "start" },
  { id: "su_xp", name: "Опыт поколений", desc: "+20% опыта за уровень.", icon: "Star", max: 5, cost: 4, effect: "xp" },
];
