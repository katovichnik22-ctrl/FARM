// ===== Технологии, магия, религия, культура =====

// ---------- ЭПОХИ ----------
export type EraId =
  | "stone" | "bronze" | "iron" | "medieval" | "renaissance" | "industrial"
  | "modern" | "information" | "space" | "arcane" | "singularity";

export interface EraDef {
  id: EraId; name: string; icon: string; desc: string;
  color: string; sciNeed: number;   // накопленной науки для входа
}

export const ERAS: EraDef[] = [
  { id: "stone", name: "Каменный век", icon: "Mountain", desc: "Кремень, костёр и первые тропы.", color: "#8a7f72", sciNeed: 0 },
  { id: "bronze", name: "Бронзовый век", icon: "Hammer", desc: "Медь звенит, рождается ремесло.", color: "#c08a5a", sciNeed: 120 },
  { id: "iron", name: "Железный век", icon: "Sword", desc: "Сталь и плуг переделывают землю.", color: "#9aa2ad", sciNeed: 340 },
  { id: "medieval", name: "Средневековье", icon: "Castle", desc: "Замки, соборы, рыцари и гильдии.", color: "#a8845c", sciNeed: 900 },
  { id: "renaissance", name: "Возрождение", icon: "Palette", desc: "Наука и искусство сбрасывают оковы.", color: "#c98ae0", sciNeed: 1900 },
  { id: "industrial", name: "Индустриальная эпоха", icon: "Factory", desc: "Пар, шестерни и дым до небес.", color: "#7d7873", sciNeed: 3600 },
  { id: "modern", name: "Новое время", icon: "Building2", desc: "Электричество и большие города.", color: "#5a9ac9", sciNeed: 6200 },
  { id: "information", name: "Эпоха знаний", icon: "Cpu", desc: "Знание течёт быстрее рек.", color: "#4ec9b0", sciNeed: 10500 },
  { id: "space", name: "Космическая эра", icon: "Rocket", desc: "Взгляд за пределы небесного свода.", color: "#6a8ae0", sciNeed: 17000 },
  { id: "arcane", name: "Эпоха чар", icon: "Sparkles", desc: "Наука и магия сплавились воедино.", color: "#a26af2", sciNeed: 27000 },
  { id: "singularity", name: "Пост-сингулярность", icon: "Infinity", desc: "Разум превзошёл своего создателя.", color: "#ffd97a", sciNeed: 42000 },
];

export type TechBranch = "mil" | "eco" | "sci" | "mag" | "cul" | "soc" | "space";
export const TECH_BRANCHES: Record<TechBranch, { name: string; icon: string; color: string }> = {
  mil: { name: "Военное", icon: "Swords", color: "#e05a5a" },
  eco: { name: "Хозяйство", icon: "Coins", color: "#f2c14e" },
  sci: { name: "Наука", icon: "FlaskConical", color: "#5a9ac9" },
  mag: { name: "Чары", icon: "Sparkles", color: "#a26af2" },
  cul: { name: "Культура", icon: "Palette", color: "#e08ac9" },
  soc: { name: "Общество", icon: "Users", color: "#7ae68a" },
  space: { name: "Небеса", icon: "Rocket", color: "#6a8ae0" },
};

export interface TechDef {
  id: string; name: string; desc: string; icon: string;
  branch: TechBranch; era: EraId; cost: number;
  needs: string[];
  unlockB?: string[];            // здания
  unlockU?: string[];            // юниты
  unlockS?: string[];            // заклинания
  effect?: {
    sci?: number; gold?: number; prod?: number; food?: number; culture?: number;
    faith?: number; mana?: number; armyAtk?: number; armyDef?: number; borders?: number;
  };
  bonusText: string;
}

// ---------- МАГИЯ ----------
export type SchoolId =
  | "fire" | "water" | "earth" | "air" | "light" | "dark"
  | "life" | "death" | "chaos" | "order" | "time" | "space";

export interface SchoolDef { id: SchoolId; name: string; icon: string; color: string; desc: string }

export const SCHOOLS: SchoolDef[] = [
  { id: "fire", name: "Огонь", icon: "Flame", color: "#f2762e", desc: "Разрушение, ярость, свет в ночи." },
  { id: "water", name: "Вода", icon: "Droplets", color: "#5cb8e0", desc: "Течение, исцеление, дожди и урожай." },
  { id: "earth", name: "Земля", icon: "Mountain", color: "#a8845c", desc: "Камень, стены, богатство недр." },
  { id: "air", name: "Воздух", icon: "Wind", color: "#a8d8f0", desc: "Ветер, скорость, буря и полёт." },
  { id: "light", name: "Свет", icon: "Sun", color: "#ffd97a", desc: "Защита, прозрение, кара тьме." },
  { id: "dark", name: "Тьма", icon: "Moon", color: "#6a5a8a", desc: "Страх, проклятия, тайные пути." },
  { id: "life", name: "Жизнь", icon: "Sprout", color: "#7ae68a", desc: "Рост, врачевание, воскрешение." },
  { id: "death", name: "Смерть", icon: "Skull", color: "#8a7f8f", desc: "Увядание, нежить, власть над концом." },
  { id: "chaos", name: "Хаос", icon: "Zap", color: "#e05ac9", desc: "Непредсказуемость и дикая сила." },
  { id: "order", name: "Порядок", icon: "Scale", color: "#c9c2b2", desc: "Закон, покой, крепость духа." },
  { id: "time", name: "Время", icon: "Clock", color: "#c9a227", desc: "Ускорение, отсрочка, взгляд вперёд." },
  { id: "space", name: "Пространство", icon: "CircleDot", color: "#8fa2f2", desc: "Перенос, врата, сжатие вёрст." },
];

export type SpellKind = "attack" | "heal" | "shield" | "summon" | "teleport" | "weather" | "revive" | "curse" | "bless";

export interface SpellDef {
  id: string; name: string; desc: string; icon: string;
  school: SchoolId; mana: number; lvl: number;
  kind: SpellKind;
  battle?: boolean;              // применимо в бою
  world?: boolean;               // применимо в мире
  power?: number; radius?: number;
  cd: number;                    // перезарядка в днях/ходах
}

export interface RitualDef {
  id: string; name: string; desc: string; icon: string;
  school: SchoolId; mana: number; days: number;
  comps: [string, number][];
  gold: number;
  bonusText: string;
  effect: { kind: string; value: number };
}

export interface ArtifactDef {
  id: string; name: string; desc: string; icon: string;
  school: SchoolId; rarity: 1 | 2 | 3;
  effect: { mana?: number; manaRegen?: number; spellPow?: number; armyAtk?: number; armyDef?: number; gold?: number; sci?: number; faith?: number; culture?: number; hp?: number };
  bonusText: string;
}

export type BeastId = "dragon" | "phoenix" | "unicorn" | "griffon" | "kraken" | "titan";
export interface BeastDef {
  id: BeastId; name: string; icon: string; desc: string;
  hp: number; power: number; tameCost: number; tameMana: number;
  school: SchoolId;
  bonusText: string;
  effect: { armyAtk?: number; armyDef?: number; mana?: number; food?: number; gold?: number; culture?: number };
}

export interface MagicState {
  unlocked: boolean;
  school: SchoolId | null;
  schools: SchoolId[];          // изученные школы
  mana: number; manaMax: number;
  spells: string[];             // изученные заклинания
  artifacts: string[];
  beasts: BeastId[];
  ritual: { id: string; left: number } | null;
  cds: Record<string, number>;
  lvl: number; xp: number;
  auraT: number;                // визуальный эффект
}

// ---------- РЕЛИГИЯ ----------
export type DoctrineId = "faithDoc" | "warDoc" | "tradeDoc" | "growthDoc" | "loreDoc" | "natureDoc";
export interface DoctrineDef {
  id: DoctrineId; name: string; desc: string; icon: string;
  effect: { faith?: number; happy?: number; armyAtk?: number; gold?: number; food?: number; sci?: number; culture?: number; spread?: number };
}

export const DOCTRINES: DoctrineDef[] = [
  { id: "faithDoc", name: "Путь Веры", desc: "Молитва сильнее меча: вера и покой в сердцах.", icon: "Church", effect: { faith: 25, happy: 8, spread: 1.3 } },
  { id: "warDoc", name: "Путь Меча", desc: "Праведная война угодна небу: войско бьёт крепче.", icon: "Swords", effect: { armyAtk: 0.14, faith: 10, happy: -3 } },
  { id: "tradeDoc", name: "Путь Изобилия", desc: "Труд и торг — молитва делом.", icon: "Coins", effect: { gold: 14, faith: 8, spread: 1.15 } },
  { id: "growthDoc", name: "Путь Плодородия", desc: "Плодитесь и наполняйте землю.", icon: "Sprout", effect: { food: 16, happy: 5, faith: 8 } },
  { id: "loreDoc", name: "Путь Познания", desc: "Знание — тоже откровение.", icon: "BookOpen", effect: { sci: 18, culture: 10, faith: 6 } },
  { id: "natureDoc", name: "Путь Рощи", desc: "Священны ручьи, камни и старые дубы.", icon: "Trees", effect: { food: 8, culture: 12, faith: 12, happy: 4 } },
];

export interface ReligionState {
  founded: boolean;
  name: string; symbol: string; color: string;
  doctrines: DoctrineId[];
  followers: number;             // доля мира 0..100
  holyCity: string;
  pilgrims: number;
  crusadeTarget: string | null;
  crusadeDays: number;
  inquisition: boolean;
  prophets: { name: string; trait: string; day: number }[];
  founderDay: number;
}

// ---------- КУЛЬТУРА ----------
export type GreatKind = "artist" | "writer" | "musician" | "scientist" | "general" | "prophet";
export interface GreatPerson {
  uid: number; name: string; kind: GreatKind;
  title: string; bio: string;
  used: boolean; day: number;
}

export const GREAT_KINDS: Record<GreatKind, { name: string; icon: string; color: string; act: string; desc: string }> = {
  artist: { name: "Художник", icon: "Palette", color: "#e08ac9", act: "Написать полотно", desc: "+120 культуры и вечная слава города" },
  writer: { name: "Писатель", icon: "BookOpen", color: "#c9a227", act: "Создать летопись", desc: "+90 культуры, +8 счастья" },
  musician: { name: "Музыкант", icon: "Music", color: "#7ae68a", act: "Дать великий концерт", desc: "+70 культуры, праздник в городе" },
  scientist: { name: "Учёный", icon: "FlaskConical", color: "#5a9ac9", act: "Совершить открытие", desc: "Мгновенно +350 науки" },
  general: { name: "Полководец", icon: "Swords", color: "#e05a5a", act: "Возглавить войско", desc: "Новый воевода высокого уровня" },
  prophet: { name: "Пророк", icon: "Church", color: "#ffd97a", act: "Явить откровение", desc: "+200 веры, религия шире" },
};

export interface CultureState {
  points: number; total: number;
  borders: number;                // радиус влияния в тайлах
  greats: GreatPerson[];
  greatProgress: number;
  masterpieces: number;
  victoryProgress: number;        // 0..100
  greatUid: number;
}

// ---------- Сохранение ----------
export interface LoreSave {
  techs: string[];
  science: number; sciTotal: number;
  era: EraId;
  researching: string | null;
  magic: MagicState;
  religion: ReligionState;
  culture: CultureState;
  worldReligions: { name: string; color: string; symbol: string; share: number }[];
}
