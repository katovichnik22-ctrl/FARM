import type { Engine } from "./engine";
import type { Building, CityState, District, CityMetrics } from "../types";
import { TIER_NAMES } from "../types/city";
import { BUILDINGS } from "../data/buildings";
import { EDICTS } from "../data/citydata";
import { ITEMS } from "../data/items";
import { clamp, clamp01, lerp } from "../lib/noise";
import { snd } from "../lib/sound";

// Энергия: кто даёт, кто потребляет (по id постройки)
const ENERGY: Record<string, number> = {
  melnica: 26, portal: 45, w_chasy: 90, w_kuznya: 70, w_mayak: 30, observatoriya: 8,
  zavod: -22, fabrika: -18, kuznica: -9, laboratoriya: -11, neboskreb: -14, shahta: -12,
  pilorama: -6, tkackaya: -5, yuvelirnaya: -5, stolyarka: -5, birzha: -4, universitet: -8,
};

const TIER_POP = [0, 12, 35, 80, 170, 340, 650];

export function freshCity(): CityState {
  return {
    founded: false, name: "Безымянное поселение", cx: 0, cy: 0, foundedDay: 0,
    pop: 0, popCap: 0, happiness: 60, taxRate: 10, jobs: 0, employed: 0,
    metrics: { food: 0, water: 0, energy: 0, health: 50, crime: 0, pollution: 0, culture: 0, faith: 0, science: 0, order: 0 },
    districts: { res: 1, ind: 1, com: 1, mil: 1, sci: 1, mag: 0, rel: 1 },
    edicts: {}, stock: {}, riot: 0, rioting: false, tier: 0,
    monuments: [], paradeT: 0, lastGrowT: 0, history: [], totalTax: 0, unrestNote: "",
  };
}

export class CitySim {
  s: CityState = freshCity();
  private recT = 0;
  private goldAcc = 0;
  private lastPopInt = 0;
  private cache = {
    food: 0, water: 0, energySup: 0, energyDem: 0, housing: 0, jobs: 0,
    culture: 0, faith: 0, science: 0, order: 0, crime: 0, pollution: 0,
    health: 0, goldEff: 0, happyEff: 0, upkeep: 0, count: 0, wonders: [] as string[],
  };

  // ---------- Основание ----------
  canFound(e: Engine): { ok: boolean; reason: string; have: number; need: number } {
    const hall = e.buildings.find((b) => b.done && BUILDINGS[b.def]?.townhall);
    if (!hall) return { ok: false, reason: "Нужна достроенная Ратуша", have: 0, need: 4 };
    let near = 0;
    for (const b of e.buildings) {
      if (!b.done || b === hall) continue;
      if (Math.abs(b.tx - hall.tx) < 18 && Math.abs(b.ty - hall.ty) < 18) near++;
    }
    if (near < 4) return { ok: false, reason: "Нужно 4 достроенных здания рядом с ратушей", have: near, need: 4 };
    return { ok: true, reason: "", have: near, need: 4 };
  }

  found(e: Engine, name: string) {
    const check = this.canFound(e);
    if (!check.ok) { e.toast(check.reason, "warn"); return false; }
    const hall = e.buildings.find((b) => b.done && BUILDINGS[b.def]?.townhall)!;
    this.s.founded = true;
    this.s.name = name.trim() || "Тихий Град";
    this.s.cx = hall.tx + 1; this.s.cy = hall.ty + 1;
    this.s.foundedDay = e.day;
    this.s.pop = 6; this.s.happiness = 70;
    this.recompute(e);
    e.toast(`Город «${this.s.name}» основан! Первые семьи уже в пути`, "good");
    snd.levelup();
    this.s.paradeT = 6;
    e.addXp(60);
    return true;
  }

  rename(n: string) { if (n.trim()) this.s.name = n.trim().slice(0, 24); }

  // ---------- Расчёт метрик ----------
  recompute(e: Engine) {
    const c = this.cache;
    c.food = c.water = c.energySup = c.energyDem = c.housing = c.jobs = 0;
    c.culture = c.faith = c.science = c.order = c.crime = c.pollution = 0;
    c.health = c.goldEff = c.happyEff = c.upkeep = c.count = 0;
    c.wonders = [];
    const d = this.s.districts;
    for (const b of e.buildings) {
      if (!b.done) continue;
      const def = BUILDINGS[b.def];
      if (!def) continue;
      const lvl = b.lvl ?? 1;
      c.count++;
      if (def.wonder) c.wonders.push(def.id);
      c.housing += (def.housing ?? 0) * lvl * (1 + d.res * 0.12);
      c.jobs += (def.jobs ?? 0) * lvl;
      c.upkeep += (def.upkeep ?? 0) * lvl;
      const en = ENERGY[def.id] ?? 0;
      if (en > 0) c.energySup += en * lvl; else c.energyDem += -en * lvl;
      const ef = def.eff;
      if (!ef) continue;
      const indM = def.cat === "Производство" ? 1 + d.ind * 0.15 : 1;
      const comM = def.cat === "Экономика" ? 1 + d.com * 0.18 : 1;
      const milM = def.cat === "Оборона" ? 1 + d.mil * 0.18 : 1;
      const sciM = def.cat === "Наука" ? 1 + d.sci * 0.18 : 1;
      const magM = def.cat === "Магия" ? 1 + d.mag * 0.2 : 1;
      const relM = def.cat === "Религия" ? 1 + d.rel * 0.18 : 1;
      const m = lvl * indM * comM * milM * sciM * magM * relM;
      c.food += (ef.food ?? 0) * m;
      c.water += (ef.water ?? 0) * m;
      c.health += (ef.health ?? 0) * m;
      c.crime += (ef.crime ?? 0) * m;
      c.pollution += (ef.pollution ?? 0) * m * (this.hasEdict("rayon_zapret") ? 0.5 : 1);
      c.culture += (ef.culture ?? 0) * m;
      c.faith += (ef.faith ?? 0) * m;
      c.science += (ef.science ?? 0) * m;
      c.order += (ef.order ?? 0) * m;
      c.goldEff += (ef.gold ?? 0) * m;
      c.happyEff += (ef.happy ?? 0) * m;
    }
    const pop = Math.max(1, this.s.pop);
    const met: CityMetrics = this.s.metrics;
    c.food += e.lore.techEffect("food") + e.lore.religionEffect("food") + e.lore.beastEffect("food");
    if (e.lore.buffs.food && e.day <= e.lore.buffs.food.until) c.food += e.lore.buffs.food.value;
    c.goldEff += e.lore.techEffect("gold") + e.lore.religionEffect("gold") + e.lore.beastEffect("gold") + e.lore.artEffect("gold");
    c.happyEff += e.lore.religionEffect("happy");
    met.food = Math.round(clamp01(c.food / (pop * 1.0)) * 100);
    met.water = Math.round(clamp01(c.water / (pop * 0.8)) * 100);
    met.energy = c.energyDem <= 0 ? 100 : Math.round(clamp01(c.energySup / c.energyDem) * 100);
    met.health = Math.round(clamp(38 + c.health * 2.2 - c.pollution * 0.7, 0, 100));
    const orderRed = c.order * 0.35 + (this.edictVal("crime") ?? 0);
    met.crime = Math.round(clamp(8 + pop * 0.06 + c.crime * 1.6 - orderRed, 0, 100));
    met.pollution = Math.round(clamp(c.pollution * 1.3, 0, 100));
    // технологии, вера и чары усиливают городские метрики
    met.culture = Math.round(c.culture + e.lore.techEffect("culture") + e.lore.religionEffect("culture") + e.lore.beastEffect("culture"));
    met.faith = Math.round(c.faith + (this.edictVal("faith") ?? 0) + e.lore.techEffect("faith") + e.lore.religionEffect("faith") + e.lore.artEffect("faith"));
    met.science = Math.round(c.science + (this.edictVal("science") ?? 0) + e.lore.techEffect("sci") + e.lore.religionEffect("sci") + e.lore.artEffect("sci"));
    met.order = Math.round(c.order + (this.edictVal("order") ?? 0));
    this.s.popCap = Math.floor(c.housing);
    this.s.jobs = Math.floor(c.jobs);
    const workforce = Math.max(1, this.s.pop * 0.62);
    this.s.employed = Math.floor(Math.min(workforce, c.jobs));
    this.s.tier = TIER_POP.filter((t) => this.s.pop >= t).length - 1;
  }

  unemployment(): number {
    const wf = Math.max(1, this.s.pop * 0.62);
    return Math.round(clamp01((wf - this.s.employed) / wf) * 100);
  }
  tierName(): string { return TIER_NAMES[clamp(this.s.tier, 0, TIER_NAMES.length - 1)]; }
  hasWonder(id: string): boolean { return this.cache.wonders.includes(id); }
  wonderCount(): number { return this.cache.wonders.length; }
  hasEdict(id: string): boolean { return (this.s.edicts[id] ?? -1) >= 0; }
  private edictVal(key: "crime" | "order" | "faith" | "science"): number {
    let v = 0;
    for (const id of Object.keys(this.s.edicts)) {
      const def = EDICTS.find((x) => x.id === id);
      if (def && def[key]) v += def[key]!;
    }
    return v;
  }
  /** Множитель скорости строек и мастерских */
  prodMul(e?: Engine): number {
    let m = 1 + this.s.districts.sci * 0.06;
    if (e) m *= 1 + e.lore.techEffect("prod");
    for (const id of Object.keys(this.s.edicts)) {
      const def = EDICTS.find((x) => x.id === id);
      if (def?.prod) m *= def.prod;
    }
    if (this.hasWonder("w_chasy")) m *= 1.25;
    if (this.hasWonder("w_kuznya")) m *= 1.3;
    if (this.s.rioting) m *= 0.5;
    return m;
  }
  taxMul(): number {
    let m = 1;
    for (const id of Object.keys(this.s.edicts)) {
      const def = EDICTS.find((x) => x.id === id);
      if (def?.taxMul) m *= def.taxMul;
    }
    return m;
  }
  happyTarget(): number {
    const c = this.cache, m = this.s.metrics, pop = Math.max(1, this.s.pop);
    let h = 45;
    h += m.food >= 100 ? 12 : -26 * (1 - m.food / 100);
    h += m.water >= 100 ? 8 : -20 * (1 - m.water / 100);
    h += m.energy >= 100 ? 4 : -10 * (1 - m.energy / 100);
    h += Math.min(20, c.culture / (2 + pop * 0.12));
    h += Math.min(14, m.faith / (2 + pop * 0.16));
    h += Math.min(12, m.health / 7);
    h -= Math.min(26, m.crime * 0.34);
    h -= Math.min(18, m.pollution * 0.35);
    h -= this.unemployment() * 0.22;
    h -= Math.max(0, this.s.taxRate - 10) * 0.85;
    h += c.happyEff;
    for (const id of Object.keys(this.s.edicts)) {
      const def = EDICTS.find((x) => x.id === id);
      if (def?.happy) h += def.happy;
    }
    if (this.s.paradeT > 0) h += 10;
    if (this.s.rioting) h -= 15;
    return clamp(h, 0, 100);
  }
  incomePerSec(e?: Engine): number {
    const c = this.cache;
    let gross = this.s.pop * (this.s.taxRate / 100) * 0.06 * (1 + this.s.districts.com * 0.3) * this.taxMul()
      + c.goldEff * 0.035;
    if (e) {
      gross *= e.dynasty.govDef().tax;
      if (e.lore.buffs.gold && e.day <= e.lore.buffs.gold.until) gross *= 1 + e.lore.buffs.gold.value;
    }
    const net = gross * (this.s.rioting ? 0.3 : 1) - c.upkeep * 0.02;
    return net;
  }

  // ---------- Городской склад ----------
  stockOf(id: string): number { return Math.floor(this.s.stock[id] ?? 0); }
  addStock(id: string, n: number) { this.s.stock[id] = (this.s.stock[id] ?? 0) + n; }
  takeStock(id: string, n: number): boolean {
    if (this.stockOf(id) < n) return false;
    this.s.stock[id] -= n;
    if (this.s.stock[id] < 0.001) delete this.s.stock[id];
    return true;
  }
  depositToCity(e: Engine, id: string, n: number) {
    const have = e.count(id);
    const take = Math.min(have, n);
    if (take <= 0) { e.toast("Нечего сдавать", "warn"); return; }
    e.take(id, take);
    this.addStock(id, take);
    e.toast(`На склад: ${ITEMS[id]?.name ?? id} ×${take}`, "good");
    snd.pickup();
  }
  withdrawFromCity(e: Engine, id: string, n: number) {
    const take = Math.min(this.stockOf(id), n);
    if (take <= 0) { e.toast("Склад пуст", "warn"); return; }
    this.takeStock(id, take);
    e.give(id, take, true);
    e.toast(`Со склада: ${ITEMS[id]?.name ?? id} ×${take}`, "good");
    snd.pickup();
  }

  // ---------- Указы ----------
  issueEdict(e: Engine, id: string) {
    const def = EDICTS.find((x) => x.id === id);
    if (!def) return;
    if (this.hasEdict(id)) { e.toast("Указ уже действует", "warn"); return; }
    if (e.player.gold < def.cost) { e.toast(`Нужно ${def.cost} золота`, "warn"); return; }
    e.player.gold -= def.cost;
    this.s.edicts[id] = e.day + def.days;
    e.stats.edict = (e.stats.edict ?? 0) + 1;
    e.toast(`Указ объявлен: «${def.name}»`, "good");
    snd.craft();
    if (def.happy && def.happy > 0) this.s.paradeT = Math.max(this.s.paradeT, 4);
    e.dynasty.onEdict(e, def);
    e.poke();
  }
  parade(e: Engine) {
    const cost = 60 + Math.floor(this.s.pop * 4);
    if (e.player.gold < cost) { e.toast(`На парад нужно ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    this.s.paradeT = 14;
    this.s.riot = Math.max(0, this.s.riot - 45);
    e.toast("Парад! Знамёна, барабаны и фейерверки над городом", "good");
    snd.levelup();
    e.dynasty.support("narod", 8);
    e.poke();
  }
  setDistrict(d: District, v: number) { this.s.districts[d] = clamp(v, 0, 2); }
  setTax(v: number) { this.s.taxRate = clamp(Math.round(v), 0, 50); }

  // ---------- Бунт ----------
  suppress(e: Engine, mode: "army" | "concede") {
    if (!this.s.rioting) return;
    if (mode === "army") {
      if (this.s.metrics.order < 25) { e.toast("Гарнизон слишком слаб — нужны казармы и порядок", "warn"); return; }
      this.s.rioting = false; this.s.riot = 0;
      this.s.happiness = clamp(this.s.happiness - 10, 0, 100);
      e.toast("Бунт подавлен силой. Улицы тихи, но взгляды косые", "warn");
      e.dynasty.support("armiya", 10);
      e.dynasty.support("narod", -14);
      snd.monster();
    } else {
      const cost = Math.floor(80 + this.s.pop * 10);
      if (e.player.gold < cost) { e.toast(`На уступки нужно ${cost} золота`, "warn"); return; }
      e.player.gold -= cost;
      this.s.rioting = false; this.s.riot = 0;
      this.s.taxRate = clamp(this.s.taxRate - 5, 0, 50);
      this.s.happiness = clamp(this.s.happiness + 16, 0, 100);
      e.toast("Вы пошли на уступки. Народ расходится с песнями", "good");
      e.dynasty.support("narod", 12);
      e.dynasty.support("znat", -8);
      snd.craft();
    }
    e.npcs.calmRiot();
    e.poke();
  }

  // ---------- Улучшение зданий ----------
  upgradeCost(b: Building): { cost: [string, number][]; gold: number; can: boolean } {
    const def = BUILDINGS[b.def];
    const lvl = b.lvl ?? 1;
    const mul = 0.7 + lvl * 0.55;
    const cost = def.cost.map(([id, n]) => [id, Math.ceil(n * mul)] as [string, number]);
    const gold = Math.floor(40 * lvl * (def.wonder ? 8 : 1) + def.buildTime * 4);
    return { cost, gold, can: lvl < (def.maxLvl ?? 3) };
  }
  upgrade(e: Engine, b: Building) {
    const def = BUILDINGS[b.def];
    const u = this.upgradeCost(b);
    if (!u.can) { e.toast(`${def.name}: уже высший уровень`, "info"); return; }
    for (const [id, n] of u.cost) if (e.count(id) < n) { e.toast(`Не хватает: ${ITEMS[id]?.name ?? id} (${e.count(id)}/${n})`, "warn"); return; }
    if (e.player.gold < u.gold) { e.toast(`Нужно ${u.gold} золота`, "warn"); return; }
    for (const [id, n] of u.cost) e.take(id, n);
    e.player.gold -= u.gold;
    b.lvl = (b.lvl ?? 1) + 1;
    e.toast(`${def.name} улучшен до уровня ${b.lvl}`, "good");
    snd.craft();
    e.spawnHitParticles((b.tx + def.w / 2) * 40, (b.ty + def.h / 2) * 40, "#f2d38a", 16, "star");
    e.addXp(8 + b.lvl * 3);
    this.recompute(e);
    e.poke();
  }

  // ---------- Производственные цепочки ----------
  private runChains(e: Engine, dt: number) {
    const mul = this.prodMul(e);
    for (const b of e.buildings) {
      if (!b.done) continue;
      const def = BUILDINGS[b.def];
      if (!def?.chain) continue;
      const lvl = b.lvl ?? 1;
      b.chainT = (b.chainT ?? 0) + dt * mul * (1 + (lvl - 1) * 0.45);
      if (b.chainT < def.chain.every) continue;
      const ok = def.chain.in.every(([id, n]) => this.stockOf(id) >= n || (id === "zoloto" && e.player.gold >= n));
      if (!ok) { b.chainT = def.chain.every; continue; }
      b.chainT = 0;
      for (const [id, n] of def.chain.in) {
        if (id === "zoloto" && this.stockOf("zoloto") < n) e.player.gold -= n;
        else this.takeStock(id, n);
      }
      const [oid, on] = def.chain.out;
      this.addStock(oid, on * lvl);
      b.smoke = 1.6;
      if (e.distTo((b.tx + 0.5) * 40, (b.ty + 0.5) * 40) < 14) {
        e.addFloater(`+${on * lvl} ${ITEMS[oid]?.name ?? oid}`, "#a8d8f2", (b.tx + def.w / 2) * 40, b.ty * 40);
      }
    }
  }

  // ---------- Главный тик ----------
  update(e: Engine, dt: number) {
    if (!this.s.founded) return;
    this.recT -= dt;
    if (this.recT <= 0) { this.recT = 0.6; this.recompute(e); }

    // счастье плавно тянется к цели
    this.s.happiness = lerp(this.s.happiness, this.happyTarget(), 1 - Math.pow(0.35, dt));

    // рост населения
    const limit = Math.min(
      this.s.popCap,
      this.cache.food / 1.0,
      this.cache.water / 0.8
    );
    if (this.s.pop < limit && this.s.happiness > 34 && !this.s.rioting) {
      const rate = 0.038 * (1 + this.s.districts.res * 0.5) * (this.s.happiness / 100) * (1 + this.s.metrics.health / 300);
      this.s.pop = Math.min(limit, this.s.pop + dt * rate);
    } else if (this.s.pop > limit + 0.5) {
      this.s.pop = Math.max(0, this.s.pop - dt * 0.05);
    }
    const pi = Math.floor(this.s.pop);
    if (pi > this.lastPopInt) {
      if (this.lastPopInt > 0 && pi % 5 === 0) {
        e.toast(`${this.s.name}: жителей уже ${pi}`, "good");
        this.s.paradeT = Math.max(this.s.paradeT, 2.5);
      }
      e.npcs.syncPopulation(e);
      this.lastPopInt = pi;
    } else if (pi < this.lastPopInt) {
      this.lastPopInt = pi;
      e.npcs.syncPopulation(e);
    }

    // доход
    this.goldAcc += this.incomePerSec(e) * dt;
    if (this.goldAcc >= 1) {
      const add = Math.floor(this.goldAcc);
      this.goldAcc -= add;
      e.player.gold += add;
      this.s.totalTax += add;
    } else if (this.goldAcc < -1) {
      const sub = Math.ceil(-this.goldAcc);
      this.goldAcc += sub;
      e.player.gold = Math.max(0, e.player.gold - sub);
    }

    // цепочки
    this.runChains(e, dt);

    // напряжение и бунт
    if (this.s.happiness < 30) {
      this.s.riot = clamp(this.s.riot + dt * (30 - this.s.happiness) * 0.16, 0, 100);
      this.s.unrestNote = this.s.metrics.food < 80 ? "Народ голодает" :
        this.s.metrics.water < 80 ? "В городе нехватка воды" :
          this.s.taxRate > 22 ? "Налоги душат людей" :
            this.unemployment() > 45 ? "Слишком много безработных" : "Жители несчастны";
    } else {
      this.s.riot = Math.max(0, this.s.riot - dt * 4);
      if (this.s.riot <= 0) this.s.unrestNote = "";
    }
    if (!this.s.rioting && this.s.riot >= 100) {
      this.s.rioting = true;
      e.toast(`БУНТ в городе «${this.s.name}»! ${this.s.unrestNote}`, "bad");
      snd.thunder();
      e.shake = 0.6;
      e.npcs.startRiot(e);
      e.dynasty.support("narod", -10);
    }
    if (this.s.rioting) {
      // бунт постепенно портит постройки
      if (Math.random() < dt * 0.2) {
        const b = e.buildings[Math.floor(Math.random() * e.buildings.length)];
        if (b && b.done && !BUILDINGS[b.def]?.townhall) {
          e.spawnHitParticles((b.tx + 0.5) * 40, (b.ty + 0.5) * 40, "#c94f5d", 6, "ember");
        }
      }
      if (this.s.happiness > 52) { this.s.rioting = false; this.s.riot = 0; e.toast("Бунт утих сам собой — жизнь налаживается", "good"); e.npcs.calmRiot(); }
    }

    if (this.s.paradeT > 0) this.s.paradeT -= dt;
  }

  dayTick(e: Engine) {
    if (!this.s.founded) return;
    // истечение указов
    for (const [id, until] of Object.entries(this.s.edicts)) {
      if (e.day > until) {
        delete this.s.edicts[id];
        const def = EDICTS.find((x) => x.id === id);
        if (def) e.toast(`Указ «${def.name}» истёк`, "info");
      }
    }
    this.s.history.push(Math.floor(this.s.pop));
    if (this.s.history.length > 60) this.s.history.shift();
  }
}
