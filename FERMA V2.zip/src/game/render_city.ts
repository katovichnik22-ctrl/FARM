import type { BuildingDef, Building, Npc, TradeRoute } from "../types";
import { TILE } from "../types";
import { NPC_ROLES } from "../types/city";
import { getShadowSprite } from "./sprites";
import { hash2 } from "../lib/noise";
import { shade } from "./sprites_objects";

// ===== Визуал города: универсальные здания, жители, караваны, дым, огни =====

const CAT_PAL: Record<string, { wall: string; wall2: string; roof: string; trim: string }> = {
  "Жильё": { wall: "#a8845c", wall2: "#8a6a44", roof: "#7a4a3a", trim: "#f2d38a" },
  "Производство": { wall: "#8a7f72", wall2: "#6f665c", roof: "#5d4a3a", trim: "#d9a05b" },
  "Еда": { wall: "#c2a96f", wall2: "#a08a55", roof: "#8a6a3a", trim: "#e8d9a0" },
  "Оборона": { wall: "#8e8a86", wall2: "#6f6b66", roof: "#4a4a52", trim: "#b8c2cc" },
  "Наука": { wall: "#8fa2b8", wall2: "#6d8096", roof: "#3f5a75", trim: "#cfe4f5" },
  "Магия": { wall: "#6a5a8a", wall2: "#4e4268", roof: "#2e2545", trim: "#b89af2" },
  "Экономика": { wall: "#c0a875", wall2: "#9c865a", roof: "#6d5a35", trim: "#f2c14e" },
  "Религия": { wall: "#cfc4ab", wall2: "#ada386", roof: "#8a7a5c", trim: "#f5e6bd" },
  "Досуг": { wall: "#b08a72", wall2: "#8f6c58", roof: "#8a4a4a", trim: "#f2a24d" },
  "Город": { wall: "#c4b393", wall2: "#a08f72", roof: "#7a5a4a", trim: "#f2c14e" },
  "Чудеса": { wall: "#dfd2ae", wall2: "#bfae86", roof: "#b58a3a", trim: "#ffd97a" },
};

/** Кратность внутреннего разрешения спрайтов зданий */
export const BS = 2;

/** Универсальный процедурный спрайт для городских построек */
export function genericBuilding(ctx: CanvasRenderingContext2D, def: BuildingDef, W: number, H: number, lvl: number) {
  const pal = CAT_PAL[def.cat] ?? CAT_PAL["Жильё"];
  const cx = W / 2;
  const base = H - 8;
  const seed = def.id.length * 31 + lvl * 7;
  const floors = Math.min(4, (def.wonder ? 3 : 1) + Math.floor((lvl - 1) * 0.9) + (def.h >= 3 ? 1 : 0));
  const bw = W * 0.84;
  const fh = Math.min(TILE * 0.7, (H - 30) / (floors + 0.9));

  // ---- фундамент из камня ----
  const fnd = base - 1;
  ctx.fillStyle = "#6e675e";
  ctx.beginPath();
  ctx.roundRect(cx - bw / 2 - 3, fnd - 7, bw + 6, 9, 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(24,20,17,0.8)";
  ctx.lineWidth = 1;
  ctx.stroke();
  for (let i = 0; i < 6; i++) {
    const sx = cx - bw / 2 - 2 + (i / 6) * (bw + 4);
    ctx.fillStyle = i % 2 ? "#867e73" : "#5d564e";
    ctx.beginPath();
    ctx.roundRect(sx, fnd - 6, (bw + 4) / 6 - 1.6, 7, 1.4);
    ctx.fill();
  }
  ctx.fillStyle = "rgba(255,250,235,0.18)";
  ctx.fillRect(cx - bw / 2 - 3, fnd - 7, bw + 6, 1.6);

  // ---- этажи ----
  for (let f = 0; f < floors; f++) {
    const shrink = 1 - f * 0.07;
    const w = bw * shrink;
    const y = fnd - 6 - fh * (f + 1);
    // корпус с боковым объёмом
    const g = ctx.createLinearGradient(cx - w / 2, 0, cx + w / 2, 0);
    g.addColorStop(0, shade(f % 2 ? pal.wall2 : pal.wall, 0.16));
    g.addColorStop(0.42, f % 2 ? pal.wall2 : pal.wall);
    g.addColorStop(1, shade(pal.wall2, -0.3));
    ctx.fillStyle = g;
    ctx.fillRect(cx - w / 2, y, w, fh);
    ctx.strokeStyle = "rgba(28,20,14,0.7)";
    ctx.lineWidth = 1;
    ctx.strokeRect(cx - w / 2 + 0.5, y + 0.5, w - 1, fh - 1);

    // кладка или брёвна по категории
    ctx.save();
    ctx.beginPath(); ctx.rect(cx - w / 2, y, w, fh); ctx.clip();
    if (def.cat === "Оборона" || def.cat === "Наука" || def.cat === "Религия" || def.wonder) {
      // каменная кладка вразбежку
      ctx.strokeStyle = "rgba(0,0,0,0.2)";
      ctx.lineWidth = 0.9;
      const bh = fh / 3;
      for (let r = 0; r <= 3; r++) {
        const by2 = y + r * bh;
        ctx.beginPath(); ctx.moveTo(cx - w / 2, by2); ctx.lineTo(cx + w / 2, by2); ctx.stroke();
        for (let k = 0; k < 4; k++) {
          const px = cx - w / 2 + ((k + (r % 2) * 0.5) / 4) * w;
          ctx.beginPath(); ctx.moveTo(px, by2); ctx.lineTo(px, by2 + bh); ctx.stroke();
        }
      }
      ctx.fillStyle = "rgba(255,255,255,0.07)";
      for (let r = 0; r < 3; r++) ctx.fillRect(cx - w / 2, y + r * bh, w, 1);
    } else {
      // горизонтальные брёвна сруба
      const logs = Math.max(3, Math.round(fh / 5));
      for (let i = 0; i < logs; i++) {
        const ly = y + (i / logs) * fh;
        const lh = fh / logs;
        ctx.fillStyle = i % 2 ? "rgba(255,244,220,0.07)" : "rgba(20,12,6,0.12)";
        ctx.fillRect(cx - w / 2, ly, w, lh);
        ctx.strokeStyle = "rgba(24,16,8,0.32)";
        ctx.lineWidth = 0.7;
        ctx.beginPath(); ctx.moveTo(cx - w / 2, ly + lh); ctx.lineTo(cx + w / 2, ly + lh); ctx.stroke();
      }
      // торцы брёвен по углам
      ctx.fillStyle = shade(pal.wall, 0.2);
      for (const dx of [-1, 1]) {
        for (let i = 0; i < logs; i += 2) {
          ctx.beginPath();
          ctx.ellipse(cx + dx * (w / 2 - 1), y + (i / logs) * fh + fh / logs / 2, 2.2, fh / logs / 2, 0, 0, 7);
          ctx.fill();
        }
      }
    }
    // затенение снизу этажа
    const sg = ctx.createLinearGradient(0, y + fh * 0.5, 0, y + fh);
    sg.addColorStop(0, "rgba(16,10,6,0)");
    sg.addColorStop(1, "rgba(16,10,6,0.28)");
    ctx.fillStyle = sg;
    ctx.fillRect(cx - w / 2, y, w, fh);
    ctx.restore();

    // окна с рамой и переплётом
    const wins = Math.max(2, Math.floor(w / 18));
    for (let i = 0; i < wins; i++) {
      const wx = cx - w / 2 + 7 + i * ((w - 14) / Math.max(1, wins - 1)) - 4;
      const wy = y + fh * 0.24;
      const ww = 8, wh = fh * 0.4;
      ctx.fillStyle = shade(pal.trim, -0.45);
      ctx.fillRect(wx - 1.2, wy - 1.2, ww + 2.4, wh + 2.4);
      const wg = ctx.createLinearGradient(wx, wy, wx + ww, wy + wh);
      wg.addColorStop(0, "rgba(46,38,32,0.95)");
      wg.addColorStop(1, "rgba(22,18,16,0.95)");
      ctx.fillStyle = wg;
      ctx.fillRect(wx, wy, ww, wh);
      ctx.strokeStyle = "rgba(255,250,232,0.22)";
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(wx + ww / 2, wy); ctx.lineTo(wx + ww / 2, wy + wh);
      ctx.moveTo(wx, wy + wh / 2); ctx.lineTo(wx + ww, wy + wh / 2);
      ctx.stroke();
      // блик стекла
      ctx.fillStyle = "rgba(180,210,235,0.18)";
      ctx.beginPath();
      ctx.moveTo(wx, wy + wh * 0.7); ctx.lineTo(wx + ww * 0.7, wy); ctx.lineTo(wx + ww, wy); ctx.lineTo(wx, wy + wh);
      ctx.closePath(); ctx.fill();
    }
  }
  const topY = fnd - 6 - fh * floors;

  // ---- крыша ----
  const roofShade = shade(pal.roof, -0.32);
  if (def.cat === "Религия" || def.cat === "Магия") {
    // шпиль
    ctx.beginPath();
    ctx.moveTo(cx - bw * 0.56, topY);
    ctx.lineTo(cx, topY - fh * 1.6);
    ctx.lineTo(cx + bw * 0.56, topY);
    ctx.closePath();
    const rg = ctx.createLinearGradient(cx - bw * 0.5, topY - fh, cx + bw * 0.5, topY);
    rg.addColorStop(0, shade(pal.roof, 0.18));
    rg.addColorStop(0.5, pal.roof);
    rg.addColorStop(1, roofShade);
    ctx.fillStyle = rg;
    ctx.fill();
    ctx.strokeStyle = "rgba(20,12,8,0.75)"; ctx.lineWidth = 1; ctx.stroke();
    ctx.strokeStyle = pal.trim; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(cx, topY - fh * 1.6); ctx.lineTo(cx, topY - fh * 2.3); ctx.stroke();
    if (def.cat === "Религия") {
      ctx.beginPath(); ctx.moveTo(cx - 4, topY - fh * 2.05); ctx.lineTo(cx + 4, topY - fh * 2.05); ctx.stroke();
    } else {
      ctx.fillStyle = pal.trim;
      ctx.beginPath(); ctx.arc(cx, topY - fh * 2.4, 3.4, 0, 7); ctx.fill();
    }
  } else if (def.cat === "Наука") {
    // купол с черепицей
    ctx.beginPath(); ctx.ellipse(cx, topY, bw * 0.46, fh * 1.05, 0, Math.PI, 0); ctx.fill();
    const dg = ctx.createLinearGradient(cx - bw * 0.4, topY - fh, cx + bw * 0.4, topY);
    dg.addColorStop(0, shade(pal.roof, 0.24));
    dg.addColorStop(0.55, pal.roof);
    dg.addColorStop(1, roofShade);
    ctx.fillStyle = dg;
    ctx.beginPath(); ctx.ellipse(cx, topY, bw * 0.46, fh * 1.05, 0, Math.PI, 0); ctx.fill();
    ctx.strokeStyle = "rgba(20,14,10,0.6)"; ctx.lineWidth = 0.8;
    for (let i = 1; i < 5; i++) {
      ctx.beginPath();
      ctx.ellipse(cx, topY, bw * 0.46 * (i / 5), fh * 1.05 * (i / 5), 0, Math.PI, 0);
      ctx.stroke();
    }
    ctx.strokeStyle = pal.trim; ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.moveTo(cx, topY - fh * 1.05); ctx.lineTo(cx + 9, topY - fh * 1.7); ctx.stroke();
  } else if (def.cat === "Оборона") {
    // зубцы
    ctx.fillStyle = pal.wall2;
    for (let i = 0; i < 5; i++) {
      const zx = cx - bw / 2 + i * (bw / 5);
      ctx.fillRect(zx, topY - 7, bw / 9, 8);
      ctx.fillStyle = "rgba(255,250,235,0.16)";
      ctx.fillRect(zx, topY - 7, bw / 9, 1.4);
      ctx.fillStyle = pal.wall2;
    }
    ctx.fillStyle = pal.roof;
    ctx.fillRect(cx - bw / 2, topY - 2, bw, 4);
    ctx.fillStyle = "rgba(20,14,10,0.3)";
    ctx.fillRect(cx - bw / 2, topY + 1, bw, 1.6);
  } else {
    // двускатная с черепицей/соломой
    const straw = def.cat === "Еда" || def.cat === "Жильё";
    ctx.beginPath();
    ctx.moveTo(cx - bw * 0.6, topY + 2);
    ctx.lineTo(cx, topY - fh * 1.05);
    ctx.lineTo(cx + bw * 0.6, topY + 2);
    ctx.closePath();
    const rg = ctx.createLinearGradient(cx - bw * 0.5, topY - fh, cx + bw * 0.5, topY);
    rg.addColorStop(0, shade(pal.roof, 0.2));
    rg.addColorStop(0.45, pal.roof);
    rg.addColorStop(1, roofShade);
    ctx.fillStyle = rg;
    ctx.fill();
    ctx.strokeStyle = "rgba(18,10,6,0.8)"; ctx.lineWidth = 1; ctx.stroke();
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(cx - bw * 0.6, topY + 2);
    ctx.lineTo(cx, topY - fh * 1.05);
    ctx.lineTo(cx + bw * 0.6, topY + 2);
    ctx.closePath();
    ctx.clip();
    if (straw) {
      // соломенные пряди
      ctx.strokeStyle = "rgba(40,26,12,0.32)";
      ctx.lineWidth = 0.8;
      for (let i = 0; i < 18; i++) {
        const t2 = i / 17;
        const sx = cx - bw * 0.6 + t2 * bw * 1.2;
        ctx.beginPath();
        ctx.moveTo(sx, topY + 2);
        ctx.lineTo(cx + (sx - cx) * 0.12, topY - fh * 0.95);
        ctx.stroke();
      }
      ctx.strokeStyle = "rgba(255,238,190,0.2)";
      for (let i = 0; i < 9; i++) {
        const sx = cx - bw * 0.55 + (i / 8) * bw * 1.1;
        ctx.beginPath();
        ctx.moveTo(sx, topY + 1);
        ctx.lineTo(cx + (sx - cx) * 0.14, topY - fh * 0.8);
        ctx.stroke();
      }
    } else {
      // черепица рядами
      const rows = 5;
      for (let r = 0; r < rows; r++) {
        const ry = topY + 2 - (r / rows) * fh * 1.05;
        const rw = bw * 1.2 * (1 - r / rows);
        for (let k = 0; k < 8; k++) {
          const tx2 = cx - rw / 2 + (k / 8) * rw;
          ctx.fillStyle = (k + r) % 2 ? shade(pal.roof, -0.14) : shade(pal.roof, 0.08);
          ctx.beginPath();
          ctx.roundRect(tx2, ry - fh * 0.2, rw / 8 - 0.8, fh * 0.2, 1.2);
          ctx.fill();
        }
      }
    }
    // конёк и тень справа
    ctx.fillStyle = "rgba(16,10,6,0.28)";
    ctx.beginPath();
    ctx.moveTo(cx, topY - fh * 1.05); ctx.lineTo(cx + bw * 0.6, topY + 2); ctx.lineTo(cx, topY + 2);
    ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.strokeStyle = shade(pal.trim, -0.2);
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(cx - bw * 0.6, topY + 2); ctx.lineTo(cx, topY - fh * 1.05); ctx.lineTo(cx + bw * 0.6, topY + 2);
    ctx.stroke();
  }

  // труба для производств
  if (def.cat === "Производство" || def.chain) {
    const px = cx + bw * 0.26;
    ctx.fillStyle = shade(pal.wall2, -0.15);
    ctx.fillRect(px, topY - fh * 1.5, 9, fh * 1.3);
    ctx.strokeStyle = "rgba(20,14,10,0.7)"; ctx.lineWidth = 0.9;
    ctx.strokeRect(px + 0.5, topY - fh * 1.5, 8, fh * 1.3);
    ctx.fillStyle = "#4a3f38";
    ctx.fillRect(px - 1.6, topY - fh * 1.56, 12, 4.4);
    ctx.fillStyle = "rgba(255,250,235,0.16)";
    ctx.fillRect(px, topY - fh * 1.5, 2, fh * 1.3);
  }

  // ---- дверь с петлями и ручкой ----
  const dw = 15, dh = fh * 0.82;
  const dx0 = cx - dw / 2, dy0 = fnd - 6 - dh;
  ctx.fillStyle = shade(pal.trim, -0.55);
  ctx.fillRect(dx0 - 1.4, dy0 - 1.4, dw + 2.8, dh + 1.8);
  const dg2 = ctx.createLinearGradient(dx0, 0, dx0 + dw, 0);
  dg2.addColorStop(0, "#5c4227");
  dg2.addColorStop(0.45, "#43301c");
  dg2.addColorStop(1, "#2c1f12");
  ctx.fillStyle = dg2;
  ctx.fillRect(dx0, dy0, dw, dh);
  ctx.strokeStyle = "rgba(90,70,44,0.7)";
  ctx.lineWidth = 0.8;
  for (let i = 1; i < 3; i++) {
    ctx.beginPath(); ctx.moveTo(dx0 + (i / 3) * dw, dy0); ctx.lineTo(dx0 + (i / 3) * dw, dy0 + dh); ctx.stroke();
  }
  // петли
  ctx.fillStyle = "#6f665c";
  ctx.fillRect(dx0 + 0.6, dy0 + dh * 0.16, 3.6, 2.2);
  ctx.fillRect(dx0 + 0.6, dy0 + dh * 0.68, 3.6, 2.2);
  // ручка
  ctx.fillStyle = pal.trim;
  ctx.beginPath(); ctx.arc(dx0 + dw - 3.4, dy0 + dh * 0.5, 1.5, 0, 7); ctx.fill();
  // ступенька
  ctx.fillStyle = "#7d766c";
  ctx.beginPath(); ctx.roundRect(cx - dw * 0.7, fnd - 6, dw * 1.4, 3, 1); ctx.fill();

  // вывеска-акцент и флаг
  ctx.fillStyle = pal.trim;
  ctx.globalAlpha = 0.9;
  ctx.fillRect(cx - bw * 0.3, fnd - 6 - fh * 0.95, bw * 0.6, 2.6);
  ctx.globalAlpha = 1;
  if (def.cat === "Город" || def.cat === "Досуг" || def.wonder) {
    ctx.strokeStyle = "#6d4c33"; ctx.lineWidth = 2;
    const fx = cx - bw * 0.46;
    ctx.beginPath(); ctx.moveTo(fx, topY); ctx.lineTo(fx, topY - 17); ctx.stroke();
    ctx.fillStyle = def.wonder ? "#ffd97a" : "#c94f5d";
    ctx.beginPath();
    ctx.moveTo(fx, topY - 17); ctx.lineTo(fx + 12, topY - 13.5); ctx.lineTo(fx, topY - 10);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "rgba(20,12,8,0.5)"; ctx.lineWidth = 0.8; ctx.stroke();
  }
  // звёздочки уровня
  for (let i = 0; i < lvl - 1; i++) {
    ctx.fillStyle = "#ffd97a";
    ctx.strokeStyle = "rgba(60,40,10,0.6)";
    ctx.lineWidth = 0.7;
    const sx = cx - 8 + i * 8;
    const sy = topY - (def.wonder ? 34 : 16) - hash2(seed, i, 2) * 2;
    ctx.beginPath();
    for (let k = 0; k < 10; k++) {
      const a = (k / 10) * Math.PI * 2 - Math.PI / 2;
      const r = k % 2 ? 1.3 : 3;
      k ? ctx.lineTo(sx + Math.cos(a) * r, sy + Math.sin(a) * r) : ctx.moveTo(sx + Math.cos(a) * r, sy + Math.sin(a) * r);
    }
    ctx.closePath(); ctx.fill(); ctx.stroke();
  }
}

/** Дорога рисуется поверх земли, до строений */
export function drawRoad(ctx: CanvasRenderingContext2D, b: Building, now: number) {
  const x = b.tx * TILE, y = b.ty * TILE;
  ctx.fillStyle = "#96876d";
  ctx.fillRect(x, y, TILE, TILE);
  ctx.fillStyle = "#87795f";
  for (let i = 0; i < 7; i++) {
    const rx = x + hash2(b.uid, i, 1) * (TILE - 8) + 2;
    const ry = y + hash2(b.uid, i, 2) * (TILE - 8) + 2;
    ctx.beginPath();
    ctx.ellipse(rx, ry, 3.6, 2.6, hash2(b.uid, i, 3) * 3, 0, 7);
    ctx.fill();
  }
  ctx.strokeStyle = "rgba(0,0,0,0.12)";
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 0.5, y + 0.5, TILE - 1, TILE - 1);
  void now;
}

/** Тёплые окна ночью + дым из труб */
export function drawBuildingLife(
  ctx: CanvasRenderingContext2D, b: Building, def: BuildingDef,
  night: number, now: number, particles: { push: (p: unknown) => void }
) {
  const bx = b.tx * TILE, by = (b.ty + def.h) * TILE;
  const lvl = b.lvl ?? 1;
  // окна
  if (night > 0.25 && (def.housing || def.jobs)) {
    const n = Math.min(8, 2 + Math.floor(((def.housing ?? 0) + (def.jobs ?? 0)) / 6) + lvl);
    for (let i = 0; i < n; i++) {
      const fl = 0.55 + Math.sin(now * 2.2 + i * 1.7 + b.uid) * 0.2;
      if (hash2(b.uid, i, 9) < 0.25) continue;
      const wx = bx + 8 + (i % 4) * ((def.w * TILE - 20) / 3);
      const wy = by - 26 - Math.floor(i / 4) * 20;
      ctx.fillStyle = `rgba(255,198,110,${(0.55 * night * fl).toFixed(2)})`;
      ctx.fillRect(wx, wy, 7, 8);
      ctx.fillStyle = `rgba(255,220,150,${(0.22 * night * fl).toFixed(2)})`;
      ctx.fillRect(wx - 3, wy - 3, 13, 14);
    }
  }
  // дым
  const hearth = def.id === "dom" || def.id === "pekarnya" || def.id === "kuznica" || def.id === "taverna";
  const smoking = def.cat === "Производство" || def.chain || hearth || (b.smoke ?? 0) > 0;
  if (smoking && Math.random() < 0.08 + (b.smoke ?? 0) * 0.07) {
    const px = bx + def.w * TILE * (hearth ? 0.7 : 0.72);
    const py = by - def.h * TILE * 0.85 - (hearth ? 18 : 12);
    // клуб дыма: несколько шариков разного размера
    for (let i = 0; i < 2; i++) {
      particles.push({
        x: px + (Math.random() - 0.5) * 4, y: py,
        vx: 4 + Math.random() * 9, vy: -12 - Math.random() * 12,
        age: 0, life: 2.4 + Math.random() * 1.2,
        color: i ? "rgba(196,188,178,0.42)" : "rgba(150,142,134,0.5)",
        size: 2.4 + Math.random() * 3.4, grav: -5, kind: "puff",
      });
    }
  }
}

/** Житель города */
export function drawNpc(ctx: CanvasRenderingContext2D, n: Npc, now: number) {
  const meta = NPC_ROLES[n.role];
  const s = n.role === "rebenok" ? 0.68 : n.role === "starik" ? 0.9 : 1;
  const moving = Math.abs(n.tx - n.x) + Math.abs(n.ty - n.y) > 10;
  const bob = moving ? Math.sin(n.bob * 9) * 1.4 : Math.sin(n.bob * 1.8) * 0.6;
  const shadow = getShadowSprite();
  ctx.drawImage(shadow, n.x - 13 * s, n.y - 3, 26 * s, 10 * s);

  ctx.save();
  ctx.translate(n.x, n.y - 10 * s + bob);
  ctx.scale(s, s);
  // тело
  ctx.fillStyle = meta.color;
  ctx.beginPath();
  ctx.moveTo(-5, 2); ctx.lineTo(-3.6, -8); ctx.lineTo(3.6, -8); ctx.lineTo(5, 2);
  ctx.closePath(); ctx.fill();
  // ноги
  ctx.strokeStyle = "#3f342b"; ctx.lineWidth = 2;
  const legs = moving ? Math.sin(n.bob * 9) * 2.6 : 0;
  ctx.beginPath(); ctx.moveTo(-2, 2); ctx.lineTo(-2 + legs, 7); ctx.moveTo(2, 2); ctx.lineTo(2 - legs, 7); ctx.stroke();
  // голова
  ctx.fillStyle = "#e8b68a";
  ctx.beginPath(); ctx.arc(0, -12, 4.4, 0, 7); ctx.fill();
  // шапка/капюшон по роли
  ctx.fillStyle = n.role === "strazhnik" ? "#9aa2ad" : n.role === "mag" ? "#6a4ac9" :
    n.role === "svyashennik" ? "#e8e0cc" : n.role === "kupec" ? "#c9a227" : "#5d4a34";
  ctx.beginPath(); ctx.arc(0, -13.4, 4.6, Math.PI, Math.PI * 2); ctx.fill();
  if (n.role === "mag") {
    ctx.beginPath();
    ctx.moveTo(-4.6, -13.4); ctx.lineTo(0, -22); ctx.lineTo(4.6, -13.4);
    ctx.closePath(); ctx.fill();
  }
  if (n.role === "strazhnik") {
    ctx.strokeStyle = "#8a6a44"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(6, -8); ctx.lineTo(6, -20); ctx.stroke();
    ctx.fillStyle = "#c8ced6";
    ctx.beginPath(); ctx.moveTo(6, -20); ctx.lineTo(4, -24); ctx.lineTo(8, -24); ctx.closePath(); ctx.fill();
  }
  ctx.restore();

  // бунт — кулак и алый нимб
  if (n.state === "riot") {
    ctx.fillStyle = `rgba(230,70,60,${(0.35 + Math.sin(now * 8 + n.uid) * 0.15).toFixed(2)})`;
    ctx.beginPath(); ctx.arc(n.x, n.y - 22 * s, 9, 0, 7); ctx.fill();
  }
  // реплика
  if (n.talkT > 0) {
    ctx.fillStyle = "rgba(245,240,230,0.9)";
    ctx.beginPath();
    ctx.roundRect(n.x + 6, n.y - 38 * s, 22, 13, 6);
    ctx.fill();
    ctx.fillStyle = "#4a3f36";
    for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(n.x + 11 + i * 5, n.y - 31.5 * s, 1.4, 0, 7); ctx.fill(); }
  }
  // задание
  if (n.quest) {
    const fy = n.y - 40 * s + Math.sin(now * 3 + n.uid) * 2;
    ctx.fillStyle = "#ffd34d";
    ctx.font = "800 15px Georgia";
    ctx.textAlign = "center";
    ctx.lineWidth = 3; ctx.strokeStyle = "rgba(0,0,0,0.75)";
    ctx.strokeText("!", n.x, fy);
    ctx.fillText("!", n.x, fy);
  }
}

/** Караван / корабль / обоз */
export function drawCaravan(ctx: CanvasRenderingContext2D, r: TradeRoute, now: number, hostile: boolean) {
  const shadow = getShadowSprite();
  ctx.drawImage(shadow, r.x - 22, r.y - 2, 44, 14);
  ctx.save();
  ctx.translate(r.x, r.y - 8);
  const dir = Math.cos(r.ang) < 0 ? -1 : 1;
  ctx.scale(dir, 1);
  if (r.kind === "ship") {
    ctx.fillStyle = "#7a5a38";
    ctx.beginPath();
    ctx.moveTo(-16, 2); ctx.quadraticCurveTo(0, 12, 16, 2); ctx.lineTo(12, -3); ctx.lineTo(-13, -3);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "#5d452e"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, -3); ctx.lineTo(0, -22); ctx.stroke();
    ctx.fillStyle = hostile ? "#c9a0a0" : "#e8e0cc";
    ctx.beginPath(); ctx.moveTo(1, -21); ctx.quadraticCurveTo(14, -12, 1, -5); ctx.closePath(); ctx.fill();
  } else {
    // повозка
    ctx.fillStyle = "#7a5a38";
    ctx.fillRect(-14, -8, 26, 11);
    ctx.fillStyle = hostile ? "#b08a6a" : "#d8cbb0";
    ctx.beginPath();
    ctx.moveTo(-14, -8); ctx.quadraticCurveTo(-1, -22, 12, -8);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#4a3826";
    const wheel = now * 4;
    for (const wx of [-9, 7]) {
      ctx.beginPath(); ctx.arc(wx, 4, 4.4, 0, 7); ctx.fill();
      ctx.strokeStyle = "#8a6a44"; ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(wx + Math.cos(wheel) * 3.6, 4 + Math.sin(wheel) * 3.6);
      ctx.lineTo(wx - Math.cos(wheel) * 3.6, 4 - Math.sin(wheel) * 3.6);
      ctx.stroke();
    }
    // тягловый вол
    ctx.fillStyle = "#6d5a48";
    ctx.beginPath(); ctx.ellipse(20, -2, 8, 5.5, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(27, -6, 3.8, 0, 7); ctx.fill();
  }
  ctx.restore();

  if (hostile) {
    const p = 0.4 + Math.sin(now * 4) * 0.2;
    ctx.fillStyle = `rgba(242,193,78,${p.toFixed(2)})`;
    ctx.font = "800 12px Georgia";
    ctx.textAlign = "center";
    ctx.fillText("чужой обоз", r.x, r.y - 30);
  }
}

/** Праздник: фейерверки над городом */
export function drawParade(
  ctx: CanvasRenderingContext2D, cx: number, cy: number, t: number,
  particles: { push: (p: unknown) => void }
) {
  if (Math.random() < 0.25) {
    const fx = cx + (Math.random() - 0.5) * 420;
    const fy = cy - 120 - Math.random() * 160;
    const hue = Math.floor(Math.random() * 360);
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2;
      const sp = 60 + Math.random() * 70;
      particles.push({
        x: fx, y: fy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
        age: 0, life: 1 + Math.random() * 0.6, color: `hsl(${hue},85%,65%)`,
        size: 2.4, grav: 40, kind: "star",
      });
    }
  }
  ctx.fillStyle = `rgba(255,214,120,${(0.05 + Math.sin(t * 3) * 0.02).toFixed(3)})`;
  ctx.fillRect(cx - 500, cy - 400, 1000, 800);
}
