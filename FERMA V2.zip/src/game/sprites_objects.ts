import { O, TILE } from "../types";
import { hash2 } from "../lib/noise";

// ===== Детальная отрисовка объектов мира =====
// Принцип для каждого объекта: тень → база → объём (градиент) → затенение снизу →
// блик сверху-слева → мелкие детали → контур.
// Свет падает сверху-слева, тени уходят вниз-вправо.

/** Внутреннее разрешение спрайтов (рисуем крупнее, показываем мельче — детали чётче) */
export const S = 2;

// ---------- Работа с цветом ----------
function hex2rgb(h: string): [number, number, number] {
  const s = h.replace("#", "");
  const v = parseInt(s.length === 3 ? s.split("").map((c) => c + c).join("") : s, 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}
/** Осветлить (amt>0) или затемнить (amt<0) цвет */
export function shade(hex: string, amt: number): string {
  const [r, g, b] = hex2rgb(hex);
  const f = (c: number) => Math.round(amt > 0 ? c + (255 - c) * amt : c * (1 + amt));
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
export function rgba(hex: string, a: number): string {
  const [r, g, b] = hex2rgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}
/** Смешать два цвета */
function mix(a: string, b: string, t: number): string {
  const [r1, g1, b1] = hex2rgb(a), [r2, g2, b2] = hex2rgb(b);
  return `rgb(${Math.round(r1 + (r2 - r1) * t)},${Math.round(g1 + (g2 - g1) * t)},${Math.round(b1 + (b2 - b1) * t)})`;
}

// ---------- Примитивы ----------
/** Мягкая тень на земле со смещением вниз-вправо */
function groundShadow(ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number, alpha = 0.34) {
  const g = ctx.createRadialGradient(cx, cy, rx * 0.15, cx, cy, rx);
  g.addColorStop(0, `rgba(16,10,8,${alpha})`);
  g.addColorStop(0.65, `rgba(16,10,8,${alpha * 0.5})`);
  g.addColorStop(1, "rgba(16,10,8,0)");
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(1, ry / rx);
  ctx.translate(-cx, -cy);
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(cx, cy, rx, 0, 7);
  ctx.fill();
  ctx.restore();
}

/** Неровная «живая» клякса — основа для крон, камней, тел */
function blobPath(ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number, seedN: number, wob = 0.22, pts = 9) {
  ctx.beginPath();
  for (let i = 0; i <= pts; i++) {
    const a = (i / pts) * Math.PI * 2;
    const k = 1 + (hash2(seedN, i, 3) - 0.5) * wob * 2;
    const x = cx + Math.cos(a) * rx * k;
    const y = cy + Math.sin(a) * ry * k;
    if (i === 0) ctx.moveTo(x, y);
    else {
      const pa = ((i - 0.5) / pts) * Math.PI * 2;
      const pk = 1 + (hash2(seedN, i - 1, 7) - 0.5) * wob * 1.4;
      ctx.quadraticCurveTo(cx + Math.cos(pa) * rx * pk * 1.06, cy + Math.sin(pa) * ry * pk * 1.06, x, y);
    }
  }
  ctx.closePath();
}

/** Объёмная клякса листвы: радиальный градиент + тёмный низ */
function leafBlob(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, base: string, seedN: number) {
  const g = ctx.createRadialGradient(cx - r * 0.38, cy - r * 0.45, r * 0.08, cx, cy + r * 0.12, r * 1.05);
  g.addColorStop(0, shade(base, 0.3));
  g.addColorStop(0.45, base);
  g.addColorStop(1, shade(base, -0.42));
  ctx.fillStyle = g;
  blobPath(ctx, cx, cy, r, r * 0.92, seedN, 0.2, 9);
  ctx.fill();
}

/** Тонкий тёмный контур по текущему пути */
function stroke(ctx: CanvasRenderingContext2D, color: string, w = S) {
  ctx.strokeStyle = color;
  ctx.lineWidth = w;
  ctx.lineJoin = "round";
  ctx.stroke();
}

/** Крап-текстура внутри произвольной области */
function speckle(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string, n: number, seedN: number, size = S) {
  ctx.fillStyle = color;
  for (let i = 0; i < n; i++) {
    const px = x + hash2(seedN, i, 11) * w;
    const py = y + hash2(seedN, i, 23) * h;
    const r = size * (0.5 + hash2(seedN, i, 31) * 0.8);
    ctx.beginPath();
    ctx.arc(px, py, r, 0, 7);
    ctx.fill();
  }
}

// ---------- Сезонные палитры листвы ----------
type Leaf = { base: string; accent: string };
const OAK_LEAF: Leaf[] = [
  { base: "#5e8f3e", accent: "#8cbf5c" }, // весна
  { base: "#4b7c34", accent: "#6fa348" }, // лето
  { base: "#b5702a", accent: "#d99a3c" }, // осень
  { base: "#4a6a52", accent: "#6e8a72" }, // зима (редкая хвоя/сухая листва)
];
const BIRCH_LEAF: Leaf[] = [
  { base: "#87b45a", accent: "#b6d97e" },
  { base: "#74a44c", accent: "#a4cc6e" },
  { base: "#d8b03c", accent: "#f0d268" },
  { base: "#6f7f68", accent: "#94a189" },
];
const PINE_LEAF: Leaf[] = [
  { base: "#2f5f3c", accent: "#48804f" },
  { base: "#2a5636", accent: "#417648" },
  { base: "#2c5238", accent: "#436c46" },
  { base: "#2e5148", accent: "#4a6d62" },
];

const BARK_OAK = ["#6b4a2e", "#4a3320", "#8a6440"];
const BARK_PINE = ["#7a4326", "#54291a", "#9c5c37"];
const BARK_BIRCH = ["#e2ded1", "#b9b3a3", "#f6f3ea"];

// ---------- Ствол ----------
function trunk(
  ctx: CanvasRenderingContext2D, cx: number, baseY: number, h: number,
  wBase: number, wTop: number, pal: string[], seedN: number, snowy = false
) {
  // корни
  ctx.fillStyle = shade(pal[1], -0.1);
  for (let i = -1; i <= 1; i += 2) {
    ctx.beginPath();
    ctx.moveTo(cx + i * wBase * 0.35, baseY - wBase * 0.3);
    ctx.quadraticCurveTo(cx + i * wBase * 1.15, baseY - wBase * 0.05, cx + i * wBase * 1.35, baseY + wBase * 0.1);
    ctx.quadraticCurveTo(cx + i * wBase * 0.9, baseY - wBase * 0.35, cx + i * wBase * 0.3, baseY + wBase * 0.1);
    ctx.closePath();
    ctx.fill();
  }
  // тело ствола — сужается кверху, слегка изогнуто
  const bend = (hash2(seedN, 5, 9) - 0.5) * wBase * 0.45;
  ctx.beginPath();
  ctx.moveTo(cx - wBase / 2, baseY);
  ctx.quadraticCurveTo(cx - wBase * 0.44 + bend, baseY - h * 0.55, cx - wTop / 2 + bend, baseY - h);
  ctx.lineTo(cx + wTop / 2 + bend, baseY - h);
  ctx.quadraticCurveTo(cx + wBase * 0.44 + bend, baseY - h * 0.55, cx + wBase / 2, baseY);
  ctx.closePath();
  const g = ctx.createLinearGradient(cx - wBase * 0.6, 0, cx + wBase * 0.6, 0);
  g.addColorStop(0, pal[2]);
  g.addColorStop(0.35, pal[0]);
  g.addColorStop(1, shade(pal[1], -0.12));
  ctx.fillStyle = g;
  ctx.fill();
  stroke(ctx, rgba(pal[1], 0.75), S * 0.9);

  // текстура коры
  ctx.save();
  ctx.clip();
  if (pal === BARK_BIRCH) {
    // берёза: чёрные штрихи-чечевички
    ctx.fillStyle = "rgba(38,34,30,0.82)";
    for (let i = 0; i < 9; i++) {
      const py = baseY - h * (0.08 + hash2(seedN, i, 2) * 0.86);
      const px = cx - wBase * 0.4 + hash2(seedN, i, 4) * wBase * 0.8 + bend * 0.5;
      const w = wBase * (0.16 + hash2(seedN, i, 6) * 0.3);
      ctx.beginPath();
      ctx.ellipse(px, py, w, S * 0.8, 0, 0, 7);
      ctx.fill();
    }
  } else {
    // вертикальные трещины коры
    ctx.strokeStyle = rgba(pal[1], 0.7);
    ctx.lineWidth = S * 0.75;
    for (let i = 0; i < 5; i++) {
      const px = cx - wBase * 0.34 + (i / 4) * wBase * 0.68 + bend * 0.4;
      ctx.beginPath();
      ctx.moveTo(px + (hash2(seedN, i, 1) - 0.5) * S * 2, baseY - h * 0.02);
      ctx.quadraticCurveTo(px + (hash2(seedN, i, 8) - 0.5) * S * 4, baseY - h * 0.5, px + (hash2(seedN, i, 3) - 0.5) * S * 3 + bend, baseY - h * 0.92);
      ctx.stroke();
    }
    ctx.strokeStyle = rgba(pal[2], 0.45);
    ctx.lineWidth = S * 0.5;
    for (let i = 0; i < 3; i++) {
      const px = cx - wBase * 0.28 + (i / 2) * wBase * 0.5;
      ctx.beginPath();
      ctx.moveTo(px, baseY - h * 0.1);
      ctx.lineTo(px + bend * 0.6, baseY - h * 0.85);
      ctx.stroke();
    }
  }
  // блик слева, затенение справа
  const hg = ctx.createLinearGradient(cx - wBase * 0.6, 0, cx + wBase * 0.6, 0);
  hg.addColorStop(0, "rgba(255,245,220,0.22)");
  hg.addColorStop(0.35, "rgba(255,245,220,0)");
  hg.addColorStop(0.72, "rgba(20,12,8,0)");
  hg.addColorStop(1, "rgba(20,12,8,0.28)");
  ctx.fillStyle = hg;
  ctx.fillRect(cx - wBase, baseY - h - S, wBase * 2, h + S * 2);
  ctx.restore();

  if (snowy) {
    ctx.fillStyle = "rgba(240,246,252,0.7)";
    ctx.beginPath();
    ctx.ellipse(cx + bend * 0.5, baseY - h * 0.99, wTop * 0.65, S * 1.4, 0, 0, 7);
    ctx.fill();
  }
  return bend;
}

/** Ветки, торчащие из кроны */
function branches(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, color: string, seedN: number, n = 4) {
  ctx.strokeStyle = color;
  ctx.lineCap = "round";
  for (let i = 0; i < n; i++) {
    const a = Math.PI + (i / (n - 1)) * Math.PI * 0.9 + (hash2(seedN, i, 12) - 0.5) * 0.3;
    ctx.lineWidth = S * (1.6 - i * 0.12);
    ctx.beginPath();
    ctx.moveTo(cx, cy + r * 0.35);
    ctx.quadraticCurveTo(cx + Math.cos(a) * r * 0.5, cy + Math.sin(a) * r * 0.5 + r * 0.2, cx + Math.cos(a) * r * 0.9, cy + Math.sin(a) * r * 0.75);
    ctx.stroke();
  }
}

/** Крона: 5-8 перекрывающихся клякс + провалы + блики + плоды */
function crown(
  ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number,
  leaf: Leaf, seedN: number, season: number, fruit?: string
) {
  const winter = season === 3;
  // тёмная подложка кроны
  ctx.fillStyle = shade(leaf.base, -0.5);
  blobPath(ctx, cx, cy + r * 0.1, r * 1.02, r * 0.9, seedN + 1, 0.16, 11);
  ctx.fill();

  // основные объёмы
  const lobes = 7;
  for (let i = 0; i < lobes; i++) {
    const a = (i / lobes) * Math.PI * 2 + hash2(seedN, i, 5) * 0.4;
    const dist = r * (0.3 + hash2(seedN, i, 9) * 0.34);
    const lr = r * (0.42 + hash2(seedN, i, 13) * 0.24);
    const lx = cx + Math.cos(a) * dist;
    const ly = cy + Math.sin(a) * dist * 0.8;
    const tint = hash2(seedN, i, 17);
    const col = tint > 0.62 ? mix(leaf.base, leaf.accent, 0.55) : tint < 0.3 ? shade(leaf.base, -0.2) : leaf.base;
    leafBlob(ctx, lx, ly, lr, col, seedN + i * 7);
  }
  // центральная масса
  leafBlob(ctx, cx, cy - r * 0.08, r * 0.6, leaf.base, seedN + 40);

  // тёмные провалы — глубина кроны
  ctx.fillStyle = rgba("#1e2a18", 0.45);
  for (let i = 0; i < 3; i++) {
    const a = 1.1 + i * 1.7 + hash2(seedN, i, 21) * 0.6;
    ctx.beginPath();
    ctx.ellipse(cx + Math.cos(a) * r * 0.42, cy + Math.sin(a) * r * 0.36 + r * 0.14, r * 0.17, r * 0.12, a, 0, 7);
    ctx.fill();
  }
  // блики сверху-слева
  ctx.fillStyle = rgba("#ffffff", 0.16);
  for (let i = 0; i < 3; i++) {
    const lx = cx - r * (0.15 + i * 0.16);
    const ly = cy - r * (0.42 - i * 0.1);
    ctx.beginPath();
    ctx.ellipse(lx, ly, r * (0.2 - i * 0.03), r * (0.12 - i * 0.02), -0.5, 0, 7);
    ctx.fill();
  }
  ctx.fillStyle = rgba(leaf.accent, 0.5);
  speckle(ctx, cx - r * 0.8, cy - r * 0.8, r * 1.1, r * 0.9, rgba(leaf.accent, 0.55), 9, seedN + 3, S * 0.9);

  // нижнее затенение
  const sg = ctx.createLinearGradient(0, cy, 0, cy + r);
  sg.addColorStop(0, "rgba(14,20,12,0)");
  sg.addColorStop(1, "rgba(14,20,12,0.4)");
  ctx.fillStyle = sg;
  blobPath(ctx, cx, cy + r * 0.1, r * 1.02, r * 0.9, seedN + 1, 0.16, 11);
  ctx.fill();

  // плоды / цветы
  if (fruit && !winter) {
    for (let i = 0; i < 3; i++) {
      const a = 0.7 + i * 2.1 + hash2(seedN, i, 27) * 0.8;
      const fx = cx + Math.cos(a) * r * 0.55;
      const fy = cy + Math.sin(a) * r * 0.5;
      ctx.fillStyle = fruit;
      ctx.beginPath();
      ctx.arc(fx, fy, S * 1.5, 0, 7);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.65)";
      ctx.beginPath();
      ctx.arc(fx - S * 0.45, fy - S * 0.45, S * 0.45, 0, 7);
      ctx.fill();
    }
  }
  // снежные шапки
  if (winter) {
    ctx.fillStyle = "rgba(244,249,253,0.85)";
    for (let i = 0; i < 4; i++) {
      const a = Math.PI + (i / 3) * Math.PI;
      const sx = cx + Math.cos(a) * r * 0.5;
      const sy = cy + Math.sin(a) * r * 0.42;
      ctx.beginPath();
      ctx.ellipse(sx, sy, r * 0.26, r * 0.12, Math.cos(a) * 0.3, 0, 7);
      ctx.fill();
    }
  }
}

// ---------- Камни и руды ----------
const ROCK_PAL = { base: "#7d7770", dark: "#4e4a45", light: "#a9a39a" };
type OreDef = { color: string; glow: string; crystal: boolean };
const ORES: Record<number, OreDef> = {
  [O.Coal]: { color: "#26242a", glow: "#000000", crystal: false },
  [O.Copper]: { color: "#c4713a", glow: "#e08a44", crystal: false },
  [O.Iron]: { color: "#b6bcc4", glow: "#cfd6de", crystal: false },
  [O.Gold]: { color: "#e6b53c", glow: "#ffd76a", crystal: false },
  [O.Mithril]: { color: "#7fd4e8", glow: "#a8ecff", crystal: true },
  [O.Adamant]: { color: "#8a6ad8", glow: "#b79cff", crystal: true },
  [O.MoonOre]: { color: "#dfe2ea", glow: "#ffffff", crystal: true },
  [O.MarsOre]: { color: "#e0703c", glow: "#ff9a5c", crystal: true },
};

/** Глыба камня из 3-4 склеенных кусков с гранями */
function rockBody(ctx: CanvasRenderingContext2D, cx: number, baseY: number, w: number, h: number, seedN: number, pal = ROCK_PAL) {
  // силуэт
  ctx.beginPath();
  ctx.moveTo(cx - w * 0.5, baseY);
  ctx.lineTo(cx - w * 0.44, baseY - h * 0.46);
  ctx.lineTo(cx - w * 0.2, baseY - h * 0.92);
  ctx.lineTo(cx + w * 0.12, baseY - h);
  ctx.lineTo(cx + w * 0.42, baseY - h * 0.6);
  ctx.lineTo(cx + w * 0.5, baseY - h * 0.12);
  ctx.closePath();
  const g = ctx.createLinearGradient(cx - w * 0.5, baseY - h, cx + w * 0.5, baseY);
  g.addColorStop(0, pal.light);
  g.addColorStop(0.45, pal.base);
  g.addColorStop(1, pal.dark);
  ctx.fillStyle = g;
  ctx.fill();
  stroke(ctx, rgba("#2b2724", 0.85), S * 0.9);

  ctx.save();
  ctx.clip();
  // верхняя освещённая грань
  ctx.fillStyle = rgba("#ffffff", 0.2);
  ctx.beginPath();
  ctx.moveTo(cx - w * 0.44, baseY - h * 0.46);
  ctx.lineTo(cx - w * 0.2, baseY - h * 0.92);
  ctx.lineTo(cx + w * 0.12, baseY - h);
  ctx.lineTo(cx - w * 0.02, baseY - h * 0.56);
  ctx.closePath();
  ctx.fill();
  // правая тёмная грань
  ctx.fillStyle = "rgba(18,14,12,0.34)";
  ctx.beginPath();
  ctx.moveTo(cx + w * 0.12, baseY - h);
  ctx.lineTo(cx + w * 0.42, baseY - h * 0.6);
  ctx.lineTo(cx + w * 0.5, baseY - h * 0.12);
  ctx.lineTo(cx + w * 0.06, baseY - h * 0.3);
  ctx.closePath();
  ctx.fill();
  // трещины
  ctx.strokeStyle = "rgba(28,24,20,0.55)";
  ctx.lineWidth = S * 0.7;
  for (let i = 0; i < 3; i++) {
    const sx = cx - w * 0.3 + hash2(seedN, i, 3) * w * 0.6;
    ctx.beginPath();
    ctx.moveTo(sx, baseY - h * 0.85);
    ctx.lineTo(sx + (hash2(seedN, i, 5) - 0.5) * w * 0.3, baseY - h * 0.45);
    ctx.lineTo(sx + (hash2(seedN, i, 9) - 0.5) * w * 0.4, baseY - h * 0.05);
    ctx.stroke();
  }
  speckle(ctx, cx - w * 0.5, baseY - h, w, h, "rgba(255,255,255,0.12)", 12, seedN + 2, S * 0.7);
  speckle(ctx, cx - w * 0.5, baseY - h, w, h, "rgba(20,16,14,0.2)", 10, seedN + 8, S * 0.8);
  ctx.restore();
}

/** Вкрапления руды на глыбе */
function oreVeins(ctx: CanvasRenderingContext2D, cx: number, baseY: number, w: number, h: number, ore: OreDef, seedN: number) {
  // мягкое свечение
  const gl = ctx.createRadialGradient(cx, baseY - h * 0.5, 1, cx, baseY - h * 0.5, w * 0.62);
  gl.addColorStop(0, rgba(ore.glow, ore.crystal ? 0.4 : 0.2));
  gl.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = gl;
  ctx.fillRect(cx - w, baseY - h * 1.4, w * 2, h * 1.8);

  const n = ore.crystal ? 4 : 5;
  for (let i = 0; i < n; i++) {
    const px = cx + (hash2(seedN, i, 19) - 0.5) * w * 0.66;
    const py = baseY - h * (0.22 + hash2(seedN, i, 23) * 0.6);
    const r = w * (0.06 + hash2(seedN, i, 29) * 0.05);
    if (ore.crystal) {
      // гранёный кристалл
      ctx.beginPath();
      ctx.moveTo(px, py - r * 1.9);
      ctx.lineTo(px + r, py - r * 0.2);
      ctx.lineTo(px + r * 0.5, py + r * 1.1);
      ctx.lineTo(px - r * 0.6, py + r * 1.1);
      ctx.lineTo(px - r, py - r * 0.3);
      ctx.closePath();
      const cg = ctx.createLinearGradient(px - r, py - r * 2, px + r, py + r);
      cg.addColorStop(0, shade(ore.color, 0.45));
      cg.addColorStop(0.5, ore.color);
      cg.addColorStop(1, shade(ore.color, -0.35));
      ctx.fillStyle = cg;
      ctx.fill();
      stroke(ctx, rgba("#16121a", 0.7), S * 0.6);
      ctx.fillStyle = "rgba(255,255,255,0.75)";
      ctx.beginPath();
      ctx.moveTo(px - r * 0.2, py - r * 1.5);
      ctx.lineTo(px + r * 0.15, py - r * 0.4);
      ctx.lineTo(px - r * 0.35, py - r * 0.1);
      ctx.closePath();
      ctx.fill();
    } else {
      // самородок с бликом
      ctx.fillStyle = shade(ore.color, -0.3);
      blobPath(ctx, px, py, r * 1.15, r, seedN + i, 0.3, 7);
      ctx.fill();
      ctx.fillStyle = ore.color;
      blobPath(ctx, px - r * 0.1, py - r * 0.12, r * 0.85, r * 0.72, seedN + i * 3, 0.28, 7);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.65)";
      ctx.beginPath();
      ctx.arc(px - r * 0.3, py - r * 0.35, r * 0.28, 0, 7);
      ctx.fill();
    }
  }
}

// ---------- Сундуки ----------
type ChestTier = 0 | 1 | 2;
const CHEST_PAL: { wood: string; woodD: string; woodL: string; metal: string; metalL: string; gem: string }[] = [
  { wood: "#8a6234", woodD: "#5c3f20", woodL: "#a87c47", metal: "#8d8378", metalL: "#c2b8a8", gem: "#c9a227" },
  { wood: "#6f6a74", woodD: "#48444e", woodL: "#948d9c", metal: "#c3ccd6", metalL: "#eaf0f6", gem: "#8fd4e8" },
  { wood: "#7a5a2c", woodD: "#4e3818", woodL: "#a07a3c", metal: "#e8c15a", metalL: "#ffe9a8", gem: "#fff0a8" },
];

function chest(ctx: CanvasRenderingContext2D, cx: number, baseY: number, w: number, h: number, tier: ChestTier, seedN: number) {
  const p = CHEST_PAL[tier];
  const metalL = tier === 2 ? "#ffe9a8" : p.metalL;
  const bodyH = h * 0.56, lidH = h * 0.4;
  const bodyY = baseY - bodyH;
  const lidY = bodyY - lidH * 0.62;

  if (tier === 2) {
    const gl = ctx.createRadialGradient(cx, baseY - h * 0.5, 1, cx, baseY - h * 0.5, w * 0.95);
    gl.addColorStop(0, "rgba(255,214,110,0.34)");
    gl.addColorStop(1, "rgba(255,214,110,0)");
    ctx.fillStyle = gl;
    ctx.fillRect(cx - w, baseY - h * 1.6, w * 2, h * 2);
  }

  // корпус
  ctx.beginPath();
  ctx.roundRect(cx - w / 2, bodyY, w, bodyH, S * 1.2);
  const bg = ctx.createLinearGradient(cx - w / 2, 0, cx + w / 2, 0);
  bg.addColorStop(0, p.woodL);
  bg.addColorStop(0.4, p.wood);
  bg.addColorStop(1, p.woodD);
  ctx.fillStyle = bg;
  ctx.fill();
  stroke(ctx, rgba("#2a1c0e", 0.85), S * 0.9);
  // доски
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(cx - w / 2, bodyY, w, bodyH, S * 1.2);
  ctx.clip();
  ctx.strokeStyle = rgba(p.woodD, 0.8);
  ctx.lineWidth = S * 0.7;
  for (let i = 1; i < 4; i++) {
    const px = cx - w / 2 + (i / 4) * w;
    ctx.beginPath();
    ctx.moveTo(px, bodyY);
    ctx.lineTo(px + S * 0.4, baseY);
    ctx.stroke();
  }
  speckle(ctx, cx - w / 2, bodyY, w, bodyH, rgba(p.woodD, 0.35), 8, seedN, S * 0.7);
  ctx.fillStyle = "rgba(20,12,6,0.26)";
  ctx.fillRect(cx - w / 2, baseY - bodyH * 0.3, w, bodyH * 0.3);
  ctx.restore();

  // крышка (полуцилиндр)
  ctx.beginPath();
  ctx.moveTo(cx - w / 2, bodyY + S * 0.6);
  ctx.quadraticCurveTo(cx - w / 2, lidY, cx, lidY);
  ctx.quadraticCurveTo(cx + w / 2, lidY, cx + w / 2, bodyY + S * 0.6);
  ctx.closePath();
  const lg = ctx.createLinearGradient(cx - w / 2, lidY, cx + w / 2, bodyY);
  lg.addColorStop(0, shade(p.woodL, 0.15));
  lg.addColorStop(0.45, p.wood);
  lg.addColorStop(1, p.woodD);
  ctx.fillStyle = lg;
  ctx.fill();
  stroke(ctx, rgba("#2a1c0e", 0.85), S * 0.9);
  // блик на крышке
  ctx.fillStyle = "rgba(255,246,222,0.26)";
  ctx.beginPath();
  ctx.ellipse(cx - w * 0.16, lidY + lidH * 0.22, w * 0.22, lidH * 0.16, -0.3, 0, 7);
  ctx.fill();

  // металлические углы и полосы
  ctx.fillStyle = p.metal;
  for (const dx of [-1, 1]) {
    ctx.fillRect(cx + dx * (w / 2 - S * 1.6) - S * 0.8, bodyY, S * 1.6, bodyH);
  }
  ctx.fillStyle = metalL;
  for (const dx of [-1, 1]) {
    ctx.fillRect(cx + dx * (w / 2 - S * 1.6) - S * 0.8, bodyY, S * 0.6, bodyH);
  }
  // замок
  ctx.fillStyle = p.metal;
  ctx.beginPath();
  ctx.roundRect(cx - S * 1.8, bodyY - S * 1.6, S * 3.6, S * 4, S * 0.8);
  ctx.fill();
  stroke(ctx, rgba("#2a1c0e", 0.7), S * 0.6);
  ctx.fillStyle = metalL;
  ctx.beginPath();
  ctx.arc(cx - S * 0.5, bodyY - S * 0.2, S * 0.7, 0, 7);
  ctx.fill();
  ctx.fillStyle = "#1b1410";
  ctx.beginPath();
  ctx.arc(cx, bodyY + S * 0.5, S * 0.55, 0, 7);
  ctx.fill();

  // гравировка на крышке
  ctx.strokeStyle = rgba(p.gem, tier === 0 ? 0.55 : 0.9);
  ctx.lineWidth = S * 0.7;
  ctx.beginPath();
  ctx.arc(cx, lidY + lidH * 0.42, w * 0.13, 0, 7);
  ctx.stroke();
  if (tier > 0) {
    ctx.fillStyle = p.gem;
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + 0.4;
      ctx.beginPath();
      ctx.arc(cx + Math.cos(a) * w * 0.13, lidY + lidH * 0.42 + Math.sin(a) * w * 0.13, S * 0.5, 0, 7);
      ctx.fill();
    }
  }
}

// ================= ГЛАВНАЯ ФУНКЦИЯ =================
/** Габариты спрайта объекта в тайлах (для крупных объектов) */
export function objSpriteBig(o: number): boolean {
  return o === O.Oak || o === O.Pine || o === O.Birch;
}

/** Крона ели: 4 яруса хвои + шишки. Вынесено, чтобы рисовать крону отдельным слоем. */
function drawPineCrown(ctx: CanvasRenderingContext2D, cx: number, baseY: number, H: number, U: number, season: number, winter: boolean) {
  const leaf = PINE_LEAF[season];
  // 4 яруса хвои: тёмная база → объём → блик
  for (let i = 0; i < 4; i++) {
    const w = U * (1.34 - i * 0.26);
    const y = baseY - H * 0.3 - i * H * 0.16;
    const tipY = y - H * 0.24;
    ctx.beginPath();
    ctx.moveTo(cx, tipY);
    ctx.lineTo(cx - w / 2, y);
    ctx.quadraticCurveTo(cx, y + S * 2.4, cx + w / 2, y);
    ctx.closePath();
    const g = ctx.createLinearGradient(cx - w / 2, tipY, cx + w / 2, y);
    g.addColorStop(0, shade(leaf.accent, 0.12));
    g.addColorStop(0.45, leaf.base);
    g.addColorStop(1, shade(leaf.base, -0.45));
    ctx.fillStyle = g;
    ctx.fill();
    stroke(ctx, rgba("#16261a", 0.6), S * 0.7);
    // иголки-штрихи
    ctx.strokeStyle = rgba(shade(leaf.base, -0.35), 0.55);
    ctx.lineWidth = S * 0.5;
    for (let k = 0; k < 5; k++) {
      const px = cx - w * 0.4 + (k / 4) * w * 0.8;
      ctx.beginPath();
      ctx.moveTo(px, y - S * 0.5);
      ctx.lineTo(px + (px - cx) * 0.12, y - H * 0.06);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(255,255,255,0.12)";
    ctx.beginPath();
    ctx.moveTo(cx - w * 0.06, tipY + S);
    ctx.lineTo(cx - w * 0.34, y - S * 0.6);
    ctx.lineTo(cx - w * 0.08, y - S * 0.6);
    ctx.closePath();
    ctx.fill();
    if (winter) {
      ctx.fillStyle = "rgba(245,250,254,0.85)";
      ctx.beginPath();
      ctx.moveTo(cx, tipY + S * 0.8);
      ctx.lineTo(cx - w * 0.2, y - S * 0.4);
      ctx.quadraticCurveTo(cx, y + S * 0.6, cx + w * 0.2, y - S * 0.4);
      ctx.closePath();
      ctx.fill();
    }
  }
  // шишки
  if (!winter) {
    ctx.fillStyle = "#6b4526";
    for (let i = 0; i < 2; i++) {
      ctx.beginPath();
      ctx.ellipse(cx + (i ? 1 : -1) * U * 0.26, baseY - H * (0.44 + i * 0.12), S * 1.1, S * 1.7, 0.2, 0, 7);
      ctx.fill();
    }
  }
}

/**
 * Рисует объект. Для больших деревьев поддерживает раздельную отрисовку:
 * part="trunk" — только ствол, ветви и тень (всегда непрозрачны),
 * part="crown" — только листва/хвоя (её рендер делает полупрозрачной,
 * когда герой стоит под ней). Для прочих объектов part игнорируется.
 */
export function drawObject(ctx: CanvasRenderingContext2D, o: number, season: number, W: number, H: number, variant = 0, part: "all" | "trunk" | "crown" = "all") {
  const winter = season === 3;
  const cx = W / 2;
  const baseY = H - S * 3;
  const seedN = o * 131 + season * 17 + variant * 7;
  const U = TILE * S; // «единица тайла» во внутреннем масштабе
  const drawCrown = part !== "trunk";
  // «крону» запросили у объекта без кроны — рисовать нечего
  if (part === "crown" && !objSpriteBig(o)) return;

  switch (o) {
    // ---------------- ДЕРЕВЬЯ ----------------
    case O.Oak: {
      if (part === "crown") {
        // крона: только листва (ствол и ветки — в слое ствола)
        const leaf = OAK_LEAF[season];
        const b = (hash2(seedN, 5, 9) - 0.5) * U * 0.3 * 0.45; // тот же изгиб, что в trunk()
        if (winter) crown(ctx, cx + b, baseY - H * 0.62, U * 0.5, leaf, seedN, season);
        else crown(ctx, cx + b, baseY - H * 0.63, U * 0.66, leaf, seedN, season, season === 2 ? "#c9452f" : "#d8563f");
        break;
      }
      groundShadow(ctx, cx + U * 0.12, baseY - U * 0.02, U * 0.62, U * 0.2, 0.36);
      const b = trunk(ctx, cx, baseY, H * 0.44, U * 0.3, U * 0.19, BARK_OAK, seedN, winter);
      branches(ctx, cx + b, baseY - H * 0.42, U * 0.5, rgba(BARK_OAK[1], 0.9), seedN, 4);
      const leaf = OAK_LEAF[season];
      if (winter) {
        // зимой — голые ветки со снегом и редкой листвой
        branches(ctx, cx + b, baseY - H * 0.5, U * 0.72, rgba(BARK_OAK[1], 0.95), seedN + 5, 6);
        if (drawCrown) crown(ctx, cx + b, baseY - H * 0.62, U * 0.5, leaf, seedN, season);
      } else {
        if (drawCrown) crown(ctx, cx + b, baseY - H * 0.63, U * 0.66, leaf, seedN, season, season === 2 ? "#c9452f" : "#d8563f");
      }
      break;
    }
    case O.Birch: {
      if (part === "crown") {
        const leaf = BIRCH_LEAF[season];
        const b = (hash2(seedN, 5, 9) - 0.5) * U * 0.19 * 0.45;
        crown(ctx, cx + b, baseY - H * 0.7, U * (winter ? 0.42 : 0.54), leaf, seedN, season, season === 0 ? "#f2e8a8" : undefined);
        break;
      }
      groundShadow(ctx, cx + U * 0.1, baseY - U * 0.02, U * 0.48, U * 0.16, 0.3);
      const b = trunk(ctx, cx, baseY, H * 0.56, U * 0.19, U * 0.12, BARK_BIRCH, seedN, winter);
      branches(ctx, cx + b, baseY - H * 0.52, U * 0.46, rgba("#cfc9bb", 0.9), seedN, 5);
      if (drawCrown) crown(ctx, cx + b, baseY - H * 0.7, U * (winter ? 0.42 : 0.54), BIRCH_LEAF[season], seedN, season, season === 0 ? "#f2e8a8" : undefined);
      break;
    }
    case O.Pine: {
      if (part === "crown") {
        drawPineCrown(ctx, cx, baseY, H, U, season, winter);
        break;
      }
      groundShadow(ctx, cx + U * 0.1, baseY - U * 0.02, U * 0.5, U * 0.17, 0.34);
      trunk(ctx, cx, baseY, H * 0.42, U * 0.22, U * 0.13, BARK_PINE, seedN, false);
      if (drawCrown) drawPineCrown(ctx, cx, baseY, H, U, season, winter);
      break;
    }

    // ---------------- КУСТЫ, ТРАВЫ, ЦВЕТЫ ----------------
    case O.Bush: {
      groundShadow(ctx, cx + U * 0.06, baseY - U * 0.02, U * 0.36, U * 0.12, 0.3);
      const leaf = OAK_LEAF[season];
      ctx.fillStyle = shade(leaf.base, -0.5);
      blobPath(ctx, cx, baseY - U * 0.26, U * 0.36, U * 0.27, seedN, 0.18, 9);
      ctx.fill();
      stroke(ctx, "rgba(18,30,16,0.65)", S * 0.9);
      // ветки внутри куста
      ctx.strokeStyle = rgba("#4a3320", 0.7);
      ctx.lineWidth = S * 0.7;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(cx + (i - 1) * U * 0.06, baseY);
        ctx.lineTo(cx + (i - 1) * U * 0.16, baseY - U * 0.28);
        ctx.stroke();
      }
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        leafBlob(ctx, cx + Math.cos(a) * U * 0.16, baseY - U * 0.28 + Math.sin(a) * U * 0.11,
          U * (0.15 + hash2(seedN, i, 3) * 0.07), i % 2 ? leaf.base : mix(leaf.base, leaf.accent, 0.5), seedN + i);
      }
      // ягоды с бликами
      if (season !== 3) {
        const berry = season === 2 ? "#a83a4a" : "#c94f5d";
        for (let i = 0; i < 6; i++) {
          const bx = cx + (hash2(seedN, i, 5) - 0.5) * U * 0.56;
          const by = baseY - U * (0.16 + hash2(seedN, i, 7) * 0.3);
          ctx.fillStyle = shade(berry, -0.3);
          ctx.beginPath(); ctx.arc(bx, by, S * 1.5, 0, 7); ctx.fill();
          ctx.fillStyle = berry;
          ctx.beginPath(); ctx.arc(bx - S * 0.15, by - S * 0.2, S * 1.15, 0, 7); ctx.fill();
          ctx.fillStyle = "rgba(255,255,255,0.7)";
          ctx.beginPath(); ctx.arc(bx - S * 0.45, by - S * 0.5, S * 0.4, 0, 7); ctx.fill();
        }
      } else {
        ctx.fillStyle = "rgba(242,248,252,0.8)";
        ctx.beginPath(); ctx.ellipse(cx - U * 0.08, baseY - U * 0.44, U * 0.2, U * 0.07, -0.2, 0, 7); ctx.fill();
      }
      break;
    }
    case O.GrassTuft: {
      const leaf = OAK_LEAF[season];
      groundShadow(ctx, cx, baseY, U * 0.24, U * 0.07, 0.22);
      for (let i = 0; i < 7; i++) {
        const x = cx + (i - 3) * U * 0.075;
        const hh = U * (0.3 + hash2(seedN, i, 3) * 0.3);
        const lean = (hash2(seedN, i, 9) - 0.3) * U * 0.22;
        ctx.strokeStyle = i % 2 ? shade(leaf.base, -0.2) : mix(leaf.base, leaf.accent, 0.6);
        ctx.lineWidth = S * (1.1 - Math.abs(i - 3) * 0.1);
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(x, baseY);
        ctx.quadraticCurveTo(x + lean * 0.4, baseY - hh * 0.6, x + lean, baseY - hh);
        ctx.stroke();
      }
      if (winter) {
        ctx.fillStyle = "rgba(240,247,252,0.7)";
        ctx.beginPath(); ctx.ellipse(cx, baseY - S, U * 0.22, S * 1.4, 0, 0, 7); ctx.fill();
      }
      break;
    }
    case O.FlowerR: case O.FlowerY: {
      groundShadow(ctx, cx, baseY, U * 0.2, U * 0.06, 0.2);
      const kinds = o === O.FlowerR
        ? [{ p: "#d0414f", c: "#2b1a12" }, { p: "#e0556a", c: "#3a2016" }, { p: "#b93a5a", c: "#2b1a12" }]  // маки
        : [{ p: "#f2ecd8", c: "#e8c44a" }, { p: "#6f8fd8", c: "#f0e08a" }, { p: "#f0d95c", c: "#8a6a24" }]; // ромашки, васильки
      for (let i = 0; i < 3; i++) {
        const x = cx + (i - 1) * U * 0.2;
        const hh = U * (0.34 + hash2(seedN, i, 3) * 0.14);
        const k = kinds[i % kinds.length];
        ctx.strokeStyle = "#4a7038";
        ctx.lineWidth = S * 0.8;
        ctx.beginPath();
        ctx.moveTo(x, baseY);
        ctx.quadraticCurveTo(x + S, baseY - hh * 0.6, x, baseY - hh);
        ctx.stroke();
        // листик
        ctx.fillStyle = "#5c8a44";
        ctx.beginPath();
        ctx.ellipse(x + S * 1.2, baseY - hh * 0.42, S * 1.4, S * 0.6, -0.5, 0, 7);
        ctx.fill();
        // лепестки
        for (let p = 0; p < 5; p++) {
          const a = (p / 5) * Math.PI * 2 + i;
          ctx.fillStyle = p % 2 ? shade(k.p, -0.12) : k.p;
          ctx.beginPath();
          ctx.ellipse(x + Math.cos(a) * S * 1.5, baseY - hh + Math.sin(a) * S * 1.5, S * 1.15, S * 0.8, a, 0, 7);
          ctx.fill();
        }
        ctx.fillStyle = k.c;
        ctx.beginPath(); ctx.arc(x, baseY - hh, S * 0.85, 0, 7); ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,0.45)";
        ctx.beginPath(); ctx.arc(x - S * 0.3, baseY - hh - S * 0.3, S * 0.3, 0, 7); ctx.fill();
      }
      break;
    }
    case O.Reeds: {
      groundShadow(ctx, cx, baseY, U * 0.22, U * 0.06, 0.2);
      for (let i = 0; i < 6; i++) {
        const x = cx + (i - 2.5) * U * 0.09;
        const hh = U * (0.45 + hash2(seedN, i, 3) * 0.32);
        const lean = (hash2(seedN, i, 11) - 0.35) * U * 0.2;
        ctx.strokeStyle = i % 2 ? "#7d9a52" : "#92ad63";
        ctx.lineWidth = S * 0.85;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(x, baseY);
        ctx.quadraticCurveTo(x + lean * 0.5, baseY - hh * 0.55, x + lean, baseY - hh);
        ctx.stroke();
        // початок
        const tg = ctx.createLinearGradient(x + lean - S, baseY - hh, x + lean + S, baseY - hh);
        tg.addColorStop(0, "#9c7442");
        tg.addColorStop(1, "#5e4226");
        ctx.fillStyle = tg;
        ctx.beginPath();
        ctx.ellipse(x + lean, baseY - hh - S * 1.4, S * 1.05, S * 2.6, 0, 0, 7);
        ctx.fill();
        ctx.fillStyle = "rgba(255,240,200,0.3)";
        ctx.beginPath();
        ctx.ellipse(x + lean - S * 0.3, baseY - hh - S * 2, S * 0.3, S * 1.1, 0, 0, 7);
        ctx.fill();
      }
      break;
    }
    case O.DeadBush: {
      groundShadow(ctx, cx, baseY, U * 0.24, U * 0.07, 0.24);
      for (let i = 0; i < 6; i++) {
        const a = Math.PI + (i / 5) * Math.PI;
        ctx.strokeStyle = i % 2 ? "#8a744f" : "#6d5b3c";
        ctx.lineWidth = S * (1.1 - i * 0.08);
        ctx.lineCap = "round";
        const ex = cx + Math.cos(a) * U * (0.2 + hash2(seedN, i, 3) * 0.12);
        const ey = baseY - U * (0.26 + hash2(seedN, i, 7) * 0.3);
        ctx.beginPath();
        ctx.moveTo(cx, baseY);
        ctx.quadraticCurveTo(cx + (ex - cx) * 0.4, baseY - U * 0.18, ex, ey);
        ctx.stroke();
        ctx.lineWidth = S * 0.6;
        ctx.beginPath();
        ctx.moveTo(ex, ey);
        ctx.lineTo(ex + (hash2(seedN, i, 13) - 0.5) * U * 0.16, ey - U * 0.1);
        ctx.stroke();
      }
      break;
    }
    case O.Cactus: {
      groundShadow(ctx, cx + U * 0.06, baseY, U * 0.26, U * 0.08, 0.28);
      const seg = (x: number, y: number, w: number, h: number) => {
        ctx.beginPath();
        ctx.roundRect(x, y, w, h, w * 0.45);
        const g = ctx.createLinearGradient(x, 0, x + w, 0);
        g.addColorStop(0, "#74a765");
        g.addColorStop(0.4, "#568b4f");
        g.addColorStop(1, "#335c33");
        ctx.fillStyle = g;
        ctx.fill();
        stroke(ctx, "rgba(22,42,22,0.7)", S * 0.8);
        ctx.strokeStyle = "rgba(24,48,26,0.35)";
        ctx.lineWidth = S * 0.5;
        for (let i = 1; i < 3; i++) {
          ctx.beginPath();
          ctx.moveTo(x + (i / 3) * w, y + w * 0.3);
          ctx.lineTo(x + (i / 3) * w, y + h - w * 0.3);
          ctx.stroke();
        }
      };
      seg(cx - U * 0.11, baseY - U * 0.68, U * 0.22, U * 0.68);
      seg(cx - U * 0.32, baseY - U * 0.44, U * 0.14, U * 0.28);
      seg(cx + U * 0.18, baseY - U * 0.52, U * 0.14, U * 0.32);
      ctx.strokeStyle = "#efe4cc";
      ctx.lineWidth = S * 0.5;
      for (let i = 0; i < 7; i++) {
        const px = cx - U * 0.08 + (i % 3) * U * 0.08;
        const py = baseY - U * (0.12 + (i / 7) * 0.5);
        ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + S * 1.1, py - S * 0.5); ctx.stroke();
      }
      // цветок на макушке
      ctx.fillStyle = "#e8628a";
      for (let p = 0; p < 5; p++) {
        const a = (p / 5) * Math.PI * 2;
        ctx.beginPath();
        ctx.ellipse(cx + Math.cos(a) * S * 1.3, baseY - U * 0.7 + Math.sin(a) * S * 1.3, S * 0.9, S * 0.6, a, 0, 7);
        ctx.fill();
      }
      ctx.fillStyle = "#f6e08a";
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.7, S * 0.7, 0, 7); ctx.fill();
      break;
    }
    case O.Mushroom: case O.GlowShroom: {
      const glow = o === O.GlowShroom;
      groundShadow(ctx, cx, baseY, U * 0.22, U * 0.07, 0.26);
      if (glow) {
        const gl = ctx.createRadialGradient(cx, baseY - U * 0.4, 1, cx, baseY - U * 0.4, U * 0.6);
        gl.addColorStop(0, "rgba(111,214,232,0.45)");
        gl.addColorStop(1, "rgba(111,214,232,0)");
        ctx.fillStyle = gl;
        ctx.fillRect(cx - U * 0.7, baseY - U, U * 1.4, U * 1.2);
      }
      for (let i = 0; i < 2; i++) {
        const mx = cx + (i ? U * 0.19 : -U * 0.12);
        const my = baseY - (i ? U * 0.06 : 0);
        const sc = i ? 0.68 : 1;
        // ножка
        const sg = ctx.createLinearGradient(mx - U * 0.07 * sc, 0, mx + U * 0.07 * sc, 0);
        sg.addColorStop(0, "#f0e6ce");
        sg.addColorStop(1, "#bfb096");
        ctx.fillStyle = sg;
        ctx.beginPath();
        ctx.roundRect(mx - U * 0.055 * sc, my - U * 0.3 * sc, U * 0.11 * sc, U * 0.3 * sc, U * 0.03);
        ctx.fill();
        stroke(ctx, "rgba(70,58,44,0.6)", S * 0.6);
        // шляпка
        ctx.beginPath();
        ctx.ellipse(mx, my - U * 0.3 * sc, U * 0.2 * sc, U * 0.15 * sc, 0, Math.PI, 0);
        const cg = ctx.createLinearGradient(mx - U * 0.2, my - U * 0.45, mx + U * 0.2, my - U * 0.25);
        if (glow) { cg.addColorStop(0, "#9ceaf8"); cg.addColorStop(0.5, "#5ec4dc"); cg.addColorStop(1, "#2e7f96"); }
        else { cg.addColorStop(0, "#d4705c"); cg.addColorStop(0.5, "#b8503e"); cg.addColorStop(1, "#7d3226"); }
        ctx.fillStyle = cg;
        ctx.fill();
        stroke(ctx, "rgba(50,26,20,0.7)", S * 0.7);
        // крапинки
        ctx.fillStyle = glow ? "rgba(230,255,255,0.85)" : "rgba(244,236,214,0.92)";
        for (let k = 0; k < 3; k++) {
          ctx.beginPath();
          ctx.arc(mx + (hash2(seedN, k, i) - 0.5) * U * 0.26, my - U * (0.33 + hash2(seedN, k, i + 5) * 0.06) * sc, S * 0.75 * sc, 0, 7);
          ctx.fill();
        }
      }
      break;
    }

    // ---------------- КАМНИ И РУДЫ ----------------
    case O.Rock: case O.Coal: case O.Copper: case O.Iron: case O.Gold:
    case O.Mithril: case O.Adamant: case O.MoonOre: case O.MarsOre: {
      const w = U * 0.78, h = U * 0.6;
      groundShadow(ctx, cx + U * 0.08, baseY, w * 0.62, h * 0.24, 0.34);
      // мелкие осколки рядом
      ctx.fillStyle = shade(ROCK_PAL.dark, 0.05);
      for (let i = 0; i < 2; i++) {
        const px = cx + (i ? w * 0.5 : -w * 0.48);
        blobPath(ctx, px, baseY - S * 1.6, S * 2.2, S * 1.4, seedN + i * 5, 0.3, 6);
        ctx.fill();
      }
      rockBody(ctx, cx, baseY, w, h, seedN);
      const ore = ORES[o];
      if (ore) oreVeins(ctx, cx, baseY, w, h, ore, seedN);
      break;
    }
    case O.Crystal: case O.SkyCrystal: {
      const col = o === O.Crystal ? "#8fd8f0" : "#c9a8f2";
      const gl = ctx.createRadialGradient(cx, baseY - U * 0.35, 1, cx, baseY - U * 0.35, U * 0.6);
      gl.addColorStop(0, rgba(col, 0.4));
      gl.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(cx - U * 0.7, baseY - U, U * 1.4, U * 1.2);
      groundShadow(ctx, cx + U * 0.05, baseY, U * 0.3, U * 0.1, 0.3);
      const specs: [number, number, number][] = [[0.5, 0.8, 0.13], [0.32, 0.5, 0.09], [0.68, 0.58, 0.1]];
      for (const [dx, hh, ww] of specs) {
        const px = cx + (dx - 0.5) * U;
        ctx.beginPath();
        ctx.moveTo(px, baseY - U * hh);
        ctx.lineTo(px + U * ww, baseY - U * hh * 0.42);
        ctx.lineTo(px + U * ww * 0.6, baseY);
        ctx.lineTo(px - U * ww * 0.6, baseY);
        ctx.lineTo(px - U * ww, baseY - U * hh * 0.4);
        ctx.closePath();
        const g = ctx.createLinearGradient(px - U * ww, baseY - U * hh, px + U * ww, baseY);
        g.addColorStop(0, shade(col, 0.5));
        g.addColorStop(0.45, col);
        g.addColorStop(1, shade(col, -0.45));
        ctx.fillStyle = g;
        ctx.fill();
        stroke(ctx, rgba("#1b2230", 0.65), S * 0.7);
        ctx.fillStyle = "rgba(255,255,255,0.7)";
        ctx.beginPath();
        ctx.moveTo(px - U * ww * 0.18, baseY - U * hh * 0.86);
        ctx.lineTo(px + U * ww * 0.12, baseY - U * hh * 0.3);
        ctx.lineTo(px - U * ww * 0.35, baseY - U * hh * 0.1);
        ctx.closePath();
        ctx.fill();
      }
      break;
    }
    case O.Clay: {
      groundShadow(ctx, cx, baseY, U * 0.34, U * 0.1, 0.26);
      for (let i = 0; i < 3; i++) {
        const px = cx + (i - 1) * U * 0.2;
        const py = baseY - U * (0.08 + hash2(seedN, i, 3) * 0.08);
        const g = ctx.createLinearGradient(px, py - U * 0.16, px, py);
        g.addColorStop(0, "#b7bec5");
        g.addColorStop(1, "#7e868f");
        ctx.fillStyle = g;
        blobPath(ctx, px, py, U * 0.16, U * 0.1, seedN + i, 0.25, 8);
        ctx.fill();
        stroke(ctx, "rgba(48,52,58,0.6)", S * 0.6);
      }
      ctx.fillStyle = "rgba(255,255,255,0.28)";
      ctx.beginPath(); ctx.ellipse(cx - U * 0.14, baseY - U * 0.16, U * 0.08, U * 0.04, -0.3, 0, 7); ctx.fill();
      break;
    }
    case O.Bones: {
      groundShadow(ctx, cx, baseY, U * 0.3, U * 0.09, 0.26);
      const bone = (x1: number, y1: number, x2: number, y2: number) => {
        ctx.strokeStyle = "#ddd6c4";
        ctx.lineWidth = S * 1.8;
        ctx.lineCap = "round";
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
        ctx.strokeStyle = "rgba(120,110,94,0.5)";
        ctx.lineWidth = S * 0.5;
        ctx.beginPath(); ctx.moveTo(x1, y1 + S * 0.5); ctx.lineTo(x2, y2 + S * 0.5); ctx.stroke();
        ctx.fillStyle = "#e9e2d0";
        for (const [bx, by] of [[x1, y1], [x2, y2]] as [number, number][]) {
          ctx.beginPath(); ctx.arc(bx, by, S * 1.15, 0, 7); ctx.fill();
        }
      };
      bone(cx - U * 0.26, baseY - U * 0.1, cx + U * 0.06, baseY - U * 0.28);
      bone(cx - U * 0.02, baseY - U * 0.06, cx + U * 0.26, baseY - U * 0.22);
      // череп
      ctx.fillStyle = "#e4ddcb";
      blobPath(ctx, cx - U * 0.2, baseY - U * 0.3, U * 0.13, U * 0.11, seedN, 0.14, 8);
      ctx.fill();
      stroke(ctx, "rgba(90,82,68,0.6)", S * 0.6);
      ctx.fillStyle = "#2b2520";
      ctx.beginPath(); ctx.ellipse(cx - U * 0.24, baseY - U * 0.31, S * 0.9, S * 1.1, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(cx - U * 0.15, baseY - U * 0.31, S * 0.9, S * 1.1, 0, 0, 7); ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.35)";
      ctx.beginPath(); ctx.ellipse(cx - U * 0.22, baseY - U * 0.37, U * 0.06, U * 0.025, -0.3, 0, 7); ctx.fill();
      break;
    }
    case O.Stump: {
      groundShadow(ctx, cx + U * 0.05, baseY, U * 0.32, U * 0.1, 0.3);
      const g = ctx.createLinearGradient(cx - U * 0.28, 0, cx + U * 0.28, 0);
      g.addColorStop(0, "#8a6440"); g.addColorStop(0.45, "#6b4a2e"); g.addColorStop(1, "#46301d");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(cx - U * 0.26, baseY - U * 0.06);
      ctx.lineTo(cx - U * 0.23, baseY - U * 0.3);
      ctx.lineTo(cx + U * 0.23, baseY - U * 0.3);
      ctx.lineTo(cx + U * 0.26, baseY - U * 0.06);
      ctx.closePath();
      ctx.fill();
      stroke(ctx, "rgba(38,24,14,0.8)", S * 0.9);
      // срез с кольцами
      ctx.fillStyle = "#b08a5e";
      ctx.beginPath(); ctx.ellipse(cx, baseY - U * 0.3, U * 0.24, U * 0.1, 0, 0, 7); ctx.fill();
      stroke(ctx, "rgba(64,42,24,0.7)", S * 0.7);
      ctx.strokeStyle = "rgba(110,76,44,0.8)";
      ctx.lineWidth = S * 0.6;
      for (let i = 1; i <= 3; i++) {
        ctx.beginPath();
        ctx.ellipse(cx, baseY - U * 0.3, U * 0.24 * (i / 4), U * 0.1 * (i / 4), 0, 0, 7);
        ctx.stroke();
      }
      ctx.fillStyle = "rgba(255,240,210,0.25)";
      ctx.beginPath(); ctx.ellipse(cx - U * 0.08, baseY - U * 0.33, U * 0.08, U * 0.03, -0.2, 0, 7); ctx.fill();
      break;
    }

    // ---------------- СУНДУКИ ----------------
    case O.Chest: {
      const tier: ChestTier = variant >= 2 ? 2 : variant === 1 ? 1 : 0;
      groundShadow(ctx, cx + U * 0.06, baseY, U * 0.38, U * 0.12, 0.34);
      chest(ctx, cx, baseY - S, U * 0.66, U * 0.55, tier, seedN);
      break;
    }
    case O.RuinChest: {
      groundShadow(ctx, cx + U * 0.06, baseY, U * 0.4, U * 0.13, 0.36);
      chest(ctx, cx, baseY - S, U * 0.68, U * 0.58, 2, seedN);
      break;
    }

    // ---------------- ПРОЧЕЕ ----------------
    case O.CaveIn: {
      groundShadow(ctx, cx, baseY - U * 0.12, U * 0.42, U * 0.18, 0.5);
      // тёмный провал с градиентом глубины
      const g = ctx.createRadialGradient(cx, baseY - U * 0.28, U * 0.04, cx, baseY - U * 0.28, U * 0.36);
      g.addColorStop(0, "#07050a");
      g.addColorStop(0.7, "#1b1524");
      g.addColorStop(1, "#332a3c");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(cx, baseY - U * 0.28, U * 0.36, U * 0.26, 0, 0, 7); ctx.fill();
      // каменная кромка
      ctx.strokeStyle = "#6b645c"; ctx.lineWidth = S * 2;
      ctx.beginPath(); ctx.ellipse(cx, baseY - U * 0.28, U * 0.38, U * 0.28, 0, 0, 7); ctx.stroke();
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        ctx.fillStyle = i % 2 ? "#847c72" : "#5d574f";
        blobPath(ctx, cx + Math.cos(a) * U * 0.38, baseY - U * 0.28 + Math.sin(a) * U * 0.28, S * 2.2, S * 1.6, seedN + i, 0.3, 6);
        ctx.fill();
      }
      // лестница вниз
      ctx.strokeStyle = "#9c8a62"; ctx.lineWidth = S * 1.2;
      ctx.beginPath(); ctx.moveTo(cx - U * 0.1, baseY - U * 0.4); ctx.lineTo(cx - U * 0.08, baseY - U * 0.14); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx + U * 0.1, baseY - U * 0.4); ctx.lineTo(cx + U * 0.08, baseY - U * 0.14); ctx.stroke();
      for (let i = 0; i < 3; i++) {
        const y = baseY - U * (0.36 - i * 0.08);
        ctx.beginPath(); ctx.moveTo(cx - U * 0.095, y); ctx.lineTo(cx + U * 0.095, y); ctx.stroke();
      }
      break;
    }
    case O.CaveOut: {
      groundShadow(ctx, cx, baseY, U * 0.3, U * 0.1, 0.3);
      ctx.strokeStyle = "#a89058"; ctx.lineWidth = S * 1.6; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(cx - U * 0.16, baseY); ctx.lineTo(cx - U * 0.06, baseY - U * 0.72); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx + U * 0.16, baseY); ctx.lineTo(cx + U * 0.06, baseY - U * 0.72); ctx.stroke();
      ctx.strokeStyle = "#c2a868"; ctx.lineWidth = S * 1.3;
      for (let i = 0; i < 5; i++) {
        const t = i / 4;
        const y = baseY - U * 0.08 - t * U * 0.6;
        const w = U * (0.16 - t * 0.1);
        ctx.beginPath(); ctx.moveTo(cx - w, y); ctx.lineTo(cx + w, y); ctx.stroke();
      }
      ctx.fillStyle = "rgba(255,240,190,0.25)";
      ctx.beginPath(); ctx.ellipse(cx, baseY - U * 0.78, U * 0.14, U * 0.06, 0, 0, 7); ctx.fill();
      break;
    }
    case O.LavaVent: {
      const gl = ctx.createRadialGradient(cx, baseY - U * 0.2, 1, cx, baseY - U * 0.2, U * 0.7);
      gl.addColorStop(0, "rgba(255,140,50,0.5)");
      gl.addColorStop(1, "rgba(255,140,50,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(cx - U * 0.8, baseY - U * 0.9, U * 1.6, U * 1.2);
      ctx.fillStyle = "#2e1810";
      blobPath(ctx, cx, baseY - U * 0.16, U * 0.36, U * 0.2, seedN, 0.2, 9);
      ctx.fill();
      stroke(ctx, "rgba(12,6,4,0.8)", S);
      const lg = ctx.createRadialGradient(cx, baseY - U * 0.18, 1, cx, baseY - U * 0.18, U * 0.24);
      lg.addColorStop(0, "#ffe9a0");
      lg.addColorStop(0.4, "#ff9a3c");
      lg.addColorStop(1, "#c4380f");
      ctx.fillStyle = lg;
      blobPath(ctx, cx, baseY - U * 0.18, U * 0.22, U * 0.12, seedN + 3, 0.22, 8);
      ctx.fill();
      // пузыри
      ctx.fillStyle = "rgba(255,220,140,0.8)";
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.arc(cx + (hash2(seedN, i, 3) - 0.5) * U * 0.28, baseY - U * (0.16 + hash2(seedN, i, 7) * 0.08), S * (0.8 + hash2(seedN, i, 9)), 0, 7);
        ctx.fill();
      }
      break;
    }
    case O.CloudTree: {
      groundShadow(ctx, cx, baseY, U * 0.3, U * 0.09, 0.2);
      ctx.strokeStyle = "#9db6cc"; ctx.lineWidth = S * 2;
      ctx.beginPath(); ctx.moveTo(cx, baseY); ctx.quadraticCurveTo(cx + S, baseY - U * 0.3, cx, baseY - U * 0.52); ctx.stroke();
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        const px = cx + Math.cos(a) * U * 0.17;
        const py = baseY - U * 0.62 + Math.sin(a) * U * 0.1;
        const g = ctx.createRadialGradient(px - S, py - S * 2, 1, px, py, U * 0.16);
        g.addColorStop(0, "#ffffff");
        g.addColorStop(0.6, "#dce9f4");
        g.addColorStop(1, "#a7bdd0");
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(px, py, U * (0.13 + hash2(seedN, i, 3) * 0.05), 0, 7); ctx.fill();
      }
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.beginPath(); ctx.arc(cx - U * 0.1, baseY - U * 0.7, U * 0.07, 0, 7); ctx.fill();
      break;
    }
    case O.ShadowTree: {
      const gl = ctx.createRadialGradient(cx, baseY - U * 0.5, 1, cx, baseY - U * 0.5, U * 0.6);
      gl.addColorStop(0, "rgba(140,100,220,0.28)");
      gl.addColorStop(1, "rgba(140,100,220,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(cx - U * 0.7, baseY - U, U * 1.4, U * 1.2);
      groundShadow(ctx, cx, baseY, U * 0.3, U * 0.1, 0.4);
      trunk(ctx, cx, baseY, U * 0.52, U * 0.15, U * 0.08, ["#2a2036", "#160f20", "#3b2f4c"], seedN);
      ctx.strokeStyle = "#241c30"; ctx.lineCap = "round";
      for (const [ex, ey] of [[0.24, 0.78], [0.76, 0.82], [0.36, 0.92], [0.66, 0.94]] as [number, number][]) {
        ctx.lineWidth = S * 1.2;
        ctx.beginPath();
        ctx.moveTo(cx, baseY - U * 0.5);
        ctx.quadraticCurveTo(cx + (ex - 0.5) * U * 0.5, baseY - U * 0.66, cx + (ex - 0.5) * U, baseY - U * ey);
        ctx.stroke();
      }
      ctx.fillStyle = "rgba(150,110,220,0.3)";
      blobPath(ctx, cx, baseY - U * 0.72, U * 0.26, U * 0.2, seedN + 2, 0.24, 9);
      ctx.fill();
      break;
    }
    case O.DreamFlower: {
      const gl = ctx.createRadialGradient(cx, baseY - U * 0.5, 1, cx, baseY - U * 0.5, U * 0.5);
      gl.addColorStop(0, "rgba(230,150,230,0.3)");
      gl.addColorStop(1, "rgba(230,150,230,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(cx - U * 0.6, baseY - U, U * 1.2, U * 1.1);
      ctx.strokeStyle = "#b98fd8"; ctx.lineWidth = S;
      ctx.beginPath(); ctx.moveTo(cx, baseY); ctx.quadraticCurveTo(cx + S * 2, baseY - U * 0.3, cx, baseY - U * 0.52); ctx.stroke();
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        const col = i % 2 ? "#f2a8e0" : "#a8d8f2";
        const g = ctx.createRadialGradient(cx + Math.cos(a) * S * 2, baseY - U * 0.52 + Math.sin(a) * S * 2, 0.5, cx + Math.cos(a) * S * 3, baseY - U * 0.52 + Math.sin(a) * S * 3, S * 3.4);
        g.addColorStop(0, shade(col, 0.3));
        g.addColorStop(1, shade(col, -0.25));
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(cx + Math.cos(a) * S * 3, baseY - U * 0.52 + Math.sin(a) * S * 3, S * 2.2, S * 1.3, a, 0, 7);
        ctx.fill();
      }
      ctx.fillStyle = "#fff3c9";
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.52, S * 1.5, 0, 7); ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.beginPath(); ctx.arc(cx - S * 0.5, baseY - U * 0.54, S * 0.5, 0, 7); ctx.fill();
      break;
    }
    case O.ChaosOrb: {
      const gl = ctx.createRadialGradient(cx, baseY - U * 0.4, 1, cx, baseY - U * 0.4, U * 0.6);
      gl.addColorStop(0, "rgba(224,90,201,0.45)");
      gl.addColorStop(1, "rgba(224,90,201,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(cx - U * 0.7, baseY - U, U * 1.4, U * 1.2);
      groundShadow(ctx, cx, baseY, U * 0.22, U * 0.07, 0.3);
      const g = ctx.createRadialGradient(cx - U * 0.08, baseY - U * 0.46, U * 0.02, cx, baseY - U * 0.4, U * 0.26);
      g.addColorStop(0, "#ffe9fb");
      g.addColorStop(0.35, "#e05ac9");
      g.addColorStop(1, "#6a1a5e");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.4, U * 0.24, 0, 7); ctx.fill();
      stroke(ctx, "rgba(40,8,36,0.6)", S * 0.8);
      ctx.strokeStyle = "rgba(255,230,255,0.55)"; ctx.lineWidth = S * 0.8;
      ctx.beginPath(); ctx.ellipse(cx, baseY - U * 0.4, U * 0.32, U * 0.11, 0.55, 0, 7); ctx.stroke();
      ctx.beginPath(); ctx.ellipse(cx, baseY - U * 0.4, U * 0.3, U * 0.09, -0.7, 0, 7); ctx.stroke();
      break;
    }
    case O.Pearl: {
      groundShadow(ctx, cx, baseY, U * 0.26, U * 0.08, 0.28);
      // раковина
      const sg = ctx.createLinearGradient(cx - U * 0.26, baseY - U * 0.2, cx + U * 0.26, baseY);
      sg.addColorStop(0, "#b08a72"); sg.addColorStop(0.5, "#8a6a5a"); sg.addColorStop(1, "#5d463c");
      ctx.fillStyle = sg;
      ctx.beginPath(); ctx.ellipse(cx, baseY - U * 0.08, U * 0.28, U * 0.18, 0, Math.PI, 0); ctx.fill();
      stroke(ctx, "rgba(42,30,24,0.7)", S * 0.8);
      ctx.strokeStyle = "rgba(60,44,36,0.5)"; ctx.lineWidth = S * 0.5;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.ellipse(cx, baseY - U * 0.08, U * 0.28 * (i / 4 + 0.2), U * 0.18 * (i / 4 + 0.2), 0, Math.PI, 0);
        ctx.stroke();
      }
      // жемчужина
      const pg = ctx.createRadialGradient(cx - S * 1.5, baseY - U * 0.2, 0.5, cx, baseY - U * 0.14, U * 0.13);
      pg.addColorStop(0, "#ffffff");
      pg.addColorStop(0.5, "#f0e6f2");
      pg.addColorStop(1, "#b9a8c0");
      ctx.fillStyle = pg;
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.14, U * 0.12, 0, 7); ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.9)";
      ctx.beginPath(); ctx.arc(cx - S * 1.4, baseY - U * 0.18, S * 0.9, 0, 7); ctx.fill();
      break;
    }
    case O.CoralObj: {
      groundShadow(ctx, cx, baseY, U * 0.28, U * 0.08, 0.24);
      const cols = ["#e0745a", "#f2a24d", "#c95a8a"];
      for (let i = 0; i < 3; i++) {
        const x = cx + (i - 1) * U * 0.18;
        ctx.strokeStyle = shade(cols[i], -0.3);
        ctx.lineWidth = S * 3;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(x, baseY);
        ctx.quadraticCurveTo(x + (i - 1) * S * 3, baseY - U * 0.3, x + (i - 1) * S * 5, baseY - U * 0.56);
        ctx.stroke();
        ctx.strokeStyle = cols[i];
        ctx.lineWidth = S * 1.8;
        ctx.stroke();
        // веточки
        ctx.lineWidth = S * 1.2;
        for (let k = 0; k < 2; k++) {
          ctx.beginPath();
          ctx.moveTo(x + (i - 1) * S * 3, baseY - U * (0.24 + k * 0.14));
          ctx.lineTo(x + (i - 1) * S * 3 + (k ? 1 : -1) * S * 3, baseY - U * (0.34 + k * 0.14));
          ctx.stroke();
        }
      }
      ctx.fillStyle = "rgba(255,255,255,0.35)";
      ctx.beginPath(); ctx.arc(cx - U * 0.14, baseY - U * 0.4, S * 0.8, 0, 7); ctx.fill();
      break;
    }
    case O.Seaweed: {
      groundShadow(ctx, cx, baseY, U * 0.22, U * 0.06, 0.2);
      // камень-якорь у основания
      ctx.fillStyle = "#4a5a52";
      blobPath(ctx, cx, baseY - S * 1.2, U * 0.13, U * 0.06, seedN, 0.3, 7);
      ctx.fill();
      stroke(ctx, "rgba(16,30,26,0.7)", S * 0.7);
      for (let i = 0; i < 4; i++) {
        const x = cx + (i - 1.5) * U * 0.14;
        const hh = U * (0.42 + hash2(seedN, i, 3) * 0.3);
        const g = ctx.createLinearGradient(x, baseY, x, baseY - hh);
        g.addColorStop(0, "#2f5f3c");
        g.addColorStop(1, "#6aa05c");
        ctx.strokeStyle = g;
        ctx.lineWidth = S * (1.6 - i * 0.15);
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(x, baseY);
        const tipX = x + (hash2(seedN, i, 9) - 0.3) * U * 0.28;
        ctx.quadraticCurveTo(x + (hash2(seedN, i, 5) - 0.5) * U * 0.3, baseY - hh * 0.55, tipX, baseY - hh);
        ctx.stroke();
        // листья-лопасти
        for (let k = 1; k <= 3; k++) {
          const ly = baseY - hh * (k / 3.4);
          const lx = x + (tipX - x) * (k / 3.4);
          ctx.fillStyle = k % 2 ? "rgba(90,150,100,0.85)" : "rgba(58,110,72,0.85)";
          ctx.beginPath();
          ctx.ellipse(lx + (k % 2 ? 1 : -1) * S * 1.6, ly, S * 2.2, S * 0.9, (k % 2 ? 0.4 : -0.4), 0, 7);
          ctx.fill();
        }
        // блик на стебле
        ctx.strokeStyle = "rgba(190,240,200,0.3)";
        ctx.lineWidth = S * 0.4;
        ctx.beginPath();
        ctx.moveTo(x - S * 0.3, baseY - hh * 0.2);
        ctx.lineTo(tipX - S * 0.3, baseY - hh * 0.9);
        ctx.stroke();
      }
      break;
    }
    case O.Wreck: {
      groundShadow(ctx, cx + U * 0.06, baseY, U * 0.44, U * 0.12, 0.34);
      const g = ctx.createLinearGradient(cx - U * 0.4, baseY - U * 0.3, cx + U * 0.4, baseY);
      g.addColorStop(0, "#7a5f42"); g.addColorStop(0.5, "#54402c"); g.addColorStop(1, "#33261a");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(cx - U * 0.38, baseY - U * 0.2);
      ctx.quadraticCurveTo(cx, baseY + U * 0.06, cx + U * 0.38, baseY - U * 0.24);
      ctx.lineTo(cx + U * 0.3, baseY - U * 0.42);
      ctx.lineTo(cx - U * 0.3, baseY - U * 0.38);
      ctx.closePath();
      ctx.fill();
      stroke(ctx, "rgba(22,14,10,0.8)", S * 0.9);
      ctx.strokeStyle = "rgba(30,20,14,0.6)"; ctx.lineWidth = S * 0.7;
      for (let i = 1; i < 4; i++) {
        const y = baseY - U * (0.4 - i * 0.07);
        ctx.beginPath(); ctx.moveTo(cx - U * 0.34, y); ctx.lineTo(cx + U * 0.34, y - U * 0.02); ctx.stroke();
      }
      // мачта с обрывком паруса
      ctx.strokeStyle = "#4a3726"; ctx.lineWidth = S * 1.6;
      ctx.beginPath(); ctx.moveTo(cx + U * 0.04, baseY - U * 0.4); ctx.lineTo(cx + U * 0.12, baseY - U * 0.9); ctx.stroke();
      ctx.fillStyle = "rgba(200,196,180,0.45)";
      ctx.beginPath();
      ctx.moveTo(cx + U * 0.1, baseY - U * 0.86);
      ctx.quadraticCurveTo(cx + U * 0.32, baseY - U * 0.72, cx + U * 0.09, baseY - U * 0.56);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(74,120,96,0.6)";
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.arc(cx + (hash2(seedN, i, 3) - 0.5) * U * 0.6, baseY - U * (0.1 + hash2(seedN, i, 7) * 0.22), S * 1.6, 0, 7);
        ctx.fill();
      }
      break;
    }
    case O.AlienRelic: {
      const gl = ctx.createRadialGradient(cx, baseY - U * 0.4, 1, cx, baseY - U * 0.4, U * 0.6);
      gl.addColorStop(0, "rgba(95,232,192,0.35)");
      gl.addColorStop(1, "rgba(95,232,192,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(cx - U * 0.7, baseY - U, U * 1.4, U * 1.2);
      groundShadow(ctx, cx, baseY, U * 0.26, U * 0.08, 0.34);
      const g = ctx.createLinearGradient(cx - U * 0.3, baseY - U * 0.8, cx + U * 0.3, baseY);
      g.addColorStop(0, "#5a6f82"); g.addColorStop(0.5, "#39485a"); g.addColorStop(1, "#1e2836");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(cx, baseY - U * 0.82);
      ctx.lineTo(cx + U * 0.26, baseY - U * 0.42);
      ctx.lineTo(cx + U * 0.14, baseY - U * 0.02);
      ctx.lineTo(cx - U * 0.14, baseY - U * 0.02);
      ctx.lineTo(cx - U * 0.26, baseY - U * 0.42);
      ctx.closePath();
      ctx.fill();
      stroke(ctx, "rgba(10,16,22,0.85)", S);
      ctx.strokeStyle = "#5fe8c0"; ctx.lineWidth = S * 0.9;
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.42, U * 0.11, 0, 7); ctx.stroke();
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(cx - U * 0.16, baseY - U * (0.24 + i * 0.1));
        ctx.lineTo(cx + U * 0.16, baseY - U * (0.24 + i * 0.1));
        ctx.stroke();
      }
      ctx.fillStyle = "#9cffe4";
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.42, S * 1.4, 0, 7); ctx.fill();
      break;
    }
    case O.Mechanism: {
      groundShadow(ctx, cx, baseY, U * 0.3, U * 0.09, 0.32);
      const g = ctx.createRadialGradient(cx - U * 0.08, baseY - U * 0.4, U * 0.03, cx, baseY - U * 0.34, U * 0.28);
      g.addColorStop(0, "#a9b4bf"); g.addColorStop(0.55, "#6f7a85"); g.addColorStop(1, "#3c444c");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.34, U * 0.24, 0, 7); ctx.fill();
      stroke(ctx, "rgba(20,26,32,0.8)", S * 0.9);
      ctx.fillStyle = "#4a5259";
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        ctx.save();
        ctx.translate(cx + Math.cos(a) * U * 0.24, baseY - U * 0.34 + Math.sin(a) * U * 0.24);
        ctx.rotate(a);
        ctx.fillRect(-S * 1.4, -S * 1.4, S * 2.8, S * 2.8);
        ctx.restore();
      }
      ctx.fillStyle = "#d9b45c";
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.34, U * 0.08, 0, 7); ctx.fill();
      stroke(ctx, "rgba(70,50,16,0.7)", S * 0.6);
      ctx.fillStyle = "rgba(255,255,255,0.3)";
      ctx.beginPath(); ctx.arc(cx - U * 0.08, baseY - U * 0.42, U * 0.05, 0, 7); ctx.fill();
      break;
    }
    case O.Trap: {
      groundShadow(ctx, cx, baseY, U * 0.3, U * 0.09, 0.2);
      ctx.fillStyle = "rgba(60,26,26,0.5)";
      ctx.beginPath(); ctx.roundRect(cx - U * 0.3, baseY - U * 0.6, U * 0.6, U * 0.58, S); ctx.fill();
      stroke(ctx, "rgba(180,60,60,0.7)", S);
      ctx.strokeStyle = "#c9c2b2"; ctx.lineWidth = S * 0.8;
      for (let i = 0; i < 5; i++) {
        const x = cx - U * 0.2 + (i / 4) * U * 0.4;
        ctx.beginPath(); ctx.moveTo(x, baseY - U * 0.1); ctx.lineTo(x, baseY - U * 0.42); ctx.stroke();
        ctx.fillStyle = "#e8e2d2";
        ctx.beginPath(); ctx.moveTo(x - S, baseY - U * 0.42); ctx.lineTo(x + S, baseY - U * 0.42); ctx.lineTo(x, baseY - U * 0.52); ctx.closePath(); ctx.fill();
      }
      break;
    }
    case O.Gate: {
      const gl = ctx.createRadialGradient(cx, baseY - U * 0.4, 1, cx, baseY - U * 0.4, U * 0.6);
      gl.addColorStop(0, "rgba(120,170,255,0.35)");
      gl.addColorStop(1, "rgba(120,170,255,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(cx - U * 0.7, baseY - U, U * 1.4, U * 1.2);
      groundShadow(ctx, cx, baseY, U * 0.34, U * 0.1, 0.32);
      // портал внутри арки
      const pg = ctx.createRadialGradient(cx, baseY - U * 0.42, U * 0.03, cx, baseY - U * 0.4, U * 0.28);
      pg.addColorStop(0, "#dce9ff");
      pg.addColorStop(0.45, "#5a86d8");
      pg.addColorStop(1, "#1b2c5a");
      ctx.fillStyle = pg;
      ctx.beginPath(); ctx.arc(cx, baseY - U * 0.4, U * 0.26, Math.PI, 0); ctx.fill();
      ctx.fillRect(cx - U * 0.26, baseY - U * 0.4, U * 0.52, U * 0.4);
      // каменная арка из блоков
      for (let i = 0; i <= 8; i++) {
        const a = Math.PI + (i / 8) * Math.PI;
        const bx = cx + Math.cos(a) * U * 0.32;
        const by = baseY - U * 0.4 + Math.sin(a) * U * 0.32;
        ctx.save();
        ctx.translate(bx, by);
        ctx.rotate(a + Math.PI / 2);
        const bgd = ctx.createLinearGradient(-S * 2, -S * 2, S * 2, S * 2);
        bgd.addColorStop(0, "#9a938a");
        bgd.addColorStop(1, "#4e4a45");
        ctx.fillStyle = bgd;
        ctx.fillRect(-S * 2.2, -S * 2, S * 4.4, S * 4);
        ctx.strokeStyle = "rgba(28,24,20,0.8)";
        ctx.lineWidth = S * 0.6;
        ctx.strokeRect(-S * 2.2, -S * 2, S * 4.4, S * 4);
        ctx.restore();
      }
      // столбы
      for (const dx of [-1, 1]) {
        ctx.fillStyle = "#6b645c";
        ctx.fillRect(cx + dx * U * 0.32 - S * 2.2, baseY - U * 0.4, S * 4.4, U * 0.4);
        ctx.strokeStyle = "rgba(28,24,20,0.8)";
        ctx.lineWidth = S * 0.6;
        ctx.strokeRect(cx + dx * U * 0.32 - S * 2.2, baseY - U * 0.4, S * 4.4, U * 0.4);
      }
      // руны
      ctx.fillStyle = "#a8c8ff";
      for (let i = 0; i < 3; i++) {
        const a = Math.PI + 0.5 + i * 0.9;
        ctx.beginPath();
        ctx.arc(cx + Math.cos(a) * U * 0.32, baseY - U * 0.4 + Math.sin(a) * U * 0.32, S * 0.7, 0, 7);
        ctx.fill();
      }
      break;
    }
    default:
      break;
  }
}
