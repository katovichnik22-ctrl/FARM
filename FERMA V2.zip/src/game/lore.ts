import type { Engine } from "./engine";
import type {
  EraId, MagicState, ReligionState, CultureState, SchoolId, GreatKind, GreatPerson, DoctrineId,
} from "../types/lore";
import { ERAS, SCHOOLS, DOCTRINES, GREAT_KINDS } from "../types/lore";
import { TECHS, TECH_BY_ID } from "../data/tech";
import { SPELLS, SPELL_BY_ID, RITUALS, ARTIFACTS, ARTIFACT_BY_ID, BEAST_BY_ID, RELIGION_PREFIX, RELIGION_SUFFIX, RELIGION_SYMS, RELIGION_COLORS, PROPHET_NAMES, PROPHET_TRAITS, GREAT_NAMES, GREAT_BIOS } from "../data/magic";
import { ITEMS } from "../data/items";
import { clamp, clamp01, mulberry32 } from "../lib/noise";
import { snd } from "../lib/sound";

export function freshMagic(): MagicState {
  return {
    unlocked: false, school: null, schools: [], mana: 0, manaMax: 100,
    spells: [], artifacts: [], beasts: [], ritual: null, cds: {},
    lvl: 1, xp: 0, auraT: 0,
  };
}
export function freshReligion(): ReligionState {
  return {
    founded: false, name: "", symbol: "✦", color: "#ffd97a", doctrines: [],
    followers: 0, holyCity: "", pilgrims: 0, crusadeTarget: null, crusadeDays: 0,
    inquisition: false, prophets: [], founderDay: 0,
  };
}
export function freshCulture(): CultureState {
  return { points: 0, total: 0, borders: 6, greats: [], greatProgress: 0, masterpieces: 0, victoryProgress: 0, greatUid: 1 };
}

export class LoreSim {
  techs = new Set<string>();
  science = 0;
  sciTotal = 0;
  era: EraId = "stone";
  researching: string | null = null;
  magic: MagicState = freshMagic();
  religion: ReligionState = freshReligion();
  culture: CultureState = freshCulture();
  worldReligions: { name: string; color: string; symbol: string; share: number }[] = [];
  /** временные эффекты ритуалов: kind -> {value, until(day)} */
  buffs: Record<string, { value: number; until: number }> = {};
  private sciAcc = 0;
  private culAcc = 0;
  private manaAcc = 0;

  init(seed: number) {
    // азы каменного века герой знает с рождения
    this.techs = new Set(["t_fire", "t_stonework", "t_hunt", "t_totem"]);
    this.science = 0; this.sciTotal = 0;
    this.era = "stone"; this.researching = null;
    this.magic = freshMagic();
    this.religion = freshReligion();
    this.culture = freshCulture();
    this.buffs = {};
    const r = mulberry32(seed ^ 0x10e3);
    this.worldReligions = [
      { name: "Древо Жизни", color: "#7ae68a", symbol: "☘", share: 20 + r() * 15 },
      { name: "Девять Ветров", color: "#8fa2f2", symbol: "✧", share: 15 + r() * 15 },
      { name: "Каменный Отец", color: "#c9c2b2", symbol: "◈", share: 12 + r() * 12 },
      { name: "Лунный Свод", color: "#a26af2", symbol: "☾", share: 10 + r() * 10 },
    ];
  }

  // ---------- ЭПОХИ И ТЕХНОЛОГИИ ----------
  eraDef() { return ERAS.find((x) => x.id === this.era)!; }
  eraIndex() { return ERAS.findIndex((x) => x.id === this.era); }
  nextEra() { return ERAS[this.eraIndex() + 1] ?? null; }
  has(id: string): boolean { return this.techs.has(id); }
  canResearch(id: string): { ok: boolean; reason: string } {
    const t = TECH_BY_ID[id];
    if (!t) return { ok: false, reason: "?" };
    if (this.has(id)) return { ok: false, reason: "Уже изучено" };
    const eraIdx = ERAS.findIndex((x) => x.id === t.era);
    if (eraIdx > this.eraIndex() + 1) return { ok: false, reason: `Нужна эпоха: ${ERAS[eraIdx - 1].name}` };
    for (const n of t.needs) if (!this.has(n)) return { ok: false, reason: `Нужно: ${TECH_BY_ID[n]?.name ?? n}` };
    return { ok: true, reason: "" };
  }
  available(): string[] { return TECHS.filter((t) => this.canResearch(t.id).ok).map((t) => t.id); }

  setResearch(e: Engine, id: string) {
    const c = this.canResearch(id);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    this.researching = id;
    e.toast(`Учёные взялись за «${TECH_BY_ID[id].name}»`, "info");
    snd.ui();
    e.poke();
  }
  /** Наука в секунду */
  sciRate(e: Engine): number {
    let s = 0.05;
    if (e.city.s.founded) s += e.city.s.metrics.science * 0.0038 * (1 + e.city.s.districts.sci * 0.2);
    s += this.techEffect("sci") * 0.0015;
    if (this.religion.founded && this.religion.doctrines.includes("loreDoc")) s *= 1.18;
    s *= e.dynasty.govDef().science;
    if (this.buffs.sciBoost && e.day <= this.buffs.sciBoost.until) s *= 1 + this.buffs.sciBoost.value;
    return s;
  }
  addScience(e: Engine, n: number) {
    this.science += n; this.sciTotal += n;
    // переход эпохи
    const nx = this.nextEra();
    if (nx && this.sciTotal >= nx.sciNeed) {
      this.era = nx.id;
      e.toast(`НАСТУПИЛА ЭПОХА: ${nx.name}! ${nx.desc}`, "good");
      e.nations.log(e, `Эпоха: ${nx.name}`, "good");
      snd.levelup();
      e.shake = 0.5;
      if (e.city.s.founded) e.city.s.paradeT = 8;
      e.addXp(120);
      this.culture.points += 60;
    }
    // учёные сами берутся за дело, если приказа нет
    if (!this.researching) {
      const avail = this.available()
        .map((id) => TECH_BY_ID[id])
        .filter((t) => t.cost <= this.science)
        .sort((a, b) => a.cost - b.cost);
      if (avail.length) {
        this.researching = avail[0].id;
        e.toast(`Учёные сами взялись за «${avail[0].name}»`, "info");
      }
    }
    // завершение исследования
    if (this.researching) {
      const t = TECH_BY_ID[this.researching];
      if (t && this.science >= t.cost) {
        this.science -= t.cost;
        this.techs.add(t.id);
        this.researching = null;
        e.toast(`Открытие: ${t.name}! ${t.bonusText}`, "good");
        e.nations.log(e, `Открытие: ${t.name}`, "good");
        snd.levelup();
        e.addXp(40);
        this.culture.points += 25;
        if (t.unlockS) for (const s of t.unlockS) if (!this.magic.spells.includes(s)) this.magic.spells.push(s);
        if (t.id === "t_ley") { this.magic.unlocked = true; e.toast("Лей-линии открыты — вы можете встать на путь мага", "good"); }
        if (t.effect?.mana) this.magic.manaMax += t.effect.mana;
        if (t.effect?.borders) this.culture.borders += t.effect.borders;
        e.poke();
      }
    }
  }
  /** Суммарный эффект изученных технологий по ключу */
  techEffect(key: "sci" | "gold" | "prod" | "food" | "culture" | "faith" | "mana" | "armyAtk" | "armyDef" | "borders"): number {
    let v = 0;
    for (const id of this.techs) {
      const t = TECH_BY_ID[id];
      const val = t?.effect?.[key];
      if (val) v += val;
    }
    return v;
  }
  /** Разблокировано ли здание технологиями (если оно вообще в дереве) */
  buildingLocked(id: string): boolean {
    let inTree = false;
    for (const t of TECHS) {
      if (t.unlockB?.includes(id)) {
        inTree = true;
        if (this.techs.has(t.id)) return false;
      }
    }
    return inTree;
  }
  buildingTech(id: string): string | null {
    for (const t of TECHS) if (t.unlockB?.includes(id)) return t.name;
    return null;
  }
  unitLocked(id: string): boolean {
    let inTree = false;
    for (const t of TECHS) {
      if (t.unlockU?.includes(id)) {
        inTree = true;
        if (this.techs.has(t.id)) return false;
      }
    }
    return inTree;
  }

  stealTech(e: Engine, nationTech: number): boolean {
    const avail = this.available();
    if (!avail.length) return false;
    const pick = avail[Math.floor(Math.random() * Math.min(avail.length, 3 + nationTech))] ?? avail[0];
    const t = TECH_BY_ID[pick];
    this.techs.add(pick);
    if (t.unlockS) for (const s of t.unlockS) if (!this.magic.spells.includes(s)) this.magic.spells.push(s);
    if (t.effect?.mana) this.magic.manaMax += t.effect.mana;
    e.toast(`Выкрадены чертежи: ${t.name}!`, "good");
    e.nations.log(e, `Украдена технология: ${t.name}`, "info");
    return true;
  }

  // ---------- МАГИЯ ----------
  canBecomeMage(e: Engine): { ok: boolean; reason: string } {
    if (this.magic.school) return { ok: false, reason: "Вы уже избрали школу" };
    const hasTower = e.buildings.some((b) => b.done && ["altar", "portal", "obsidian_tron"].includes(b.def));
    if (!this.magic.unlocked && !hasTower) return { ok: false, reason: "Нужна технология «Чтение лей-линий» или алтарь" };
    if (!hasTower) return { ok: false, reason: "Нужна магическая башня: алтарь, портал или трон" };
    return { ok: true, reason: "" };
  }
  becomeMage(e: Engine, school: SchoolId) {
    const c = this.canBecomeMage(e);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    this.magic.unlocked = true;
    this.magic.school = school;
    if (!this.magic.schools.includes(school)) this.magic.schools.push(school);
    this.magic.manaMax = Math.max(100, this.magic.manaMax);
    this.magic.mana = this.magic.manaMax * 0.5;
    // стартовые заклинания школы
    for (const s of SPELLS) if (s.school === school && s.lvl <= 1 && !this.magic.spells.includes(s.id)) this.magic.spells.push(s.id);
    if (!this.magic.spells.length) this.magic.spells.push("s_firebolt");
    const sd = SCHOOLS.find((x) => x.id === school)!;
    e.toast(`Вы встали на путь мага школы «${sd.name}». Мир изменился навсегда`, "good");
    e.nations.log(e, `Путь мага: школа ${sd.name}`, "good");
    this.magic.auraT = 6;
    snd.levelup();
    e.addXp(80);
    e.dynasty.support("magi", 14);
    e.poke();
  }
  learnSchoolCost(): number { return 600 + this.magic.schools.length * 450; }
  learnSchool(e: Engine, school: SchoolId) {
    if (this.magic.schools.includes(school)) { e.toast("Школа уже изучена", "info"); return; }
    const cost = this.learnSchoolCost();
    if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота`, "warn"); return; }
    if (this.magic.lvl < this.magic.schools.length + 1) { e.toast(`Нужен ${this.magic.schools.length + 1} уровень мага`, "warn"); return; }
    e.player.gold -= cost;
    this.magic.schools.push(school);
    for (const s of SPELLS) if (s.school === school && s.lvl <= this.magic.lvl && !this.magic.spells.includes(s.id)) this.magic.spells.push(s.id);
    this.magic.manaMax += 30;
    e.toast(`Изучена школа «${SCHOOLS.find((x) => x.id === school)!.name}»`, "good");
    snd.craft();
    e.poke();
  }
  spellReady(id: string): boolean { return (this.magic.cds[id] ?? 0) <= 0; }
  knowsSpell(id: string): boolean { return this.magic.spells.includes(id); }
  spellPower(): number {
    let p = 1 + (this.magic.lvl - 1) * 0.12;
    for (const a of this.magic.artifacts) p += ARTIFACT_BY_ID[a]?.effect.spellPow ?? 0;
    return p;
  }
  castWorld(e: Engine, id: string) {
    const sp = SPELL_BY_ID[id];
    if (!sp || !this.knowsSpell(id)) { e.toast("Заклинание неведомо", "warn"); return; }
    if (!sp.world) { e.toast("Эти чары творят лишь в бою", "warn"); return; }
    if (!this.spellReady(id)) { e.toast(`Чары не готовы (${Math.ceil(this.magic.cds[id])})`, "warn"); return; }
    if (this.magic.mana < sp.mana) { e.toast(`Не хватает маны (${Math.floor(this.magic.mana)}/${sp.mana})`, "warn"); return; }
    this.magic.mana -= sp.mana;
    this.magic.cds[id] = sp.cd * 12;
    const pow = (sp.power ?? 30) * this.spellPower();
    switch (sp.kind) {
      case "heal":
        e.player.hp = clamp(e.player.hp + pow, 0, e.player.maxHp);
        e.player.poisonT = 0;
        e.addFloater(`+${Math.round(pow)}`, "#8ae68a", e.player.x, e.player.y - 30, true);
        break;
      case "shield":
        this.buffs.shield = { value: 0.3, until: e.day + 2 };
        e.toast("Мерцающий оберег окружил вас и войско", "good");
        break;
      case "weather": {
        const w = ["rain", "clear", "storm", "snow", "fog"] as const;
        e.weather = w[Math.floor(Math.random() * w.length)];
        e.weatherT = 240;
        e.toast(`Небо подчинилось: ${e.weather === "rain" ? "хлынул дождь" : e.weather === "storm" ? "грянула гроза" : e.weather === "snow" ? "повалил снег" : e.weather === "fog" ? "лёг туман" : "прояснилось"}`, "good");
        break;
      }
      case "curse": {
        const foes = e.nations.atWar();
        if (!foes.length) { e.toast("Некого проклинать — вы ни с кем не воюете", "warn"); this.magic.mana += sp.mana; return; }
        for (const n of foes) { n.army = Math.max(1, n.army - 2); n.warScore = clamp(n.warScore - 8, -100, 100); }
        e.toast("Проклятие пало на врагов: их войско слабеет", "good");
        break;
      }
      case "bless":
        this.buffs.atk = { value: 0.25, until: e.day + 3 };
        if (id === "s_timewarp") this.buffs.sciBoost = { value: 0.6, until: e.day + 3 };
        e.toast(id === "s_timewarp" ? "Время течёт иначе: работа кипит" : "Благословение на войске", "good");
        break;
      case "revive": {
        let back = 0;
        for (const h of [...e.army.hospital]) { back += h.n; const sq = e.army.squads.find((s) => s.kind === h.kind); if (sq) sq.n += h.n; }
        e.army.hospital = [];
        e.toast(back > 0 ? `Воскрешение: ${back} бойцов вернулись в строй` : "Воскрешать некого", back > 0 ? "good" : "info");
        break;
      }
      case "teleport": {
        const sp2 = e.spawnPoint();
        e.player.x = sp2.x * 40 + 20; e.player.y = sp2.y * 40 + 20;
        e.cam.x = e.player.x; e.cam.y = e.player.y;
        e.moveTarget = null;
        e.toast("Шаг сквозь складку мира — вы у родного порога", "good");
        break;
      }
      default:
        e.toast(`${sp.name} сотворено`, "good");
    }
    this.magic.auraT = 2.5;
    this.magicXp(e, 8);
    e.spawnHitParticles(e.player.x, e.player.y - 10, SCHOOLS.find((x) => x.id === sp.school)?.color ?? "#a26af2", 20, "star");
    snd.fireball();
    e.shake = 0.25;
    e.poke();
  }
  magicXp(e: Engine, n: number) {
    this.magic.xp += n;
    const need = 60 + this.magic.lvl * 70;
    if (this.magic.xp >= need) {
      this.magic.xp -= need;
      this.magic.lvl++;
      this.magic.manaMax += 25;
      // новые заклинания по уровню
      for (const s of SPELLS) {
        if (this.magic.schools.includes(s.school) && s.lvl <= this.magic.lvl && !this.magic.spells.includes(s.id)) {
          this.magic.spells.push(s.id);
          e.toast(`Постигнуто заклинание: ${s.name}`, "good");
        }
      }
      e.toast(`Магическая сила растёт: уровень ${this.magic.lvl}`, "good");
      snd.levelup();
    }
  }

  // ---------- РИТУАЛЫ ----------
  canRitual(e: Engine, id: string): { ok: boolean; reason: string } {
    const r = RITUALS.find((x) => x.id === id);
    if (!r) return { ok: false, reason: "?" };
    if (this.magic.ritual) return { ok: false, reason: "Другой ритуал уже идёт" };
    if (!this.magic.school) return { ok: false, reason: "Нужно встать на путь мага" };
    if (this.magic.mana < r.mana) return { ok: false, reason: `Мало маны (${Math.floor(this.magic.mana)}/${r.mana})` };
    if (e.player.gold < r.gold) return { ok: false, reason: `Нужно ${r.gold} золота` };
    for (const [cid, n] of r.comps) {
      const have = e.count(cid) + e.city.stockOf(cid);
      if (have < n) return { ok: false, reason: `Не хватает: ${ITEMS[cid]?.name ?? cid} (${have}/${n})` };
    }
    return { ok: true, reason: "" };
  }
  startRitual(e: Engine, id: string) {
    const c = this.canRitual(e, id);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    const r = RITUALS.find((x) => x.id === id)!;
    this.magic.mana -= r.mana;
    e.player.gold -= r.gold;
    for (const [cid, n] of r.comps) {
      let need = n;
      const fromCity = Math.min(need, e.city.stockOf(cid));
      if (fromCity > 0) { e.city.takeStock(cid, fromCity); need -= fromCity; }
      if (need > 0) e.take(cid, need);
    }
    const days = this.has("t_manacore") ? Math.max(1, Math.ceil(r.days / 2)) : r.days;
    this.magic.ritual = { id, left: days };
    e.toast(`Начат ритуал «${r.name}». Завершится через ${days} дн.`, "info");
    this.magic.auraT = 5;
    snd.craft();
    e.poke();
  }
  private finishRitual(e: Engine) {
    const cur = this.magic.ritual;
    if (!cur) return;
    const r = RITUALS.find((x) => x.id === cur.id);
    this.magic.ritual = null;
    if (!r) return;
    const ef = r.effect;
    switch (ef.kind) {
      case "food": this.buffs.food = { value: ef.value, until: e.day + 6 }; break;
      case "weather": e.weather = "rain"; e.weatherT = 300; break;
      case "def": this.buffs.def = { value: ef.value, until: e.day + 8 }; break;
      case "atk": this.buffs.atk = { value: ef.value, until: e.day + 8 }; break;
      case "gold": this.buffs.gold = { value: ef.value, until: e.day + 6 }; break;
      case "sci": this.addScience(e, ef.value); break;
      case "veil": this.buffs.veil = { value: 1, until: e.day + ef.value }; break;
      case "ascend":
        this.culture.points += 200; this.culture.total += 200;
        if (e.city.s.founded) { e.city.s.metrics.faith += 150; e.city.s.paradeT = 12; }
        break;
    }
    e.toast(`Ритуал «${r.name}» завершён! ${r.bonusText}`, "good");
    e.nations.log(e, `Ритуал: ${r.name}`, "good");
    this.magic.auraT = 8;
    this.magicXp(e, 30);
    snd.levelup();
    e.shake = 0.4;
  }

  // ---------- АРТЕФАКТЫ ----------
  hasArtifact(id: string): boolean { return this.magic.artifacts.includes(id); }
  grantArtifact(e: Engine, id?: string): boolean {
    const pool = ARTIFACTS.filter((a) => !this.hasArtifact(a.id));
    if (!pool.length) return false;
    const art = id ? ARTIFACT_BY_ID[id] : pool[Math.floor(Math.random() * pool.length)];
    if (!art || this.hasArtifact(art.id)) return false;
    this.magic.artifacts.push(art.id);
    if (art.effect.mana) this.magic.manaMax += art.effect.mana;
    e.toast(`АРТЕФАКТ: ${art.name}! ${art.bonusText}`, "good");
    e.nations.log(e, `Обретён артефакт: ${art.name}`, "good");
    e.spawnHitParticles(e.player.x, e.player.y - 20, "#ffd97a", 26, "star");
    snd.levelup();
    e.shake = 0.5;
    e.poke();
    return true;
  }
  buyArtifact(e: Engine) {
    const pool = ARTIFACTS.filter((a) => !this.hasArtifact(a.id));
    if (!pool.length) { e.toast("Торговцы чудесами разводят руками: всё уже у вас", "info"); return; }
    const cost = 900 + this.magic.artifacts.length * 700;
    if (e.player.gold < cost) { e.toast(`Странствующий маг просит ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    this.grantArtifact(e);
  }
  artEffect(key: keyof NonNullable<(typeof ARTIFACTS)[number]["effect"]>): number {
    let v = 0;
    for (const id of this.magic.artifacts) {
      const val = ARTIFACT_BY_ID[id]?.effect[key];
      if (val) v += val;
    }
    return v;
  }

  // ---------- МИФИЧЕСКИЕ СУЩЕСТВА ----------
  tame(e: Engine, id: string) {
    const b = BEAST_BY_ID[id];
    if (!b) return;
    if (this.magic.beasts.includes(b.id)) { e.toast(`${b.name} уже служит вам`, "info"); return; }
    if (!this.magic.school) { e.toast("Приручать чудищ может лишь маг", "warn"); return; }
    if (e.player.gold < b.tameCost) { e.toast(`Нужно ${b.tameCost} золота на дары и снаряжение`, "warn"); return; }
    if (this.magic.mana < b.tameMana) { e.toast(`Нужно ${b.tameMana} маны`, "warn"); return; }
    e.player.gold -= b.tameCost;
    this.magic.mana -= b.tameMana;
    const bonus = (this.magic.schools.includes(b.school) ? 0.25 : 0) + this.magic.lvl * 0.04 + e.army.power() / 2500;
    if (Math.random() < clamp01(0.4 + bonus)) {
      this.magic.beasts.push(b.id);
      e.toast(`${b.name} склонил голову! ${b.bonusText}`, "good");
      e.nations.log(e, `Приручён ${b.name}`, "good");
      this.magicXp(e, 45);
      e.addXp(100);
      this.culture.points += 80;
      snd.levelup();
      e.shake = 0.6;
    } else {
      e.toast(`${b.name} вырвался и ушёл в горы. Дары потеряны`, "bad");
      e.player.hp = clamp(e.player.hp - 18, 1, e.player.maxHp);
      snd.hurt();
    }
    e.poke();
  }
  beastEffect(key: "armyAtk" | "armyDef" | "mana" | "food" | "gold" | "culture"): number {
    let v = 0;
    for (const id of this.magic.beasts) {
      const val = BEAST_BY_ID[id]?.effect[key];
      if (val) v += val;
    }
    return v;
  }

  /** Суммарные боевые множители от магии, религии, технологий и ритуалов */
  armyAtkMul(e: Engine): number {
    let m = 1 + this.techEffect("armyAtk") + this.artEffect("armyAtk") + this.beastEffect("armyAtk");
    if (this.religion.founded && this.religion.doctrines.includes("warDoc")) m += 0.14;
    if (this.buffs.atk && e.day <= this.buffs.atk.until) m += this.buffs.atk.value;
    return m;
  }
  armyDefMul(e: Engine): number {
    let m = 1 + this.techEffect("armyDef") + this.artEffect("armyDef") + this.beastEffect("armyDef");
    if (this.buffs.def && e.day <= this.buffs.def.until) m += this.buffs.def.value;
    if (this.buffs.shield && e.day <= this.buffs.shield.until) m += this.buffs.shield.value;
    return m;
  }

  // ---------- РЕЛИГИЯ ----------
  canFoundReligion(e: Engine): { ok: boolean; reason: string } {
    if (this.religion.founded) return { ok: false, reason: "Религия уже основана" };
    if (!e.city.s.founded) return { ok: false, reason: "Нужен основанный город" };
    const temple = e.buildings.some((b) => b.done && ["hram", "sobor", "monastyr"].includes(b.def));
    if (!temple) return { ok: false, reason: "Нужен храм, собор или монастырь" };
    if (e.city.s.metrics.faith < 20) return { ok: false, reason: `Мало веры в городе (${e.city.s.metrics.faith}/20)` };
    return { ok: true, reason: "" };
  }
  suggestReligionName(): string {
    const p = RELIGION_PREFIX[Math.floor(Math.random() * RELIGION_PREFIX.length)];
    const s = RELIGION_SUFFIX[Math.floor(Math.random() * RELIGION_SUFFIX.length)];
    return `${p} ${s}`;
  }
  foundReligion(e: Engine, name: string, doctrine: DoctrineId) {
    const c = this.canFoundReligion(e);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    const r = this.religion;
    r.founded = true;
    r.name = name.trim() || this.suggestReligionName();
    r.symbol = RELIGION_SYMS[Math.floor(Math.random() * RELIGION_SYMS.length)];
    r.color = RELIGION_COLORS[Math.floor(Math.random() * RELIGION_COLORS.length)];
    r.doctrines = [doctrine];
    r.followers = 8;
    r.holyCity = e.city.s.name;
    r.founderDay = e.day;
    e.toast(`Основана религия «${r.name}»! Священный город — ${r.holyCity}`, "good");
    e.nations.log(e, `Основана религия ${r.name}`, "good");
    e.dynasty.support("cerkov", 20);
    if (e.city.s.founded) { e.city.s.metrics.faith += 40; e.city.s.paradeT = 8; }
    this.culture.points += 100;
    e.addXp(100);
    snd.levelup();
    e.poke();
  }
  addDoctrineCost(): number { return 500 + this.religion.doctrines.length * 600; }
  addDoctrine(e: Engine, id: DoctrineId) {
    const r = this.religion;
    if (!r.founded) return;
    if (r.doctrines.includes(id)) { e.toast("Догмат уже принят", "info"); return; }
    if (r.doctrines.length >= 4) { e.toast("Больше четырёх догматов вера не вместит", "warn"); return; }
    const need = 25 * r.doctrines.length;
    if (r.followers < need) { e.toast(`Нужно ${need}% последователей`, "warn"); return; }
    const cost = this.addDoctrineCost();
    if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    r.doctrines.push(id);
    const d = DOCTRINES.find((x) => x.id === id)!;
    e.toast(`Принят догмат «${d.name}»`, "good");
    e.dynasty.support("cerkov", 8);
    snd.craft();
    e.poke();
  }
  religionEffect(key: "faith" | "happy" | "armyAtk" | "gold" | "food" | "sci" | "culture" | "spread"): number {
    if (!this.religion.founded) return key === "spread" ? 1 : 0;
    let v = key === "spread" ? 1 : 0;
    for (const id of this.religion.doctrines) {
      const d = DOCTRINES.find((x) => x.id === id);
      const val = d?.effect[key];
      if (val) { if (key === "spread") v *= val; else v += val; }
    }
    return v;
  }
  sendMissionaries(e: Engine) {
    if (!this.religion.founded) return;
    const cost = 220;
    if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    const gain = (2.5 + Math.random() * 4) * this.religionEffect("spread");
    this.religion.followers = clamp(this.religion.followers + gain, 0, 100);
    this.religion.pilgrims += 2;
    for (const n of e.nations.nations) {
      if (Math.random() < 0.35) n.rel = clamp(n.rel + (n.char === "vera" ? 4 : 1.5), -100, 100);
    }
    e.toast(`Проповедники разошлись по свету: последователей ${this.religion.followers.toFixed(1)}%`, "good");
    snd.craft();
    e.poke();
  }
  callCrusade(e: Engine, nationId: string) {
    if (!this.religion.founded) return;
    const n = e.nations.get(nationId);
    if (!n) return;
    if (this.religion.followers < 25) { e.toast("Для похода нужно 25% последователей", "warn"); return; }
    const cost = 800;
    if (e.player.gold < cost) { e.toast(`Поход требует ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    this.religion.crusadeTarget = n.id;
    this.religion.crusadeDays = 6;
    if (n.state !== "war") e.nations.declareWar(e, n, true);
    this.buffs.atk = { value: 0.3, until: e.day + 6 };
    e.toast(`СВЯЩЕННЫЙ ПОХОД на ${n.name}! Войско воспылало рвением`, "warn");
    e.nations.log(e, `Крестовый поход: ${n.name}`, "bad");
    e.dynasty.support("cerkov", 14);
    e.dynasty.support("narod", 6);
    if (e.city.s.founded) e.city.s.metrics.faith += 30;
    snd.thunder();
    e.poke();
  }
  toggleInquisition(e: Engine) {
    if (!this.religion.founded) return;
    this.religion.inquisition = !this.religion.inquisition;
    if (this.religion.inquisition) {
      e.toast("Объявлена инквизиция: чужая вера искореняется огнём и словом", "warn");
      e.dynasty.support("cerkov", 10);
      e.dynasty.support("narod", -8);
      e.dynasty.support("magi", -10);
    } else {
      e.toast("Инквизиция распущена. В городе выдохнули", "good");
      e.dynasty.support("narod", 6);
    }
    e.poke();
  }

  // ---------- КУЛЬТУРА ----------
  culRate(e: Engine): number {
    let c = 0.02;
    if (e.city.s.founded) c += e.city.s.metrics.culture * 0.0045;
    c += this.techEffect("culture") * 0.0012;
    c += this.beastEffect("culture") * 0.002;
    c += this.religionEffect("culture") * 0.002;
    if (this.buffs.gold && e.day <= this.buffs.gold.until) c *= 1.1;
    return c;
  }
  greatCost(): number { return 240 + this.culture.greats.length * 180; }
  private makeGreat(e: Engine): GreatPerson {
    const kinds: GreatKind[] = ["artist", "writer", "musician", "scientist", "general"];
    if (this.religion.founded) kinds.push("prophet");
    const kind = kinds[Math.floor(Math.random() * kinds.length)];
    const g: GreatPerson = {
      uid: this.culture.greatUid++,
      name: GREAT_NAMES[Math.floor(Math.random() * GREAT_NAMES.length)],
      kind,
      title: GREAT_KINDS[kind].name,
      bio: GREAT_BIOS[Math.floor(Math.random() * GREAT_BIOS.length)],
      used: false, day: e.day,
    };
    this.culture.greats.push(g);
    return g;
  }
  useGreat(e: Engine, uid: number) {
    const g = this.culture.greats.find((x) => x.uid === uid && !x.used);
    if (!g) return;
    g.used = true;
    switch (g.kind) {
      case "artist":
        this.culture.points += 120; this.culture.total += 120; this.culture.masterpieces++;
        if (e.city.s.founded) e.city.s.metrics.culture += 20;
        e.toast(`${g.name} создал великое полотно: +120 культуры`, "good");
        break;
      case "writer":
        this.culture.points += 90; this.culture.total += 90; this.culture.masterpieces++;
        if (e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness + 8, 0, 100);
        e.toast(`${g.name} завершил летопись: +90 культуры, народ доволен`, "good");
        break;
      case "musician":
        this.culture.points += 70; this.culture.total += 70;
        if (e.city.s.founded) { e.city.s.paradeT = 10; e.city.s.happiness = clamp(e.city.s.happiness + 10, 0, 100); }
        e.toast(`${g.name} дал великий концерт! Город поёт`, "good");
        break;
      case "scientist":
        this.addScience(e, 350);
        e.toast(`${g.name} совершил открытие: +350 науки`, "good");
        break;
      case "general": {
        const gen = e.army.makeGeneral();
        gen.name = g.name.split(" ")[0];
        gen.title = "Великий";
        gen.lvl = 3; gen.atkBonus += 0.1; gen.defBonus += 0.08;
        e.army.generals.push(gen);
        e.toast(`${g.name} возглавил войско как великий воевода`, "good");
        break;
      }
      case "prophet":
        if (this.religion.founded) {
          this.religion.followers = clamp(this.religion.followers + 12, 0, 100);
          this.religion.prophets.push({
            name: PROPHET_NAMES[Math.floor(Math.random() * PROPHET_NAMES.length)],
            trait: PROPHET_TRAITS[Math.floor(Math.random() * PROPHET_TRAITS.length)],
            day: e.day,
          });
          if (e.city.s.founded) e.city.s.metrics.faith += 200;
        }
        e.toast(`${g.name} явил откровение: вера разлилась по земле`, "good");
        break;
    }
    e.addXp(50);
    snd.levelup();
    e.poke();
  }
  /** Радиус культурных границ */
  borderRadius(): number {
    return Math.round(this.culture.borders + Math.sqrt(Math.max(0, this.culture.total)) * 0.6 + this.techEffect("borders"));
  }

  // ---------- ТИК ----------
  update(e: Engine, dt: number) {
    // наука
    this.sciAcc += this.sciRate(e) * dt;
    if (this.sciAcc >= 1) { const n = Math.floor(this.sciAcc); this.sciAcc -= n; this.addScience(e, n); }
    // культура
    this.culAcc += this.culRate(e) * dt;
    if (this.culAcc >= 1) {
      const n = Math.floor(this.culAcc); this.culAcc -= n;
      this.culture.points += n; this.culture.total += n;
      this.culture.greatProgress += n;
      if (this.culture.greatProgress >= this.greatCost()) {
        this.culture.greatProgress = 0;
        const g = this.makeGreat(e);
        e.toast(`В ваших землях явился великий человек: ${g.name}, ${g.title.toLowerCase()}`, "good");
        snd.levelup();
        e.poke();
      }
      // культурная победа
      this.culture.victoryProgress = clamp01(this.culture.total / 45000) * 100;
      if (this.culture.victoryProgress >= 100 && !this.buffs.culWin) {
        this.buffs.culWin = { value: 1, until: 1e9 };
        e.toast("КУЛЬТУРНАЯ ПОБЕДА! Ваше искусство покорило мир без единого меча", "good");
        e.nations.log(e, "Культурная победа", "good");
        snd.levelup();
        e.shake = 0.8;
      }
    }
    // мана
    if (this.magic.school) {
      let regen = 0.55 + this.magic.lvl * 0.14 + this.artEffect("manaRegen") + this.beastEffect("mana") * 0.004;
      if (e.buildings.some((b) => b.done && ["altar", "portal", "obsidian_tron"].includes(b.def))) regen *= 1.5;
      if (e.isNight() && this.magic.school === "dark") regen *= 1.3;
      if (!e.isNight() && this.magic.school === "light") regen *= 1.3;
      this.manaAcc += regen * dt;
      if (this.manaAcc >= 0.5) {
        this.magic.mana = clamp(this.magic.mana + this.manaAcc, 0, this.magic.manaMax + this.artEffect("mana"));
        this.manaAcc = 0;
      }
    }
    // перезарядки
    for (const k of Object.keys(this.magic.cds)) {
      if (this.magic.cds[k] > 0) this.magic.cds[k] = Math.max(0, this.magic.cds[k] - dt);
    }
    if (this.magic.auraT > 0) this.magic.auraT -= dt;
  }

  dayTick(e: Engine) {
    // ритуал
    if (this.magic.ritual) {
      this.magic.ritual.left--;
      if (this.magic.ritual.left <= 0) this.finishRitual(e);
    }
    // распространение религии
    const r = this.religion;
    if (r.founded) {
      const base = 0.25 + (e.city.s.founded ? e.city.s.metrics.faith * 0.004 : 0);
      const spread = base * this.religionEffect("spread") * (r.inquisition ? 1.5 : 1);
      r.followers = clamp(r.followers + spread, 0, 100);
      r.pilgrims = Math.floor(r.followers * 0.3);
      // мировые религии уступают
      const total = this.worldReligions.reduce((a, w) => a + w.share, 0) + r.followers;
      if (total > 100) {
        for (const w of this.worldReligions) w.share = Math.max(0, w.share - spread * 0.4);
      }
      if (r.inquisition) {
        if (e.city.s.founded) {
          e.city.s.happiness = clamp(e.city.s.happiness - 1.5, 0, 100);
          e.city.s.metrics.faith += 4;
        }
        for (const n of e.nations.nations) if (Math.random() < 0.25) n.rel = clamp(n.rel - 2, -100, 100);
      }
      // отношения: религиозные страны тянутся или злятся
      for (const n of e.nations.nations) {
        if (n.char === "vera") n.rel = clamp(n.rel + (r.followers > 40 ? 1.2 : -0.5), -100, 100);
      }
      if (r.crusadeDays > 0) {
        r.crusadeDays--;
        if (r.crusadeDays === 0) {
          const t = r.crusadeTarget ? e.nations.get(r.crusadeTarget) : null;
          if (t && t.state === "war") { t.warScore = clamp(t.warScore - 15, -100, 100); }
          r.crusadeTarget = null;
          e.toast("Священный поход завершён. Летописцы уже пишут о нём", "info");
        }
      }
      // милостыня от паломников
      if (r.pilgrims > 0) e.player.gold += Math.floor(r.pilgrims * 0.6);
    }
    // истечение баффов
    for (const k of Object.keys(this.buffs)) {
      if (k !== "culWin" && this.buffs[k].until < e.day) delete this.buffs[k];
    }
    // редкая находка артефакта в дальних землях
    if (this.magic.school && Math.random() < 0.05) {
      const zone = Math.max(Math.abs(e.player.x / 40), Math.abs(e.player.y / 40)) / 224;
      if (zone > 1 && Math.random() < clamp01(zone / 8)) this.grantArtifact(e);
    }
  }
}
