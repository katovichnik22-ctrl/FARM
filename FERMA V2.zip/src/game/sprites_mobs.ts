import { shade, rgba } from "./sprites_objects";

// ===== Тела мобов и боссов =====
// Рисуются в локальных координатах (герой ≈ 20 ед. высотой), центр — на уровне груди.
// Свет сверху-слева: у каждого тела градиент «светлый верх → тёмный низ» и контур.

const INK = "rgba(14,10,12,0.78)";

/** Объёмная заливка: светлее сверху-слева, темнее снизу-справа */
function vol(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, base: string, lightAmt = 0.32, darkAmt = -0.4): CanvasGradient {
  const g = ctx.createRadialGradient(cx - r * 0.4, cy - r * 0.5, r * 0.08, cx, cy + r * 0.15, r * 1.15);
  g.addColorStop(0, shade(base, lightAmt));
  g.addColorStop(0.5, base);
  g.addColorStop(1, shade(base, darkAmt));
  return g;
}
function ell(ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number, base: string, rot = 0, outline = INK, lw = 1.5) {
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, rot, 0, 7);
  ctx.fillStyle = vol(ctx, cx, cy, Math.max(rx, ry), base);
  ctx.fill();
  if (outline) { ctx.strokeStyle = outline; ctx.lineWidth = lw; ctx.stroke(); }
}
function limb(ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number, w: number, col: string) {
  ctx.strokeStyle = shade(col, -0.32);
  ctx.lineWidth = w + 1.1;
  ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
  ctx.strokeStyle = col;
  ctx.lineWidth = w;
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
}
/** Светящийся глаз */
function eye(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, col: string, glow = true) {
  if (glow) {
    const g = ctx.createRadialGradient(x, y, 0.2, x, y, r * 3.4);
    g.addColorStop(0, rgba(col, 0.75));
    g.addColorStop(1, rgba(col, 0));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y, r * 3.4, 0, 7); ctx.fill();
  }
  ctx.fillStyle = col;
  ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  ctx.beginPath(); ctx.arc(x - r * 0.3, y - r * 0.35, r * 0.38, 0, 7); ctx.fill();
}
/** Верхняя подсветка поверх тела */
function topLight(ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number) {
  ctx.fillStyle = "rgba(255,248,226,0.18)";
  ctx.beginPath();
  ctx.ellipse(cx - rx * 0.28, cy - ry * 0.5, rx * 0.5, ry * 0.3, -0.4, 0, 7);
  ctx.fill();
}
/** Пятна/детали */
function spots(ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number, col: string, n: number, seed: number) {
  ctx.fillStyle = col;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + seed;
    const d = 0.35 + ((i * 37) % 10) / 22;
    ctx.beginPath();
    ctx.ellipse(cx + Math.cos(a) * rx * d, cy + Math.sin(a) * ry * d, rx * 0.16, ry * 0.13, a, 0, 7);
    ctx.fill();
  }
}

export interface MobDrawCtx { now: number; breathe: number; moving: boolean; state: string; fuse: number }

/** Тело моба. Возвращает true, если такой моб отрисован. */
export function drawMobBody(ctx: CanvasRenderingContext2D, id: string, c: MobDrawCtx): boolean {
  const t = c.now;
  const walk = Math.sin(c.breathe * 9);
  switch (id) {
    // ================= ДНЕВНЫЕ ЗВЕРИ =================
    case "olen": {
      limb(ctx, -6, 4, -6 + walk * 3, 11, 2.6, "#6b5238");
      limb(ctx, 5, 4, 5 - walk * 3, 11, 2.6, "#6b5238");
      ell(ctx, 0, -2, 12.5, 8.5, "#8a6a4a");
      topLight(ctx, 0, -2, 12.5, 8.5);
      spots(ctx, 0, -2, 12, 8, "rgba(240,226,200,0.28)", 5, 1.2);
      ell(ctx, 10, -9, 5.6, 4.6, "#9a7854", 0.2);
      // рога
      ctx.strokeStyle = "#e0d6c0"; ctx.lineWidth = 2; ctx.lineCap = "round";
      for (const dx of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(9 + dx * 2, -12.5);
        ctx.quadraticCurveTo(9 + dx * 5, -19, 8 + dx * 7, -21);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(9 + dx * 3.6, -16.5);
        ctx.lineTo(9 + dx * 7.5, -17.5);
        ctx.stroke();
      }
      ctx.fillStyle = "#2b2018";
      ctx.beginPath(); ctx.ellipse(14.6, -8.2, 1.5, 1.1, 0, 0, 7); ctx.fill();
      eye(ctx, 12, -10.4, 1.15, "#3a2a1c", false);
      ctx.strokeStyle = "#6b5238"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-11.5, -4); ctx.quadraticCurveTo(-15, -6, -14, -9); ctx.stroke();
      return true;
    }
    case "krolik": {
      limb(ctx, -3, 4, -4 + walk * 1.6, 8, 2, "#8f877a");
      limb(ctx, 3, 4, 2 - walk * 1.6, 8, 2, "#8f877a");
      ell(ctx, 0, 0, 9, 7, "#b8b0a4");
      topLight(ctx, 0, 0, 9, 7);
      ell(ctx, 6.5, -5, 4.8, 4.2, "#c4bcb0");
      // уши
      for (const [ex, rot] of [[4.6, -0.22], [8, 0.2]] as [number, number][]) {
        ctx.beginPath();
        ctx.ellipse(ex, -12.5, 1.9, 5.4, rot, 0, 7);
        ctx.fillStyle = vol(ctx, ex, -12.5, 5, "#bdb4a8");
        ctx.fill();
        ctx.strokeStyle = INK; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.fillStyle = "rgba(226,166,166,0.65)";
        ctx.beginPath(); ctx.ellipse(ex, -12.5, 0.85, 3.6, rot, 0, 7); ctx.fill();
      }
      eye(ctx, 8.4, -5.6, 1.15, "#2b2420", false);
      ctx.fillStyle = "#d8a0a0";
      ctx.beginPath(); ctx.arc(10.6, -4.2, 0.9, 0, 7); ctx.fill();
      ctx.fillStyle = "rgba(250,248,244,0.9)";
      ctx.beginPath(); ctx.arc(-8.5, 1.5, 3.2, 0, 7); ctx.fill();
      return true;
    }
    case "kaban": {
      limb(ctx, -5, 6, -5 + walk * 2, 11.5, 2.8, "#3f3226");
      limb(ctx, 5, 6, 5 - walk * 2, 11.5, 2.8, "#3f3226");
      ell(ctx, 0, 0, 13.5, 9.5, "#5d4a3c");
      topLight(ctx, 0, 0, 13.5, 9.5);
      // щетина на загривке
      ctx.strokeStyle = "#2f251c"; ctx.lineWidth = 1.3;
      for (let i = 0; i < 6; i++) {
        const x = -6 + i * 2.6;
        ctx.beginPath(); ctx.moveTo(x, -8.4); ctx.lineTo(x + 0.6, -12.4); ctx.stroke();
      }
      ell(ctx, 10.5, -3, 6.6, 5.6, "#4c3c30");
      ctx.fillStyle = "#3a2e24";
      ctx.beginPath(); ctx.ellipse(15.6, -1.6, 2.4, 2, 0, 0, 7); ctx.fill();
      ctx.fillStyle = "#241c16";
      ctx.beginPath(); ctx.arc(15.2, -2.2, 0.6, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(16.4, -1.2, 0.6, 0, 7); ctx.fill();
      // клыки
      ctx.strokeStyle = "#ece2cc"; ctx.lineWidth = 1.8; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(14.4, 0.6); ctx.quadraticCurveTo(16.6, -1, 15.6, -3.6); ctx.stroke();
      eye(ctx, 11.8, -5.6, 1.1, "#c94f3a", true);
      return true;
    }

    // ================= НОЧНЫЕ ЧУДИЩА =================
    case "zombi": {
      const reach = c.state === "chase" ? 6 : 2;
      limb(ctx, -4, 7, -4 + walk * 2, 13, 2.8, "#4a5a42");
      limb(ctx, 4, 7, 4 - walk * 2, 13, 2.8, "#4a5a42");
      ell(ctx, 0, 0, 8.2, 10.4, "#56694c");
      // рваная одежда
      ctx.fillStyle = "rgba(60,52,44,0.72)";
      ctx.beginPath();
      ctx.moveTo(-7.6, -1); ctx.lineTo(7.6, -1); ctx.lineTo(6.4, 7); ctx.lineTo(3, 4.5);
      ctx.lineTo(0, 8); ctx.lineTo(-3.4, 4); ctx.lineTo(-6.6, 7.5);
      ctx.closePath(); ctx.fill();
      // рёбра наружу
      ctx.strokeStyle = "rgba(226,218,196,0.6)"; ctx.lineWidth = 1.1;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(-4, -4 + i * 2.4); ctx.quadraticCurveTo(-1, -3.2 + i * 2.4, 1.6, -4.4 + i * 2.4);
        ctx.stroke();
      }
      topLight(ctx, 0, 0, 8, 10);
      spots(ctx, 0, 0, 8, 10, "rgba(38,58,34,0.55)", 4, 0.6);
      limb(ctx, 6, -4, 8 + reach, -3 + Math.sin(t * 2) * 1.2, 2.8, "#6b8258");
      limb(ctx, -6, -4, 2 + reach, -1, 2.6, "#5e7550");
      ell(ctx, 0, -13, 6.4, 6, "#7a9464");
      ctx.fillStyle = "rgba(30,44,26,0.55)";
      ctx.beginPath(); ctx.ellipse(-2.4, -11.5, 2.2, 1.6, 0.4, 0, 7); ctx.fill();
      eye(ctx, 2.6, -14, 1.25, "#f2e86a");
      eye(ctx, -1.4, -14.2, 1.05, "#f2e86a");
      ctx.strokeStyle = "rgba(30,24,20,0.8)"; ctx.lineWidth = 1.1;
      ctx.beginPath(); ctx.moveTo(-2, -10.4); ctx.lineTo(3.4, -10.8); ctx.stroke();
      return true;
    }
    case "skelet": {
      // кости ног и рук
      limb(ctx, -3, 6, -3.6 + walk * 1.6, 12, 2.2, "#d8d0bc");
      limb(ctx, 3, 6, 3.6 - walk * 1.6, 12, 2.2, "#d8d0bc");
      // позвоночник и рёбра
      limb(ctx, 0, -8, 0, 6.5, 2.6, "#ddd6c4");
      ctx.strokeStyle = "#cfc6b0"; ctx.lineWidth = 2;
      for (let i = 0; i < 4; i++) {
        const y = -5 + i * 2.6;
        ctx.beginPath();
        ctx.moveTo(-5.6 + i * 0.3, y);
        ctx.quadraticCurveTo(0, y + 1.6, 5.6 - i * 0.3, y);
        ctx.stroke();
      }
      ctx.strokeStyle = "rgba(120,110,92,0.5)"; ctx.lineWidth = 0.7;
      for (let i = 0; i < 4; i++) {
        const y = -5 + i * 2.6;
        ctx.beginPath(); ctx.moveTo(-5, y + 0.8); ctx.quadraticCurveTo(0, y + 2.4, 5, y + 0.8); ctx.stroke();
      }
      // таз и ключицы
      ctx.fillStyle = "#d8d0bc";
      ctx.beginPath(); ctx.ellipse(0, 6.4, 4.4, 2.4, 0, 0, 7); ctx.fill();
      // череп
      ell(ctx, 0, -12.4, 5.6, 5.2, "#e6dfcc");
      ctx.fillStyle = "#1a1512";
      ctx.beginPath(); ctx.ellipse(2, -13, 1.5, 1.9, 0.1, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(-1.9, -13.1, 1.5, 1.9, -0.1, 0, 7); ctx.fill();
      ctx.fillStyle = "rgba(226,96,72,0.9)";
      ctx.beginPath(); ctx.arc(2, -12.8, 0.7, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(-1.9, -12.9, 0.7, 0, 7); ctx.fill();
      ctx.strokeStyle = "rgba(60,52,40,0.7)"; ctx.lineWidth = 0.9;
      ctx.beginPath(); ctx.moveTo(-2.6, -9.4); ctx.lineTo(2.6, -9.4); ctx.stroke();
      for (let i = 0; i < 4; i++) {
        ctx.beginPath(); ctx.moveTo(-2 + i * 1.3, -10.2); ctx.lineTo(-2 + i * 1.3, -8.8); ctx.stroke();
      }
      // ржавый лук
      ctx.strokeStyle = "#7a5636"; ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.arc(9, -1, 7.4, -1.25, 1.25); ctx.stroke();
      ctx.strokeStyle = "rgba(210,200,178,0.75)"; ctx.lineWidth = 0.8;
      ctx.beginPath(); ctx.moveTo(11.3, -8); ctx.lineTo(11.3, 6); ctx.stroke();
      return true;
    }
    case "pauk": {
      // ноги с суставами
      for (let side = -1; side <= 1; side += 2) {
        for (let i = 0; i < 4; i++) {
          const baseA = -0.55 + i * 0.36;
          const sw = Math.sin(c.breathe * 8 + i * 1.3) * 0.12;
          const kx = side * (9 + i * 1.2), ky = -3 + i * 2.2 + sw * 6;
          const fx = side * (15 + i * 0.8), fy = 4 + i * 2.4;
          ctx.strokeStyle = "#241f2c"; ctx.lineWidth = 2.2; ctx.lineCap = "round";
          ctx.beginPath(); ctx.moveTo(side * 3, -1); ctx.lineTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke();
          ctx.strokeStyle = "#3d3448"; ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.moveTo(side * 3, -1); ctx.lineTo(kx, ky); ctx.stroke();
          void baseA;
        }
      }
      ell(ctx, -3, 0, 8.6, 7, "#463d50");
      // волоски
      ctx.strokeStyle = "rgba(20,16,26,0.85)"; ctx.lineWidth = 0.8;
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(-3 + Math.cos(a) * 7.4, Math.sin(a) * 6);
        ctx.lineTo(-3 + Math.cos(a) * 10, Math.sin(a) * 8.4);
        ctx.stroke();
      }
      ctx.fillStyle = "rgba(190,160,220,0.35)";
      ctx.beginPath(); ctx.ellipse(-4.5, -2.5, 3.4, 2.4, -0.4, 0, 7); ctx.fill();
      ell(ctx, 6.4, -2, 4.8, 4, "#514659");
      // 6 глаз
      for (let i = 0; i < 3; i++) eye(ctx, 7 + i * 1.1, -4.4 + i * 0.5, 0.85, "#e0483c", i === 0);
      for (let i = 0; i < 3; i++) eye(ctx, 6.4 + i * 1.1, -1.6 + i * 0.4, 0.65, "#c0362c", false);
      // жвала
      ctx.strokeStyle = "#1f1a26"; ctx.lineWidth = 1.4;
      ctx.beginPath(); ctx.moveTo(10, 0.6); ctx.lineTo(12.4, 2.4); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(9.4, 1.6); ctx.lineTo(11.6, 3.6); ctx.stroke();
      return true;
    }
    case "kriper": {
      const boom = c.state === "boom";
      const flash = boom && Math.sin(t * 30) > 0;
      const base = flash ? "#f2ede2" : "#6a8a4a";
      for (const dx of [-5.5, 5.5]) {
        for (const dz of [-1, 1]) {
          ctx.fillStyle = shade(base, -0.45);
          ctx.beginPath();
          ctx.roundRect(dx - 2.2 + dz * 1.2, 5.5, 4.4, 5.5, 1.4);
          ctx.fill();
          ctx.strokeStyle = INK; ctx.lineWidth = 1; ctx.stroke();
        }
      }
      ctx.beginPath();
      ctx.roundRect(-8, -14, 16, 21, 4.5);
      ctx.fillStyle = vol(ctx, 0, -4, 14, base);
      ctx.fill();
      ctx.strokeStyle = INK; ctx.lineWidth = 1.6; ctx.stroke();
      ctx.save();
      ctx.beginPath(); ctx.roundRect(-8, -14, 16, 21, 4.5); ctx.clip();
      // мшистые пятна
      ctx.fillStyle = flash ? "rgba(200,80,70,0.55)" : "rgba(38,56,28,0.6)";
      for (let i = 0; i < 7; i++) {
        const px = -6 + ((i * 37) % 12);
        const py = -12 + ((i * 53) % 18);
        ctx.beginPath(); ctx.ellipse(px, py, 2.4, 1.8, i, 0, 7); ctx.fill();
      }
      topLight(ctx, 0, -6, 8, 10);
      ctx.fillStyle = "rgba(10,16,8,0.3)";
      ctx.fillRect(-8, 1, 16, 6);
      ctx.restore();
      // злое лицо
      ctx.fillStyle = "#1a2414";
      ctx.beginPath(); ctx.roundRect(1.2, -9.6, 3.4, 3, 0.6); ctx.fill();
      ctx.beginPath(); ctx.roundRect(-4.6, -9.6, 3.4, 3, 0.6); ctx.fill();
      ctx.beginPath();
      ctx.moveTo(-3, -5.2); ctx.lineTo(3, -5.2); ctx.lineTo(2, -0.6); ctx.lineTo(0.8, -3);
      ctx.lineTo(-0.8, -0.6); ctx.lineTo(-2, -3); ctx.closePath();
      ctx.fill();
      if (boom) {
        const gl = ctx.createRadialGradient(0, -4, 1, 0, -4, 22);
        gl.addColorStop(0, `rgba(255,${flash ? 200 : 120},60,0.5)`);
        gl.addColorStop(1, "rgba(255,120,60,0)");
        ctx.fillStyle = gl;
        ctx.fillRect(-24, -28, 48, 48);
      }
      return true;
    }
    case "prizrak": case "lunnyi_prizrak": {
      const moon = id === "lunnyi_prizrak";
      const col = moon ? "#dfe6f2" : "#dfe8f2";
      const eyeCol = moon ? "#a8c8ff" : "#6fb8d9";
      const wob = Math.sin(t * 2.2) * 1.4;
      const gl = ctx.createRadialGradient(0, -4, 1, 0, -4, 20);
      gl.addColorStop(0, rgba(eyeCol, 0.28));
      gl.addColorStop(1, rgba(eyeCol, 0));
      ctx.fillStyle = gl;
      ctx.fillRect(-22, -24, 44, 44);
      ctx.globalAlpha = 0.72;
      ctx.beginPath();
      ctx.moveTo(-8.4, 8);
      ctx.quadraticCurveTo(-9.6, -10, 0, -14.6);
      ctx.quadraticCurveTo(9.6, -10, 8.4, 8);
      ctx.quadraticCurveTo(5.6, 4 + wob, 3.2, 9);
      ctx.quadraticCurveTo(0.4, 3.4 - wob, -2.4, 8.6);
      ctx.quadraticCurveTo(-5.2, 3.6 + wob, -8.4, 8);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, -14, 0, 9);
      g.addColorStop(0, shade(col, 0.2));
      g.addColorStop(0.55, col);
      g.addColorStop(1, rgba(col, 0.25));
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = rgba(eyeCol, 0.45); ctx.lineWidth = 1.1; ctx.stroke();
      ctx.globalAlpha = 1;
      eye(ctx, -2.6, -7, 1.5, eyeCol);
      eye(ctx, 2.6, -7, 1.5, eyeCol);
      ctx.fillStyle = rgba(eyeCol, 0.4);
      ctx.beginPath(); ctx.ellipse(0, -2.6, 1.8, 2.6, 0, 0, 7); ctx.fill();
      return true;
    }
    case "mysh": {
      const flap = Math.sin(t * 16) * 6;
      for (const side of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(side * 2, -2);
        ctx.quadraticCurveTo(side * 12, -8 - flap, side * 15, 0 - flap);
        ctx.quadraticCurveTo(side * 11, 1, side * 8, 2.4);
        ctx.quadraticCurveTo(side * 6, 0, side * 2, 1);
        ctx.closePath();
        const g = ctx.createLinearGradient(0, -6, side * 15, 2);
        g.addColorStop(0, "#5d5260");
        g.addColorStop(1, "#332c38");
        ctx.fillStyle = g;
        ctx.fill();
        ctx.strokeStyle = INK; ctx.lineWidth = 1; ctx.stroke();
        // косточки крыла
        ctx.strokeStyle = "rgba(120,106,130,0.7)"; ctx.lineWidth = 0.8;
        for (let i = 1; i <= 2; i++) {
          ctx.beginPath();
          ctx.moveTo(side * 2, -1);
          ctx.lineTo(side * (5 + i * 4), -3 - flap * (i / 2) + i * 2);
          ctx.stroke();
        }
      }
      ell(ctx, 0, 0, 4.6, 5, "#5d5260");
      ctx.fillStyle = "#4a4048";
      for (const dx of [-2.2, 2.2]) {
        ctx.beginPath();
        ctx.ellipse(dx, -5.4, 1.7, 2.6, dx * 0.12, 0, 7);
        ctx.fill();
      }
      eye(ctx, -1.4, -1.4, 0.9, "#e0483c", true);
      eye(ctx, 1.4, -1.4, 0.9, "#e0483c", true);
      ctx.fillStyle = "#e8e2d2";
      ctx.beginPath(); ctx.moveTo(-0.9, 1.6); ctx.lineTo(-0.2, 3.2); ctx.lineTo(0.5, 1.6); ctx.closePath(); ctx.fill();
      return true;
    }
    case "sliz": {
      const wob = Math.sin(c.breathe * 4) * 1.8;
      const gl = ctx.createRadialGradient(0, -2, 1, 0, -2, 16);
      gl.addColorStop(0, "rgba(120,220,180,0.2)");
      gl.addColorStop(1, "rgba(120,220,180,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(-18, -18, 36, 32);
      ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.moveTo(-11 - wob, 7);
      ctx.quadraticCurveTo(-12 - wob, -8 + wob, 0, -9 - wob);
      ctx.quadraticCurveTo(12 + wob, -8 + wob, 11 + wob, 7);
      ctx.quadraticCurveTo(0, 10.5, -11 - wob, 7);
      ctx.closePath();
      const g = ctx.createRadialGradient(-4, -5, 1, 0, 0, 14);
      g.addColorStop(0, "#9fe0c8");
      g.addColorStop(0.45, "#5f8a7d");
      g.addColorStop(1, "#2f4f46");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "rgba(20,44,38,0.6)"; ctx.lineWidth = 1.3; ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = "rgba(255,255,255,0.45)";
      ctx.beginPath(); ctx.ellipse(-4.5, -4.5, 3.2, 2, -0.5, 0, 7); ctx.fill();
      // пузырьки внутри
      ctx.fillStyle = "rgba(180,240,215,0.5)";
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.arc(-5 + i * 3.4, 1 + Math.sin(t * 1.6 + i) * 1.4, 1.1 + (i % 2) * 0.5, 0, 7);
        ctx.fill();
      }
      eye(ctx, 3, -4, 1.7, "#1f3b34", false);
      eye(ctx, -2.4, -4.6, 1.3, "#1f3b34", false);
      return true;
    }

    // ================= ТВАРИ СЛОЁВ =================
    case "lavoviy": {
      const gl = ctx.createRadialGradient(0, -2, 1, 0, -2, 20);
      gl.addColorStop(0, "rgba(255,130,50,0.36)");
      gl.addColorStop(1, "rgba(255,130,50,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(-22, -22, 44, 38);
      // сегменты тела
      for (let i = 0; i < 4; i++) {
        const sx = -8 + i * 5.4;
        const sy = Math.sin(t * 3 + i * 0.9) * 1.6;
        ell(ctx, sx, sy, 5.4 - i * 0.5, 4.6 - i * 0.3, "#3a1a10", 0, "rgba(10,4,2,0.8)", 1.3);
        ctx.fillStyle = `rgba(255,${140 + i * 14},60,${0.55 + Math.sin(t * 4 + i) * 0.16})`;
        ctx.beginPath();
        ctx.ellipse(sx, sy + 0.6, 3 - i * 0.3, 1.5, 0, 0, 7);
        ctx.fill();
      }
      ell(ctx, 10, -1, 5.6, 4.8, "#4a2214");
      ctx.fillStyle = "#ffb04a";
      ctx.beginPath(); ctx.moveTo(13, 1); ctx.lineTo(15.6, 3); ctx.lineTo(12.6, 3.4); ctx.closePath(); ctx.fill();
      eye(ctx, 11.6, -2.6, 1.3, "#ffd76a");
      return true;
    }
    case "magmit": {
      const gl = ctx.createRadialGradient(0, -3, 1, 0, -3, 26);
      gl.addColorStop(0, "rgba(255,110,40,0.42)");
      gl.addColorStop(1, "rgba(255,110,40,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(-28, -28, 56, 46);
      ell(ctx, 0, -1, 12, 10.5, "#3d1c12");
      ctx.save();
      ctx.beginPath(); ctx.ellipse(0, -1, 12, 10.5, 0, 0, 7); ctx.clip();
      // трещины с лавой
      ctx.strokeStyle = `rgba(255,${150 + Math.sin(t * 5) * 40},50,0.9)`;
      ctx.lineWidth = 1.8;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo(-11 + i * 2, -10);
        ctx.quadraticCurveTo(-4 + i * 3, 0, -9 + i * 5, 10);
        ctx.stroke();
      }
      ctx.strokeStyle = "rgba(255,220,140,0.55)"; ctx.lineWidth = 0.7;
      ctx.beginPath(); ctx.moveTo(-8, -2); ctx.lineTo(9, 1); ctx.stroke();
      ctx.restore();
      ctx.strokeStyle = "rgba(14,6,2,0.85)"; ctx.lineWidth = 1.7;
      ctx.beginPath(); ctx.ellipse(0, -1, 12, 10.5, 0, 0, 7); ctx.stroke();
      // «плечи»-глыбы
      ell(ctx, -9, -8, 4.4, 3.6, "#4e2618", -0.4);
      ell(ctx, 9, -8, 4.4, 3.6, "#4e2618", 0.4);
      eye(ctx, 3.4, -4, 1.7, "#ffdc7a");
      eye(ctx, -3.4, -4.4, 1.5, "#ffdc7a");
      return true;
    }
    case "vihrevik": {
      const spin = t * 3;
      ctx.globalAlpha = 0.82;
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = `rgba(190,225,245,${0.5 - i * 0.12})`;
        ctx.lineWidth = 2.6 - i * 0.6;
        ctx.beginPath();
        for (let k = 0; k <= 22; k++) {
          const a = spin + i * 2 + (k / 22) * Math.PI * 2.4;
          const r = 3 + k * 0.42;
          const x = Math.cos(a) * r, y = Math.sin(a) * r * 0.55 - k * 0.24;
          k ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
        }
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
      ell(ctx, 0, -2, 5, 5.4, "#cfe6f4");
      eye(ctx, -1.8, -3, 1.1, "#4aa8d8");
      eye(ctx, 1.8, -3, 1.1, "#4aa8d8");
      return true;
    }
    case "grifon": {
      const flap = Math.sin(t * 4) * 0.4;
      for (const side of [-1, 1]) {
        ctx.save();
        ctx.rotate(side * (0.3 + flap) * 0.4);
        ctx.beginPath();
        ctx.moveTo(side * 3, -6);
        ctx.quadraticCurveTo(side * 20, -20, side * 26, -4);
        ctx.quadraticCurveTo(side * 16, -7, side * 6, 0);
        ctx.closePath();
        const g = ctx.createLinearGradient(0, -14, side * 24, 0);
        g.addColorStop(0, "#d8c9a4");
        g.addColorStop(1, "#8a7550");
        ctx.fillStyle = g;
        ctx.fill();
        ctx.strokeStyle = INK; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.strokeStyle = "rgba(90,74,48,0.6)"; ctx.lineWidth = 0.8;
        for (let i = 1; i <= 3; i++) {
          ctx.beginPath();
          ctx.moveTo(side * 4, -5);
          ctx.lineTo(side * (8 + i * 5), -12 + i * 3);
          ctx.stroke();
        }
        ctx.restore();
      }
      limb(ctx, -5, 6, -6, 12, 2.6, "#9a7c4e");
      limb(ctx, 5, 6, 6, 12, 2.6, "#9a7c4e");
      ell(ctx, 0, 0, 11, 8.6, "#b2924f");
      topLight(ctx, 0, 0, 11, 8.6);
      ell(ctx, 9.5, -7, 5.4, 4.8, "#e6dccc", 0.15);
      ctx.fillStyle = "#e8b64f";
      ctx.beginPath(); ctx.moveTo(13.6, -6.4); ctx.lineTo(17.4, -5); ctx.lineTo(13.4, -3.2); ctx.closePath(); ctx.fill();
      eye(ctx, 11.4, -8.4, 1.2, "#f2c14e");
      ctx.strokeStyle = "#8a7550"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-10, 2); ctx.quadraticCurveTo(-16, 4, -15, 9); ctx.stroke();
      return true;
    }
    case "murena": {
      const wob = Math.sin(t * 5) * 2.4;
      ctx.beginPath();
      ctx.moveTo(-14, wob);
      ctx.quadraticCurveTo(-4, -6 - wob, 6, -2);
      ctx.quadraticCurveTo(12, 0, 14, 1);
      ctx.quadraticCurveTo(10, 5, 4, 4);
      ctx.quadraticCurveTo(-4, 4 - wob, -14, wob + 4);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, -6, 0, 6);
      g.addColorStop(0, "#6f9a72");
      g.addColorStop(0.5, "#436b4e");
      g.addColorStop(1, "#24402f");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = INK; ctx.lineWidth = 1.3; ctx.stroke();
      ctx.fillStyle = "rgba(200,230,200,0.35)";
      for (let i = 0; i < 5; i++) {
        ctx.beginPath(); ctx.ellipse(-10 + i * 5, -1 + Math.sin(i) * 1.5, 1.6, 1, 0, 0, 7); ctx.fill();
      }
      ctx.fillStyle = "#e8e2d2";
      ctx.beginPath(); ctx.moveTo(9, 0.4); ctx.lineTo(13.6, 1.4); ctx.lineTo(9, 3); ctx.closePath(); ctx.fill();
      eye(ctx, 8.6, -1.8, 1.1, "#f2e86a", false);
      return true;
    }
    case "rusalka": {
      const wob = Math.sin(t * 2.4) * 2;
      ctx.beginPath();
      ctx.moveTo(-1, 2);
      ctx.quadraticCurveTo(-6, 8 + wob, -3, 13);
      ctx.quadraticCurveTo(0, 10, 3, 13 - wob);
      ctx.quadraticCurveTo(6, 8, 2, 2);
      ctx.closePath();
      const tg = ctx.createLinearGradient(0, 2, 0, 13);
      tg.addColorStop(0, "#4aa8a0");
      tg.addColorStop(1, "#1f5f66");
      ctx.fillStyle = tg;
      ctx.fill();
      ctx.strokeStyle = INK; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = "rgba(160,240,230,0.35)";
      for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(-1 + (i % 2) * 2.4, 4 + i * 2, 1.1, 0, 7); ctx.fill(); }
      ell(ctx, 0, -4, 5, 6.4, "#e8c9a8");
      ell(ctx, 0, -12, 4.4, 4.2, "#f0d4b4");
      // волосы
      ctx.fillStyle = "#3f7a5c";
      ctx.beginPath();
      ctx.moveTo(-4.6, -13.6);
      ctx.quadraticCurveTo(-8, -6, -5 + wob * 0.4, 1);
      ctx.quadraticCurveTo(-2.4, -6, -1, -14);
      ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.arc(0, -14.4, 4.6, Math.PI, Math.PI * 2); ctx.fill();
      eye(ctx, 1.6, -12.4, 1, "#2aa8c4", false);
      eye(ctx, -1.6, -12.4, 1, "#2aa8c4", false);
      return true;
    }
    case "marsianin": {
      limb(ctx, -4, 7, -5, 13, 3, "#6e4030");
      limb(ctx, 4, 7, 5, 13, 3, "#6e4030");
      ell(ctx, 0, -1, 9, 10, "#8a4a32");
      ctx.save();
      ctx.beginPath(); ctx.ellipse(0, -1, 9, 10, 0, 0, 7); ctx.clip();
      ctx.strokeStyle = "rgba(255,180,120,0.35)"; ctx.lineWidth = 1;
      for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(-9, -8 + i * 5); ctx.lineTo(9, -6 + i * 5); ctx.stroke(); }
      topLight(ctx, 0, -1, 9, 10);
      ctx.restore();
      // наплечники
      ell(ctx, -8, -7, 4, 3.2, "#a25a3a", -0.3);
      ell(ctx, 8, -7, 4, 3.2, "#a25a3a", 0.3);
      ell(ctx, 0, -13, 5.6, 5, "#9c5438");
      // визор
      ctx.fillStyle = "rgba(20,30,40,0.85)";
      ctx.beginPath(); ctx.roundRect(-4, -14.6, 8, 3.4, 1.4); ctx.fill();
      ctx.fillStyle = "#5fe8c0";
      ctx.beginPath(); ctx.arc(1.4, -12.9, 1, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(-1.8, -12.9, 1, 0, 7); ctx.fill();
      // излучатель
      limb(ctx, 7, -3, 14, -5, 2.4, "#6e6a62");
      ctx.fillStyle = "#5fe8c0";
      ctx.beginPath(); ctx.arc(15, -5.2, 1.6, 0, 7); ctx.fill();
      return true;
    }
    case "ten_ohotnik": {
      const gl = ctx.createRadialGradient(0, -4, 1, 0, -4, 22);
      gl.addColorStop(0, "rgba(140,100,220,0.3)");
      gl.addColorStop(1, "rgba(140,100,220,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(-24, -26, 48, 44);
      // дымный плащ
      ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.moveTo(-8, 9);
      ctx.quadraticCurveTo(-11, -6, 0, -14);
      ctx.quadraticCurveTo(11, -6, 8, 9);
      ctx.quadraticCurveTo(4, 6 + Math.sin(t * 3) * 1.6, 0, 10);
      ctx.quadraticCurveTo(-4, 6 - Math.sin(t * 3) * 1.6, -8, 9);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, -14, 0, 10);
      g.addColorStop(0, "#463a60");
      g.addColorStop(0.6, "#241c34");
      g.addColorStop(1, "#120d1c");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "rgba(150,110,220,0.4)"; ctx.lineWidth = 1.1; ctx.stroke();
      ctx.globalAlpha = 1;
      // капюшон
      ctx.fillStyle = "#1a1428";
      ctx.beginPath(); ctx.arc(0, -12, 5.6, Math.PI * 0.9, Math.PI * 2.1); ctx.fill();
      eye(ctx, -2.2, -11.4, 1.2, "#c07af2");
      eye(ctx, 2.2, -11.4, 1.2, "#c07af2");
      // когти
      ctx.strokeStyle = "#8f78c0"; ctx.lineWidth = 1.2; ctx.lineCap = "round";
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(7, -2 + i * 1.6);
        ctx.lineTo(12.4 + i * 0.6, 1 + i * 1.8);
        ctx.stroke();
      }
      return true;
    }
    case "koshmar": {
      const pulse = 1 + Math.sin(t * 2.6) * 0.08;
      const gl = ctx.createRadialGradient(0, -4, 1, 0, -4, 22 * pulse);
      gl.addColorStop(0, "rgba(224,138,201,0.3)");
      gl.addColorStop(1, "rgba(224,138,201,0)");
      ctx.fillStyle = gl;
      ctx.fillRect(-24, -26, 48, 44);
      ctx.globalAlpha = 0.78;
      ctx.beginPath();
      for (let i = 0; i <= 14; i++) {
        const a = (i / 14) * Math.PI * 2;
        const r = 9 + Math.sin(a * 3 + t * 2) * 2.4;
        const x = Math.cos(a) * r, y = Math.sin(a) * r * 0.9 - 3;
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.closePath();
      const g = ctx.createRadialGradient(-3, -6, 1, 0, -3, 12);
      g.addColorStop(0, "#f0b8e4");
      g.addColorStop(0.5, "#a05ec0");
      g.addColorStop(1, "#3c1f4e");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.globalAlpha = 1;
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2 + t * 0.6;
        eye(ctx, Math.cos(a) * 4.4, -3 + Math.sin(a) * 3.4, 1.15, "#fff0a8", i === 0);
      }
      return true;
    }
    case "haoszver": {
      const hue = Math.floor((t * 60) % 360);
      const gl = ctx.createRadialGradient(0, -4, 1, 0, -4, 26);
      gl.addColorStop(0, `hsla(${hue},80%,60%,0.35)`);
      gl.addColorStop(1, `hsla(${hue},80%,60%,0)`);
      ctx.fillStyle = gl;
      ctx.fillRect(-28, -30, 56, 50);
      // рваное тело
      ctx.beginPath();
      for (let i = 0; i <= 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        const r = 11 + Math.sin(a * 4 + t * 5) * 3.4;
        const x = Math.cos(a) * r, y = Math.sin(a) * r * 0.86 - 2;
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.closePath();
      const g = ctx.createLinearGradient(-12, -12, 12, 10);
      g.addColorStop(0, `hsl(${hue},70%,62%)`);
      g.addColorStop(0.5, `hsl(${(hue + 60) % 360},60%,38%)`);
      g.addColorStop(1, `hsl(${(hue + 140) % 360},60%,22%)`);
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "rgba(20,8,20,0.8)"; ctx.lineWidth = 1.5; ctx.stroke();
      // шипы
      ctx.fillStyle = `hsl(${(hue + 180) % 360},80%,70%)`;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2 + t;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * 9, Math.sin(a) * 8 - 2);
        ctx.lineTo(Math.cos(a + 0.2) * 15, Math.sin(a + 0.2) * 13 - 2);
        ctx.lineTo(Math.cos(a - 0.2) * 9.5, Math.sin(a - 0.2) * 8.5 - 2);
        ctx.closePath(); ctx.fill();
      }
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2 + t * 1.4;
        eye(ctx, Math.cos(a) * 4, -2 + Math.sin(a) * 3.4, 1.3, "#fff0a8", false);
      }
      return true;
    }
    default:
      return false;
  }
}

// ================= БОССЫ =================
/** Аура под боссом (рисуется до тела, в мировых координатах) */
export function bossAura(ctx: CanvasRenderingContext2D, id: string, x: number, y: number, t: number, scale: number): boolean {
  const AURA: Record<string, [string, string]> = {
    drakon: ["rgba(242,120,46,", "rgba(242,120,46,0)"],
    korol_nezhiti: ["rgba(120,220,170,", "rgba(120,220,170,0)"],
    vladyka_lavy: ["rgba(255,110,40,", "rgba(255,110,40,0)"],
    ledyanaya_koroleva: ["rgba(150,220,255,", "rgba(150,220,255,0)"],
    kraken: ["rgba(60,170,200,", "rgba(60,170,200,0)"],
    lunnyi_bog: ["rgba(210,225,255,", "rgba(210,225,255,0)"],
    kosmouzhas: ["rgba(180,90,230,", "rgba(180,90,230,0)"],
    vladyka_bezdny: ["rgba(130,80,200,", "rgba(130,80,200,0)"],
    haos_avatar: ["", ""],
  };
  const a = AURA[id];
  if (!a) return false;
  const pulse = 1 + Math.sin(t * 1.8) * 0.12;
  const r = 52 * scale * pulse;
  const g = ctx.createRadialGradient(x, y - 14 * scale, 4, x, y - 14 * scale, r);
  if (id === "haos_avatar") {
    const hue = Math.floor((t * 70) % 360);
    g.addColorStop(0, `hsla(${hue},85%,62%,0.34)`);
    g.addColorStop(0.55, `hsla(${(hue + 120) % 360},80%,55%,0.16)`);
    g.addColorStop(1, "rgba(0,0,0,0)");
  } else {
    g.addColorStop(0, `${a[0]}0.3)`);
    g.addColorStop(0.55, `${a[0]}0.12)`);
    g.addColorStop(1, a[1]);
  }
  ctx.fillStyle = g;
  ctx.fillRect(x - r, y - 14 * scale - r, r * 2, r * 2);
  // вращающееся кольцо силы
  ctx.save();
  ctx.translate(x, y + 2);
  ctx.scale(1, 0.34);
  ctx.rotate(t * 0.6);
  ctx.strokeStyle = id === "haos_avatar" ? `hsla(${Math.floor((t * 70) % 360)},85%,70%,0.4)` : `${a[0]}0.35)`;
  ctx.lineWidth = 2.4;
  ctx.setLineDash([10, 8]);
  ctx.beginPath();
  ctx.arc(0, 0, 30 * scale, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();
  return true;
}

/** Тела боссов (в локальных координатах, уже отмасштабированных) */
export function drawBossBody(ctx: CanvasRenderingContext2D, id: string, c: MobDrawCtx): boolean {
  const t = c.now;
  switch (id) {
    case "drakon": {
      const wing = Math.sin(c.breathe * 3.2) * 0.35;
      for (const side of [1, -1]) {
        ctx.save();
        ctx.scale(side, 1);
        ctx.rotate(-0.3 + wing * 0.4);
        ctx.beginPath();
        ctx.moveTo(-6, -6);
        ctx.quadraticCurveTo(-30, -28, -38, -4);
        ctx.quadraticCurveTo(-26, -9, -20, 0);
        ctx.quadraticCurveTo(-14, -6, -6, 2);
        ctx.closePath();
        const wg = ctx.createLinearGradient(-6, -20, -36, 2);
        wg.addColorStop(0, "#8a4030");
        wg.addColorStop(0.6, "#5d2a22");
        wg.addColorStop(1, "#361612");
        ctx.fillStyle = wg;
        ctx.fill();
        ctx.strokeStyle = "rgba(18,8,6,0.85)"; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.strokeStyle = "rgba(200,120,80,0.4)"; ctx.lineWidth = 1;
        for (let i = 1; i <= 3; i++) {
          ctx.beginPath(); ctx.moveTo(-7, -5); ctx.lineTo(-12 - i * 8, -18 + i * 6); ctx.stroke();
        }
        ctx.restore();
      }
      // хвост
      ctx.strokeStyle = "#5d2a22"; ctx.lineWidth = 7; ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(-12, 2);
      ctx.quadraticCurveTo(-26, 8 + Math.sin(t * 1.8) * 4, -34, 0 + Math.sin(t * 1.8) * 5);
      ctx.stroke();
      ctx.fillStyle = "#8a4030";
      ctx.beginPath();
      ctx.moveTo(-32, 2 + Math.sin(t * 1.8) * 5); ctx.lineTo(-40, -3 + Math.sin(t * 1.8) * 6); ctx.lineTo(-33, -4 + Math.sin(t * 1.8) * 5);
      ctx.closePath(); ctx.fill();
      // тело
      ell(ctx, 0, 0, 16, 12, "#7a3a2e", 0, "rgba(16,6,4,0.85)", 1.8);
      // брюшные щитки
      ctx.fillStyle = "#d8892e";
      ctx.beginPath(); ctx.ellipse(2, 4, 10, 6.4, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = "rgba(120,70,20,0.5)"; ctx.lineWidth = 0.9;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath(); ctx.moveTo(-6 + i * 4, -0.6); ctx.lineTo(-6 + i * 4, 9); ctx.stroke();
      }
      // чешуя
      ctx.strokeStyle = "rgba(40,16,10,0.45)"; ctx.lineWidth = 0.9;
      for (let r = 0; r < 3; r++) {
        for (let i = 0; i < 5; i++) {
          ctx.beginPath();
          ctx.arc(-10 + i * 5 + (r % 2) * 2.4, -8 + r * 4, 2.6, Math.PI * 0.15, Math.PI * 0.85);
          ctx.stroke();
        }
      }
      // гребень
      ctx.fillStyle = "#3f1a14";
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(-10 + i * 5, -11);
        ctx.lineTo(-8 + i * 5, -17 - (i === 2 ? 3 : 0));
        ctx.lineTo(-6 + i * 5, -11);
        ctx.closePath(); ctx.fill();
      }
      // шея и голова
      ell(ctx, 14, -11, 8, 5.6, "#7a3a2e", -0.45);
      ell(ctx, 21, -16, 7, 5.2, "#8a4234", -0.2);
      ctx.strokeStyle = "#e8dcc2"; ctx.lineWidth = 2.2; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(19, -20); ctx.lineTo(16, -27); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(23, -20); ctx.lineTo(26, -27); ctx.stroke();
      // пасть с жаром
      ctx.fillStyle = "rgba(255,160,60,0.9)";
      ctx.beginPath(); ctx.moveTo(26, -15); ctx.lineTo(30, -13.4); ctx.lineTo(26, -12); ctx.closePath(); ctx.fill();
      eye(ctx, 23.4, -17.4, 1.7, "#ffd34d");
      // жар в груди
      const glow = 0.45 + Math.sin(t * 5) * 0.2;
      const cg = ctx.createRadialGradient(8, -2, 0.5, 8, -2, 7);
      cg.addColorStop(0, `rgba(255,220,120,${glow})`);
      cg.addColorStop(1, "rgba(255,140,50,0)");
      ctx.fillStyle = cg;
      ctx.beginPath(); ctx.arc(8, -2, 7, 0, 7); ctx.fill();
      return true;
    }
    case "korol_nezhiti": {
      // плащ
      ctx.beginPath();
      ctx.moveTo(-13, 14);
      ctx.quadraticCurveTo(-17, -6, -4, -14);
      ctx.lineTo(4, -14);
      ctx.quadraticCurveTo(17, -6, 13, 14);
      ctx.quadraticCurveTo(6, 10 + Math.sin(t * 2) * 2, 0, 15);
      ctx.quadraticCurveTo(-6, 10 - Math.sin(t * 2) * 2, -13, 14);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, -14, 0, 15);
      g.addColorStop(0, "#2e3f4a");
      g.addColorStop(0.5, "#1b2630");
      g.addColorStop(1, "#0d1318");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "rgba(120,220,170,0.35)"; ctx.lineWidth = 1.3; ctx.stroke();
      // рёбра-грудь
      ctx.strokeStyle = "rgba(216,208,188,0.75)"; ctx.lineWidth = 1.5;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath(); ctx.moveTo(-5, -6 + i * 3); ctx.quadraticCurveTo(0, -4 + i * 3, 5, -6 + i * 3); ctx.stroke();
      }
      // череп
      ell(ctx, 0, -17, 7, 6.4, "#e6dfcc", 0, "rgba(40,34,28,0.7)", 1.4);
      ctx.fillStyle = "#0e1a16";
      ctx.beginPath(); ctx.ellipse(2.6, -18, 2, 2.4, 0.1, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(-2.6, -18, 2, 2.4, -0.1, 0, 7); ctx.fill();
      eye(ctx, 2.6, -17.8, 1.15, "#7ef2c0");
      eye(ctx, -2.6, -17.8, 1.15, "#7ef2c0");
      ctx.strokeStyle = "rgba(60,52,40,0.8)"; ctx.lineWidth = 0.9;
      for (let i = 0; i < 5; i++) { ctx.beginPath(); ctx.moveTo(-3 + i * 1.5, -13.6); ctx.lineTo(-3 + i * 1.5, -11.6); ctx.stroke(); }
      // корона
      ctx.fillStyle = "#d9b45c";
      ctx.beginPath();
      ctx.moveTo(-7.4, -22);
      for (let i = 0; i < 5; i++) {
        ctx.lineTo(-7.4 + i * 3.7 + 1.85, -28 - (i % 2 ? 0 : 2.5));
        ctx.lineTo(-7.4 + (i + 1) * 3.7, -22);
      }
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "rgba(90,66,20,0.8)"; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = "#7ef2c0";
      ctx.beginPath(); ctx.arc(0, -24.5, 1.4, 0, 7); ctx.fill();
      // посох
      limb(ctx, 12, -8, 15, 16, 2.4, "#4a3a2e");
      ctx.fillStyle = "#7ef2c0";
      const pg = ctx.createRadialGradient(11.4, -12, 0.5, 11.4, -12, 7);
      pg.addColorStop(0, "rgba(126,242,192,0.9)");
      pg.addColorStop(1, "rgba(126,242,192,0)");
      ctx.fillStyle = pg;
      ctx.beginPath(); ctx.arc(11.4, -12, 7, 0, 7); ctx.fill();
      ctx.fillStyle = "#c8ffe8";
      ctx.beginPath(); ctx.arc(11.4, -12, 2.4, 0, 7); ctx.fill();
      return true;
    }
    case "vladyka_lavy": {
      // раскалённое тело
      ell(ctx, 0, 0, 17, 15, "#3d1c12", 0, "rgba(12,4,2,0.9)", 2);
      ctx.save();
      ctx.beginPath(); ctx.ellipse(0, 0, 17, 15, 0, 0, 7); ctx.clip();
      const pulse = 150 + Math.sin(t * 4) * 50;
      ctx.strokeStyle = `rgba(255,${pulse},40,0.95)`;
      ctx.lineWidth = 2.4;
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(-16 + i * 3, -15);
        ctx.quadraticCurveTo(-6 + i * 4, 0, -14 + i * 7, 15);
        ctx.stroke();
      }
      ctx.strokeStyle = `rgba(255,220,140,0.8)`; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-14, -4); ctx.lineTo(14, 2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-12, 6); ctx.lineTo(13, -6); ctx.stroke();
      ctx.restore();
      // плечи-глыбы
      ell(ctx, -13, -11, 6, 5, "#4e2618", -0.4);
      ell(ctx, 13, -11, 6, 5, "#4e2618", 0.4);
      // голова в короне пламени
      ell(ctx, 0, -18, 7.4, 6.6, "#4a2214");
      eye(ctx, 3, -19, 1.9, "#ffe08a");
      eye(ctx, -3, -19, 1.9, "#ffe08a");
      ctx.fillStyle = "#1a0a06";
      ctx.beginPath(); ctx.roundRect(-3.6, -15.4, 7.2, 2.2, 1); ctx.fill();
      for (let i = 0; i < 5; i++) {
        const fh = 5 + Math.sin(t * 7 + i) * 2.6;
        ctx.fillStyle = i % 2 ? "#ff9a3c" : "#ffd76a";
        ctx.beginPath();
        ctx.moveTo(-6 + i * 3, -23);
        ctx.quadraticCurveTo(-5 + i * 3, -23 - fh, -4 + i * 3, -23);
        ctx.closePath(); ctx.fill();
      }
      return true;
    }
    case "ledyanaya_koroleva": {
      // платье
      ctx.beginPath();
      ctx.moveTo(-4, -8);
      ctx.quadraticCurveTo(-16, 6, -13, 16);
      ctx.quadraticCurveTo(0, 19, 13, 16);
      ctx.quadraticCurveTo(16, 6, 4, -8);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, -8, 0, 16);
      g.addColorStop(0, "#f2fbff");
      g.addColorStop(0.5, "#c3e2f4");
      g.addColorStop(1, "#7fb2d4");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "rgba(90,150,190,0.7)"; ctx.lineWidth = 1.3; ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255,0.65)"; ctx.lineWidth = 0.9;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath(); ctx.moveTo(-8 + i * 5, -4); ctx.quadraticCurveTo(-9 + i * 6, 6, -11 + i * 7.4, 16); ctx.stroke();
      }
      ell(ctx, 0, -12, 5, 5.4, "#eef8ff");
      ell(ctx, 0, -19, 4.6, 4.4, "#f6fbff");
      // волосы-льдинки
      ctx.fillStyle = "#bfe4f8";
      ctx.beginPath();
      ctx.moveTo(-4.8, -20.4); ctx.quadraticCurveTo(-9, -10, -5.6, -4); ctx.quadraticCurveTo(-3, -12, -1.6, -21);
      ctx.closePath(); ctx.fill();
      eye(ctx, 1.7, -19.4, 1.15, "#5ec8ff");
      eye(ctx, -1.7, -19.4, 1.15, "#5ec8ff");
      // ледяная корона
      ctx.fillStyle = "#d8f2ff";
      for (let i = 0; i < 5; i++) {
        const hh = 7 - Math.abs(i - 2) * 1.8;
        ctx.beginPath();
        ctx.moveTo(-6 + i * 3, -23);
        ctx.lineTo(-4.6 + i * 3, -23 - hh);
        ctx.lineTo(-3.2 + i * 3, -23);
        ctx.closePath(); ctx.fill();
      }
      ctx.strokeStyle = "rgba(120,190,230,0.8)"; ctx.lineWidth = 0.9; ctx.stroke();
      // снежинки вокруг
      ctx.strokeStyle = "rgba(230,248,255,0.85)"; ctx.lineWidth = 1;
      for (let i = 0; i < 6; i++) {
        const a = t * 0.8 + (i / 6) * Math.PI * 2;
        const sx = Math.cos(a) * 22, sy = Math.sin(a) * 16 - 8;
        for (let k = 0; k < 3; k++) {
          const ka = (k / 3) * Math.PI;
          ctx.beginPath();
          ctx.moveTo(sx - Math.cos(ka) * 2.4, sy - Math.sin(ka) * 2.4);
          ctx.lineTo(sx + Math.cos(ka) * 2.4, sy + Math.sin(ka) * 2.4);
          ctx.stroke();
        }
      }
      return true;
    }
    case "kraken": {
      // щупальца
      for (let i = 0; i < 6; i++) {
        const side = i < 3 ? -1 : 1;
        const k = i % 3;
        const sw = Math.sin(t * 2 + i) * 4;
        ctx.strokeStyle = "#2f6a72"; ctx.lineWidth = 5 - k; ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(side * 4, 4);
        ctx.quadraticCurveTo(side * (16 + k * 5), 8 + sw, side * (24 + k * 6), 16 - sw);
        ctx.stroke();
        ctx.strokeStyle = "#4a9aa4"; ctx.lineWidth = 2.4 - k * 0.4;
        ctx.stroke();
        // присоски
        ctx.fillStyle = "rgba(200,240,240,0.5)";
        for (let s = 1; s <= 3; s++) {
          ctx.beginPath();
          ctx.arc(side * (6 + s * 5.5), 7 + sw * (s / 3) + s, 1.1, 0, 7);
          ctx.fill();
        }
      }
      ell(ctx, 0, -4, 15, 14, "#38808a", 0, "rgba(8,26,30,0.85)", 1.8);
      ctx.fillStyle = "rgba(180,240,240,0.2)";
      ctx.beginPath(); ctx.ellipse(-5, -10, 6, 4, -0.4, 0, 7); ctx.fill();
      spots(ctx, 0, -4, 14, 13, "rgba(20,70,80,0.45)", 6, 0.8);
      eye(ctx, 6, -6, 3, "#f2e86a");
      eye(ctx, -6, -6, 3, "#f2e86a");
      ctx.fillStyle = "#0d2a2e";
      ctx.beginPath(); ctx.ellipse(6, -6, 1, 2.6, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(-6, -6, 1, 2.6, 0, 0, 7); ctx.fill();
      // клюв
      ctx.fillStyle = "#1d1410";
      ctx.beginPath(); ctx.moveTo(-3, 6); ctx.lineTo(3, 6); ctx.lineTo(0, 11); ctx.closePath(); ctx.fill();
      return true;
    }
    case "lunnyi_bog": {
      const halo = ctx.createRadialGradient(0, -14, 8, 0, -14, 30);
      halo.addColorStop(0, "rgba(230,240,255,0.3)");
      halo.addColorStop(1, "rgba(230,240,255,0)");
      ctx.fillStyle = halo;
      ctx.beginPath(); ctx.arc(0, -14, 30, 0, 7); ctx.fill();
      // лунный диск за спиной
      ctx.fillStyle = "rgba(240,246,255,0.22)";
      ctx.beginPath(); ctx.arc(0, -12, 20, 0, 7); ctx.fill();
      ctx.fillStyle = "rgba(200,214,240,0.2)";
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.arc(-8 + i * 6, -16 + (i % 2) * 8, 3 - (i % 2), 0, 7);
        ctx.fill();
      }
      // мантия
      ctx.beginPath();
      ctx.moveTo(-10, 14);
      ctx.quadraticCurveTo(-14, -4, 0, -12);
      ctx.quadraticCurveTo(14, -4, 10, 14);
      ctx.quadraticCurveTo(0, 17, -10, 14);
      ctx.closePath();
      const g = ctx.createLinearGradient(0, -12, 0, 14);
      g.addColorStop(0, "#e8eef8");
      g.addColorStop(0.5, "#aeb9cf");
      g.addColorStop(1, "#5c6478");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "rgba(90,100,124,0.7)"; ctx.lineWidth = 1.3; ctx.stroke();
      ell(ctx, 0, -17, 6, 6, "#dfe6f2");
      eye(ctx, 2.4, -18, 1.5, "#a8c8ff");
      eye(ctx, -2.4, -18, 1.5, "#a8c8ff");
      // рога-полумесяцы
      ctx.strokeStyle = "#e8eef8"; ctx.lineWidth = 2.2; ctx.lineCap = "round";
      for (const side of [-1, 1]) {
        ctx.beginPath();
        ctx.arc(side * 7, -22, 5, side > 0 ? -1.4 : Math.PI + 1.4, side > 0 ? 1.2 : Math.PI - 1.2, side < 0);
        ctx.stroke();
      }
      return true;
    }
    case "vladyka_bezdny": {
      // щупальца тьмы
      for (let i = 0; i < 7; i++) {
        const a = Math.PI + (i / 6) * Math.PI;
        const sw = Math.sin(t * 2.4 + i) * 3;
        ctx.strokeStyle = "#241634"; ctx.lineWidth = 4;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(0, 2);
        ctx.quadraticCurveTo(Math.cos(a) * 12, 8 + sw, Math.cos(a) * 22, 14 + sw);
        ctx.stroke();
        ctx.strokeStyle = "rgba(140,90,210,0.45)"; ctx.lineWidth = 1.4;
        ctx.stroke();
      }
      ctx.beginPath();
      for (let i = 0; i <= 14; i++) {
        const a = (i / 14) * Math.PI * 2;
        const r = 14 + Math.sin(a * 3 + t * 1.6) * 2.6;
        const x = Math.cos(a) * r, y = Math.sin(a) * r * 0.92 - 4;
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.closePath();
      const g = ctx.createRadialGradient(-4, -10, 1, 0, -4, 18);
      g.addColorStop(0, "#4a3468");
      g.addColorStop(0.55, "#241634");
      g.addColorStop(1, "#0c0714");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "rgba(150,100,220,0.4)"; ctx.lineWidth = 1.4; ctx.stroke();
      // множество глаз
      for (let i = 0; i < 7; i++) {
        const a = (i / 7) * Math.PI * 2 + t * 0.4;
        const r = 3 + (i % 3) * 2.6;
        eye(ctx, Math.cos(a) * r * 1.6, -4 + Math.sin(a) * r, 1.05 + (i % 2) * 0.5, "#c07af2", i % 3 === 0);
      }
      return true;
    }
    case "kosmouzhas": {
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2 + t * 0.5;
        const sw = Math.sin(t * 3 + i) * 3;
        ctx.strokeStyle = "#3a1c56"; ctx.lineWidth = 4.4;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(0, -2);
        ctx.quadraticCurveTo(Math.cos(a) * 14, -2 + Math.sin(a) * 12 + sw, Math.cos(a) * 26, -2 + Math.sin(a) * 22 + sw);
        ctx.stroke();
        ctx.strokeStyle = "rgba(190,110,240,0.4)"; ctx.lineWidth = 1.6;
        ctx.stroke();
      }
      ell(ctx, 0, -4, 15, 14, "#4a2470", 0, "rgba(14,4,22,0.9)", 1.8);
      // звёзды внутри тела
      ctx.save();
      ctx.beginPath(); ctx.ellipse(0, -4, 15, 14, 0, 0, 7); ctx.clip();
      for (let i = 0; i < 14; i++) {
        const sx = -14 + ((i * 47) % 28);
        const sy = -17 + ((i * 31) % 27);
        const tw = 0.4 + Math.abs(Math.sin(t * 2 + i));
        ctx.fillStyle = `rgba(255,255,240,${(tw * 0.8).toFixed(2)})`;
        ctx.beginPath(); ctx.arc(sx, sy, i % 5 === 0 ? 1.5 : 0.8, 0, 7); ctx.fill();
      }
      ctx.restore();
      // центральный глаз
      const pulse = 1 + Math.sin(t * 3) * 0.12;
      eye(ctx, 0, -5, 4.4 * pulse, "#ffe08a");
      ctx.fillStyle = "#1a0824";
      ctx.beginPath(); ctx.ellipse(0, -5, 1.5, 4 * pulse, 0, 0, 7); ctx.fill();
      return true;
    }
    case "haos_avatar": {
      const hue = Math.floor((t * 70) % 360);
      for (let i = 0; i < 9; i++) {
        const a = (i / 9) * Math.PI * 2 + t * 0.8;
        ctx.strokeStyle = `hsla(${(hue + i * 40) % 360},85%,62%,0.7)`;
        ctx.lineWidth = 3.4;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(0, -4);
        const mid = 14 + Math.sin(t * 4 + i) * 5;
        ctx.quadraticCurveTo(Math.cos(a) * mid, -4 + Math.sin(a) * mid, Math.cos(a) * 28, -4 + Math.sin(a) * 24);
        ctx.stroke();
      }
      ctx.beginPath();
      for (let i = 0; i <= 16; i++) {
        const a = (i / 16) * Math.PI * 2;
        const r = 16 + Math.sin(a * 5 + t * 6) * 4.4;
        const x = Math.cos(a) * r, y = Math.sin(a) * r * 0.9 - 4;
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.closePath();
      const g = ctx.createLinearGradient(-16, -18, 16, 14);
      g.addColorStop(0, `hsl(${hue},80%,66%)`);
      g.addColorStop(0.4, `hsl(${(hue + 80) % 360},70%,42%)`);
      g.addColorStop(1, `hsl(${(hue + 170) % 360},70%,20%)`);
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "rgba(20,6,20,0.85)"; ctx.lineWidth = 1.8; ctx.stroke();
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2 + t * 1.6;
        eye(ctx, Math.cos(a) * 6, -4 + Math.sin(a) * 5, 1.5, "#fff4c0", i % 2 === 0);
      }
      return true;
    }
    default:
      return false;
  }
}

export const BOSS_IDS = new Set([
  "drakon", "korol_nezhiti", "vladyka_lavy", "ledyanaya_koroleva",
  "kraken", "lunnyi_bog", "kosmouzhas", "vladyka_bezdny", "haos_avatar",
]);
