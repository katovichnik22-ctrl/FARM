import type { Engine } from "./engine";
import { TILE, G, O } from "../types";
import {
  L, LAYERS, LAYER_BY_ID, GATES, SPACE_BUILDS, ALIENS, LAYER_BOSSES,
  LAYER_SPAWN, LAYER_GEAR,
} from "../data/layers";
import type { LayerDef, GateDef } from "../data/layers";
import { layerDrop, hazardStrength } from "../world/layergen";
import { tileAt } from "../world/worldgen";
import { ITEMS } from "../data/items";
import { clamp, clamp01, pickW, hash2 } from "../lib/noise";
import { snd } from "../lib/sound";

export interface LayerSave {
  unlocked: number[];
  gates: string[];
  spaceBuilds: string[];
  bossesKilled: string[];
  gear: string[];
  aliens: Record<string, number>;   // id -> отношение
  building: { id: string; left: number } | null;
  visits: Record<number, number>;
  oxygen: number;
  chaosRule: string;
  chaosT: number;
}

export class LayerSim {
  unlocked = new Set<number>([0, 1]);
  gates = new Set<string>();
  spaceBuilds = new Set<string>();
  bossesKilled = new Set<string>();
  gear = new Set<string>();
  aliens: Record<string, number> = {};
  building: { id: string; left: number } | null = null;
  visits: Record<number, number> = {};
  oxygen = 100;
  chaosRule = "";
  chaosT = 0;
  private hazT = 0;
  private spawnBossT = 8;
  private alienT = 40;

  reset() {
    this.unlocked = new Set([0, 1]);
    this.gates = new Set();
    this.spaceBuilds = new Set();
    this.bossesKilled = new Set();
    this.gear = new Set();
    this.aliens = {};
    for (const a of ALIENS) this.aliens[a.id] = a.temper === "friend" ? 30 : a.temper === "foe" ? -40 : 0;
    this.building = null;
    this.visits = {};
    this.oxygen = 100;
    this.chaosRule = "";
  }

  def(z: number): LayerDef { return LAYER_BY_ID[z] ?? LAYERS[0]; }
  isUnlocked(z: number): boolean { return z === 0 || z === 1 || this.unlocked.has(z); }
  hasGate(id: string): boolean { return this.gates.has(id); }
  hasGear(id: string): boolean { return this.gear.has(id); }

  /** Список доступных переходов из текущего слоя */
  gatesFrom(z: number): GateDef[] { return GATES.filter((g) => g.from === z || (g.to === z && this.hasGate(g.id))); }

  // ---------- Постройка переходов ----------
  canBuildGate(e: Engine, id: string): { ok: boolean; reason: string } {
    const g = GATES.find((x) => x.id === id);
    if (!g) return { ok: false, reason: "?" };
    if (this.hasGate(id)) return { ok: false, reason: "Уже построено" };
    if (this.building) return { ok: false, reason: "Другая стройка уже идёт" };
    if (g.needTech && !e.lore.has(g.needTech)) return { ok: false, reason: "Нужна технология" };
    if (g.needLayerUnlock !== undefined && !this.isUnlocked(g.needLayerUnlock)) {
      return { ok: false, reason: `Сначала откройте: ${this.def(g.needLayerUnlock).name}` };
    }
    if (!e.city.s.founded) return { ok: false, reason: "Нужен основанный город" };
    if (e.player.gold < g.cost.gold) return { ok: false, reason: `Нужно ${g.cost.gold} золота` };
    for (const [rid, n] of g.cost.res) {
      const have = e.count(rid) + e.city.stockOf(rid);
      if (have < n) return { ok: false, reason: `Не хватает: ${ITEMS[rid]?.name ?? rid} (${have}/${n})` };
    }
    return { ok: true, reason: "" };
  }
  buildGate(e: Engine, id: string) {
    const c = this.canBuildGate(e, id);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    const g = GATES.find((x) => x.id === id)!;
    e.player.gold -= g.cost.gold;
    for (const [rid, n] of g.cost.res) {
      let need = n;
      const fromCity = Math.min(need, e.city.stockOf(rid));
      if (fromCity > 0) { e.city.takeStock(rid, fromCity); need -= fromCity; }
      if (need > 0) e.take(rid, need);
    }
    this.building = { id, left: Math.ceil(g.buildTime / 12) };
    e.toast(`Начата стройка: ${g.name}. Готово через ${this.building.left} дн.`, "info");
    snd.buildHammer();
    e.poke();
  }
  private finishGate(e: Engine) {
    if (!this.building) return;
    const g = GATES.find((x) => x.id === this.building!.id);
    this.building = null;
    if (!g) return;
    this.gates.add(g.id);
    this.unlocked.add(g.to);
    const d = this.def(g.to);
    e.toast(`${g.name} готов! Открыт путь: ${d.name}`, "good");
    e.nations.log(e, `Открыт слой: ${d.name}`, "good");
    e.addXp(150);
    e.lore.culture.points += 120;
    snd.levelup();
    e.shake = 0.6;
    if (e.city.s.founded) e.city.s.paradeT = 8;
    e.poke();
  }

  // ---------- Снаряжение ----------
  canBuyGear(e: Engine, id: string): { ok: boolean; reason: string } {
    const gr = LAYER_GEAR.find((x) => x.id === id);
    if (!gr) return { ok: false, reason: "?" };
    if (this.hasGear(id)) return { ok: false, reason: "Уже есть" };
    if (gr.tech && !e.lore.has(gr.tech)) return { ok: false, reason: "Нужна технология" };
    if (e.player.gold < gr.cost.gold) return { ok: false, reason: `Нужно ${gr.cost.gold} золота` };
    for (const [rid, n] of gr.cost.res) {
      const have = e.count(rid) + e.city.stockOf(rid);
      if (have < n) return { ok: false, reason: `Не хватает: ${ITEMS[rid]?.name ?? rid} (${have}/${n})` };
    }
    return { ok: true, reason: "" };
  }
  buyGear(e: Engine, id: string) {
    const c = this.canBuyGear(e, id);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    const gr = LAYER_GEAR.find((x) => x.id === id)!;
    e.player.gold -= gr.cost.gold;
    for (const [rid, n] of gr.cost.res) {
      let need = n;
      const fromCity = Math.min(need, e.city.stockOf(rid));
      if (fromCity > 0) { e.city.takeStock(rid, fromCity); need -= fromCity; }
      if (need > 0) e.take(rid, need);
    }
    this.gear.add(id);
    e.toast(`${gr.name} готов. Теперь новые земли не страшны`, "good");
    snd.craft();
    e.poke();
  }

  // ---------- Путешествие ----------
  canTravel(e: Engine, to: number): { ok: boolean; reason: string } {
    if (to === e.z) return { ok: false, reason: "Вы уже здесь" };
    if (e.battle.s.active) return { ok: false, reason: "Идёт битва" };
    if (to === 0) return { ok: true, reason: "" };
    if (!this.isUnlocked(to)) return { ok: false, reason: "Путь ещё не открыт" };
    const d = this.def(to);
    if (d.needItem && !this.hasGear(d.needItem)) return { ok: false, reason: `Нужно снаряжение: ${d.needItemName}` };
    // цепочка: Марс только с Луны
    if (to === L.Mars && e.z !== L.Moon && !this.hasGate("g_marsship")) return { ok: false, reason: "Нужен межпланетный корабль" };
    return { ok: true, reason: "" };
  }

  travel(e: Engine, to: number) {
    const c = this.canTravel(e, to);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    const from = e.z;
    e.z = to;
    e.mobs = []; e.projectiles = []; e.particles = []; e.floaters = [];
    e.moveTarget = null; e.pending = null;
    this.oxygen = 100;
    this.visits[to] = (this.visits[to] ?? 0) + 1;
    // ищем проходимое место
    const ptx = Math.floor(e.player.x / TILE), pty = Math.floor(e.player.y / TILE);
    let placed = false;
    outer: for (let r = 0; r < 40; r++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
          const t = tileAt(e.seed, ptx + dx, pty + dy, to);
          if (!e.isBlocked(ptx + dx, pty + dy)) {
            e.player.x = (ptx + dx) * TILE + TILE / 2;
            e.player.y = (pty + dy) * TILE + TILE / 2;
            placed = true;
            void t;
            break outer;
          }
        }
      }
    }
    if (!placed) { e.player.x = ptx * TILE + 20; e.player.y = pty * TILE + 20; }
    e.cam.x = e.player.x; e.cam.y = e.player.y;
    e.cam.panX = 0; e.cam.panY = 0; e.cam.follow = true;
    const d = this.def(to);
    const first = (this.visits[to] ?? 0) === 1;
    e.toast(first ? `Впервые: ${d.name}. ${d.desc}` : `Вы перешли в слой: ${d.name}`, first ? "good" : "info");
    if (first) {
      e.addXp(120);
      e.lore.culture.points += 80;
      e.nations.log(e, `Первый шаг: ${d.name}`, "good");
      snd.levelup();
    } else snd.splash();
    e.shake = 0.35;
    this.spawnBossT = 10;
    void from;
    e.poke();
  }

  // ---------- Космическая программа ----------
  canBuildSpace(e: Engine, id: string): { ok: boolean; reason: string } {
    const b = SPACE_BUILDS.find((x) => x.id === id);
    if (!b) return { ok: false, reason: "?" };
    if (this.spaceBuilds.has(id)) return { ok: false, reason: "Уже построено" };
    if (!this.isUnlocked(b.layer)) return { ok: false, reason: `Нужен доступ: ${this.def(b.layer).name}` };
    if (b.id === "sb_mine" && !this.spaceBuilds.has("sb_base")) return { ok: false, reason: "Сначала лунная база" };
    if (b.id === "sb_station" && !this.spaceBuilds.has("sb_base")) return { ok: false, reason: "Сначала лунная база" };
    if (b.id === "sb_warp" && !this.spaceBuilds.has("sb_colony")) return { ok: false, reason: "Сначала колония на Марсе" };
    if (e.player.gold < b.cost.gold) return { ok: false, reason: `Нужно ${b.cost.gold} золота` };
    for (const [rid, n] of b.cost.res) {
      const have = e.count(rid) + e.city.stockOf(rid);
      if (have < n) return { ok: false, reason: `Не хватает: ${ITEMS[rid]?.name ?? rid} (${have}/${n})` };
    }
    return { ok: true, reason: "" };
  }
  buildSpace(e: Engine, id: string) {
    const c = this.canBuildSpace(e, id);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    const b = SPACE_BUILDS.find((x) => x.id === id)!;
    e.player.gold -= b.cost.gold;
    for (const [rid, n] of b.cost.res) {
      let need = n;
      const fromCity = Math.min(need, e.city.stockOf(rid));
      if (fromCity > 0) { e.city.takeStock(rid, fromCity); need -= fromCity; }
      if (need > 0) e.take(rid, need);
    }
    this.spaceBuilds.add(id);
    e.toast(`Построено: ${b.name}. ${b.bonusText}`, "good");
    e.nations.log(e, `Космос: ${b.name}`, "good");
    e.addXp(180);
    e.lore.culture.points += 150;
    snd.levelup();
    e.poke();
  }
  spaceEffect(key: "gold" | "sci" | "def"): number {
    let v = 0;
    for (const id of this.spaceBuilds) {
      const b = SPACE_BUILDS.find((x) => x.id === id);
      const val = b?.effect[key];
      if (typeof val === "number") v += val;
    }
    return v;
  }

  // ---------- Инопланетяне ----------
  alienAct(e: Engine, id: string, act: "gift" | "trade" | "attack") {
    const a = ALIENS.find((x) => x.id === id);
    if (!a) return;
    const rel = this.aliens[id] ?? 0;
    switch (act) {
      case "gift": {
        const cost = 800;
        if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота`, "warn"); return; }
        e.player.gold -= cost;
        this.aliens[id] = clamp(rel + 22, -100, 100);
        e.toast(`${a.name} приняли дар. Отношения теплеют`, "good");
        if (this.aliens[id] > 55) {
          e.lore.addScience(e, 400);
          e.toast(`${a.name} поделились знанием звёзд: +400 науки`, "good");
        }
        snd.craft();
        break;
      }
      case "trade": {
        if (rel < 0) { e.toast(`${a.name} не станут торговать с врагом`, "warn"); return; }
        const cost = 500;
        if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота`, "warn"); return; }
        e.player.gold -= cost;
        const goods = ["adamantit", "mifril", "lunnyi_kamen", "marsianit", "alien_tech"];
        const pick = goods[Math.floor(Math.random() * goods.length)];
        const n = 3 + Math.floor(Math.random() * 6);
        e.give(pick, n, true);
        this.aliens[id] = clamp(rel + 5, -100, 100);
        e.toast(`Обмен с ${a.name}: получено ${ITEMS[pick]?.name ?? pick} ×${n}`, "good");
        snd.pickup();
        break;
      }
      case "attack": {
        const power = e.army.power();
        if (power < 300) { e.toast("Войско слишком слабо для звёздной войны", "warn"); return; }
        this.aliens[id] = clamp(rel - 45, -100, 100);
        const win = Math.random() < clamp01(power / 1200);
        if (win) {
          const loot = 2000 + Math.floor(Math.random() * 3000);
          e.player.gold += loot;
          e.give("alien_tech", 5, true);
          e.toast(`${a.name} разбиты! Трофеи: ${loot} золота и чужие детали`, "good");
          e.nations.fame += 25;
          e.addXp(400);
        } else {
          const loss = Math.min(e.player.gold, 1500);
          e.player.gold -= loss;
          for (const s of e.army.squads) s.n = Math.max(0, Math.round(s.n * 0.6));
          e.army.squads = e.army.squads.filter((s) => s.n > 0);
          e.toast(`${a.name} отбились. Войско разбито, потеряно ${loss} золота`, "bad");
        }
        snd.explosion();
        e.shake = 0.7;
        break;
      }
    }
    e.poke();
  }

  // ---------- Боссы слоёв ----------
  bossOf(z: number) { return LAYER_BOSSES[z] ?? null; }
  bossAlive(z: number): boolean {
    const b = this.bossOf(z);
    return !!b && !this.bossesKilled.has(b.id);
  }
  private trySpawnBoss(e: Engine) {
    const b = this.bossOf(e.z);
    if (!b || this.bossesKilled.has(b.id)) return;
    if (e.mobs.some((m) => m.def === b.id)) return;
    // босс появляется, когда игрок ушёл достаточно далеко от точки входа
    const dist = Math.hypot(e.player.x / TILE, e.player.y / TILE);
    const need = 40 + e.z * 10;
    if (dist < need) return;
    if (Math.random() > 0.25) return;
    const ang = Math.random() * Math.PI * 2;
    e.mobs.push({
      uid: Date.now() % 100000,
      def: b.id,
      x: e.player.x + Math.cos(ang) * 11 * TILE,
      y: e.player.y + Math.sin(ang) * 11 * TILE,
      hp: 1, maxHp: 1, state: "chase", t: 0, cd: 3, flash: 0, lvl: 1,
      tx: 0, ty: 0, breathe: 0, hitT: 0,
    });
    const m = e.mobs[e.mobs.length - 1];
    const def = e.mobDef(b.id);
    if (def) { m.hp = def.hp; m.maxHp = def.hp; }
    e.toast(`${b.name} пробудился! ${this.def(e.z).name} содрогается`, "bad");
    e.nations.log(e, `Пробуждён ${b.name}`, "bad");
    snd.thunder();
    e.shake = 0.9;
    e.poke();
  }
  onBossKilled(e: Engine, id: string) {
    if (this.bossesKilled.has(id)) return;
    const entry = Object.values(LAYER_BOSSES).find((b) => b.id === id);
    if (!entry) return;
    this.bossesKilled.add(id);
    e.toast(`${entry.name} повержен! ${entry.layerName} усмирён`, "good");
    e.nations.log(e, `Повержен ${entry.name}`, "good");
    e.nations.fame += 30;
    e.lore.culture.points += 250;
    e.lore.grantArtifact(e);
    e.addXp(500);
    snd.levelup();
    e.shake = 1;
  }

  // ---------- Ловушки и руины ----------
  triggerTrap(e: Engine, tx: number, ty: number) {
    const r = hash2(e.seed ^ 0x77a, tx, ty);
    e.setTile(tx, ty, O.None, 0);
    if (r < 0.35) {
      const dmg = 12 + e.z * 6;
      e.hurtPlayer(dmg, tx * TILE, ty * TILE);
      e.toast("Ловушка! Из пола ударили колья", "bad");
      e.spawnHitParticles(tx * TILE + 20, ty * TILE + 20, "#c94f5d", 14, "spark");
    } else if (r < 0.6) {
      e.player.poisonT = 12;
      e.toast("Ловушка: облако ядовитого газа", "bad");
      e.spawnHitParticles(tx * TILE + 20, ty * TILE + 20, "#8ae68a", 18, "puff");
    } else if (r < 0.8) {
      e.toast("Механизм щёлкнул вхолостую — вам повезло", "info");
    } else {
      const gold = 50 + Math.floor(r * 300);
      e.player.gold += gold;
      e.toast(`За ловушкой оказался тайник: +${gold} золота`, "good");
      snd.chest();
    }
    e.shake = 0.4;
    snd.explosion();
  }
  openRuinChest(e: Engine, tx: number, ty: number) {
    const r = (k: number) => hash2(e.seed ^ 0xc4e5, tx * 5 + k, ty * 9 + k);
    e.setTile(tx, ty, O.None, 0);
    const zBonus = e.z;
    const gold = 100 + Math.floor(r(1) * 400 * (1 + zBonus * 0.4));
    e.player.gold += gold;
    const pool = ["mifril", "adamantit", "kristall", "nebesnyi_kristall", "zhemchug", "lunnyi_kamen", "marsianit", "tenevaya_sut", "pyl_snov", "oskolok_haosa", "alien_tech"];
    const pick = pool[Math.floor(r(2) * pool.length)];
    e.give(pick, 2 + Math.floor(r(3) * 4), true);
    if (r(4) < 0.18 + zBonus * 0.03) e.lore.grantArtifact(e);
    e.toast(`Древний сундук: +${gold} золота и редкие материалы`, "good");
    snd.chest();
    e.addXp(30);
  }

  // ---------- Тик ----------
  update(e: Engine, dt: number) {
    const z = e.z;
    const d = this.def(z);

    // хаос меняет правила
    if (z === L.Chaos) {
      this.chaosT -= dt;
      if (this.chaosT <= 0) {
        this.chaosT = 25 + Math.random() * 30;
        const rules = [
          "Всё вокруг легчает: прыжок выше, шаг шире",
          "Время густеет: движения даются тяжело",
          "Золото само липнет к рукам",
          "Мана течёт рекой",
          "Раны затягиваются на глазах",
          "Воздух жжёт кожу",
        ];
        const i = Math.floor(Math.random() * rules.length);
        this.chaosRule = rules[i];
        e.toast(`Хаос: ${this.chaosRule}`, "warn");
        if (i === 2) e.player.gold += 50 + Math.floor(Math.random() * 300);
        if (i === 3 && e.lore.magic.school) e.lore.magic.mana = e.lore.magic.manaMax;
        if (i === 4) e.player.hp = clamp(e.player.hp + 30, 0, e.player.maxHp);
        if (i === 5) e.hurtPlayer(10, e.player.x + 30, e.player.y);
        e.lore.magic.auraT = 3;
        e.poke();
      }
    }

    if (z === 0) { this.oxygen = 100; return; }

    // опасности слоя
    this.hazT -= dt;
    if (this.hazT <= 0) {
      this.hazT = 1;
      const ptx = Math.floor(e.player.x / TILE), pty = Math.floor(e.player.y / TILE);
      const hasGear = !d.needItem || this.hasGear(d.needItem);
      switch (d.hazard) {
        case "heat": {
          const near = hazardStrength(z, ptx, pty, e.seed);
          const dmg = hasGear ? 0.4 * near : 3.5 * near;
          if (dmg > 0.1) {
            e.player.hp = clamp(e.player.hp - dmg, 0, e.player.maxHp);
            e.player.water = clamp(e.player.water - dmg * 0.6, 0, 100);
            if (!hasGear && Math.random() < 0.3) e.addFloater("Жар!", "#f2762e", e.player.x, e.player.y - 34);
          }
          break;
        }
        case "cold":
          e.player.temp = Math.min(e.player.temp, -4 + e.warmthSum() * 2);
          if (e.player.temp < 0 && Math.random() < 0.3) e.addFloater("Стужа", "#9fd4f2", e.player.x, e.player.y - 34);
          break;
        case "drown":
        case "vacuum": {
          const atBase = e.buildings.some((b) => b.done && e.distTo((b.tx + 0.5) * TILE, (b.ty + 0.5) * TILE) < 6);
          if (atBase || (z === L.Moon && this.spaceBuilds.has("sb_base"))) {
            this.oxygen = clamp(this.oxygen + 6, 0, 100);
            break;
          }
          if (hasGear) {
            this.oxygen = clamp(this.oxygen - 0.2, 0, 100);
            if (this.oxygen <= 0) {
              e.player.hp = clamp(e.player.hp - 1.6, 0, e.player.maxHp);
              if (Math.random() < 0.4) e.addFloater(d.hazard === "drown" ? "Нет воздуха!" : "Вакуум!", "#7fd4f2", e.player.x, e.player.y - 34);
            }
          } else {
            this.oxygen = clamp(this.oxygen - 4, 0, 100);
            e.player.hp = clamp(e.player.hp - 4, 0, e.player.maxHp);
            if (Math.random() < 0.5) e.addFloater("Задыхаюсь!", "#e05a5a", e.player.x, e.player.y - 34);
          }
          break;
        }
        case "radiation": {
          const dmg = hasGear ? 0.25 : 5;
          e.player.hp = clamp(e.player.hp - dmg, 0, e.player.maxHp);
          if (Math.random() < 0.25) e.addFloater("Радиация", "#a8e68a", e.player.x, e.player.y - 34);
          break;
        }
        case "madness": {
          if (Math.random() < 0.06) {
            e.player.stamina = clamp(e.player.stamina - 12, 0, 100);
            e.addFloater("Шёпот…", "#a26af2", e.player.x, e.player.y - 34);
          }
          break;
        }
        default: break;
      }
      if (e.player.hp <= 0 && !e.player.dead) e.hurtPlayer(1, e.player.x, e.player.y);
    }

    // боссы слоёв
    this.spawnBossT -= dt;
    if (this.spawnBossT <= 0) { this.spawnBossT = 20; this.trySpawnBoss(e); }

    // инопланетяне на Луне/Марсе
    if (z === L.Moon || z === L.Mars) {
      this.alienT -= dt;
      if (this.alienT <= 0) {
        this.alienT = 90 + Math.random() * 120;
        const a = ALIENS[Math.floor(Math.random() * ALIENS.length)];
        const rel = this.aliens[a.id] ?? 0;
        if (a.temper === "foe" && rel < -20 && Math.random() < 0.5) {
          e.toast(`${a.name} атакуют вашу базу!`, "bad");
          const loss = Math.min(e.player.gold, 300);
          e.player.gold -= loss;
          snd.monster();
        } else {
          e.toast(`Замечены ${a.name}: ${a.offer}`, "info");
        }
        e.poke();
      }
    }
  }

  /** Спавн-таблица для текущего слоя */
  spawnTable(z: number): [string, number][] | null { return LAYER_SPAWN[z] ?? null; }
  spawnPick(z: number, r: number): string | null {
    const t = this.spawnTable(z);
    return t ? pickW(r, t) : null;
  }

  dayTick(e: Engine) {
    if (this.building) {
      this.building.left--;
      if (this.building.left <= 0) this.finishGate(e);
    }
    // доход космических построек
    const gold = this.spaceEffect("gold");
    if (gold > 0) e.player.gold += Math.round(gold);
    const sci = this.spaceEffect("sci");
    if (sci > 0) e.lore.addScience(e, Math.round(sci * 0.4));
    for (const id of this.spaceBuilds) {
      const b = SPACE_BUILDS.find((x) => x.id === id);
      if (b?.effect.res) {
        const [rid, n] = b.effect.res;
        e.city.addStock(rid, n);
      }
    }
    // отношения с пришельцами дрейфуют
    for (const a of ALIENS) {
      const cur = this.aliens[a.id] ?? 0;
      this.aliens[a.id] = clamp(cur + (a.temper === "foe" ? -0.6 : 0.4), -100, 100);
    }
  }

  serialize(): LayerSave {
    return {
      unlocked: [...this.unlocked], gates: [...this.gates],
      spaceBuilds: [...this.spaceBuilds], bossesKilled: [...this.bossesKilled],
      gear: [...this.gear], aliens: { ...this.aliens },
      building: this.building ? { ...this.building } : null,
      visits: { ...this.visits }, oxygen: this.oxygen,
      chaosRule: this.chaosRule, chaosT: this.chaosT,
    };
  }
  load(s: LayerSave) {
    if (!s) return;
    this.unlocked = new Set(s.unlocked ?? [0, 1]);
    this.gates = new Set(s.gates ?? []);
    this.spaceBuilds = new Set(s.spaceBuilds ?? []);
    this.bossesKilled = new Set(s.bossesKilled ?? []);
    this.gear = new Set(s.gear ?? []);
    this.aliens = { ...this.aliens, ...(s.aliens ?? {}) };
    this.building = s.building ? { ...s.building } : null;
    this.visits = { ...(s.visits ?? {}) };
    this.oxygen = s.oxygen ?? 100;
    this.chaosRule = s.chaosRule ?? "";
  }
}

export { L, LAYERS, GATES, SPACE_BUILDS, ALIENS, LAYER_GEAR };
export const LAYER_DROPS = layerDrop;
export const GROUND_LAVA = G.Lava;
