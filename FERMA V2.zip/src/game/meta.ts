import type { Engine } from "./engine";
import type {
  GameMode, Quest, QuestGoal, MetaSave, JournalEntry, DailyTask, AchCtx,
} from "../types/meta";
import { MODE_BY_ID, STAR_UPGRADES } from "../types/meta";
import { STORY_QUESTS, QUEST_BY_ID, SIDE_TEMPLATES, RUMORS, CHAR_BY_ID, ACTS } from "../data/story";
import { ACHIEVEMENTS, COLLECTION, COLLECT_MAP, DAILY_POOL } from "../data/achievements";
import { ITEMS } from "../data/items";
import { BUILDINGS } from "../data/buildings";
import { clamp, mulberry32 } from "../lib/noise";
import { snd } from "../lib/sound";

const PRESTIGE_KEY = "tihoe-plamya:meta";

/** Постоянный прогресс между мирами (звёзды, апгрейды, перерождения) */
interface GlobalMeta {
  stars: number;
  starUpgrades: Record<string, number>;
  prestige: number;
  achievements: string[];
  collection: string[];
  bestRating: number;
  daily: { lastDay: string; streak: number; claimed: boolean };
}

function loadGlobal(): GlobalMeta {
  try {
    const raw = localStorage.getItem(PRESTIGE_KEY);
    if (raw) {
      const d = JSON.parse(raw) as GlobalMeta;
      return {
        stars: d.stars ?? 0, starUpgrades: d.starUpgrades ?? {}, prestige: d.prestige ?? 0,
        achievements: d.achievements ?? [], collection: d.collection ?? [],
        bestRating: d.bestRating ?? 0,
        daily: d.daily ?? { lastDay: "", streak: 0, claimed: false },
      };
    }
  } catch { /* пусто */ }
  return { stars: 0, starUpgrades: {}, prestige: 0, achievements: [], collection: [], bestRating: 0, daily: { lastDay: "", streak: 0, claimed: false } };
}
function saveGlobal(g: GlobalMeta) {
  try { localStorage.setItem(PRESTIGE_KEY, JSON.stringify(g)); } catch { /* пусто */ }
}

export function todayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export class MetaSim {
  mode: GameMode = "normal";
  quests: Quest[] = [];
  questsDone = new Set<string>();
  act = 1;
  choices: Record<string, string> = {};
  journal: JournalEntry[] = [];
  achievements = new Set<string>();
  collection = new Set<string>();
  stars = 0;
  starUpgrades: Record<string, number> = {};
  prestige = 0;
  daily = { lastDay: "", streak: 0, claimed: false, tasks: [] as DailyTask[] };
  rating = 0;
  rumors: string[] = [];
  charMet = new Set<string>();
  battlesWon = 0;
  notifications = false;
  questUid = 1;
  private sideT = 45;
  private rumorT = 70;
  private achT = 3;
  private lastGather = 0;
  private walkAcc = 0;

  // ---------- Инициализация ----------
  init(mode: GameMode) {
    const g = loadGlobal();
    this.mode = mode;
    this.quests = []; this.questsDone = new Set(); this.act = 1;
    this.choices = {}; this.journal = [];
    this.achievements = new Set(g.achievements);
    this.collection = new Set(g.collection);
    this.stars = g.stars; this.starUpgrades = { ...g.starUpgrades };
    this.prestige = g.prestige;
    this.daily = { ...g.daily, tasks: [] };
    this.rating = 0; this.rumors = []; this.charMet = new Set();
    this.battlesWon = 0; this.questUid = 1;
    this.rollDaily();
  }

  modeDef() { return MODE_BY_ID[this.mode]; }
  upg(id: string): number { return this.starUpgrades[id] ?? 0; }
  /** Множители от звёздных апгрейдов */
  mGather(): number { return 1 + this.upg("su_gather") * 0.25; }
  mGold(): number { return 1 + this.upg("su_gold") * 0.2; }
  mSci(): number { return 1 + this.upg("su_sci") * 0.25; }
  mArmy(): number { return 1 + this.upg("su_army") * 0.15; }
  mXp(): number { return (1 + this.upg("su_xp") * 0.2) * this.modeDef().xpMul; }
  bonusHp(): number { return this.upg("su_hp") * 20; }
  bonusMana(): number { return this.upg("su_mana") * 40; }
  startGold(): number { return this.modeDef().startGold + this.upg("su_start") * 2000 + this.prestige * 500; }

  // ---------- Дневник ----------
  log(e: Engine, text: string, kind: JournalEntry["kind"] = "world") {
    this.journal.unshift({ day: e.day, text, kind });
    if (this.journal.length > 120) this.journal.pop();
  }

  // ---------- Квесты ----------
  activeQuests(): Quest[] { return this.quests.filter((q) => q.state === "active"); }
  storyQuest(): Quest | undefined { return this.quests.find((q) => q.state === "active" && q.act !== undefined); }

  private makeQuest(def: typeof STORY_QUESTS[number], e: Engine): Quest {
    return {
      uid: this.questUid++, id: def.id, title: def.title, text: def.text, giver: def.giver,
      goals: def.goals.map((g) => ({ ...g, have: 0 })),
      reward: { gold: def.reward.gold, xp: def.reward.xp, items: def.reward.items ?? [], stars: def.reward.stars, fame: def.reward.fame },
      state: "active", act: def.act, day: e.day, chain: def.next,
    };
  }

  startStory(e: Engine) {
    if (this.quests.some((q) => q.act !== undefined && q.state === "active")) return;
    const next = STORY_QUESTS.find((d) => !this.questsDone.has(d.id));
    if (!next) return;
    const q = this.makeQuest(next, e);
    this.quests.push(q);
    const ch = CHAR_BY_ID[next.giver];
    if (ch && !this.charMet.has(ch.id)) {
      this.charMet.add(ch.id);
      this.log(e, `Встреча: ${ch.name}, ${ch.title.toLowerCase()}`, "story");
    }
    this.log(e, `Новая глава: «${q.title}»`, "story");
    e.toast(`${ch?.name ?? "Некто"}: «${q.title}»`, "info");
    snd.uiOpen();
    e.poke();
  }

  /** Процедурный побочный квест */
  private makeSide(e: Engine) {
    if (this.quests.filter((q) => q.state === "active" && q.act === undefined).length >= 4) return;
    const rng = mulberry32((e.seed ^ (this.questUid * 7919) ^ e.day * 131) >>> 0);
    const tpl = SIDE_TEMPLATES[Math.floor(rng() * SIDE_TEMPLATES.length)];
    let target = tpl.targets[Math.floor(rng() * tpl.targets.length)];
    if (tpl.kind === "build" && !e.city.s.founded) target = "koster";
    const need = Math.max(1, Math.round(tpl.min + rng() * (tpl.max - tpl.min)));
    const name = tpl.kind === "kill" ? "тварей"
      : tpl.kind === "build" ? (BUILDINGS[target]?.name ?? target)
        : (ITEMS[target]?.name ?? target);
    const npc = e.npcs.npcs.length ? e.npcs.npcs[Math.floor(rng() * e.npcs.npcs.length)] : null;
    const gold = Math.round(need * tpl.goldPer * (1 + e.lore.eraIndex() * 0.25));
    const q: Quest = {
      uid: this.questUid++, id: `side_${this.questUid}`,
      title: tpl.titles[Math.floor(rng() * tpl.titles.length)],
      text: tpl.texts[Math.floor(rng() * tpl.texts.length)],
      giver: npc?.name ?? "Житель",
      goals: [{
        kind: tpl.kind, target, need, have: 0,
        label: tpl.kind === "kill" ? `Одолеть ${name}` : tpl.kind === "build" ? `Построить: ${name}` : `${tpl.kind === "craft" ? "Смастерить" : "Собрать"}: ${name}`,
      }],
      reward: { gold, xp: Math.round(need * tpl.xpPer), items: [] },
      state: "active", day: e.day, deadline: e.day + 8,
    };
    this.quests.push(q);
    e.toast(`Новое поручение: «${q.title}»`, "info");
    e.poke();
  }

  /** Отметить прогресс цели */
  progress(e: Engine, kind: QuestGoal["kind"], target: string, n = 1) {
    let changed = false;
    for (const q of this.quests) {
      if (q.state !== "active") continue;
      for (const g of q.goals) {
        if (g.have >= g.need) continue;
        if (g.kind !== kind) continue;
        if (g.target !== target && g.target !== "any") continue;
        g.have = Math.min(g.need, g.have + n);
        changed = true;
      }
      if (q.goals.every((g) => g.have >= g.need)) this.complete(e, q);
    }
    // задания дня
    for (const t of this.daily.tasks) {
      if (t.done) continue;
      const match = (t.kind === "gather" && kind === "gather") || (t.kind === "kill" && kind === "kill")
        || (t.kind === "craft" && kind === "craft") || (t.kind === "build" && kind === "build");
      if (match) {
        t.have = Math.min(t.target, t.have + n);
        if (t.have >= t.target) { t.done = true; this.finishDaily(e, t); }
        changed = true;
      }
    }
    if (changed) e.poke();
  }

  /** Проверка целей-состояний (город, союз, слои и т.п.) */
  checkStateGoals(e: Engine) {
    const val = (target: string): number => {
      switch (target) {
        case "city": return e.city.s.founded ? 1 : 0;
        case "route": return (e.stats.route ?? 0);
        case "happy": return e.city.s.founded ? Math.round(e.city.s.happiness) : 0;
        case "army": return e.army.totalMen();
        case "ally": return e.nations.allies().length;
        case "spy": return e.stats.spy ?? 0;
        case "victory": return (e.stats.battleWin ?? 0) + (e.stats.royalMarriage ?? 0);
        case "tech": return e.lore.techs.size;
        case "tech_phalanx": return e.lore.has("t_phalanx") ? 1 : 0;
        case "mage": return e.lore.magic.school ? 1 : 0;
        case "religion": return e.lore.religion.founded ? 1 : 0;
        case "culture": return Math.floor(e.lore.culture.total);
        case "finale": return (e.player.level >= 25 || e.layers.unlocked.size >= 6) ? 1 : 0;
        case "layer1": return (e.layers.visits[1] ?? 0) > 0 ? 1 : 0;
        case "layer5": return (e.layers.visits[5] ?? 0) > 0 ? 1 : 0;
        case "layer_any": return Math.max(0, e.layers.unlocked.size - 2);
        case "boss": return e.layers.bossesKilled.size;
        default: return 0;
      }
    };
    for (const q of this.quests) {
      if (q.state !== "active") continue;
      let touched = false;
      for (const g of q.goals) {
        if (g.kind === "reach" || g.kind === "explore") {
          const v = val(g.target);
          if (v > g.have) { g.have = Math.min(g.need, v); touched = true; }
        }
        if (g.kind === "build" && g.have < g.need) {
          const built = g.target.startsWith("g_")
            ? (e.layers.hasGate(g.target) ? 1 : 0)
            : e.buildings.filter((b) => b.done && b.def === g.target).length;
          if (built > g.have) { g.have = Math.min(g.need, built); touched = true; }
        }
        if (g.kind === "gather" && g.have < g.need) {
          const have = e.count(g.target) + e.city.stockOf(g.target);
          if (have > g.have) { g.have = Math.min(g.need, have); touched = true; }
        }
        if (g.kind === "craft" && g.have < g.need) {
          const have = e.count(g.target);
          if (have > g.have) { g.have = Math.min(g.need, have); touched = true; }
        }
      }
      if (touched && q.goals.every((g) => g.have >= g.need)) this.complete(e, q);
    }
  }

  complete(e: Engine, q: Quest) {
    if (q.state !== "active") return;
    const def = QUEST_BY_ID[q.id];
    // если есть выбор — ждём решения игрока
    if (def?.choices && !q.choiceId) {
      q.state = "done";
      this.pendingChoice = q;
      e.onOpenPanel?.("choice");
      snd.uiOpen();
      e.poke();
      return;
    }
    this.finishQuest(e, q);
  }
  pendingChoice: Quest | null = null;

  makeChoice(e: Engine, q: Quest, choiceId: string) {
    const def = QUEST_BY_ID[q.id];
    const ch = def?.choices?.find((c) => c.id === choiceId);
    q.choiceId = choiceId;
    this.choices[q.id] = choiceId;
    if (ch) {
      this.log(e, `Выбор: ${ch.label}. ${ch.text}`, "choice");
      e.toast(ch.text, "info");
      this.applyChoice(e, ch.effect);
    }
    this.pendingChoice = null;
    this.finishQuest(e, q);
  }

  private applyChoice(e: Engine, effect: string) {
    switch (effect) {
      case "good": e.player.maxHp += 10; e.player.hp = e.player.maxHp; break;
      case "cold": e.player.gold += 250; break;
      case "people": if (e.city.s.founded) { e.city.setTax(Math.max(0, e.city.s.taxRate - 5)); e.city.s.happiness = clamp(e.city.s.happiness + 15, 0, 100); } e.dynasty.support("narod", 15); break;
      case "greed": e.player.gold += 1200; e.dynasty.support("kupcy", 10); e.dynasty.support("narod", -12); break;
      case "war": e.nations.fame += 25; e.dynasty.support("armiya", 18); e.dynasty.support("kupcy", -10); break;
      case "peace": e.dynasty.support("znat", 18); e.dynasty.support("armiya", -8); for (const n of e.nations.nations) n.rel = clamp(n.rel + 10, -100, 100); break;
      case "faith": e.dynasty.support("cerkov", 20); e.dynasty.support("magi", -15); if (e.lore.religion.founded) e.lore.religion.followers = clamp(e.lore.religion.followers + 15, 0, 100); break;
      case "dark": e.dynasty.support("magi", 20); e.dynasty.support("cerkov", -15); e.lore.magic.manaMax += 60; e.lore.grantArtifact(e); break;
      case "ascend": case "rule": case "quiet": {
        this.finaleEnding = effect;
        this.rating += 500;
        e.nations.fame += 100;
        this.log(e, effect === "ascend" ? "ВОЗНЕСЕНИЕ: вы стали пламенем" : effect === "rule" ? "ВЛАДЫЧЕСТВО: галактика склонилась" : "ПОКОЙ: вы вернулись к первому костру", "story");
        break;
      }
    }
  }
  finaleEnding: string | null = null;

  private finishQuest(e: Engine, q: Quest) {
    q.state = "done";
    this.questsDone.add(q.id);
    e.player.gold += q.reward.gold;
    e.addXp(q.reward.xp);
    for (const [id, n] of q.reward.items) e.give(id, n, true);
    if (q.reward.stars) this.addStars(e, q.reward.stars);
    if (q.reward.fame) e.nations.fame += q.reward.fame;
    this.rating += 10 + (q.act ? 40 : 0);
    this.log(e, `Выполнено: «${q.title}» (+${q.reward.gold} зол.)`, "quest");
    e.toast(`Задание выполнено: ${q.title} (+${q.reward.gold} зол.)`, "good");
    snd.levelup();
    this.progress(e, "talk", "quest_done", 1);
    for (const t of this.daily.tasks) {
      if (t.kind === "quest" && !t.done) { t.have++; if (t.have >= t.target) { t.done = true; this.finishDaily(e, t); } }
    }
    // следующая глава
    if (q.act !== undefined) {
      const def = QUEST_BY_ID[q.id];
      if (def?.next) {
        const nd = QUEST_BY_ID[def.next];
        if (nd) {
          if (nd.act && nd.act > this.act) {
            this.act = nd.act;
            const a = ACTS[this.act - 1];
            e.toast(`АКТ ${a.n}: ${a.name}. ${a.desc}`, "good");
            this.log(e, `Начался акт ${a.n}: ${a.name}`, "story");
            e.shake = 0.5;
            if (e.city.s.founded) e.city.s.paradeT = 6;
          }
          setTimeout(() => { this.startStory(e); }, 100);
        }
      } else {
        this.log(e, "Кампания завершена. Летопись окончена, но жизнь — нет.", "story");
        e.toast("Кампания пройдена! Мир остаётся вашим", "good");
      }
    }
    e.poke();
  }

  abandon(e: Engine, uid: number) {
    const q = this.quests.find((x) => x.uid === uid);
    if (!q || q.act !== undefined) { e.toast("Сюжетное задание нельзя бросить", "warn"); return; }
    q.state = "failed";
    e.toast(`Задание «${q.title}» брошено`, "info");
    e.poke();
  }

  // ---------- Звёзды и престиж ----------
  addStars(e: Engine, n: number) {
    this.stars += n;
    this.persist();
    e.toast(`+${n} ★ звёзд`, "good");
  }
  buyUpgrade(e: Engine, id: string) {
    const u = STAR_UPGRADES.find((x) => x.id === id);
    if (!u) return;
    const lvl = this.upg(id);
    if (lvl >= u.max) { e.toast("Улучшение на пределе", "info"); return; }
    const cost = u.cost * (lvl + 1);
    if (this.stars < cost) { e.toast(`Нужно ${cost} ★`, "warn"); return; }
    this.stars -= cost;
    this.starUpgrades[id] = lvl + 1;
    if (id === "su_hp") { e.player.maxHp += 20; e.player.hp += 20; }
    if (id === "su_mana") e.lore.magic.manaMax += 40;
    this.persist();
    e.toast(`${u.name} — уровень ${lvl + 1}`, "good");
    snd.levelup();
    e.poke();
  }
  prestigeGain(e: Engine): number {
    const score = e.player.level * 2 + Math.floor(e.lore.sciTotal / 800) + Math.floor(e.lore.culture.total / 900)
      + e.layers.unlocked.size * 2 + e.layers.bossesKilled.size * 3 + this.questsDone.size
      + (e.city.s.founded ? Math.floor(e.city.s.pop / 25) : 0);
    return Math.max(0, Math.floor(score * this.modeDef().ratingMul));
  }
  canPrestige(e: Engine): boolean { return this.prestigeGain(e) >= 15; }
  doPrestige(e: Engine) {
    if (!this.canPrestige(e)) { e.toast("Слишком рано: наберите больше величия (нужно 15 ★)", "warn"); return; }
    const gain = this.prestigeGain(e);
    this.stars += gain;
    this.prestige += 1;
    this.persist();
    e.toast(`ПЕРЕРОЖДЕНИЕ! Получено ${gain} ★. Мир начинается заново`, "good");
    snd.levelup();
    const seed = (Math.random() * 1e9) | 0;
    e.newGame(seed, e.slot, e.worldName);
    e.meta.mode = this.mode;
    e.poke();
  }
  private persist() {
    const g = loadGlobal();
    g.stars = this.stars;
    g.starUpgrades = { ...this.starUpgrades };
    g.prestige = this.prestige;
    g.achievements = [...this.achievements];
    g.collection = [...this.collection];
    g.bestRating = Math.max(g.bestRating, Math.round(this.rating));
    g.daily = { lastDay: this.daily.lastDay, streak: this.daily.streak, claimed: this.daily.claimed };
    saveGlobal(g);
  }

  // ---------- Достижения ----------
  private ctx(e: Engine): AchCtx {
    return {
      day: e.day, level: e.player.level, gold: e.player.gold,
      cityPop: Math.floor(e.city.s.pop), cityFounded: e.city.s.founded,
      techs: e.lore.techs.size, era: e.lore.eraIndex(),
      mage: !!e.lore.magic.school, spells: e.lore.magic.spells.length,
      artifacts: e.lore.magic.artifacts.length, beasts: e.lore.magic.beasts.length,
      religion: e.lore.religion.founded, followers: e.lore.religion.followers,
      culture: Math.floor(e.lore.culture.total), greats: e.lore.culture.greats.length,
      armyMen: e.army.totalMen(), battlesWon: this.battlesWon,
      nationsVassal: e.nations.vassals().length, nationsAlly: e.nations.allies().length,
      layers: e.layers.unlocked.size, bosses: e.layers.bossesKilled.size,
      spaceBuilds: e.layers.spaceBuilds.size,
      questsDone: this.questsDone.size, collection: this.collection.size, prestige: this.prestige,
      killed: e.stats.killed ?? 0, crafted: e.stats.crafted ?? 0, built: e.stats.built ?? 0,
      dragonDead: e.dragonDead,
      wondersBuilt: e.buildings.filter((b) => b.done && BUILDINGS[b.def]?.wonder).length,
    };
  }
  checkAchievements(e: Engine) {
    const c = this.ctx(e);
    let got = 0;
    for (const a of ACHIEVEMENTS) {
      if (this.achievements.has(a.id)) continue;
      if (a.check(c)) {
        this.achievements.add(a.id);
        this.stars += a.stars;
        this.rating += a.stars * 5;
        got++;
        e.toast(`Достижение: ${a.name} (+${a.stars} ★)`, "good");
        this.log(e, `Достижение: ${a.name}`, "discovery");
      }
    }
    if (got) { snd.levelup(); this.persist(); e.poke(); }
  }

  // ---------- Коллекция ----------
  collect(e: Engine, key: string) {
    const id = COLLECT_MAP[key];
    if (!id || this.collection.has(id)) return;
    this.collection.add(id);
    const entry = COLLECTION.find((c) => c.id === id);
    this.rating += 4;
    this.persist();
    if (entry) {
      e.toast(`В коллекцию: ${entry.name}`, "good");
      this.log(e, `Открыто в коллекции: ${entry.name}`, "discovery");
    }
  }

  // ---------- Ежедневные ----------
  rollDaily() {
    const key = todayKey();
    if (this.daily.lastDay === key && this.daily.tasks.length) return;
    const yest = new Date(Date.now() - 864e5);
    const yKey = `${yest.getFullYear()}-${yest.getMonth() + 1}-${yest.getDate()}`;
    if (this.daily.lastDay === yKey) this.daily.streak += 1;
    else if (this.daily.lastDay !== key) this.daily.streak = 1;
    this.daily.lastDay = key;
    this.daily.claimed = false;
    const rng = mulberry32(key.split("-").reduce((a, b) => a * 31 + Number(b), 7));
    const pool = [...DAILY_POOL];
    this.daily.tasks = [];
    const count = 3 + Math.floor(rng() * 2);
    for (let i = 0; i < count && pool.length; i++) {
      const t = pool.splice(Math.floor(rng() * pool.length), 1)[0];
      const target = Math.round(t.min + rng() * (t.max - t.min));
      this.daily.tasks.push({ id: t.id, text: t.text, target, have: 0, reward: t.reward, kind: t.kind, done: false });
    }
    this.persist();
  }
  private finishDaily(e: Engine, t: DailyTask) {
    this.stars += t.reward;
    this.rating += t.reward * 3;
    this.persist();
    e.toast(`Задание дня выполнено: ${t.text} (+${t.reward} ★)`, "good");
    snd.craft();
  }
  claimDaily(e: Engine) {
    if (this.daily.claimed) { e.toast("Награда за сегодня уже получена", "info"); return; }
    this.daily.claimed = true;
    const streak = Math.max(1, this.daily.streak);
    const gold = 300 + streak * 150;
    const stars = 2 + Math.floor(streak / 3);
    e.player.gold += gold;
    this.stars += stars;
    this.rating += 10;
    // редкая награда на длинной серии
    if (streak >= 5 && Math.random() < 0.5) e.lore.grantArtifact(e);
    if (streak % 7 === 0) { e.give("cheshuya", 2, true); e.toast("Недельный сундук: чешуя дракона!", "good"); }
    this.persist();
    e.toast(`Ежедневная награда: +${gold} зол., +${stars} ★ (серия ${streak} дн.)`, "good");
    snd.levelup();
    e.poke();
  }

  // ---------- Рейтинг ----------
  computeRating(e: Engine): number {
    const base = e.player.level * 10
      + Math.floor(e.player.gold / 100)
      + (e.city.s.founded ? Math.floor(e.city.s.pop) * 3 : 0)
      + e.lore.techs.size * 12
      + Math.floor(e.lore.culture.total / 60)
      + e.layers.unlocked.size * 25
      + e.layers.bossesKilled.size * 60
      + this.questsDone.size * 15
      + this.collection.size * 8
      + this.achievements.size * 10
      + this.prestige * 400
      + e.nations.fame * 3;
    return Math.round(base * this.modeDef().ratingMul);
  }
  bestRating(): number { return loadGlobal().bestRating; }
  /** Таблица рейтинга: игрок среди вымышленных соперников */
  leaderboard(e: Engine): { name: string; score: number; you: boolean }[] {
    const my = this.computeRating(e);
    const rng = mulberry32(0xf00d);
    const names = ["Владыка Зорь", "Сестра Тумана", "Кузнец Миров", "Тихий Странник", "Огненный Князь",
      "Хозяйка Троп", "Звездочёт Ро", "Пепельный Гость", "Дева Пламени", "Последний Зодчий"];
    const rows = names.map((n, i) => ({
      name: n,
      score: Math.round((300 + rng() * 9000) * (1 + i * 0.22)),
      you: false,
    }));
    rows.push({ name: "Вы", score: my, you: true });
    return rows.sort((a, b) => b.score - a.score).slice(0, 11);
  }

  // ---------- Тик ----------
  update(e: Engine, dt: number) {
    // побочные квесты
    this.sideT -= dt;
    if (this.sideT <= 0) {
      this.sideT = 70 + Math.random() * 90;
      if (e.city.s.founded || e.day > 2) this.makeSide(e);
    }
    // слухи
    this.rumorT -= dt;
    if (this.rumorT <= 0) {
      this.rumorT = 110 + Math.random() * 140;
      const r = RUMORS[Math.floor(Math.random() * RUMORS.length)];
      this.rumors.unshift(r);
      if (this.rumors.length > 12) this.rumors.pop();
      e.toast(`Слух: ${r}`, "info");
      e.poke();
    }
    // состояния целей и достижения
    this.achT -= dt;
    if (this.achT <= 0) {
      this.achT = 2.5;
      this.checkStateGoals(e);
      this.checkAchievements(e);
      this.rating = this.computeRating(e);
      // сюжет не должен простаивать
      if (!this.quests.some((q) => q.act !== undefined && q.state === "active") && !this.pendingChoice) this.startStory(e);
    }
    // пройденный путь для заданий дня
    if (e.player.moving) {
      this.walkAcc += dt;
      if (this.walkAcc > 1) {
        this.walkAcc = 0;
        for (const t of this.daily.tasks) {
          if (t.kind === "walk" && !t.done) { t.have++; if (t.have >= t.target) { t.done = true; this.finishDaily(e, t); } }
        }
      }
    }
    void this.lastGather;
  }

  dayTick(e: Engine) {
    this.rollDaily();
    // просроченные квесты
    for (const q of this.quests) {
      if (q.state === "active" && q.deadline && e.day > q.deadline) {
        q.state = "failed";
        e.toast(`Срок вышел: «${q.title}»`, "warn");
      }
    }
    this.quests = this.quests.filter((q) => q.state !== "failed" || e.day - q.day < 12);
    this.persist();
    // уведомление браузера о важном
    if (this.notifications && e.nations.nations.some((n) => n.incoming)) {
      this.notify("Тихое Пламя", "Вражеское войско у ваших границ!");
    }
  }

  notify(title: string, body: string) {
    try {
      if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
      new Notification(title, { body, silent: true });
    } catch { /* пусто */ }
  }
  async askNotifications(e: Engine) {
    try {
      if (typeof Notification === "undefined") { e.toast("Уведомления недоступны", "warn"); return; }
      const p = await Notification.requestPermission();
      this.notifications = p === "granted";
      e.toast(this.notifications ? "Уведомления включены" : "Уведомления отклонены", this.notifications ? "good" : "info");
      e.poke();
    } catch { /* пусто */ }
  }

  // ---------- Сохранение ----------
  serialize(): MetaSave {
    return {
      mode: this.mode,
      quests: this.quests.map((q) => ({ ...q, goals: q.goals.map((g) => ({ ...g })) })),
      questsDone: [...this.questsDone],
      act: this.act, choices: { ...this.choices },
      journal: this.journal.map((j) => ({ ...j })),
      achievements: [...this.achievements], collection: [...this.collection],
      stars: this.stars, starUpgrades: { ...this.starUpgrades },
      prestige: this.prestige, prestigePoints: 0,
      daily: { ...this.daily, tasks: this.daily.tasks.map((t) => ({ ...t })) },
      rating: this.rating, questUid: this.questUid,
      rumors: [...this.rumors], notifications: this.notifications,
      charMet: [...this.charMet], battlesWon: this.battlesWon,
    };
  }
  load(s: MetaSave) {
    if (!s) return;
    const g = loadGlobal();
    this.mode = s.mode ?? "normal";
    this.quests = (s.quests ?? []).map((q) => ({ ...q, goals: (q.goals ?? []).map((x) => ({ ...x })) }));
    this.questsDone = new Set(s.questsDone ?? []);
    this.act = s.act ?? 1;
    this.choices = { ...(s.choices ?? {}) };
    this.journal = (s.journal ?? []).map((j) => ({ ...j }));
    this.achievements = new Set([...(s.achievements ?? []), ...g.achievements]);
    this.collection = new Set([...(s.collection ?? []), ...g.collection]);
    this.stars = Math.max(s.stars ?? 0, g.stars);
    this.starUpgrades = { ...g.starUpgrades, ...(s.starUpgrades ?? {}) };
    this.prestige = Math.max(s.prestige ?? 0, g.prestige);
    this.daily = s.daily ? { ...s.daily, tasks: (s.daily.tasks ?? []).map((t) => ({ ...t })) } : { lastDay: "", streak: 0, claimed: false, tasks: [] };
    this.rating = s.rating ?? 0;
    this.questUid = Math.max(1, s.questUid ?? 1);
    this.rumors = [...(s.rumors ?? [])];
    this.notifications = !!s.notifications;
    this.charMet = new Set(s.charMet ?? []);
    this.battlesWon = s.battlesWon ?? 0;
    this.rollDaily();
  }
}

export { loadGlobal as loadGlobalMeta };
