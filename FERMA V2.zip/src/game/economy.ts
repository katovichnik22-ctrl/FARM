import type { Engine } from "./engine";
import type { BankState, GoodMarket, NeighborTown, TradeRoute, RouteKind } from "../types";
import { GOODS, TOWN_NAMES } from "../data/citydata";
import { ITEMS } from "../data/items";
import { clamp, lerp, mulberry32, hash2 } from "../lib/noise";
import { snd } from "../lib/sound";

const ROUTE_SPEED: Record<RouteKind, number> = { caravan: 1, ship: 1.45, train: 1.9 };
const ROUTE_CAP: Record<RouteKind, number> = { caravan: 40, ship: 90, train: 160 };
export const ROUTE_NAMES: Record<RouteKind, string> = { caravan: "Караван", ship: "Корабль", train: "Обоз-экспресс" };

export function freshBank(): BankState {
  return { deposit: 0, depRate: 3.5, loans: [], loanRate: 9, invested: 0, investDay: 0, credit: 60 };
}

export class EconomySim {
  market: Record<string, GoodMarket> = {};
  bank: BankState = freshBank();
  routes: TradeRoute[] = [];
  foreign: TradeRoute[] = [];
  towns: NeighborTown[] = [];
  private uid = 1;
  private t = 0;
  private foreignT = 25;

  init(seed: number) {
    const r = mulberry32(seed ^ 0x7ead);
    this.market = {};
    for (const g of GOODS) {
      const p = g.base * (0.85 + r() * 0.3);
      this.market[g.id] = { price: p, trend: 0, stock: 60 + r() * 80, demand: 60 + r() * 80, hist: [p] };
    }
    this.bank = freshBank();
    this.routes = []; this.foreign = [];
    this.towns = [];
    const used = new Set<number>();
    for (let i = 0; i < 5; i++) {
      let idx = Math.floor(r() * TOWN_NAMES.length);
      while (used.has(idx)) idx = (idx + 1) % TOWN_NAMES.length;
      used.add(idx);
      const gs = GOODS[Math.floor(r() * GOODS.length)];
      const gw = GOODS[Math.floor(r() * GOODS.length)];
      this.towns.push({
        id: `t${i}`, name: TOWN_NAMES[idx],
        dist: 40 + Math.floor(r() * 150),
        ang: r() * Math.PI * 2,
        wants: gw.id, gives: gs.id,
        relation: 45 + Math.floor(r() * 30), embargo: false,
      });
    }
  }

  price(id: string): number { return this.market[id]?.price ?? ITEMS[id] ? (this.market[id]?.price ?? 10) : 10; }
  priceOf(id: string): number { return this.market[id]?.price ?? 10; }

  // ---------- Биржа ----------
  buy(e: Engine, id: string, n: number) {
    const m = this.market[id];
    if (!m) return;
    const total = Math.ceil(m.price * n * 1.04); // комиссия рынка
    if (e.player.gold < total) { e.toast(`Нужно ${total} золота`, "warn"); return; }
    e.player.gold -= total;
    e.give(id, n, true);
    m.stock = Math.max(6, m.stock - n);
    m.demand += n * 0.55;
    m.price = clamp(m.price * (1 + n / Math.max(24, m.stock)), this.base(id) * 0.3, this.base(id) * 3.6);
    e.toast(`Куплено: ${ITEMS[id]?.name ?? id} ×${n} за ${total} зол.`, "good");
    snd.craft();
    e.dynasty.support("kupcy", 0.6);
    e.poke();
  }
  sell(e: Engine, id: string, n: number, fromCity = false) {
    const m = this.market[id];
    if (!m) return;
    const have = fromCity ? e.city.stockOf(id) : e.count(id);
    const cnt = Math.min(have, n);
    if (cnt <= 0) { e.toast("Товара нет", "warn"); return; }
    if (fromCity) e.city.takeStock(id, cnt); else e.take(id, cnt);
    const comBonus = e.city.s.founded ? 1 + e.city.s.districts.com * 0.05 : 1;
    const total = Math.floor(m.price * cnt * 0.96 * comBonus);
    e.player.gold += total;
    m.stock += cnt;
    m.demand = Math.max(10, m.demand - cnt * 0.4);
    m.price = clamp(m.price * (1 - cnt / Math.max(40, m.stock + cnt)), this.base(id) * 0.3, this.base(id) * 3.6);
    e.toast(`Продано: ${ITEMS[id]?.name ?? id} ×${cnt} за ${total} зол.`, "good");
    snd.pickup();
    e.dynasty.support("kupcy", 0.8);
    e.poke();
  }
  base(id: string): number { return GOODS.find((g) => g.id === id)?.base ?? 10; }

  // ---------- Банк ----------
  deposit(e: Engine, n: number) {
    const amt = Math.min(n, e.player.gold);
    if (amt <= 0) return;
    e.player.gold -= amt; this.bank.deposit += amt;
    e.toast(`Вклад пополнен на ${amt} зол. (${this.bank.depRate.toFixed(1)}% в день)`, "good");
    snd.pickup(); e.poke();
  }
  withdraw(e: Engine, n: number) {
    const amt = Math.min(n, Math.floor(this.bank.deposit));
    if (amt <= 0) { e.toast("Вклад пуст", "warn"); return; }
    this.bank.deposit -= amt; e.player.gold += amt;
    e.toast(`Снято со вклада: ${amt} зол.`, "good");
    snd.pickup(); e.poke();
  }
  maxLoan(e: Engine): number {
    const popBase = e.city.s.founded ? e.city.s.pop * 22 : 150;
    const debt = this.bank.loans.reduce((a, l) => a + l.left, 0);
    return Math.max(0, Math.floor(popBase * (this.bank.credit / 60) - debt));
  }
  takeLoan(e: Engine, n: number) {
    const max = this.maxLoan(e);
    const amt = Math.min(n, max);
    if (amt <= 20) { e.toast("Банк отказал: слишком низкий кредит доверия", "warn"); return; }
    this.bank.loans.push({ id: this.uid++, amount: amt, rate: this.bank.loanRate, left: Math.ceil(amt * 1.18), dueDay: e.day + 8 });
    e.player.gold += amt;
    e.toast(`Ссуда ${amt} зол. Вернуть ${Math.ceil(amt * 1.18)} до дня ${e.day + 8}`, "info");
    snd.craft(); e.poke();
  }
  repay(e: Engine, loanId: number) {
    const l = this.bank.loans.find((x) => x.id === loanId);
    if (!l) return;
    const pay = Math.min(e.player.gold, l.left);
    if (pay <= 0) { e.toast("Нет золота", "warn"); return; }
    e.player.gold -= pay; l.left -= pay;
    if (l.left <= 0) {
      this.bank.loans = this.bank.loans.filter((x) => x.id !== loanId);
      this.bank.credit = clamp(this.bank.credit + 8, 0, 100);
      e.toast("Долг закрыт. Кредит доверия вырос", "good");
    } else e.toast(`Внесено ${pay}. Осталось ${l.left}`, "info");
    snd.pickup(); e.poke();
  }
  invest(e: Engine, n: number) {
    const amt = Math.min(n, e.player.gold);
    if (amt < 50) { e.toast("Минимальные вложения — 50 золота", "warn"); return; }
    e.player.gold -= amt;
    this.bank.invested += amt;
    this.bank.investDay = e.day + 5;
    e.toast(`Вложено ${amt} зол. Итог через 5 дней — как повезёт`, "info");
    snd.craft(); e.poke();
  }

  // ---------- Торговые пути ----------
  routeDur(t: NeighborTown, kind: RouteKind, e: Engine): number {
    let d = (t.dist / ROUTE_SPEED[kind]) * 0.9;
    if (e.city.hasWonder("w_most")) d *= 0.67;
    if (e.city.hasWonder("w_mayak") && kind === "ship") d *= 0.7;
    return Math.max(20, d);
  }
  startRoute(e: Engine, townId: string, good: string, n: number, kind: RouteKind, fromCity: boolean) {
    const t = this.towns.find((x) => x.id === townId);
    if (!t) return;
    if (t.embargo) { e.toast(`${t.name}: эмбарго, торговля закрыта`, "bad"); return; }
    const cap = ROUTE_CAP[kind];
    const want = Math.min(n, cap);
    const have = fromCity ? e.city.stockOf(good) : e.count(good);
    if (have < want) { e.toast(`Не хватает товара (${have}/${want})`, "warn"); return; }
    if (fromCity) e.city.takeStock(good, want); else e.take(good, want);
    const bonus = t.wants === good ? 1.75 : 1.12;
    const mayak = e.city.hasWonder("w_mayak") ? 1.3 : 1;
    const profit = Math.floor(this.priceOf(good) * want * bonus * (1 + t.relation / 260) * mayak);
    const order = e.city.s.founded ? e.city.s.metrics.order : 0;
    const risk = clamp(0.3 - order / 420 + (kind === "ship" ? 0.06 : 0) - (e.city.hasWonder("w_mayak") ? 0.1 : 0), 0.03, 0.42);
    const dur = this.routeDur(t, kind, e);
    this.routes.push({
      id: this.uid++, kind, town: t.id, good, n: want,
      progress: 0, dur, profit, risk, state: "go",
      x: 0, y: 0, ang: t.ang,
    });
    e.stats.route = (e.stats.route ?? 0) + 1;
    e.toast(`${ROUTE_NAMES[kind]} вышел в ${t.name}. Ожидаемая выручка ${profit} зол.`, "good");
    snd.place();
    e.dynasty.support("kupcy", 2);
    e.poke();
  }

  private finishRoute(e: Engine, r: TradeRoute) {
    const t = this.towns.find((x) => x.id === r.town);
    if (!t) return;
    e.player.gold += r.profit;
    t.relation = clamp(t.relation + 4, 0, 100);
    e.toast(`${ROUTE_NAMES[r.kind]} вернулся из ${t.name}: +${r.profit} золота`, "good");
    snd.levelup();
    e.addXp(6);
    if (e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness + 1.5, 0, 100);
    e.dynasty.support("kupcy", 3);
  }

  /** Грабёж чужого каравана */
  raid(e: Engine, r: TradeRoute) {
    const t = this.towns.find((x) => x.id === r.town);
    const loot = Math.floor(r.profit * 0.6);
    e.player.gold += loot;
    e.give(r.good, Math.max(1, Math.floor(r.n * 0.5)), true);
    this.foreign = this.foreign.filter((x) => x.id !== r.id);
    if (t) {
      t.relation = clamp(t.relation - 32, 0, 100);
      if (t.relation < 18) { t.embargo = true; e.toast(`${t.name} объявил вам эмбарго!`, "bad"); }
      else e.toast(`Караван ${t.name} ограблен: +${loot} золота. Отношения испорчены`, "warn");
    }
    if (e.city.s.founded) e.city.s.metrics.crime += 6;
    e.dynasty.support("kupcy", -8);
    e.dynasty.support("narod", 3);
    e.spawnHitParticles(r.x, r.y, "#f2c14e", 18, "star");
    e.shake = 0.4;
    snd.chest();
    e.addXp(14);
    e.poke();
  }

  // ---------- Тик ----------
  update(e: Engine, dt: number) {
    this.t += dt;
    // цены
    if (this.t > 0.8) {
      const step = this.t; this.t = 0;
      for (const g of GOODS) {
        const m = this.market[g.id];
        const ratio = clamp(m.demand / Math.max(8, m.stock), 0.35, 3.2);
        const fair = g.base * ratio;
        const prev = m.price;
        m.price = clamp(lerp(m.price, fair, step * 0.12) * (1 + (Math.random() - 0.5) * 0.012), g.base * 0.3, g.base * 3.6);
        m.trend = m.price - prev;
        m.stock = lerp(m.stock, 100, step * 0.02);
        m.demand = lerp(m.demand, 100 + (e.city.s.founded ? e.city.s.pop * 0.35 : 0), step * 0.02);
      }
    }
    // свои пути
    for (const r of [...this.routes]) {
      r.progress += dt;
      const half = r.dur / 2;
      const t = this.towns.find((x) => x.id === r.town);
      const frac = clamp(r.progress / r.dur, 0, 1);
      const away = frac < 0.5 ? frac * 2 : (1 - frac) * 2;
      const dist = (t ? Math.min(t.dist, 26) : 20) * away;
      const cx = e.city.s.founded ? e.city.s.cx : Math.floor(e.player.x / 40);
      const cy = e.city.s.founded ? e.city.s.cy : Math.floor(e.player.y / 40);
      r.x = (cx + Math.cos(r.ang) * dist) * 40;
      r.y = (cy + Math.sin(r.ang) * dist) * 40;
      if (r.state === "go" && r.progress >= half) {
        r.state = Math.random() < r.risk ? "raided" : "back";
        if (r.state === "raided") {
          e.toast(`${ROUTE_NAMES[r.kind]} разграблен разбойниками у ${t?.name ?? "дороги"}!`, "bad");
          snd.monster();
          this.routes = this.routes.filter((x) => x.id !== r.id);
          if (e.city.s.founded) e.city.s.metrics.crime += 4;
          continue;
        }
      }
      if (r.progress >= r.dur) {
        this.finishRoute(e, r);
        this.routes = this.routes.filter((x) => x.id !== r.id);
      }
    }
    // чужие караваны (их можно грабить)
    this.foreignT -= dt;
    if (this.foreignT <= 0 && this.foreign.length < 2 && this.towns.length) {
      this.foreignT = 70 + Math.random() * 80;
      const t = this.towns[Math.floor(Math.random() * this.towns.length)];
      const g = GOODS[Math.floor(Math.random() * GOODS.length)];
      const n = 4 + Math.floor(Math.random() * 12);
      const ang = Math.random() * Math.PI * 2;
      const cx = Math.floor(e.player.x / 40), cy = Math.floor(e.player.y / 40);
      this.foreign.push({
        id: this.uid++, kind: Math.random() < 0.8 ? "caravan" : "train", town: t.id,
        good: g.id, n, progress: 0, dur: 120, profit: Math.floor(this.priceOf(g.id) * n),
        risk: 0, state: "go", x: (cx + Math.cos(ang) * 18) * 40, y: (cy + Math.sin(ang) * 18) * 40, ang: ang + Math.PI,
      });
    }
    for (const r of [...this.foreign]) {
      r.progress += dt;
      r.x += Math.cos(r.ang) * 26 * dt;
      r.y += Math.sin(r.ang) * 26 * dt;
      if (r.progress > r.dur || e.distTo(r.x, r.y) > 46) this.foreign = this.foreign.filter((x) => x.id !== r.id);
    }
  }

  dayTick(e: Engine) {
    // вклад и проценты
    if (this.bank.deposit > 0) {
      const gain = Math.floor(this.bank.deposit * (this.bank.depRate / 100));
      this.bank.deposit += gain;
      if (gain > 0) e.toast(`Банк начислил ${gain} зол. по вкладу`, "good");
    }
    // долги
    for (const l of [...this.bank.loans]) {
      if (e.day > l.dueDay) {
        const pay = Math.min(e.player.gold, Math.ceil(l.left * 0.25));
        e.player.gold -= pay; l.left -= pay;
        this.bank.credit = clamp(this.bank.credit - 6, 0, 100);
        if (l.left <= 0) {
          this.bank.loans = this.bank.loans.filter((x) => x.id !== l.id);
          e.toast("Долг взыскан банком", "warn");
        } else e.toast(`Просрочка! Банк взял ${pay} зол. Кредит доверия падает`, "bad");
      }
    }
    // инвестиции
    if (this.bank.invested > 0 && e.day >= this.bank.investDay) {
      const luck = 0.65 + Math.random() * 1.15 + (e.city.s.founded ? e.city.s.districts.com * 0.06 : 0);
      const back = Math.floor(this.bank.invested * luck);
      e.player.gold += back;
      const diff = back - this.bank.invested;
      e.toast(diff >= 0 ? `Вложения принесли +${diff} золота!` : `Вложения прогорели: ${diff} золота`, diff >= 0 ? "good" : "bad");
      this.bank.invested = 0;
    }
    // отношения соседей
    for (const t of this.towns) {
      t.relation = clamp(t.relation + (t.embargo ? 0.5 : 1.2), 0, 100);
      if (t.embargo && t.relation > 45) { t.embargo = false; e.toast(`${t.name} снял эмбарго`, "good"); }
    }
    // история цен
    for (const g of GOODS) {
      const m = this.market[g.id];
      m.hist.push(m.price);
      if (m.hist.length > 24) m.hist.shift();
    }
  }

  /** Случайное событие рынка (вызывается движком раз в несколько дней) */
  marketEvent(e: Engine, seedN: number) {
    const g = GOODS[Math.floor(hash2(seedN, e.day, 7) * GOODS.length)];
    const m = this.market[g.id];
    if (!m) return;
    if (hash2(seedN, e.day, 11) < 0.5) {
      m.demand *= 1.9; m.stock *= 0.65;
      e.toast(`Спрос взлетел: ${g.name} нарасхват!`, "info");
    } else {
      m.stock *= 1.9; m.demand *= 0.7;
      e.toast(`Рынок завален: ${g.name} дешевеет`, "info");
    }
  }
}
