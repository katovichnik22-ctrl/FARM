import type { Engine } from "./engine";
import type { Squad, General, GenTrait, UnitKind } from "../types/war";
import { GEN_TRAITS } from "../types/war";
import { UNITS, GEN_NAMES_M, GEN_NAMES_F, GEN_TITLES, GEN_BIOS, SQUAD_EPITHETS } from "../data/army";
import { ITEMS } from "../data/items";
import { clamp } from "../lib/noise";
import { snd } from "../lib/sound";

const MAX_SQUADS = 12;

export class ArmySim {
  squads: Squad[] = [];
  generals: General[] = [];
  hospital: { kind: UnitKind; n: number; t: number }[] = [];
  squadUid = 1;
  genUid = 1;
  private upkeepT = 60;
  desertT = 0;

  reset() {
    this.squads = []; this.generals = []; this.hospital = [];
    this.squadUid = 1; this.genUid = 1; this.upkeepT = 60;
  }

  // ---------- Сила ----------
  power(): number {
    let p = 0;
    for (const s of this.squads) {
      const d = UNITS[s.kind];
      const g = this.genOf(s.general);
      const gb = g ? 1 + g.atkBonus * 0.5 + g.defBonus * 0.3 : 1;
      p += (d.atk + d.def) * 0.5 * s.n * (1 + (s.lvl - 1) * 0.16) * (s.morale / 100) * gb;
    }
    return Math.round(p);
  }
  totalMen(): number { return this.squads.reduce((a, s) => a + s.n, 0); }
  upkeepGold(): number {
    let g = this.squads.reduce((a, s) => a + UNITS[s.kind].upkeepGold * s.n, 0);
    g += this.generals.filter((x) => x.alive).reduce((a, x) => a + x.wage, 0);
    return Math.round(g * 10) / 10;
  }
  upkeepFood(): number {
    return Math.round(this.squads.reduce((a, s) => a + UNITS[s.kind].upkeepFood * s.n, 0) * 10) / 10;
  }
  genOf(uid: number): General | undefined { return this.generals.find((g) => g.uid === uid && g.alive); }
  freeGenerals(): General[] {
    const busy = new Set(this.squads.map((s) => s.general));
    return this.generals.filter((g) => g.alive && !busy.has(g.uid));
  }

  // ---------- Найм ----------
  canRecruit(e: Engine, kind: UnitKind, n: number): { ok: boolean; reason: string } {
    const d = UNITS[kind];
    if (e.lore.unitLocked(kind)) return { ok: false, reason: "Нужна технология этого рода войск" };
    if (d.need && !e.buildings.some((b) => b.done && b.def === d.need)) {
      const nm = (e.buildingName(d.need) ?? d.need);
      return { ok: false, reason: `Нужно здание: ${nm}` };
    }
    if (!e.city.s.founded) return { ok: false, reason: "Нужен основанный город" };
    if (e.player.gold < d.cost.gold * n) return { ok: false, reason: `Нужно ${d.cost.gold * n} золота` };
    for (const [id, c] of d.cost.res) {
      const have = e.count(id) + e.city.stockOf(id);
      if (have < c * n) return { ok: false, reason: `Не хватает: ${ITEMS[id]?.name ?? id} (${have}/${c * n})` };
    }
    const men = this.totalMen();
    const cap = this.manpowerCap(e);
    if (men + n > cap) return { ok: false, reason: `Не хватает людей: ${men}/${cap}. Растите город` };
    return { ok: true, reason: "" };
  }
  manpowerCap(e: Engine): number {
    if (!e.city.s.founded) return 0;
    const barracks = e.buildings.filter((b) => b.done && ["kazarmy", "strelkovaya", "konyushni", "osadnaya"].includes(b.def))
      .reduce((a, b) => a + 6 * (b.lvl ?? 1), 0);
    return Math.floor(e.city.s.pop * 0.35 + barracks);
  }

  recruit(e: Engine, kind: UnitKind, n: number) {
    const check = this.canRecruit(e, kind, n);
    if (!check.ok) { e.toast(check.reason, "warn"); return; }
    const d = UNITS[kind];
    e.player.gold -= d.cost.gold * n;
    for (const [id, c] of d.cost.res) {
      let need = c * n;
      const fromCity = Math.min(need, e.city.stockOf(id));
      if (fromCity > 0) { e.city.takeStock(id, fromCity); need -= fromCity; }
      if (need > 0) e.take(id, need);
    }
    // в существующий отряд того же рода или новый
    const same = this.squads.find((s) => s.kind === kind && s.n < 40);
    if (same) {
      const add = Math.min(n, 40 - same.n);
      same.n += add;
      same.morale = clamp((same.morale * (same.n - add) + 80 * add) / same.n, 0, 100);
      if (n - add > 0) this.newSquad(kind, n - add);
    } else this.newSquad(kind, n);
    e.toast(`Набрано: ${d.name} ×${n}`, "good");
    snd.craft();
    e.addXp(3 * n);
    e.dynasty.support("armiya", 2);
    e.poke();
  }

  private newSquad(kind: UnitKind, n: number): Squad | null {
    if (this.squads.length >= MAX_SQUADS) return null;
    const ep = SQUAD_EPITHETS[Math.floor(Math.random() * SQUAD_EPITHETS.length)];
    const s: Squad = {
      uid: this.squadUid++, kind, n, hp: 100, xp: 0, lvl: 1,
      morale: 80, fatigue: 0, general: 0, wounded: 0,
      name: `${ep} ${UNITS[kind].plural.toLowerCase()}`,
    };
    this.squads.push(s);
    return s;
  }

  disband(e: Engine, uid: number) {
    const s = this.squads.find((x) => x.uid === uid);
    if (!s) return;
    e.player.gold += Math.floor(UNITS[s.kind].cost.gold * s.n * 0.3);
    this.squads = this.squads.filter((x) => x.uid !== uid);
    e.toast(`${s.name} распущены. Часть снаряжения продана`, "info");
    e.poke();
  }

  merge(e: Engine, a: number, b: number) {
    const sa = this.squads.find((x) => x.uid === a);
    const sb = this.squads.find((x) => x.uid === b);
    if (!sa || !sb || sa.kind !== sb.kind) { e.toast("Объединять можно только одинаковые рода войск", "warn"); return; }
    const total = sa.n + sb.n;
    if (total > 60) { e.toast("Слишком большой отряд (макс. 60)", "warn"); return; }
    sa.morale = (sa.morale * sa.n + sb.morale * sb.n) / total;
    sa.fatigue = (sa.fatigue * sa.n + sb.fatigue * sb.n) / total;
    sa.xp += sb.xp; sa.n = total;
    sa.lvl = Math.max(sa.lvl, sb.lvl);
    if (!sa.general && sb.general) sa.general = sb.general;
    this.squads = this.squads.filter((x) => x.uid !== b);
    e.toast(`Отряды слиты: ${sa.name} (${sa.n})`, "good");
    snd.ui(); e.poke();
  }
  split(e: Engine, uid: number) {
    const s = this.squads.find((x) => x.uid === uid);
    if (!s || s.n < 2) { e.toast("Слишком мало бойцов для разделения", "warn"); return; }
    if (this.squads.length >= MAX_SQUADS) { e.toast("Слишком много отрядов", "warn"); return; }
    const half = Math.floor(s.n / 2);
    s.n -= half;
    const ns = this.newSquad(s.kind, half);
    if (ns) { ns.morale = s.morale; ns.xp = Math.floor(s.xp / 2); ns.lvl = s.lvl; }
    e.toast("Отряд разделён надвое", "info");
    snd.ui(); e.poke();
  }
  assignGeneral(e: Engine, squadUid: number, genUid: number) {
    const s = this.squads.find((x) => x.uid === squadUid);
    if (!s) return;
    for (const o of this.squads) if (o.general === genUid && o.uid !== squadUid) o.general = 0;
    s.general = s.general === genUid ? 0 : genUid;
    const g = this.genOf(s.general);
    e.toast(g ? `${g.name} «${g.title}» принял ${s.name}` : "Генерал отозван", "info");
    snd.ui(); e.poke();
  }

  // ---------- Генералы ----------
  hireCost(): number { return 300 + this.generals.filter((g) => g.alive).length * 220; }
  hireGeneral(e: Engine) {
    const cost = this.hireCost();
    if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота`, "warn"); return; }
    if (this.generals.filter((g) => g.alive).length >= 6) { e.toast("Больше шести воевод не прокормить", "warn"); return; }
    e.player.gold -= cost;
    const g = this.makeGeneral();
    this.generals.push(g);
    e.toast(`${g.name} «${g.title}» вступил в вашу службу`, "good");
    snd.levelup();
    e.dynasty.support("armiya", 4);
    e.poke();
  }
  makeGeneral(): General {
    const sex = Math.random() < 0.78 ? 0 : 1;
    const name = sex === 0
      ? GEN_NAMES_M[Math.floor(Math.random() * GEN_NAMES_M.length)]
      : GEN_NAMES_F[Math.floor(Math.random() * GEN_NAMES_F.length)];
    const keys = Object.keys(GEN_TRAITS) as GenTrait[];
    const trait = keys[Math.floor(Math.random() * keys.length)];
    const t = GEN_TRAITS[trait];
    return {
      uid: this.genUid++, name,
      title: GEN_TITLES[Math.floor(Math.random() * GEN_TITLES.length)],
      lvl: 1, xp: 0, trait,
      bio: GEN_BIOS[Math.floor(Math.random() * GEN_BIOS.length)],
      atkBonus: t.atk, defBonus: t.def, moralBonus: t.mor,
      battles: 0, wins: 0, alive: true,
      wage: 3 + Math.floor(Math.random() * 3),
    };
  }
  genXp(g: General, n: number, e: Engine) {
    g.xp += n;
    const need = 40 + g.lvl * 45;
    if (g.xp >= need) {
      g.xp -= need; g.lvl++;
      g.atkBonus += 0.035; g.defBonus += 0.03; g.moralBonus += 0.02;
      g.wage += 1;
      e.toast(`${g.name} возвысился до ${g.lvl} уровня воеводы`, "good");
      snd.levelup();
    }
  }

  // ---------- Опыт и раны ----------
  squadXp(s: Squad, n: number, e: Engine) {
    s.xp += n;
    const need = 30 + s.lvl * 40;
    if (s.xp >= need) {
      s.xp -= need; s.lvl++;
      e.toast(`${s.name}: закалились в боях (ур. ${s.lvl})`, "good");
    }
  }
  wound(kind: UnitKind, n: number) {
    if (n <= 0) return;
    const ex = this.hospital.find((h) => h.kind === kind);
    if (ex) { ex.n += n; ex.t = Math.max(ex.t, 40); }
    else this.hospital.push({ kind, n, t: 55 });
  }
  hospitalCapacity(e: Engine): number {
    return e.buildings.filter((b) => b.done && ["hram", "monastyr", "sobor", "kuhnya"].includes(b.def)).length > 0 ? 1 : 0.45;
  }

  // ---------- Тик ----------
  update(e: Engine, dt: number) {
    if (!this.squads.length && !this.hospital.length) return;
    // восстановление морали/усталости
    for (const s of this.squads) {
      const resting = !e.battle.s.active;
      if (resting) {
        s.fatigue = clamp(s.fatigue - dt * 1.6, 0, 100);
        const target = e.city.s.founded ? 70 + e.city.s.happiness * 0.3 : 70;
        s.morale = clamp(s.morale + dt * (s.morale < target ? 1.1 : -0.2), 0, 100);
        if (s.hp < 100) s.hp = clamp(s.hp + dt * 1.2, 0, 100);
      }
    }
    // госпиталь
    const heal = this.hospitalCapacity(e);
    for (const h of [...this.hospital]) {
      h.t -= dt * heal;
      if (h.t <= 0) {
        const back = Math.max(1, Math.round(h.n * 0.65));
        const sq = this.squads.find((s) => s.kind === h.kind);
        if (sq) sq.n += back; else this.newSquad(h.kind, back);
        e.toast(`Из госпиталя вернулись: ${UNITS[h.kind].name} ×${back}`, "good");
        this.hospital = this.hospital.filter((x) => x !== h);
        e.poke();
      }
    }
    // содержание раз в минуту
    this.upkeepT -= dt;
    if (this.upkeepT <= 0) {
      this.upkeepT = 60;
      this.payUpkeep(e);
    }
  }

  payUpkeep(e: Engine) {
    if (!this.squads.length) return;
    const gold = Math.ceil(this.upkeepGold());
    const food = Math.ceil(this.upkeepFood());
    let starving = false;
    if (e.player.gold >= gold) e.player.gold -= gold;
    else {
      e.player.gold = 0;
      starving = true;
    }
    // еда: сначала склад города, потом сумка
    let need = food;
    for (const id of ["hleb", "zharkoe", "myaso", "zerno", "yagoda"]) {
      if (need <= 0) break;
      const st = e.city.stockOf(id);
      if (st > 0) { const t = Math.min(st, need); e.city.takeStock(id, t); need -= t; }
    }
    for (const id of ["hleb", "zharkoe", "myaso", "yagoda"]) {
      if (need <= 0) break;
      const have = e.count(id);
      if (have > 0) { const t = Math.min(have, need); e.take(id, t); need -= t; }
    }
    if (need > 0) starving = true;
    if (starving) {
      this.desertT++;
      for (const s of this.squads) {
        s.morale = clamp(s.morale - 14, 0, 100);
        if (Math.random() < 0.55 && s.n > 0) {
          const lost = Math.max(1, Math.round(s.n * 0.14));
          s.n -= lost;
          e.toast(`Дезертирство! ${s.name} потеряли ${lost} бойцов`, "bad");
        }
      }
      this.squads = this.squads.filter((s) => s.n > 0);
      e.dynasty.support("armiya", -5);
      snd.hurt();
      e.poke();
    } else if (gold > 0) {
      e.addFloater(`−${gold} содержание`, "#d9a05b", e.player.x, e.player.y - 40);
    }
  }
}
