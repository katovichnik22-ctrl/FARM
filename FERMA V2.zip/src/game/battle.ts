import type { Engine } from "./engine";
import type {
  BattleState, BattleUnit, HexCell, HexTerrain, Nation, Squad, UnitKind, BattleKind,
} from "../types/war";
import { UNITS } from "../data/army";
import { SPELL_BY_ID } from "../data/magic";
import { clamp, mulberry32 } from "../lib/noise";
import { snd } from "../lib/sound";

export const HEX_W = 20, HEX_H = 15;

// --- гексовая геометрия (odd-r offset) ---
export function hexNeighbors(q: number, r: number): [number, number][] {
  const odd = r & 1;
  const d: [number, number][] = odd
    ? [[1, 0], [0, -1], [-1, -1], [-1, 0], [-1, 1], [0, 1]]
    : [[1, 0], [1, -1], [0, -1], [-1, 0], [0, 1], [1, 1]];
  return d.map(([dq, dr]) => [q + dq, r + dr] as [number, number]);
}
function axial(q: number, r: number): [number, number] {
  return [q - ((r - (r & 1)) >> 1), r];
}
export function hexDist(q1: number, r1: number, q2: number, r2: number): number {
  const [aq, ar] = axial(q1, r1), [bq, br] = axial(q2, r2);
  return (Math.abs(aq - bq) + Math.abs(aq + ar - bq - br) + Math.abs(ar - br)) / 2;
}

const TERRAIN_DEF: Record<HexTerrain, { move: number; def: number; name: string }> = {
  grass: { move: 1, def: 0, name: "Трава" },
  forest: { move: 2, def: 0.22, name: "Лес" },
  hill: { move: 2, def: 0.18, name: "Холм" },
  water: { move: 99, def: -0.1, name: "Вода" },
  wall: { move: 99, def: 0.5, name: "Стена" },
  gate: { move: 99, def: 0.35, name: "Ворота" },
  tower: { move: 99, def: 0.45, name: "Башня" },
  road: { move: 0.5, def: -0.05, name: "Дорога" },
  rubble: { move: 1.5, def: 0.08, name: "Развалины" },
};

function emptyBattle(): BattleState {
  return {
    active: false, kind: "field", nationId: "", cells: [], units: [],
    turn: 1, side: 0, sel: 0, log: [],
    wallHp: 0, wallMax: 0, gateHp: 0, gateMax: 0, sapper: 0,
    weather: "clear", night: false,
    over: null, reward: { gold: 0, xp: 0, annex: false },
    spellCd: 0, ap: 0,
  };
}

export class BattleSim {
  s: BattleState = emptyBattle();
  private uid = 1;
  private aiTimer = 0;
  pendingNation: Nation | null = null;
  invitePrompt: { nation: string; kind: BattleKind } | null = null;

  reset() { this.s = emptyBattle(); this.pendingNation = null; this.invitePrompt = null; }

  // ---------- Подготовка ----------
  /** Враг дошёл до владений игрока — предложить битву */
  startInvasion(e: Engine, n: Nation) {
    if (this.s.active || this.invitePrompt) return;
    const kind: BattleKind = e.city.s.founded ? "defense" : "field";
    this.invitePrompt = { nation: n.id, kind };
    e.onOpenPanel?.("battleStart");
    e.toast(`${n.name} у ваших границ! Примите бой или откупитесь`, "bad");
    snd.thunder();
    e.poke();
  }

  /** Игрок сам нападает на нацию */
  canAttack(e: Engine, n: Nation): { ok: boolean; reason: string } {
    if (this.s.active) return { ok: false, reason: "Битва уже идёт" };
    if (n.state !== "war") return { ok: false, reason: "Сначала объявите войну" };
    if (!e.army.squads.length) return { ok: false, reason: "У вас нет войска" };
    return { ok: true, reason: "" };
  }

  begin(e: Engine, nationId: string, kind: BattleKind) {
    const n = e.nations.get(nationId);
    if (!n) return;
    if (!e.army.squads.length && kind !== "defense") { e.toast("Нет войск для битвы", "warn"); return; }
    const s = emptyBattle();
    s.active = true;
    s.kind = kind;
    s.nationId = nationId;
    s.night = e.isNight();
    s.weather = e.weather;
    s.ap = 0;
    this.uid = 1;
    const rng = mulberry32((e.seed ^ e.day * 7919 ^ nationId.length * 131) >>> 0);
    s.cells = this.genField(rng, kind);
    if (kind === "siege") { s.wallMax = s.wallHp = 150 + n.cities * 50; s.gateMax = s.gateHp = 100 + n.cities * 25; }
    if (kind === "defense") {
      const walls = e.buildings.filter((b) => b.done && ["stena", "chastokol", "bashnya", "vorota"].includes(b.def)).length;
      s.wallMax = s.wallHp = walls * 40;
      s.gateMax = s.gateHp = walls > 0 ? 80 : 0;
    }
    // войска игрока
    const mine = e.army.squads.filter((sq) => sq.n > 0);
    let idx = 0;
    for (const sq of mine.slice(0, 8)) {
      const spot = this.spawnSpot(s, 0, idx++, kind);
      s.units.push(this.mkUnit(sq, 0, spot[0], spot[1]));
    }
    // войска врага
    const enemyUnits = this.genEnemy(n, rng, kind);
    idx = 0;
    for (const u of enemyUnits) {
      const spot = this.spawnSpot(s, 1, idx++, kind);
      u.q = spot[0]; u.r = spot[1];
      s.units.push(u);
    }
    s.reward = {
      gold: Math.floor(180 + n.gold * 0.1 + n.army * 18),
      xp: 60 + n.army * 5,
      annex: kind === "siege",
    };
    s.sel = s.units.find((u) => u.side === 0)?.uid ?? 0;
    this.s = s;
    this.pushLog(`Битва с ${n.name}: ${kind === "siege" ? "осада города" : kind === "defense" ? "оборона наших земель" : "полевое сражение"}`, "info");
    if (s.night) this.pushLog("Ночь: стрелки бьют хуже, засады удаются лучше", "info");
    if (s.weather === "rain" || s.weather === "storm") this.pushLog("Дождь: земля раскисла, конница вязнет", "info");
    this.invitePrompt = null;
    e.onOpenPanel?.("battle");
    snd.thunder();
    e.poke();
  }

  private genField(rng: () => number, kind: BattleKind): HexCell[] {
    const cells: HexCell[] = [];
    for (let r = 0; r < HEX_H; r++) {
      for (let q = 0; q < HEX_W; q++) {
        let t: HexTerrain = "grass";
        const n = rng();
        if (n < 0.14) t = "forest";
        else if (n < 0.24) t = "hill";
        else if (n < 0.28) t = "water";
        else if (n < 0.33) t = "road";
        // осада: стены справа
        if (kind === "siege") {
          if (q === HEX_W - 4) t = r === Math.floor(HEX_H / 2) || r === Math.floor(HEX_H / 2) - 1 ? "gate" : "wall";
          else if (q > HEX_W - 4) t = (q === HEX_W - 1 && r % 4 === 0) ? "tower" : "grass";
        }
        if (kind === "defense") {
          if (q === 4) t = r === Math.floor(HEX_H / 2) ? "gate" : rng() < 0.75 ? "wall" : "grass";
          else if (q < 4) t = rng() < 0.2 ? "road" : "grass";
        }
        cells.push({ q, r, t, hp: t === "wall" || t === "gate" ? 100 : undefined });
      }
    }
    return cells;
  }

  private spawnSpot(s: BattleState, side: 0 | 1, i: number, kind: BattleKind): [number, number] {
    const col = side === 0
      ? (kind === "defense" ? 1 + (i % 3) : 1 + (i % 3))
      : (kind === "siege" ? HEX_W - 3 + (i % 3) : HEX_W - 2 - (i % 3));
    let row = 1 + ((i * 2) % (HEX_H - 2));
    for (let tries = 0; tries < HEX_H; tries++) {
      const c = s.cells.find((x) => x.q === col && x.r === row);
      const taken = s.units.some((u) => u.q === col && u.r === row);
      if (c && !taken && TERRAIN_DEF[c.t].move < 90) return [col, row];
      row = (row + 1) % HEX_H;
    }
    return [col, Math.min(HEX_H - 1, 1 + i)];
  }

  private mkUnit(sq: Squad, side: 0 | 1, q: number, r: number): BattleUnit {
    return {
      uid: this.uid++, squadUid: sq.uid, side,
      kind: sq.kind, n: sq.n, maxN: sq.n,
      hp: sq.hp, morale: sq.morale, fatigue: sq.fatigue,
      q, r, moved: false, acted: false,
      general: sq.general, lvl: sq.lvl, flash: 0, shake: 0,
    };
  }

  private genEnemy(n: Nation, rng: () => number, kind: BattleKind): BattleUnit[] {
    const out: BattleUnit[] = [];
    const budget = Math.max(3, Math.round(n.army * (kind === "siege" ? 1.15 : 0.85)));
    const pool: UnitKind[] = ["infantry", "infantry", "archer", "cavalry"];
    if (n.tech >= 3) pool.push("catapult");
    if (n.magic >= 3) pool.push("mage");
    if (n.magic >= 4 && rng() < 0.3) pool.push("dragon");
    if (n.fleet > 4) pool.push("fleet");
    let left = budget;
    let i = 0;
    while (left > 0 && out.length < 8) {
      const kindU = pool[Math.floor(rng() * pool.length)];
      const size = Math.max(2, Math.min(left, Math.round(3 + rng() * 7)));
      left -= size;
      out.push({
        uid: this.uid++, squadUid: -1 - i, side: 1,
        kind: kindU, n: size, maxN: size,
        hp: 100, morale: 70 + rng() * 25, fatigue: 0,
        q: 0, r: 0, moved: false, acted: false,
        general: 0, lvl: Math.max(1, Math.round(n.tech * 0.6)), flash: 0, shake: 0,
      });
      i++;
    }
    return out;
  }

  // ---------- Доступ ----------
  cellAt(q: number, r: number): HexCell | undefined { return this.s.cells.find((c) => c.q === q && c.r === r); }
  unitAt(q: number, r: number): BattleUnit | undefined { return this.s.units.find((u) => u.q === q && u.r === r && u.n > 0); }
  selected(): BattleUnit | undefined { return this.s.units.find((u) => u.uid === this.s.sel); }
  terrainName(t: HexTerrain): string { return TERRAIN_DEF[t].name; }

  pushLog(text: string, kind: BattleLogKind = "info") {
    this.s.log.unshift({ t: this.s.turn, text, kind });
    if (this.s.log.length > 60) this.s.log.pop();
  }

  /** Куда юнит может пройти */
  reachable(u: BattleUnit): { q: number; r: number }[] {
    const def = UNITS[u.kind];
    const budget = def.move * (u.fatigue > 60 ? 0.6 : 1);
    const out: { q: number; r: number; cost: number }[] = [];
    const seen = new Map<string, number>();
    const queue: { q: number; r: number; cost: number }[] = [{ q: u.q, r: u.r, cost: 0 }];
    seen.set(`${u.q},${u.r}`, 0);
    while (queue.length) {
      const cur = queue.shift()!;
      for (const [nq, nr] of hexNeighbors(cur.q, cur.r)) {
        if (nq < 0 || nr < 0 || nq >= HEX_W || nr >= HEX_H) continue;
        const c = this.cellAt(nq, nr);
        if (!c) continue;
        const flying = u.kind === "dragon";
        const naval = UNITS[u.kind].water;
        let mv = TERRAIN_DEF[c.t].move;
        if (flying) mv = 1;
        else if (naval) mv = c.t === "water" ? 1 : 99;
        else if (c.t === "water") mv = 99;
        if (mv > 90) continue;
        if (this.unitAt(nq, nr)) continue;
        const cost = cur.cost + mv;
        if (cost > budget) continue;
        const key = `${nq},${nr}`;
        if ((seen.get(key) ?? 99) <= cost) continue;
        seen.set(key, cost);
        out.push({ q: nq, r: nr, cost });
        queue.push({ q: nq, r: nr, cost });
      }
    }
    return out.map(({ q, r }) => ({ q, r }));
  }

  /** Кого юнит может атаковать */
  targets(u: BattleUnit): BattleUnit[] {
    const def = UNITS[u.kind];
    const rng = def.rng + (u.general && u.kind === "archer" ? 1 : 0);
    return this.s.units.filter((o) => o.side !== u.side && o.n > 0 && hexDist(u.q, u.r, o.q, o.r) <= rng);
  }
  /** Может ли бить стену/ворота */
  siegeTargets(u: BattleUnit): HexCell[] {
    const def = UNITS[u.kind];
    if (!def.siege) return [];
    return this.s.cells.filter((c) => (c.t === "wall" || c.t === "gate") && hexDist(u.q, u.r, c.q, c.r) <= Math.max(1, def.rng));
  }

  // ---------- Боевая математика ----------
  private terrainDef(q: number, r: number): number {
    const c = this.cellAt(q, r);
    return c ? TERRAIN_DEF[c.t].def : 0;
  }
  private genBonus(e: Engine, u: BattleUnit): { atk: number; def: number; mor: number } {
    if (u.side === 1 || !u.general) return { atk: 0, def: 0, mor: 0 };
    const g = e.army.genOf(u.general);
    return g ? { atk: g.atkBonus, def: g.defBonus, mor: g.moralBonus } : { atk: 0, def: 0, mor: 0 };
  }
  private matchup(a: UnitKind, d: UnitKind): number {
    const A = UNITS[a];
    if (A.strongVs?.includes(d)) return 1.35;
    if (A.weakVs?.includes(d)) return 0.72;
    return 1;
  }

  attack(e: Engine, attacker: BattleUnit, target: BattleUnit) {
    const ad = UNITS[attacker.kind], td = UNITS[target.kind];
    const gb = this.genBonus(e, attacker);
    const gd = this.genBonus(e, target);
    const ranged = hexDist(attacker.q, attacker.r, target.q, target.r) > 1;
    const loreAtk = attacker.side === 0 ? e.lore.armyAtkMul(e) : 1;
    const loreDef = target.side === 0 ? e.lore.armyDefMul(e) : 1;
    let atk = ad.atk * attacker.n * (1 + (attacker.lvl - 1) * 0.12) * (1 + gb.atk) * loreAtk;
    atk *= 0.55 + (attacker.morale / 100) * 0.65;
    atk *= 1 - attacker.fatigue / 260;
    atk *= this.matchup(attacker.kind, target.kind);
    if (this.s.night && ranged) atk *= 0.75;
    if ((this.s.weather === "rain" || this.s.weather === "storm") && attacker.kind === "archer") atk *= 0.8;
    if (this.s.weather === "fog" && ranged) atk *= 0.7;
    if (this.s.weather === "snow" && attacker.kind === "cavalry") atk *= 0.85;
    let dfn = td.def * target.n * (1 + (target.lvl - 1) * 0.1) * (1 + gd.def) * loreDef;
    dfn *= 1 + this.terrainDef(target.q, target.r);
    dfn *= 0.6 + (target.morale / 100) * 0.5;
    const dmg = Math.max(1, Math.round((atk / Math.max(1, dfn)) * 9 * (0.85 + Math.random() * 0.3)));
    const crit = Math.random() < 0.12 + (attacker.general ? 0.05 : 0);
    const finalDmg = crit ? Math.round(dmg * 1.7) : dmg;

    // потери
    const before = target.n;
    target.hp -= finalDmg;
    while (target.hp <= 0 && target.n > 0) { target.n--; target.hp += 100; }
    const killed = before - target.n;
    target.morale = clamp(target.morale - (killed * 4 + 3), 0, 100);
    target.flash = 0.25; target.shake = 0.4;
    attacker.fatigue = clamp(attacker.fatigue + (ranged ? 5 : 9), 0, 100);
    attacker.acted = true;
    if (!ranged) attacker.moved = true;

    this.pushLog(
      `${UNITS[attacker.kind].name} бьёт ${UNITS[target.kind].name}: ${finalDmg} урона${crit ? " (крит!)" : ""}${killed ? `, пало ${killed}` : ""}`,
      crit ? "kill" : "hit"
    );
    snd[crit ? "crit" : "hit"]();

    // ответный удар вблизи
    if (!ranged && target.n > 0 && td.rng >= 1) {
      const back = Math.max(1, Math.round(finalDmg * 0.4 * this.matchup(target.kind, attacker.kind)));
      const b4 = attacker.n;
      attacker.hp -= back;
      while (attacker.hp <= 0 && attacker.n > 0) { attacker.n--; attacker.hp += 100; }
      const bk = b4 - attacker.n;
      attacker.morale = clamp(attacker.morale - (bk * 3 + 2), 0, 100);
      attacker.flash = 0.2;
      this.pushLog(`Ответный удар: ${back} урона${bk ? `, пало ${bk}` : ""}`, "hit");
    }
    if (target.n <= 0) {
      this.pushLog(`${UNITS[target.kind].plural} разбиты!`, "kill");
      snd.mobDie();
      // мораль соседей падает
      for (const o of this.s.units) if (o.side === target.side && o.n > 0) o.morale = clamp(o.morale - 8, 0, 100);
    }
    this.checkEnd(e);
    e.poke();
  }

  siegeAttack(e: Engine, u: BattleUnit, cell: HexCell) {
    const def = UNITS[u.kind];
    const g = this.genBonus(e, u);
    const mult = e.army.genOf(u.general)?.trait === "kuznec" ? 2 : 1;
    const dmg = Math.round((def.siege ?? 10) * u.n * 0.45 * (1 + g.atk) * mult * (0.85 + Math.random() * 0.3));
    if (cell.t === "gate") {
      this.s.gateHp = Math.max(0, this.s.gateHp - dmg);
      if (this.s.gateHp <= 0) { cell.t = "rubble"; this.pushLog("ВОРОТА ПАЛИ! Путь в город открыт", "siege"); snd.explosion(); }
      else this.pushLog(`Таран бьёт ворота: ${dmg} (осталось ${this.s.gateHp})`, "siege");
    } else {
      this.s.wallHp = Math.max(0, this.s.wallHp - dmg);
      cell.hp = (cell.hp ?? 100) - dmg;
      if ((cell.hp ?? 0) <= 0) { cell.t = "rubble"; this.pushLog("Пролом в стене!", "siege"); snd.explosion(); }
      else this.pushLog(`Камнемёты крушат стену: ${dmg} (прочность ${this.s.wallHp})`, "siege");
    }
    u.acted = true; u.moved = true;
    u.fatigue = clamp(u.fatigue + 8, 0, 100);
    e.shake = 0.3;
    snd.buildHammer();
    this.checkEnd(e);
    e.poke();
  }

  /** Подкоп: медленно, но рушит стену без осадных машин */
  sap(e: Engine) {
    const u = this.selected();
    if (!u || u.side !== 0 || u.acted) { e.toast("Нужен свежий отряд", "warn"); return; }
    this.s.sapper += 25 + u.n;
    u.acted = true; u.moved = true;
    u.fatigue = clamp(u.fatigue + 14, 0, 100);
    this.pushLog(`${UNITS[u.kind].plural} роют подкоп (${Math.min(100, this.s.sapper)}%)`, "siege");
    if (this.s.sapper >= 100) {
      this.s.wallHp = Math.max(0, this.s.wallHp - 120);
      const wall = this.s.cells.find((c) => c.t === "wall");
      if (wall) wall.t = "rubble";
      this.s.sapper = 0;
      this.pushLog("Подкоп обрушил участок стены!", "siege");
      snd.explosion();
      e.shake = 0.6;
    }
    snd.dig();
    e.poke();
  }

  /** Боевое заклинание: базовый вихрь или выбранное заклинание мага-игрока */
  castSpell(e: Engine, q: number, r: number, spellId?: string) {
    const sp = spellId ? SPELL_BY_ID[spellId] : null;
    // --- заклинание мага-игрока ---
    if (sp) {
      if (!e.lore.knowsSpell(sp.id)) { e.toast("Заклинание неведомо", "warn"); return; }
      if (!sp.battle) { e.toast("Эти чары творят вне боя", "warn"); return; }
      if (e.lore.magic.mana < sp.mana) { e.toast(`Мало маны (${Math.floor(e.lore.magic.mana)}/${sp.mana})`, "warn"); return; }
      if (!e.lore.spellReady(sp.id)) { e.toast("Чары не восстановились", "warn"); return; }
      e.lore.magic.mana -= sp.mana;
      e.lore.magic.cds[sp.id] = sp.cd * 6;
      const pow = (sp.power ?? 40) * e.lore.spellPower();
      const rad = sp.radius ?? 1;
      switch (sp.kind) {
        case "attack": {
          const hit = this.s.units.filter((u) => u.side === 1 && u.n > 0 && hexDist(q, r, u.q, u.r) <= rad);
          if (!hit.length) { this.pushLog(`${sp.name}: чары ушли в пустоту`, "spell"); break; }
          for (const t of hit) {
            const dmg = Math.round(pow * (0.8 + Math.random() * 0.4));
            const b4 = t.n;
            t.hp -= dmg;
            while (t.hp <= 0 && t.n > 0) { t.n--; t.hp += 100; }
            t.morale = clamp(t.morale - 16, 0, 100);
            t.flash = 0.4; t.shake = 0.6;
            this.pushLog(`${sp.name}: ${UNITS[t.kind].name} теряет ${b4 - t.n} бойцов (${dmg})`, "spell");
          }
          snd.fireball(); e.shake = 0.55;
          break;
        }
        case "heal": {
          for (const u of this.s.units.filter((x) => x.side === 0 && x.n > 0)) {
            u.hp = clamp(u.hp + pow, 0, 100);
            u.morale = clamp(u.morale + 14, 0, 100);
            u.flash = 0.25;
          }
          this.pushLog(`${sp.name}: раны затянулись, дух окреп`, "spell");
          snd.levelup();
          break;
        }
        case "shield": case "bless": {
          for (const u of this.s.units.filter((x) => x.side === 0 && x.n > 0)) {
            u.morale = clamp(u.morale + 22, 0, 100);
            u.fatigue = clamp(u.fatigue - 25, 0, 100);
            u.flash = 0.2;
          }
          this.pushLog(`${sp.name}: войско воспряло`, "spell");
          snd.levelup();
          break;
        }
        case "curse": case "weather": {
          for (const u of this.s.units.filter((x) => x.side === 1 && x.n > 0 && hexDist(q, r, x.q, x.r) <= rad + 1)) {
            u.morale = clamp(u.morale - 26, 0, 100);
            u.fatigue = clamp(u.fatigue + 22, 0, 100);
            u.flash = 0.3;
          }
          this.pushLog(`${sp.name}: враг пал духом`, "spell");
          snd.thunder();
          break;
        }
        case "summon": {
          const spot = this.s.cells.find((c) => c.q === q && c.r === r && !this.unitAt(c.q, c.r));
          if (!spot) { this.pushLog("Негде явить защитника", "spell"); break; }
          this.s.units.push({
            uid: this.uid++, squadUid: -999, side: 0,
            kind: "infantry", n: Math.max(3, Math.round(pow / 6)), maxN: 10,
            hp: 100, morale: 100, fatigue: 0, q, r,
            moved: true, acted: true, general: 0, lvl: 2, flash: 0.4, shake: 0,
          });
          this.pushLog(`${sp.name}: каменный страж встал в строй`, "spell");
          snd.place();
          break;
        }
        case "teleport": {
          const u = this.selected();
          if (u && !this.unitAt(q, r) && u.side === 0) {
            u.q = q; u.r = r; u.moved = false;
            this.pushLog(`${sp.name}: отряд шагнул сквозь складку мира`, "spell");
            snd.ui();
          }
          break;
        }
        default:
          this.pushLog(`${sp.name} сотворено`, "spell");
      }
      e.lore.magic.auraT = 2;
      e.lore.magicXp(e, 10);
      this.checkEnd(e);
      e.poke();
      return;
    }

    // --- базовый вихрь от отряда чародеев ---
    if (this.s.spellCd > 0) { e.toast("Чары ещё не восстановились", "warn"); return; }
    const hasMage = this.s.units.some((u) => u.side === 0 && u.kind === "mage" && u.n > 0);
    if (!hasMage) { e.toast("Нужны чародеи в войске или своя магия", "warn"); return; }
    this.s.spellCd = 3;
    const hit = this.s.units.filter((u) => u.side === 1 && u.n > 0 && hexDist(q, r, u.q, u.r) <= 1);
    if (!hit.length) { this.pushLog("Огненный вихрь ушёл в пустоту", "spell"); e.poke(); return; }
    for (const t of hit) {
      const dmg = Math.round((40 + Math.random() * 30) * e.lore.spellPower());
      const b4 = t.n;
      t.hp -= dmg;
      while (t.hp <= 0 && t.n > 0) { t.n--; t.hp += 100; }
      t.morale = clamp(t.morale - 14, 0, 100);
      t.flash = 0.35;
      this.pushLog(`Огненный вихрь: ${UNITS[t.kind].name} теряет ${b4 - t.n} бойцов`, "spell");
    }
    snd.fireball();
    e.shake = 0.5;
    this.checkEnd(e);
    e.poke();
  }

  // ---------- Ходы ----------
  move(e: Engine, u: BattleUnit, q: number, r: number) {
    if (u.moved) { e.toast("Отряд уже ходил", "warn"); return; }
    const ok = this.reachable(u).some((c) => c.q === q && c.r === r);
    if (!ok) return;
    u.q = q; u.r = r; u.moved = true;
    u.fatigue = clamp(u.fatigue + 3, 0, 100);
    snd.step();
    e.poke();
  }

  endTurn(e: Engine) {
    if (!this.s.active || this.s.over) return;
    this.s.side = 1;
    this.pushLog(`— ход ${e.nations.get(this.s.nationId)?.adj ?? "вражеских"} войск —`, "info");
    this.aiTimer = 0.45;
    e.poke();
  }

  private aiTurn(e: Engine) {
    const enemies = this.s.units.filter((u) => u.side === 1 && u.n > 0);
    for (const u of enemies) {
      if (this.s.over) break;
      const mine = this.s.units.filter((o) => o.side === 0 && o.n > 0);
      if (!mine.length) break;
      // бежит при низкой морали
      if (u.morale < 22 && Math.random() < 0.5) {
        this.pushLog(`${UNITS[u.kind].plural} дрогнули и отступают`, "info");
        u.n = Math.max(0, u.n - Math.ceil(u.n * 0.3));
        continue;
      }
      // цель: ближайший/слабейший
      let best = mine[0], bestScore = -1e9;
      for (const t of mine) {
        const d = hexDist(u.q, u.r, t.q, t.r);
        const score = this.matchup(u.kind, t.kind) * 40 - d * 6 - t.n * 1.2 + (t.kind === "catapult" || t.kind === "mage" ? 25 : 0);
        if (score > bestScore) { bestScore = score; best = t; }
      }
      // осадные бьют стены при обороне игрока
      const def = UNITS[u.kind];
      if (this.s.kind === "defense" && def.siege && this.s.gateHp > 0) {
        const gate = this.s.cells.find((c) => c.t === "gate");
        if (gate && hexDist(u.q, u.r, gate.q, gate.r) <= Math.max(1, def.rng)) {
          const dmg = Math.round((def.siege ?? 10) * u.n * 0.4);
          this.s.gateHp = Math.max(0, this.s.gateHp - dmg);
          this.pushLog(`Враг бьёт наши ворота: ${dmg}`, "siege");
          if (this.s.gateHp <= 0) { gate.t = "rubble"; this.pushLog("Наши ворота пали!", "siege"); }
          continue;
        }
      }
      // подойти и ударить
      const dist = hexDist(u.q, u.r, best.q, best.r);
      if (dist > def.rng) {
        const cells = this.reachable(u);
        let pick: { q: number; r: number } | null = null;
        let pd = dist;
        for (const c of cells) {
          const d = hexDist(c.q, c.r, best.q, best.r);
          if (d < pd) { pd = d; pick = c; }
        }
        if (pick) { u.q = pick.q; u.r = pick.r; }
      }
      if (hexDist(u.q, u.r, best.q, best.r) <= def.rng) this.attack(e, u, best);
    }
    // конец хода ИИ
    this.s.turn++;
    this.s.side = 0;
    for (const u of this.s.units) {
      u.moved = false; u.acted = false;
      u.fatigue = clamp(u.fatigue - 2, 0, 100);
      if (u.side === 0 && u.morale < 100) u.morale = clamp(u.morale + 2, 0, 100);
    }
    if (this.s.spellCd > 0) this.s.spellCd--;
    this.pushLog(`— ход ${this.s.turn}: ваши приказы —`, "info");
    this.checkEnd(e);
    e.poke();
  }

  // ---------- Завершение ----------
  private checkEnd(e: Engine) {
    if (this.s.over) return;
    const mine = this.s.units.filter((u) => u.side === 0 && u.n > 0).length;
    const foes = this.s.units.filter((u) => u.side === 1 && u.n > 0).length;
    const siegeDone = this.s.kind === "siege" && this.s.wallMax > 0 && this.s.wallHp <= 0 && this.s.gateHp <= 0;
    if (foes === 0 || siegeDone) this.finish(e, true);
    else if (mine === 0) this.finish(e, false);
    else if (this.s.turn > 25) this.finish(e, this.sideStrength(0) > this.sideStrength(1));
  }
  private sideStrength(side: 0 | 1): number {
    return this.s.units.filter((u) => u.side === side).reduce((a, u) => a + u.n * (UNITS[u.kind].atk + UNITS[u.kind].def), 0);
  }

  finish(e: Engine, win: boolean) {
    const n = e.nations.get(this.s.nationId);
    // синхронизация потерь с реальными отрядами
    for (const u of this.s.units.filter((x) => x.side === 0)) {
      const sq = e.army.squads.find((s) => s.uid === u.squadUid);
      if (!sq) continue;
      const lost = Math.max(0, sq.n - u.n);
      const wounded = Math.round(lost * 0.4);
      e.army.wound(sq.kind, wounded);
      sq.n = u.n;
      sq.morale = clamp(u.morale, 5, 100);
      sq.fatigue = clamp(u.fatigue, 0, 100);
      sq.hp = clamp(u.hp, 10, 100);
      if (u.n > 0) e.army.squadXp(sq, win ? 26 : 12, e);
      const g = e.army.genOf(sq.general);
      if (g) {
        g.battles++;
        if (win) g.wins++;
        e.army.genXp(g, win ? 35 : 15, e);
      }
    }
    e.army.squads = e.army.squads.filter((s) => s.n > 0);

    let text = "";
    let loot = 0;
    if (win) {
      loot = this.s.reward.gold;
      e.player.gold += loot;
      e.addXp(this.s.reward.xp);
      e.nations.fame += 8;
      if (n) {
        n.warScore = clamp(n.warScore + (this.s.kind === "siege" ? 42 : 28), -100, 100);
        n.army = Math.max(1, n.army - Math.round(n.army * 0.3));
        n.incoming = false;
        n.marchT = 120 + Math.random() * 90;
        if (this.s.kind === "siege") { n.cities = Math.max(0, n.cities - 1); n.gold = Math.floor(n.gold * 0.7); }
      }
      text = this.s.kind === "siege"
        ? `Город взят! Добыча ${loot} золота. ${n?.name ?? "Враг"} на грани.`
        : `Победа! Враг бежал с поля. Добыча ${loot} золота.`;
      e.stats.battleWin = (e.stats.battleWin ?? 0) + 1;
      e.meta.battlesWon++;
      e.meta.log(e, `Победа в битве с ${n?.name ?? "врагом"}`, "battle");
      snd.setMood("victory", true);
      e.dynasty.support("armiya", 10);
      e.dynasty.support("narod", 5);
      if (e.city.s.founded) { e.city.s.happiness = clamp(e.city.s.happiness + 8, 0, 100); e.city.s.paradeT = 8; }
      snd.levelup();
    } else {
      if (n) {
        n.warScore = clamp(n.warScore - 32, -100, 100);
        n.incoming = false;
        n.marchT = 90 + Math.random() * 60;
        const pillage = Math.min(e.player.gold, Math.floor(120 + Math.random() * 380));
        e.player.gold -= pillage;
        loot = -pillage;
        if (e.city.s.founded) {
          e.city.s.happiness = clamp(e.city.s.happiness - 14, 0, 100);
          e.city.s.pop = Math.max(1, e.city.s.pop * 0.9);
          e.city.s.riot = clamp(e.city.s.riot + 20, 0, 100);
        }
        text = `Поражение. ${n.name} разграбили округу на ${pillage} золота. Беженцы идут в город.`;
      } else text = "Поражение.";
      e.dynasty.support("armiya", -10);
      e.nations.fame = Math.max(0, e.nations.fame - 5);
      snd.death();
    }
    this.s.over = { win, loot, text };
    this.s.active = true;
    e.nations.log(e, win ? `Победа над ${n?.name ?? "врагом"}` : `Поражение от ${n?.name ?? "врага"}`, win ? "good" : "bad");
    e.shake = 0.7;
    e.poke();
  }

  close(e: Engine) {
    this.s = emptyBattle();
    e.onOpenPanel?.("");
    e.poke();
  }

  // ---------- Авто-бой ----------
  autoBattle(e: Engine, nationId?: string, kind?: BattleKind) {
    const id = nationId ?? this.s.nationId;
    const n = e.nations.get(id);
    if (!n) return;
    if (!this.s.active) this.begin(e, id, kind ?? "field");
    const logs: string[] = [];
    let round = 0;
    while (!this.s.over && round < 30) {
      round++;
      const mine = this.s.units.filter((u) => u.side === 0 && u.n > 0);
      const foes = this.s.units.filter((u) => u.side === 1 && u.n > 0);
      if (!mine.length || !foes.length) break;
      const myPow = this.sideStrength(0) * (1 + e.nations.fame / 300);
      const foePow = this.sideStrength(1);
      const roll = myPow / (myPow + foePow);
      // раунд: обе стороны несут потери
      const foeTarget = foes[Math.floor(Math.random() * foes.length)];
      const myTarget = mine[Math.floor(Math.random() * mine.length)];
      const foeLoss = Math.max(1, Math.round(foeTarget.n * (0.12 + roll * 0.25)));
      const myLoss = Math.max(0, Math.round(myTarget.n * (0.1 + (1 - roll) * 0.22)));
      foeTarget.n = Math.max(0, foeTarget.n - foeLoss);
      myTarget.n = Math.max(0, myTarget.n - myLoss);
      myTarget.morale = clamp(myTarget.morale - myLoss * 3, 0, 100);
      logs.push(`Сшибка ${round}: враг теряет ${foeLoss}, мы — ${myLoss}`);
      this.pushLog(`Сшибка ${round}: враг −${foeLoss}, мы −${myLoss}`, "hit");
      if (this.s.kind === "siege") {
        const dmg = Math.round(20 + Math.random() * 30);
        this.s.wallHp = Math.max(0, this.s.wallHp - dmg);
        if (this.s.wallHp <= 0) this.s.gateHp = Math.max(0, this.s.gateHp - dmg);
        this.pushLog(`Осадные орудия: стена −${dmg}`, "siege");
      }
      this.checkEnd(e);
    }
    if (!this.s.over) this.finish(e, this.sideStrength(0) > this.sideStrength(1));
    snd.explosion();
    e.onOpenPanel?.("battle");
    e.poke();
  }

  /** Осада измором и подкуп гарнизона */
  starveOut(e: Engine) {
    const n = e.nations.get(this.s.nationId);
    if (!n) return;
    const cost = 300;
    if (e.player.gold < cost) { e.toast(`Измор требует ${cost} золота на припасы`, "warn"); return; }
    e.player.gold -= cost;
    const chance = 0.35 + (e.army.power() / Math.max(60, e.nations.strength(n))) * 0.3;
    if (Math.random() < chance) {
      this.pushLog("Город сдался от голода — ворота открыты без крови", "siege");
      this.finish(e, true);
    } else {
      for (const u of this.s.units.filter((x) => x.side === 0)) {
        u.fatigue = clamp(u.fatigue + 18, 0, 100);
        u.morale = clamp(u.morale - 8, 0, 100);
      }
      this.s.turn += 2;
      this.pushLog("Осада затянулась: войско устало, город держится", "info");
      e.toast("Город не сдался. Войско ропщет", "warn");
    }
    e.poke();
  }
  bribeGarrison(e: Engine) {
    const n = e.nations.get(this.s.nationId);
    if (!n) return;
    const cost = Math.floor(500 + n.army * 40);
    if (e.player.gold < cost) { e.toast(`На подкуп нужно ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    if (Math.random() < 0.55 + e.nations.fame / 300) {
      this.pushLog("Гарнизон подкуплен: ворота распахнулись сами", "siege");
      this.finish(e, true);
    } else {
      this.pushLog("Подкуп раскрыт! Защитники в ярости", "info");
      for (const u of this.s.units.filter((x) => x.side === 1)) u.morale = clamp(u.morale + 12, 0, 100);
      e.toast("Подкуп не удался, золото пропало", "bad");
    }
    e.poke();
  }

  /** Откупиться от вторжения */
  buyOff(e: Engine) {
    const p = this.invitePrompt;
    if (!p) return;
    const n = e.nations.get(p.nation);
    if (!n) return;
    const cost = Math.floor(250 + n.army * 45);
    if (e.player.gold < cost) { e.toast(`Откуп стоит ${cost} золота — нечем платить`, "bad"); return; }
    e.player.gold -= cost;
    n.incoming = false;
    n.marchT = 160;
    n.rel = clamp(n.rel + 10, -100, 100);
    n.warScore = clamp(n.warScore - 10, -100, 100);
    this.invitePrompt = null;
    e.toast(`${n.name} приняли ${cost} золота и отвели войска`, "warn");
    e.dynasty.support("armiya", -6);
    e.onOpenPanel?.("");
    e.poke();
  }
  declineBattle(e: Engine) {
    const p = this.invitePrompt;
    if (!p) return;
    const n = e.nations.get(p.nation);
    this.invitePrompt = null;
    if (n) {
      n.incoming = false;
      n.marchT = 80;
      n.warScore = clamp(n.warScore - 22, -100, 100);
      const pillage = Math.min(e.player.gold, 200);
      e.player.gold -= pillage;
      if (e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness - 10, 0, 100);
      e.toast(`Вы уклонились от боя. ${n.name} разорили округу (−${pillage} зол.)`, "bad");
    }
    e.onOpenPanel?.("");
    e.poke();
  }

  update(e: Engine, dt: number) {
    if (!this.s.active || this.s.over) return;
    for (const u of this.s.units) {
      if (u.flash > 0) u.flash -= dt;
      if (u.shake > 0) u.shake -= dt * 2;
    }
    if (this.s.side === 1) {
      this.aiTimer -= dt;
      if (this.aiTimer <= 0) this.aiTurn(e);
    }
  }
}

type BattleLogKind = "hit" | "kill" | "move" | "info" | "spell" | "siege";
