import type { Engine } from "./engine";
import type { Royal, Faction, FactionId, GovForm } from "../types";
import { FACTION_BASE, GOVERNMENTS, TRAITS, AMBITIONS } from "../types/city";
import { NAMES_M, NAMES_F, SURNAMES } from "../data/citydata";
import { BUILDINGS } from "../data/buildings";
import { clamp } from "../lib/noise";
import { snd } from "../lib/sound";

const REFORM_COST = 420;

export class DynastySim {
  royals: Royal[] = [];
  factions: Faction[] = [];
  gov: GovForm = "monarchy";
  house = "Пламенных";
  uid = 1;
  coupWarn = 0;
  log: { day: number; text: string; kind: string }[] = [];

  init(day: number) {
    this.royals = []; this.uid = 1; this.gov = "monarchy";
    this.house = SURNAMES[Math.floor(Math.random() * SURNAMES.length)] + "ых";
    const ruler = this.make("ruler", 0, 26 + Math.floor(Math.random() * 12), day);
    const consort = this.make("consort", 1, ruler.age - 2 + Math.floor(Math.random() * 5), day);
    ruler.spouse = consort.uid; consort.spouse = ruler.uid;
    const heir = this.make("heir", Math.random() < 0.5 ? 0 : 1, 2 + Math.floor(Math.random() * 10), day);
    heir.parent = ruler.uid;
    this.make("relative", Math.random() < 0.5 ? 0 : 1, 30 + Math.floor(Math.random() * 25), day);
    this.factions = FACTION_BASE.map((f) => ({
      id: f.id, name: f.name, icon: f.icon,
      power: 10 + Math.floor(Math.random() * 12),
      support: 48 + Math.floor(Math.random() * 16),
      demand: f.demands[Math.floor(Math.random() * f.demands.length)],
    }));
    this.log = [{ day, text: `Род ${this.house} принял правление`, kind: "info" }];
  }

  private make(role: Royal["role"], sex: 0 | 1, age: number, day: number): Royal {
    const r: Royal = {
      uid: this.uid++, sex, age, role,
      name: sex === 0 ? NAMES_M[Math.floor(Math.random() * NAMES_M.length)] : NAMES_F[Math.floor(Math.random() * NAMES_F.length)],
      trait: TRAITS[Math.floor(Math.random() * TRAITS.length)],
      ambition: AMBITIONS[Math.floor(Math.random() * AMBITIONS.length)],
      loyalty: 55 + Math.floor(Math.random() * 40),
      skill: 25 + Math.floor(Math.random() * 60),
      alive: true, spouse: 0, parent: 0, born: day,
    };
    this.royals.push(r);
    return r;
  }

  ruler(): Royal | undefined { return this.royals.find((r) => r.alive && r.role === "ruler"); }
  heir(): Royal | undefined {
    const heirs = this.royals.filter((r) => r.alive && (r.role === "heir" || r.role === "child")).sort((a, b) => b.age - a.age);
    return heirs[0];
  }
  govDef() { return GOVERNMENTS.find((g) => g.id === this.gov)!; }
  avgSupport(): number {
    if (!this.factions.length) return 50;
    let w = 0, s = 0;
    for (const f of this.factions) { w += f.power; s += f.support * f.power; }
    return Math.round(s / Math.max(1, w));
  }
  support(id: FactionId, delta: number) {
    const f = this.factions.find((x) => x.id === id);
    if (f) f.support = clamp(f.support + delta, 0, 100);
  }
  addLog(e: Engine, text: string, kind = "info") {
    this.log.unshift({ day: e.day, text, kind });
    if (this.log.length > 30) this.log.pop();
  }

  onEdict(e: Engine, def: { id: string }) {
    switch (def.id) {
      case "nalog_up": this.support("narod", -10); this.support("kupcy", -6); this.support("znat", 5); break;
      case "nalog_down": this.support("narod", 8); this.support("kupcy", 9); this.support("znat", -4); break;
      case "prazdnik": this.support("narod", 12); this.support("cerkov", -3); break;
      case "molitva": this.support("cerkov", 14); this.support("magi", -6); break;
      case "rekruty": this.support("armiya", 14); this.support("narod", -8); break;
      case "nauka": this.support("magi", 10); this.support("cerkov", -5); break;
      case "komendant": this.support("armiya", 8); this.support("narod", -9); break;
      case "hleb": this.support("narod", 11); this.support("znat", -4); break;
      case "rayon_zapret": this.support("kupcy", -8); this.support("narod", 6); break;
      case "stroyka": this.support("kupcy", 5); this.support("narod", -4); break;
    }
    void e;
  }

  // ---------- Требования фракций ----------
  demandCost(e: Engine, f: Faction): number {
    return Math.floor(120 + f.power * 12 + (e.city.s.founded ? e.city.s.pop * 4 : 0));
  }
  acceptDemand(e: Engine, id: FactionId) {
    const f = this.factions.find((x) => x.id === id);
    if (!f) return;
    const cost = this.demandCost(e, f);
    if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота, чтобы удовлетворить ${f.name}`, "warn"); return; }
    e.player.gold -= cost;
    f.support = clamp(f.support + 20, 0, 100);
    f.power = clamp(f.power + 2, 5, 40);
    // побочные эффекты
    if (e.city.s.founded) {
      if (id === "narod") e.city.s.happiness = clamp(e.city.s.happiness + 8, 0, 100);
      if (id === "armiya") e.city.s.metrics.order += 8;
      if (id === "cerkov") e.city.s.metrics.faith += 10;
      if (id === "magi") e.city.s.metrics.science += 10;
      if (id === "kupcy") e.economy.bank.credit = clamp(e.economy.bank.credit + 6, 0, 100);
      if (id === "znat") e.city.s.metrics.order += 4;
    }
    for (const o of this.factions) if (o.id !== id && Math.random() < 0.5) o.support = clamp(o.support - 4, 0, 100);
    const next = FACTION_BASE.find((b) => b.id === id)!;
    f.demand = next.demands[Math.floor(Math.random() * next.demands.length)];
    e.toast(`${f.name}: требование удовлетворено`, "good");
    this.addLog(e, `${f.name} довольны: «${f.demand}» обещано`, "good");
    snd.craft();
    e.poke();
  }
  refuseDemand(e: Engine, id: FactionId) {
    const f = this.factions.find((x) => x.id === id);
    if (!f) return;
    f.support = clamp(f.support - 14, 0, 100);
    const next = FACTION_BASE.find((b) => b.id === id)!;
    f.demand = next.demands[Math.floor(Math.random() * next.demands.length)];
    e.toast(`${f.name} недовольны отказом`, "warn");
    this.addLog(e, `${f.name}: отказ. Ропот в палате`, "warn");
    snd.ui();
    e.poke();
  }

  // ---------- Реформы ----------
  canReform(e: Engine, gov: GovForm): { ok: boolean; reason: string } {
    if (gov === this.gov) return { ok: false, reason: "Это нынешняя форма правления" };
    const has = (id: string) => e.buildings.some((b) => b.done && b.def === id);
    const sup = (id: FactionId) => this.factions.find((f) => f.id === id)?.support ?? 0;
    switch (gov) {
      case "monarchy": return { ok: sup("znat") >= 45, reason: "Знать должна поддерживать (45+)" };
      case "republic":
        if (!has("parlament")) return { ok: false, reason: "Нужен Парламент" };
        return { ok: sup("kupcy") >= 60, reason: "Купцы должны поддерживать (60+)" };
      case "theocracy":
        if (!has("sobor") && !has("hram")) return { ok: false, reason: "Нужен Собор или Храм" };
        return { ok: sup("cerkov") >= 60, reason: "Церковь должна поддерживать (60+)" };
      case "dictature":
        if (!has("kazarmy")) return { ok: false, reason: "Нужны Казармы" };
        return { ok: sup("armiya") >= 60, reason: "Армия должна поддерживать (60+)" };
      case "magocracy":
        if (!has("obsidian_tron")) return { ok: false, reason: "Нужен Обсидиановый трон" };
        return { ok: sup("magi") >= 60, reason: "Круг магов должен поддерживать (60+)" };
      case "technocracy":
        if (!has("universitet")) return { ok: false, reason: "Нужен Университет" };
        return { ok: (sup("magi") + sup("kupcy")) / 2 >= 55, reason: "Маги и купцы вместе (55+)" };
    }
  }
  reform(e: Engine, gov: GovForm) {
    const c = this.canReform(e, gov);
    if (!c.ok) { e.toast(c.reason, "warn"); return; }
    if (e.player.gold < REFORM_COST) { e.toast(`Реформа стоит ${REFORM_COST} золота`, "warn"); return; }
    e.player.gold -= REFORM_COST;
    this.gov = gov;
    const def = this.govDef();
    e.toast(`Провозглашена новая форма правления: ${def.name}!`, "good");
    this.addLog(e, `Реформа: ${def.name}`, "good");
    snd.levelup();
    if (e.city.s.founded) e.city.s.paradeT = 8;
    for (const f of this.factions) f.support = clamp(f.support + (Math.random() * 16 - 6), 0, 100);
    e.addXp(50);
    e.poke();
  }

  // ---------- Брак и наследие ----------
  arrangeMarriage(e: Engine, uid: number) {
    const r = this.royals.find((x) => x.uid === uid && x.alive);
    if (!r) return;
    if (r.spouse) { e.toast(`${r.name} уже в браке`, "info"); return; }
    if (r.age < 16) { e.toast(`${r.name} ещё слишком юн для брака`, "warn"); return; }
    const cost = 260;
    if (e.player.gold < cost) { e.toast(`На свадьбу нужно ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    const sp = this.make(r.role === "ruler" ? "consort" : "relative", r.sex === 0 ? 1 : 0, Math.max(16, r.age - 3 + Math.floor(Math.random() * 6)), e.day);
    sp.spouse = r.uid; r.spouse = sp.uid;
    this.support("znat", 8);
    if (e.city.s.founded) e.city.s.paradeT = 6;
    e.toast(`Свадьба! ${r.name} и ${sp.name} соединили судьбы`, "good");
    this.addLog(e, `Брак: ${r.name} × ${sp.name}`, "good");
    snd.levelup();
    e.poke();
  }

  /** Брак с иноземным домом (дипломатия) */
  arrangeMarriageForeign(e: Engine, uid: number, house: string) {
    const r = this.royals.find((x) => x.uid === uid && x.alive);
    if (!r || r.spouse) return;
    const sp = this.make(r.role === "ruler" ? "consort" : "relative", r.sex === 0 ? 1 : 0, Math.max(16, r.age - 2), e.day);
    sp.spouse = r.uid; r.spouse = sp.uid;
    sp.trait = "Прекрасный";
    this.addLog(e, `Брак: ${r.name} × ${sp.name} из дома ${house}`, "good");
    e.stats.royalMarriage = (e.stats.royalMarriage ?? 0) + 1;
    this.support("znat", 6);
  }

  designateHeir(e: Engine, uid: number) {
    const r = this.royals.find((x) => x.uid === uid && x.alive);
    if (!r || r.role === "ruler") return;
    for (const o of this.royals) if (o.role === "heir") o.role = "child";
    r.role = "heir";
    e.toast(`${r.name} объявлен наследником рода ${this.house}`, "good");
    this.addLog(e, `Наследник: ${r.name}`, "info");
    this.support("znat", 5);
    e.poke();
  }

  private succession(e: Engine) {
    const heir = this.heir();
    if (heir) {
      heir.role = "ruler";
      e.toast(`Новый правитель: ${heir.name} из рода ${this.house}`, "info");
      this.addLog(e, `Восшествие: ${heir.name}`, "good");
      for (const f of this.factions) f.support = clamp(f.support - 5 + Math.random() * 10, 0, 100);
      snd.levelup();
    } else {
      const rel = this.royals.find((r) => r.alive && r.role === "relative");
      if (rel) { rel.role = "ruler"; e.toast(`Трон занял родич — ${rel.name}. Знать ропщет`, "warn"); this.support("znat", -12); }
      else {
        const n = this.make("ruler", Math.random() < 0.5 ? 0 : 1, 22, e.day);
        e.toast(`Род пресёкся! Правителем стал ${n.name} из младшей ветви`, "bad");
        for (const f of this.factions) f.support = clamp(f.support - 12, 0, 100);
      }
      if (e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness - 10, 0, 100);
    }
  }

  // ---------- Ежедневный тик ----------
  dayTick(e: Engine) {
    for (const r of [...this.royals]) {
      if (!r.alive) continue;
      r.age += 1;
      if (r.age > 58 && Math.random() < (r.age - 58) * 0.02 + 0.02) {
        r.alive = false;
        e.toast(`${r.name} (${r.role === "ruler" ? "правитель" : "член рода"}) скончался в ${r.age} лет`, r.role === "ruler" ? "bad" : "info");
        this.addLog(e, `Смерть: ${r.name}, ${r.age} лет`, "bad");
        if (r.role === "ruler") this.succession(e);
      }
    }
    // рождение наследников
    const ruler = this.ruler();
    if (ruler && ruler.spouse) {
      const sp = this.royals.find((x) => x.uid === ruler.spouse && x.alive);
      const kids = this.royals.filter((x) => x.alive && (x.role === "heir" || x.role === "child")).length;
      if (sp && sp.age < 46 && kids < 4 && Math.random() < 0.1) {
        const baby = this.make(kids === 0 ? "heir" : "child", Math.random() < 0.5 ? 0 : 1, 0, e.day);
        baby.parent = ruler.uid;
        e.toast(`В роду ${this.house} родился ${baby.sex === 0 ? "сын" : "дочь"} — ${baby.name}`, "good");
        this.addLog(e, `Рождение: ${baby.name}`, "good");
      }
    }
    // интриги
    if (Math.random() < 0.22) this.intrigue(e);
    // требования фракций дрейфуют
    for (const f of this.factions) {
      f.support = clamp(f.support + (Math.random() * 6 - 3) + (e.city.s.founded ? (e.city.s.happiness - 50) * 0.05 : 0), 0, 100);
      if (Math.random() < 0.18) {
        const base = FACTION_BASE.find((b) => b.id === f.id)!;
        f.demand = base.demands[Math.floor(Math.random() * base.demands.length)];
      }
    }
    // угроза переворота
    const avg = this.avgSupport();
    if (avg < 24) {
      this.coupWarn += 1;
      if (this.coupWarn === 1) e.toast("В палате шепчутся о перевороте! Поддержка фракций на дне", "bad");
      if (this.coupWarn >= 3) this.coup(e);
    } else this.coupWarn = Math.max(0, this.coupWarn - 1);
  }

  private intrigue(e: Engine) {
    const roll = Math.random();
    const f = this.factions[Math.floor(Math.random() * this.factions.length)];
    if (roll < 0.25) {
      const loss = Math.floor(30 + Math.random() * 120);
      e.player.gold = Math.max(0, e.player.gold - loss);
      e.toast(`Казнокрадство! Из казны пропало ${loss} золота`, "bad");
      this.addLog(e, `Интрига: хищение ${loss} зол.`, "bad");
    } else if (roll < 0.45) {
      const gain = Math.floor(40 + Math.random() * 140);
      e.player.gold += gain;
      e.toast(`Дар от ${f.name}: +${gain} золота`, "good");
      this.addLog(e, `${f.name} преподнесли дар`, "good");
      this.support(f.id, 4);
    } else if (roll < 0.65) {
      const r = this.royals.filter((x) => x.alive)[Math.floor(Math.random() * this.royals.filter((x) => x.alive).length)];
      if (r) {
        r.loyalty = clamp(r.loyalty - 20 - Math.random() * 20, 0, 100);
        e.toast(`${r.name} плетёт интриги против трона (верность ${Math.round(r.loyalty)})`, "warn");
        this.addLog(e, `Заговор: ${r.name}`, "warn");
      }
    } else if (roll < 0.8) {
      this.support(f.id, 9);
      e.toast(`${f.name} поддержали вашу политику`, "good");
    } else {
      this.support(f.id, -9);
      e.toast(`${f.name} недовольны положением дел`, "warn");
    }
  }

  private coup(e: Engine) {
    this.coupWarn = 0;
    const loss = Math.floor(e.player.gold * 0.35);
    e.player.gold -= loss;
    e.toast(`ПЕРЕВОРОТ! Заговорщики взяли казну (−${loss} зол.) и навязали диктатуру`, "bad");
    this.addLog(e, "Переворот в столице", "bad");
    this.gov = "dictature";
    for (const f of this.factions) f.support = clamp(f.support + 22, 0, 100);
    if (e.city.s.founded) {
      e.city.s.happiness = clamp(e.city.s.happiness - 18, 0, 100);
      e.city.s.riot = 0; e.city.s.rioting = false;
      e.npcs.calmRiot();
    }
    const ruler = this.ruler();
    if (ruler) { ruler.alive = false; this.succession(e); }
    e.shake = 0.8;
    snd.thunder();
    e.poke();
  }

  /** Требование фракции выполнено постройкой? (мягкая подсказка) */
  demandHint(e: Engine, f: Faction): boolean {
    const has = (id: string) => e.buildings.some((b) => b.done && b.def === id);
    const d = f.demand.toLowerCase();
    if (d.includes("дворец")) return has("dvorec");
    if (d.includes("биржу")) return has("birzha");
    if (d.includes("храм")) return has("hram") || has("sobor");
    if (d.includes("казармы")) return has("kazarmy");
    if (d.includes("алтарь")) return has("altar");
    if (d.includes("портал")) return has("portal");
    if (d.includes("академию")) return has("akademiya") || has("universitet");
    if (d.includes("стены")) return e.buildings.some((b) => b.done && BUILDINGS[b.def]?.cat === "Оборона");
    return false;
  }
}
