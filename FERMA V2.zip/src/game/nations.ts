import type { Engine } from "./engine";
import type { Nation, NationChar, Envoy } from "../types/war";

import {
  NATION_NAMES, NATION_CAPITALS, NATION_RULERS_M, NATION_RULERS_F,
  RELIGIONS, CULTURES, NATION_GOVS, FLAG_SYMS, FLAG_BG, FLAG_FG,
} from "../data/army";
import { mulberry32, clamp } from "../lib/noise";
import { snd } from "../lib/sound";

const CHARS: NationChar[] = ["agro", "mir", "torg", "vera", "hitr", "bezum", "mudr"];

export class NationSim {
  nations: Nation[] = [];
  envoys: Envoy[] = [];
  league = { member: false, influence: 0, founded: false };
  cb: Record<string, number> = {};
  warLog: { day: number; text: string; kind: string }[] = [];
  fame = 0;
  guerrilla = false;
  private envoyUid = 1;
  private aiT = 14;
  private tributeT = 60;

  init(seed: number) {
    const r = mulberry32(seed ^ 0x51a7);
    this.nations = [];
    this.envoys = [];
    this.cb = {};
    this.warLog = [];
    this.league = { member: false, influence: 0, founded: false };
    const count = 14 + Math.floor(r() * 5);
    const names = [...NATION_NAMES];
    for (let i = 0; i < count && names.length; i++) {
      const idx = Math.floor(r() * names.length);
      const [name, adj] = names.splice(idx, 1)[0];
      const ch = CHARS[Math.floor(r() * CHARS.length)];
      const ang = (i / count) * Math.PI * 2 + r() * 0.5;
      const dist = 180 + r() * 900;
      const rulerM = r() < 0.72;
      const strength = 0.5 + r() * 1.7 + (dist / 900) * 0.8;
      this.nations.push({
        id: `n${i}`, name, adj,
        flag: {
          bg: FLAG_BG[Math.floor(r() * FLAG_BG.length)],
          fg: FLAG_FG[Math.floor(r() * FLAG_FG.length)],
          sym: FLAG_SYMS[Math.floor(r() * FLAG_SYMS.length)],
        },
        capital: NATION_CAPITALS[i % NATION_CAPITALS.length],
        ruler: (rulerM ? NATION_RULERS_M[Math.floor(r() * NATION_RULERS_M.length)] : NATION_RULERS_F[Math.floor(r() * NATION_RULERS_F.length)])
          + (rulerM ? " " : " ") + ["Первый", "Второй", "Третий", "Старый", "Юный", "Хромой", "Светлый", "Тёмный"][Math.floor(r() * 8)],
        religion: RELIGIONS[Math.floor(r() * RELIGIONS.length)],
        culture: CULTURES[Math.floor(r() * CULTURES.length)],
        gov: NATION_GOVS[Math.floor(r() * NATION_GOVS.length)],
        char: ch,
        x: Math.round(Math.cos(ang) * dist), y: Math.round(Math.sin(ang) * dist),
        pop: Math.floor(400 + r() * 5200 * strength),
        gold: Math.floor(300 + r() * 2600 * strength),
        tech: Math.floor(1 + r() * 5), magic: Math.floor(r() * 5),
        army: Math.max(2, Math.round((4 + r() * 16) * strength)),
        fleet: Math.round(r() * 8 * strength),
        cities: 1 + Math.floor(r() * 5),
        rel: Math.round((ch === "mir" ? 20 : ch === "agro" ? -18 : 0) + r() * 40 - 15),
        state: "peace", truceUntil: 0, tribute: 0, league: r() < 0.45,
        spyKnown: 0, wars: [], allies: [], aggression: ch === "agro" ? 0.7 : ch === "bezum" ? 0.55 : ch === "mir" ? 0.08 : 0.28,
        lastAction: "живут своей жизнью", warScore: 0, siegeOf: null, marchT: 0, incoming: false,
      });
    }
    // взаимные войны/союзы между ИИ
    for (const n of this.nations) {
      for (const o of this.nations) {
        if (n === o) continue;
        const rr = r();
        if (rr < 0.06 && !n.wars.includes(o.id)) { n.wars.push(o.id); o.wars.push(n.id); }
        else if (rr > 0.94 && !n.allies.includes(o.id)) { n.allies.push(o.id); o.allies.push(n.id); }
      }
    }
    this.league.founded = true;
  }

  get(id: string): Nation | undefined { return this.nations.find((n) => n.id === id); }
  atWar(): Nation[] { return this.nations.filter((n) => n.state === "war"); }
  allies(): Nation[] { return this.nations.filter((n) => n.state === "ally"); }
  vassals(): Nation[] { return this.nations.filter((n) => n.state === "vassal"); }
  overlord(): Nation | undefined { return this.nations.find((n) => n.state === "overlord"); }
  log(e: Engine, text: string, kind = "info") {
    this.warLog.unshift({ day: e.day, text, kind });
    if (this.warLog.length > 40) this.warLog.pop();
  }
  hasCB(id: string, day: number): boolean { return (this.cb[id] ?? -1) >= day; }

  /** Оценка силы нации (видимая игроку зависит от разведки) */
  strength(n: Nation): number { return Math.round(n.army * 12 + n.fleet * 8 + n.tech * 14 + n.magic * 10); }
  visibleStrength(n: Nation): string {
    if (n.spyKnown >= 2) return `${this.strength(n)}`;
    if (n.spyKnown === 1) return `~${Math.round(this.strength(n) / 25) * 25}`;
    const s = this.strength(n);
    return s > 320 ? "грозная" : s > 200 ? "немалая" : s > 110 ? "средняя" : "малая";
  }
  relLabel(rel: number): string {
    return rel > 70 ? "братья навек" : rel > 40 ? "добрые друзья" : rel > 10 ? "дружелюбны"
      : rel > -10 ? "нейтральны" : rel > -40 ? "холодны" : rel > -70 ? "враждебны" : "смертельные враги";
  }

  // ---------- Дипломатия игрока ----------
  act(e: Engine, id: string, actId: string) {
    const n = this.get(id);
    if (!n) return;
    const G = (v: number) => { if (e.player.gold < v) { e.toast(`Нужно ${v} золота`, "warn"); return false; } e.player.gold -= v; return true; };

    switch (actId) {
      case "gift": {
        if (!G(200)) return;
        n.rel = clamp(n.rel + 15, -100, 100);
        e.toast(`${n.name}: дары приняты с поклоном (+15)`, "good");
        snd.pickup();
        break;
      }
      case "trade": {
        if (n.rel < 20) { e.toast("Слишком холодны для договора", "warn"); return; }
        if (!G(350)) return;
        n.rel = clamp(n.rel + 8, -100, 100);
        n.tribute = Math.max(n.tribute, Math.round(3 + n.pop / 900));
        e.toast(`Торговый договор с ${n.name}: +${n.tribute} зол./день`, "good");
        e.dynasty.support("kupcy", 6);
        snd.craft();
        break;
      }
      case "alliance": {
        if (n.rel < 55) { e.toast(`${n.name} не готовы к союзу (нужно +55)`, "warn"); return; }
        if (!G(600)) return;
        n.state = "ally"; n.rel = clamp(n.rel + 12, -100, 100);
        this.log(e, `Союз с ${n.name}`, "good");
        e.toast(`Союз заключён: ${n.name} — братья навек!`, "good");
        e.dynasty.support("znat", 6);
        snd.levelup();
        break;
      }
      case "marriage": {
        if (n.rel < 35) { e.toast("Правящий дом отказал в браке", "warn"); return; }
        if (!G(800)) return;
        n.rel = clamp(n.rel + 25, -100, 100);
        n.truceUntil = e.day + 20;
        if (n.state === "war") { n.state = "peace"; n.warScore = 0; }
        const r = e.dynasty.royals.find((x) => x.alive && !x.spouse && x.age >= 16);
        if (r) {
          e.dynasty.arrangeMarriageForeign(e, r.uid, n.name);
        }
        this.log(e, `Династический брак с ${n.name}`, "good");
        e.toast(`Свадьба с домом ${n.name}! Мир скреплён кровью`, "good");
        e.dynasty.support("znat", 10);
        snd.levelup();
        break;
      }
      case "vassal": {
        const mine = e.army.power() + (e.city.s.founded ? e.city.s.pop * 1.2 : 0);
        const theirs = this.strength(n);
        if (mine < theirs * 1.6) { e.toast(`${n.name} смеются над требованием. Нужна сила втрое`, "warn"); return; }
        n.state = "vassal"; n.rel = clamp(n.rel - 15, -100, 100);
        n.tribute = Math.round(6 + n.pop / 550);
        this.log(e, `${n.name} стали вашим вассалом`, "good");
        e.toast(`${n.name} склонили голову! Дань ${n.tribute} зол./день`, "good");
        this.fame += 18;
        e.addXp(80);
        snd.levelup();
        break;
      }
      case "submit": {
        n.state = "overlord";
        n.rel = clamp(n.rel + 30, -100, 100);
        if (n.state === "overlord") { n.wars = n.wars.filter((w) => w !== "player"); }
        this.log(e, `Вы признали сюзереном ${n.name}`, "warn");
        e.toast(`Вы под рукой ${n.name}. Защита есть, но гордость уязвлена`, "warn");
        e.dynasty.support("znat", -12);
        e.dynasty.support("narod", -6);
        break;
      }
      case "tribute": {
        const mine = e.army.power();
        if (mine < this.strength(n) * 1.2) { e.toast(`${n.name} отказали и оскорбились`, "warn"); n.rel = clamp(n.rel - 12, -100, 100); return; }
        n.tribute = Math.round(4 + n.pop / 800);
        n.rel = clamp(n.rel - 18, -100, 100);
        e.toast(`${n.name} согласились платить ${n.tribute} зол./день`, "good");
        break;
      }
      case "embargo": {
        n.rel = clamp(n.rel - 22, -100, 100);
        n.gold = Math.floor(n.gold * 0.85);
        n.tribute = 0;
        e.toast(`Санкции против ${n.name}. Их казна худеет`, "info");
        e.dynasty.support("kupcy", -4);
        break;
      }
      case "cb": {
        if (!G(250)) return;
        this.cb[n.id] = e.day + 10;
        e.toast(`Найден повод к войне с ${n.name} (10 дней)`, "info");
        this.log(e, `Casus belli против ${n.name}`, "info");
        snd.ui();
        break;
      }
      case "war": {
        this.declareWar(e, n, true);
        break;
      }
      case "peace": {
        this.offerPeace(e, n);
        break;
      }
    }
    e.poke();
  }

  declareWar(e: Engine, n: Nation, byPlayer: boolean) {
    if (n.state === "war") return;
    if (!byPlayer && !e.modeAllowsWar()) return;
    const hadCB = this.hasCB(n.id, e.day);
    n.state = "war";
    n.warScore = 0;
    n.rel = clamp(n.rel - 45, -100, 100);
    n.marchT = 70 + Math.random() * 90;
    if (byPlayer) {
      if (!hadCB) {
        e.dynasty.support("znat", -10);
        e.dynasty.support("cerkov", -8);
        e.dynasty.support("narod", -6);
        this.fame -= 8;
        e.toast(`Война ${n.name} объявлена без повода. Позор пятнает имя рода`, "bad");
        for (const o of this.nations) if (o !== n && o.state === "peace") o.rel = clamp(o.rel - 7, -100, 100);
      } else {
        delete this.cb[n.id];
        e.dynasty.support("armiya", 8);
        e.toast(`Война с ${n.name} объявлена по праву!`, "warn");
      }
      // союзники врага вступают
      for (const aId of n.allies) {
        const a = this.get(aId);
        if (a && a.state === "peace" && Math.random() < 0.6) {
          a.state = "war"; a.rel = clamp(a.rel - 30, -100, 100); a.marchT = 130 + Math.random() * 120;
          e.toast(`${a.name} вступили в войну на стороне ${n.name}`, "bad");
        }
      }
    } else {
      e.toast(`${n.name} объявили вам войну!`, "bad");
      // ваши союзники помогают
      for (const a of this.allies()) {
        if (Math.random() < 0.7) {
          this.log(e, `${a.name} поддержали вас против ${n.name}`, "good");
          e.toast(`Союзник ${a.name} идёт вам на помощь`, "good");
          n.army = Math.max(1, n.army - 2);
        }
      }
    }
    this.log(e, `Война: ${n.name}`, "bad");
    snd.thunder();
    e.shake = 0.6;
  }

  offerPeace(e: Engine, n: Nation) {
    if (n.state !== "war") return;
    const ws = n.warScore;
    if (ws >= 55) {
      // победа игрока — аннексия/вассалитет
      const loot = Math.floor(n.gold * 0.45 + 300);
      e.player.gold += loot;
      n.gold = Math.floor(n.gold * 0.55);
      if (ws >= 85 && n.cities <= 2) {
        e.toast(`${n.name} покорены и вошли в вашу державу! Добыча ${loot} зол.`, "good");
        n.state = "vassal"; n.tribute = Math.round(8 + n.pop / 500);
        this.fame += 25;
      } else {
        n.state = "peace"; n.tribute = Math.round(4 + ws / 8);
        n.cities = Math.max(1, n.cities - 1);
        e.toast(`Мир на ваших условиях: контрибуция ${loot} зол., дань ${n.tribute}/день`, "good");
        this.fame += 12;
      }
      e.addXp(120);
      e.dynasty.support("armiya", 10);
      e.dynasty.support("narod", 8);
      snd.levelup();
    } else if (ws <= -55) {
      const pay = Math.min(e.player.gold, Math.floor(400 + Math.abs(ws) * 12));
      e.player.gold -= pay;
      n.gold += pay;
      n.state = "peace"; n.rel = clamp(n.rel + 12, -100, 100);
      if (e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness - 12, 0, 100);
      e.toast(`Унизительный мир с ${n.name}: репарации ${pay} золота`, "bad");
      e.dynasty.support("armiya", -12);
      e.dynasty.support("znat", -8);
    } else {
      const accept = Math.abs(ws) < 20 || Math.random() < 0.5 + ws / 120;
      if (!accept) { e.toast(`${n.name} отвергли мир — война продолжается`, "warn"); n.rel = clamp(n.rel - 4, -100, 100); return; }
      n.state = "peace"; n.rel = clamp(n.rel + 8, -100, 100);
      e.toast(`Белый мир с ${n.name}. Оружие в ножны`, "info");
    }
    n.truceUntil = e.day + 12;
    n.warScore = 0;
    n.incoming = false;
    n.siegeOf = null;
    this.guerrilla = false;
    this.log(e, `Мир с ${n.name}`, "good");
    e.poke();
  }

  // ---------- Шпионаж ----------
  spy(e: Engine, id: string, actId: string) {
    e.stats.spy = (e.stats.spy ?? 0) + 1;
    const n = this.get(id);
    if (!n) return;
    const costs: Record<string, number> = { recon: 120, sabotage: 300, steal: 350, bribe: 500, revolt: 700 };
    const cost = costs[actId] ?? 100;
    if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    const skill = 0.55 + (e.city.s.founded ? e.city.s.metrics.science / 300 : 0) + this.fame / 400;
    const ok = Math.random() < clamp(skill, 0.2, 0.92);
    if (!ok) {
      n.rel = clamp(n.rel - 16, -100, 100);
      e.toast(`Лазутчик схвачен в ${n.capital}! ${n.name} в ярости`, "bad");
      this.log(e, `Провал шпионажа: ${n.name}`, "bad");
      if (n.char === "agro" && Math.random() < 0.4) this.declareWar(e, n, false);
      e.poke();
      return;
    }
    switch (actId) {
      case "recon":
        n.spyKnown = Math.min(3, n.spyKnown + 1);
        e.toast(`Разведка: ${n.name} — войско ${n.army} полков, казна ${n.gold} зол.`, "good");
        break;
      case "sabotage": {
        const loss = Math.max(1, Math.round(n.army * 0.18));
        n.army -= loss; n.gold = Math.floor(n.gold * 0.86);
        n.rel = clamp(n.rel - 8, -100, 100);
        e.toast(`Диверсия удалась: ${n.name} потеряли ${loss} полков`, "good");
        break;
      }
      case "steal": {
        if (n.tech > 1) n.tech--;
        e.addXp(40);
        // крадём настоящую технологию из дерева
        if (!e.lore.stealTech(e, n.tech)) {
          e.lore.addScience(e, 250 + n.tech * 120);
          e.toast(`Выкрадены чертежи ${n.adj} мастеров! +наука`, "good");
        }
        e.dynasty.support("magi", 5);
        break;
      }
      case "bribe": {
        const loss = Math.max(1, Math.round(n.army * 0.12));
        n.army -= loss;
        if (Math.random() < 0.45) {
          const g = e.army.makeGeneral();
          g.name = `${g.name}`; g.title = `Перебежчик из ${n.capital}`;
          e.army.generals.push(g);
          e.toast(`${g.name} перешёл на вашу сторону вместе с дружиной!`, "good");
        } else e.toast(`Подкуп удался: ${n.name} лишились ${loss} полков`, "good");
        n.rel = clamp(n.rel - 10, -100, 100);
        break;
      }
      case "revolt": {
        n.pop = Math.floor(n.pop * 0.85);
        n.army = Math.max(1, Math.round(n.army * 0.75));
        n.gold = Math.floor(n.gold * 0.7);
        n.rel = clamp(n.rel - 20, -100, 100);
        n.lastAction = "давят восстание";
        e.toast(`В ${n.capital} вспыхнуло восстание! Страна ослаблена надолго`, "good");
        this.log(e, `Восстание в ${n.name}`, "warn");
        break;
      }
    }
    snd.craft();
    e.poke();
  }

  // ---------- Лига Наций ----------
  joinLeague(e: Engine) {
    if (this.league.member) return;
    const cost = 900;
    if (e.player.gold < cost) { e.toast(`Вступление стоит ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    this.league.member = true;
    this.league.influence = 10;
    for (const n of this.nations) if (n.league) n.rel = clamp(n.rel + 12, -100, 100);
    e.toast("Вы вступили в Лигу Наций. Голос вашей державы слышен", "good");
    this.log(e, "Вступление в Лигу Наций", "good");
    snd.levelup();
    e.poke();
  }
  leaveLeague(e: Engine) {
    this.league.member = false;
    for (const n of this.nations) if (n.league) n.rel = clamp(n.rel - 15, -100, 100);
    e.toast("Вы покинули Лигу. Многие сочли это вызовом", "warn");
    e.poke();
  }
  leaguePush(e: Engine, id: string) {
    if (!this.league.member) { e.toast("Сначала вступите в Лигу", "warn"); return; }
    const n = this.get(id);
    if (!n) return;
    const cost = 200;
    if (this.league.influence < 10) { e.toast("Мало влияния в Лиге (нужно 10)", "warn"); return; }
    if (e.player.gold < cost) { e.toast(`Нужно ${cost} золота`, "warn"); return; }
    e.player.gold -= cost;
    this.league.influence -= 10;
    if (n.state === "war") {
      n.warScore -= 12;
      n.rel = clamp(n.rel + 8, -100, 100);
      e.toast(`Лига осудила ${n.name}. Их положение шатко`, "good");
      if (Math.random() < 0.4) this.offerPeace(e, n);
    } else {
      for (const o of this.nations) if (o.league && o !== n) o.rel = clamp(o.rel - 2, -100, 100);
      n.rel = clamp(n.rel - 10, -100, 100);
      n.gold = Math.floor(n.gold * 0.9);
      e.toast(`Лига ввела санкции против ${n.name}`, "info");
    }
    e.poke();
  }

  // ---------- Послы ----------
  private sendEnvoy(e: Engine, n: Nation, kind: Envoy["kind"], text: string, gold: number, act: string) {
    if (this.envoys.length > 4) this.envoys.shift();
    this.envoys.push({ id: this.envoyUid++, nation: n.id, text, kind, day: e.day, gold, act });
    e.toast(`Посол из ${n.name} у ваших ворот`, kind === "demand" ? "warn" : "info");
    snd.uiOpen();
    e.poke();
  }
  answerEnvoy(e: Engine, envoyId: number, accept: boolean) {
    const en = this.envoys.find((x) => x.id === envoyId);
    if (!en) return;
    const n = this.get(en.nation);
    this.envoys = this.envoys.filter((x) => x.id !== envoyId);
    if (!n) { e.poke(); return; }
    if (accept) {
      switch (en.act) {
        case "pay":
          if (e.player.gold < en.gold) { e.toast("Нечем платить! Оскорбление принято за отказ", "bad"); n.rel = clamp(n.rel - 20, -100, 100); this.declareWar(e, n, false); break; }
          e.player.gold -= en.gold;
          n.rel = clamp(n.rel + 14, -100, 100);
          n.truceUntil = e.day + 10;
          e.toast(`${n.name} приняли ${en.gold} золота и отступили`, "info");
          break;
        case "ally":
          n.state = "ally"; n.rel = clamp(n.rel + 18, -100, 100);
          e.toast(`Союз с ${n.name} заключён`, "good");
          break;
        case "trade":
          n.tribute = Math.max(n.tribute, Math.round(3 + n.pop / 1000));
          n.rel = clamp(n.rel + 10, -100, 100);
          e.toast(`Торговый договор с ${n.name}: +${n.tribute} зол./день`, "good");
          break;
        case "gift":
          e.player.gold += en.gold;
          n.rel = clamp(n.rel + 6, -100, 100);
          e.toast(`Дар от ${n.name}: +${en.gold} золота`, "good");
          break;
        case "vassalize":
          n.state = "overlord"; n.rel = clamp(n.rel + 20, -100, 100);
          e.toast(`Вы признали ${n.name} сюзереном`, "warn");
          e.dynasty.support("znat", -10);
          break;
      }
    } else {
      switch (en.act) {
        case "pay": case "vassalize":
          n.rel = clamp(n.rel - 25, -100, 100);
          e.toast(`Вы отказали ${n.name}. Гонец умчался без поклона`, "warn");
          if (Math.random() < 0.65) this.declareWar(e, n, false);
          else e.dynasty.support("armiya", 5);
          break;
        case "gift":
          n.rel = clamp(n.rel - 6, -100, 100);
          e.toast("Дар отвергнут", "info");
          break;
        default:
          n.rel = clamp(n.rel - 10, -100, 100);
          e.toast(`${n.name} огорчены отказом`, "info");
      }
    }
    e.poke();
  }

  // ---------- Жизнь ИИ ----------
  update(e: Engine, dt: number) {
    if (!this.nations.length) return;
    // дань/договоры
    this.tributeT -= dt;
    if (this.tributeT <= 0) {
      this.tributeT = 60;
      let income = 0;
      for (const n of this.nations) {
        if (n.state === "overlord") { income -= Math.round(6 + (e.city.s.founded ? e.city.s.pop * 0.05 : 1)); continue; }
        if (n.tribute > 0 && n.state !== "war") income += n.tribute;
      }
      if (income !== 0) {
        e.player.gold = Math.max(0, e.player.gold + income);
        if (income > 0) e.addFloater(`+${income} дань`, "#f2c14e", e.player.x, e.player.y - 52);
      }
      if (this.league.member) this.league.influence = Math.min(100, this.league.influence + 4);
    }

    // марш вражеских армий
    for (const n of this.nations) {
      if (n.state !== "war") continue;
      n.marchT -= dt;
      if (n.marchT <= 0 && !n.incoming && !e.battle.s.active) {
        n.incoming = true;
        n.marchT = 55 + Math.random() * 40;
        e.toast(`Войско ${n.name} идёт на ваши земли! Готовьтесь к битве`, "bad");
        this.log(e, `${n.name} вторгаются`, "bad");
        snd.thunder();
        e.poke();
      } else if (n.incoming && n.marchT <= 0 && !e.battle.s.active) {
        // армия дошла — начинается осада/битва
        n.marchT = 60;
        e.battle.startInvasion(e, n);
      }
    }

    // тик мировой политики
    this.aiT -= dt;
    if (this.aiT <= 0) {
      this.aiT = 12 + Math.random() * 10;
      this.aiTick(e);
    }
  }

  private aiTick(e: Engine) {
    const n = this.nations[Math.floor(Math.random() * this.nations.length)];
    if (!n) return;
    // собственное развитие
    n.gold += Math.round(n.pop * 0.02);
    if (Math.random() < 0.25) n.army += 1;
    if (Math.random() < 0.08 && n.gold > 600) { n.tech++; n.gold -= 400; n.lastAction = "исследуют ремёсла"; }
    if (Math.random() < 0.06 && n.gold > 500) { n.cities++; n.gold -= 350; n.lastAction = "основали новый город"; }

    // войны между ИИ
    if (Math.random() < n.aggression * 0.45) {
      const target = this.nations[Math.floor(Math.random() * this.nations.length)];
      if (target && target !== n && !n.wars.includes(target.id) && !n.allies.includes(target.id)) {
        n.wars.push(target.id); target.wars.push(n.id);
        n.lastAction = `воюют с ${target.name}`;
        target.lastAction = `отбиваются от ${n.name}`;
        if (Math.random() < 0.4) this.log(e, `${n.name} напали на ${target.name}`, "info");
      }
    }
    // разрешение чужих войн
    for (const w of [...n.wars]) {
      if (Math.random() < 0.3) {
        const o = this.get(w);
        if (!o) { n.wars = n.wars.filter((x) => x !== w); continue; }
        const win = this.strength(n) + Math.random() * 100 > this.strength(o) + Math.random() * 100;
        const winner = win ? n : o, loser = win ? o : n;
        winner.gold += 200; winner.cities += Math.random() < 0.3 ? 1 : 0;
        loser.army = Math.max(1, Math.round(loser.army * 0.75));
        loser.cities = Math.max(1, loser.cities - (Math.random() < 0.3 ? 1 : 0));
        n.wars = n.wars.filter((x) => x !== w);
        o.wars = o.wars.filter((x) => x !== n.id);
        winner.lastAction = `победили в войне с ${loser.name}`;
        if (Math.random() < 0.35) this.log(e, `${winner.name} одолели ${loser.name}`, "info");
      }
    }
    // союзы
    if (Math.random() < 0.12) {
      const o = this.nations[Math.floor(Math.random() * this.nations.length)];
      if (o && o !== n && !n.allies.includes(o.id) && !n.wars.includes(o.id)) {
        n.allies.push(o.id); o.allies.push(n.id);
        n.lastAction = `в союзе с ${o.name}`;
      }
    }
    // отношение к игроку дрейфует
    const playerPow = e.army.power() + this.fame * 4;
    for (const nn of this.nations) {
      if (nn.state === "war") continue;
      let drift = 0.4;
      if (nn.char === "mir") drift += 0.5;
      if (nn.char === "agro") drift -= 0.7;
      if (nn.char === "torg" && e.city.s.founded) drift += e.city.s.districts.com * 0.3;
      if (nn.char === "vera" && e.city.s.founded) drift += e.city.s.metrics.faith > 30 ? 0.5 : -0.4;
      if (this.league.member && nn.league) drift += 0.3;
      if (playerPow > this.strength(nn) * 1.5) drift += 0.35;
      nn.rel = clamp(nn.rel + drift * (Math.random() * 1.6 - 0.3), -100, 100);
    }

    // действия против игрока
    if (n.state === "peace" && e.day > n.truceUntil) {
      const weak = e.army.power() < this.strength(n) * 0.65;
      const rich = e.player.gold > 900;
      const roll = Math.random();
      if (n.rel < -35 && roll < n.aggression * 0.5 && weak) {
        this.declareWar(e, n, false);
      } else if (n.rel < -10 && rich && roll < 0.2) {
        const demand = Math.floor(200 + Math.random() * 500);
        this.sendEnvoy(e, n, "demand", `${n.ruler} требует ${demand} золота «за спокойствие на границах». Иначе — война.`, demand, "pay");
      } else if (n.rel > 55 && roll < 0.16 && n.state === "peace") {
        this.sendEnvoy(e, n, "offer", `${n.name} предлагают военный союз против общих врагов.`, 0, "ally");
      } else if (n.rel > 25 && roll < 0.18) {
        this.sendEnvoy(e, n, "offer", `Купцы ${n.adj} земель просят открыть торговые пути.`, 0, "trade");
      } else if (n.rel > 40 && roll < 0.1) {
        const gift = Math.floor(120 + Math.random() * 300);
        this.sendEnvoy(e, n, "gift", `${n.ruler} шлёт дары в знак доброй воли: ${gift} золота.`, gift, "gift");
      } else if (this.strength(n) > e.army.power() * 3 && roll < 0.08 && !this.overlord()) {
        this.sendEnvoy(e, n, "demand", `${n.ruler} предлагает «покровительство»: станьте вассалом или готовьтесь к войне.`, 0, "vassalize");
      } else if (n.char === "hitr" && roll < 0.12) {
        const steal = Math.min(e.player.gold, Math.floor(40 + Math.random() * 160));
        if (steal > 0) {
          e.player.gold -= steal;
          e.toast(`Лазутчики ${n.name} обчистили казну на ${steal} золота`, "bad");
        }
      } else if (n.char === "vera" && roll < 0.1 && e.city.s.founded && e.city.s.metrics.faith < 20) {
        n.rel = clamp(n.rel - 12, -100, 100);
        n.lastAction = "зовут в поход за веру";
        e.toast(`${n.name} осуждают ваше безверие`, "warn");
      } else if (n.char === "bezum" && roll < 0.08) {
        n.rel = clamp(n.rel + (Math.random() * 60 - 30), -100, 100);
        n.lastAction = "творят необъяснимое";
      }
    }
  }

  dayTick(e: Engine) {
    for (const n of this.nations) {
      if (n.state === "war") {
        // разорение: война бьёт по городу
        if (e.city.s.founded) {
          e.city.s.happiness = clamp(e.city.s.happiness - 1.2, 0, 100);
          if (Math.random() < 0.3) e.city.s.metrics.crime += 2;
        }
        n.warScore = clamp(n.warScore - 1.5, -100, 100);
      }
      if (n.state === "vassal") { n.rel = clamp(n.rel + 0.6, -100, 100); if (Math.random() < 0.04) { n.state = "peace"; n.tribute = 0; e.toast(`${n.name} сбросили вассальное ярмо!`, "bad"); } }
      if (n.state === "ally" && n.rel < 20) { n.state = "peace"; e.toast(`${n.name} разорвали союз`, "warn"); }
    }
    // партизанщина при проигрыше
    const losing = this.atWar().some((n) => n.warScore < -40);
    if (losing && !this.guerrilla && e.city.s.founded) {
      this.guerrilla = true;
      e.toast("Народ уходит в леса: началась партизанская война", "warn");
      this.log(e, "Партизанская война", "warn");
    }
    if (this.guerrilla) {
      for (const n of this.atWar()) {
        n.army = Math.max(1, n.army - (Math.random() < 0.5 ? 1 : 0));
        n.warScore = clamp(n.warScore - 2.5, -100, 100);
      }
      if (!this.atWar().length) this.guerrilla = false;
    }
    if (this.league.member) this.league.influence = Math.min(100, this.league.influence + 3);
  }
}
