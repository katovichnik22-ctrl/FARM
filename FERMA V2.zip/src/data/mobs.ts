import type { MobDef } from "../types";

// ===== Звери дня и чудища ночи =====
export const MOBS: Record<string, MobDef> = Object.fromEntries(
  (
    [
      // Дневные
      { id: "olen", name: "Олень", hp: 34, dmg: 6, speed: 2.6, xp: 9, ai: "flee", scale: 1.1, aggroR: 5, atkR: 1.2, atkCd: 1, drops: [{ id: "myaso", n: 2, ch: 1 }, { id: "kozha", n: 2, ch: 0.9 }, { id: "kost", n: 1, ch: 0.5 }] },
      { id: "krolik", name: "Заяц", hp: 12, dmg: 0, speed: 3.4, xp: 4, ai: "flee", scale: 0.6, aggroR: 6, atkR: 0, atkCd: 1, drops: [{ id: "myaso", n: 1, ch: 1 }, { id: "kozha", n: 1, ch: 0.7 }] },
      { id: "kaban", name: "Кабан", hp: 46, dmg: 11, speed: 2.4, xp: 12, ai: "neutral", scale: 1, aggroR: 3.5, atkR: 1.2, atkCd: 1.1, drops: [{ id: "myaso", n: 3, ch: 1 }, { id: "kozha", n: 2, ch: 0.9 }] },
      // Ночные
      { id: "zombi", name: "Утопленник", hp: 46, dmg: 10, speed: 1.6, xp: 12, ai: "aggro", night: true, scale: 1, aggroR: 11, atkR: 1.3, atkCd: 1.3, drops: [{ id: "gnil", n: 2, ch: 0.9 }, { id: "nit", n: 1, ch: 0.5 }, { id: "zoloto", n: 3, ch: 0.3 }] },
      { id: "skelet", name: "Костяной стрелок", hp: 32, dmg: 9, speed: 2, xp: 14, ai: "ranged", night: true, scale: 1, aggroR: 12, atkR: 7.5, atkCd: 2.4, drops: [{ id: "kost", n: 2, ch: 1 }, { id: "pero", n: 1, ch: 0.4 }, { id: "zoloto", n: 4, ch: 0.3 }] },
      { id: "pauk", name: "Теневой паук", hp: 30, dmg: 8, speed: 3.1, xp: 11, ai: "aggro", night: true, scale: 0.9, aggroR: 12, atkR: 1.2, atkCd: 0.9, drops: [{ id: "nit", n: 3, ch: 1 }, { id: "pero", n: 1, ch: 0.2 }] },
      { id: "kriper", name: "Мшистый грохотун", hp: 26, dmg: 30, speed: 2.7, xp: 16, ai: "explode", night: true, scale: 0.95, aggroR: 9, atkR: 1.4, atkCd: 99, drops: [{ id: "ugol", n: 2, ch: 0.9 }, { id: "zoloto", n: 6, ch: 0.5 }] },
      { id: "prizrak", name: "Белая кикимора", hp: 24, dmg: 12, speed: 2.2, xp: 15, ai: "ghost", night: true, cave: true, scale: 1, aggroR: 13, atkR: 1.2, atkCd: 1.2, flying: true, drops: [{ id: "zoloto", n: 8, ch: 0.7 }, { id: "pero", n: 2, ch: 0.6 }] },
      { id: "mysh", name: "Кожаная мышь", hp: 14, dmg: 5, speed: 3, xp: 5, ai: "aggro", night: true, cave: true, scale: 0.55, aggroR: 9, atkR: 1, atkCd: 0.8, flying: true, drops: [{ id: "pero", n: 2, ch: 0.8 }, { id: "nit", n: 1, ch: 0.3 }] },
      // Пещерные
      { id: "sliz", name: "Пещерный слизень", hp: 40, dmg: 12, speed: 1.4, xp: 13, ai: "aggro", cave: true, scale: 0.95, aggroR: 8, atkR: 1.3, atkCd: 1.4, drops: [{ id: "glina", n: 3, ch: 0.8 }, { id: "zoloto", n: 5, ch: 0.4 }] },
      // Босс
      { id: "drakon", name: "Древний Дракон", hp: 900, dmg: 24, speed: 2.3, xp: 300, ai: "boss", scale: 2.6, aggroR: 20, atkR: 2.6, atkCd: 1.8, drops: [{ id: "cheshuya", n: 4, ch: 1 }, { id: "zoloto", n: 140, ch: 1 }, { id: "kost", n: 6, ch: 1 }] },
    ] as MobDef[]
  ).map((m) => [m.id, m])
);

// Веса спавна ночью: [id, вес]
export const NIGHT_SPAWN: [string, number][] = [
  ["zombi", 34], ["skelet", 20], ["pauk", 24], ["kriper", 10], ["prizrak", 6], ["mysh", 8],
];
export const CAVE_SPAWN: [string, number][] = [
  ["mysh", 30], ["sliz", 28], ["prizrak", 16], ["pauk", 22],
];
export const DAY_SPAWN: [string, number][] = [
  ["olen", 30], ["krolik", 45], ["kaban", 25],
];
