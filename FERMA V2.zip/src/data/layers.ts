import type { MobDef } from "../types";

// ===== Слои мира =====
export const L = {
  Surface: 0, Cave: 1, Deep: 2, Sky: 3, Ocean: 4,
  Moon: 5, Mars: 6, Shadow: 7, Dream: 8, Chaos: 9,
} as const;
export type LayerKey = (typeof L)[keyof typeof L];

export interface LayerDef {
  id: number; name: string; short: string; icon: string; color: string;
  desc: string;
  /** как туда попасть */
  gate: string;
  danger: number;          // 1..10
  light: number;           // базовая освещённость 0..1
  gravity: number;         // множитель скорости
  hazard: null | "heat" | "cold" | "vacuum" | "radiation" | "drown" | "madness";
  hazardText: string;
  needItem?: string;       // снаряжение для выживания
  needItemName?: string;
  music: string;
  bgTop: string; bgBot: string;
}

export const LAYERS: LayerDef[] = [
  {
    id: 0, name: "Поверхность", short: "Земля", icon: "Mountain", color: "#7fa95e",
    desc: "Леса, поля, реки и города людей. Родной дом.",
    gate: "—", danger: 1, light: 1, gravity: 1, hazard: null, hazardText: "",
    music: "calm", bgTop: "#1a1620", bgBot: "#171219",
  },
  {
    id: 1, name: "Подземелье", short: "Пещеры", icon: "Pickaxe", color: "#8a7f8f",
    desc: "Пещеры, шахты, светлячники и первые руды. Тут всегда ночь.",
    gate: "Провал в пещеру или шахтный лифт",
    danger: 3, light: 0.12, gravity: 1, hazard: null, hazardText: "",
    music: "cave", bgTop: "#100c14", bgBot: "#0b080e",
  },
  {
    id: 2, name: "Глубины", short: "Бездна", icon: "Flame", color: "#e0662e",
    desc: "Реки лавы, обсидиан и адамантин. Здесь дышит сама земля.",
    gate: "Глубинный лифт в подземелье",
    danger: 7, light: 0.2, gravity: 1, hazard: "heat",
    hazardText: "Жар выжигает силы без огнеупорного костюма",
    needItem: "kostyum_ognya", needItemName: "Огнеупорный костюм",
    music: "deep", bgTop: "#1d0c08", bgBot: "#120604",
  },
  {
    id: 3, name: "Небо", short: "Небеса", icon: "Wind", color: "#a8d8f0",
    desc: "Летающие острова, облачные города и ветер, что держит камни.",
    gate: "Дирижабль с воздушной пристани",
    danger: 5, light: 1, gravity: 0.78, hazard: "cold",
    hazardText: "На высоте студёно — нужна тёплая справа",
    music: "sky", bgTop: "#3b5f8a", bgBot: "#87b0d8",
  },
  {
    id: 4, name: "Океан", short: "Глубь вод", icon: "Waves", color: "#2f7a9a",
    desc: "Подводные города, затонувшие корабли, жемчуг и кракены.",
    gate: "Подводная лодка с причала",
    danger: 5, light: 0.45, gravity: 0.62, hazard: "drown",
    hazardText: "Без водолазного костюма дыхания надолго не хватит",
    needItem: "kostyum_vody", needItemName: "Водолазный костюм",
    music: "ocean", bgTop: "#0d3550", bgBot: "#062134",
  },
  {
    id: 5, name: "Луна", short: "Луна", icon: "Moon", color: "#c9c2b2",
    desc: "Серая пыль, кратеры и тишина, в которой слышно сердце.",
    gate: "Ракета с космодрома",
    danger: 6, light: 0.85, gravity: 0.38, hazard: "vacuum",
    hazardText: "Вакуум убивает без скафандра",
    needItem: "skafandr", needItemName: "Скафандр",
    music: "space", bgTop: "#0a0a14", bgBot: "#14141f",
  },
  {
    id: 6, name: "Марс", short: "Марс", icon: "Rocket", color: "#c2653a",
    desc: "Рыжие пустыни, древние каналы и следы чужого разума.",
    gate: "Межпланетный перелёт с лунной базы",
    danger: 8, light: 0.8, gravity: 0.45, hazard: "radiation",
    hazardText: "Радиация точит тело даже сквозь скафандр",
    needItem: "skafandr", needItemName: "Скафандр",
    music: "space", bgTop: "#1a0a08", bgBot: "#2a120c",
  },
  {
    id: 7, name: "Мир теней", short: "Тени", icon: "Moon", color: "#6a5a8a",
    desc: "Изнанка мира: всё то же, но выцветшее и голодное.",
    gate: "Теневой портал",
    danger: 7, light: 0.18, gravity: 1.05, hazard: "madness",
    hazardText: "Тени шепчут и точат рассудок",
    music: "shadow", bgTop: "#0e0a16", bgBot: "#150f22",
  },
  {
    id: 8, name: "Мир снов", short: "Сны", icon: "Sparkles", color: "#e08ac9",
    desc: "Мягкие холмы из мысли, где сбывается задуманное и забытое.",
    gate: "Портал сновидений",
    danger: 4, light: 0.7, gravity: 0.7, hazard: null, hazardText: "",
    music: "dream", bgTop: "#2a1840", bgBot: "#43265c",
  },
  {
    id: 9, name: "Мир хаоса", short: "Хаос", icon: "Zap", color: "#e05ac9",
    desc: "Здесь правила меняются каждый вздох. Награда под стать риску.",
    gate: "Хаотический разлом",
    danger: 10, light: 0.5, gravity: 0.9, hazard: "madness",
    hazardText: "Хаос переписывает всё, включая вас",
    music: "chaos", bgTop: "#1f0a1f", bgBot: "#3a1030",
  },
];
export const LAYER_BY_ID: Record<number, LayerDef> = Object.fromEntries(LAYERS.map((l) => [l.id, l]));

// ===== Транспорт между слоями =====
export interface GateDef {
  id: string; name: string; desc: string; icon: string;
  from: number; to: number;
  cost: { gold: number; res: [string, number][] };
  buildTime: number;
  needTech?: string;
  needLayerUnlock?: number;
}

export const GATES: GateDef[] = [
  { id: "g_shaft", name: "Шахтный лифт", desc: "Скрипучая клеть на цепях. Возит в пещеры и обратно.", icon: "ArrowDownUp", from: 0, to: 1, cost: { gold: 200, res: [["doska", 14], ["zhel_slitok", 4]] }, buildTime: 14 },
  { id: "g_deep", name: "Глубинный лифт", desc: "Уходит туда, где камень светится изнутри.", icon: "ArrowDownUp", from: 1, to: 2, cost: { gold: 900, res: [["zhel_slitok", 14], ["kamen", 40], ["ugol", 20]] }, buildTime: 30, needTech: "t_siegecraft" },
  { id: "g_airdock", name: "Воздушная пристань", desc: "Мачта с причалом для дирижабля.", icon: "Wind", from: 0, to: 3, cost: { gold: 1400, res: [["doska", 40], ["tkan", 20], ["med_slitok", 10]] }, buildTime: 36, needTech: "t_navigation" },
  { id: "g_subdock", name: "Подводный причал", desc: "Док для лодки с медными иллюминаторами.", icon: "Anchor", from: 0, to: 4, cost: { gold: 1600, res: [["doska", 36], ["zhel_slitok", 16], ["tkan", 12]] }, buildTime: 38, needTech: "t_navigation" },
  { id: "g_cosmodrome", name: "Космодром", desc: "Стартовый стол, мачты и запах гари. Отсюда — к Луне.", icon: "Rocket", from: 0, to: 5, cost: { gold: 6000, res: [["zhel_slitok", 60], ["instrument", 20], ["ugol", 60]] }, buildTime: 90, needTech: "t_rocketry" },
  { id: "g_marsship", name: "Межпланетный корабль", desc: "Долгий перелёт к рыжей планете.", icon: "Rocket", from: 5, to: 6, cost: { gold: 12000, res: [["instrument", 40], ["zhel_slitok", 80], ["cheshuya", 2]] }, buildTime: 110, needTech: "t_orbital", needLayerUnlock: 5 },
  { id: "g_shadowgate", name: "Теневой портал", desc: "Круг обсидиана, в котором нет отражения.", icon: "CircleDot", from: 0, to: 7, cost: { gold: 2500, res: [["kamen", 50], ["cheshuya", 2], ["ugol", 30]] }, buildTime: 45, needTech: "t_thaumaturgy" },
  { id: "g_dreamgate", name: "Портал сновидений", desc: "Арка из лунного камня; шагнув, вы засыпаете наяву.", icon: "Sparkles", from: 0, to: 8, cost: { gold: 2800, res: [["pesok", 40], ["ukrashenie", 6], ["nit", 30]] }, buildTime: 45, needTech: "t_thaumaturgy" },
  { id: "g_chaosrift", name: "Хаотический разлом", desc: "Трещина в самом законе мира. Лучше не смотреть долго.", icon: "Zap", from: 0, to: 9, cost: { gold: 5000, res: [["cheshuya", 4], ["zoloto", 800], ["adamantit", 6]] }, buildTime: 70, needTech: "t_worldweave" },
];

// ===== Космическая программа =====
export interface SpaceBuildDef {
  id: string; name: string; desc: string; icon: string;
  layer: number; cost: { gold: number; res: [string, number][] };
  effect: { gold?: number; sci?: number; res?: [string, number]; def?: number };
  bonusText: string;
}

export const SPACE_BUILDS: SpaceBuildDef[] = [
  { id: "sb_base", name: "Лунная база", desc: "Купол, шлюз и запас воздуха. Дом вдали от дома.", icon: "Home", layer: 5, cost: { gold: 4000, res: [["zhel_slitok", 40], ["instrument", 10]] }, effect: { sci: 40 }, bonusText: "+40 науки, можно жить на Луне" },
  { id: "sb_mine", name: "Добывающий комплекс", desc: "Роботизированные буры грызут реголит круглые сутки.", icon: "Pickaxe", layer: 5, cost: { gold: 5500, res: [["instrument", 20], ["zhel_slitok", 50]] }, effect: { res: ["lunnyi_kamen", 3], gold: 30 }, bonusText: "+3 лунного камня и +30 золота в день" },
  { id: "sb_station", name: "Орбитальная станция", desc: "Кольцо на орбите: обзор, связь, склад.", icon: "Rocket", layer: 5, cost: { gold: 9000, res: [["instrument", 30], ["zhel_slitok", 70]] }, effect: { sci: 90, gold: 50 }, bonusText: "+90 науки, +50 золота в день" },
  { id: "sb_cannon", name: "Орбитальное орудие", desc: "Копьё из вольфрама, падающее с небес.", icon: "Crosshair", layer: 5, cost: { gold: 14000, res: [["instrument", 50], ["adamantit", 10]] }, effect: { def: 0.3 }, bonusText: "+30% силы войска: удар с орбиты" },
  { id: "sb_colony", name: "Марсианская колония", desc: "Теплицы под красным небом и первые рождённые вне Земли.", icon: "Building2", layer: 6, cost: { gold: 18000, res: [["instrument", 60], ["adamantit", 14], ["tkan", 40]] }, effect: { sci: 150, gold: 90 }, bonusText: "+150 науки, +90 золота в день" },
  { id: "sb_warp", name: "Варп-двигатель", desc: "Складка пространства вместо дороги. Галактика близко.", icon: "CircleDot", layer: 6, cost: { gold: 30000, res: [["adamantit", 30], ["cheshuya", 6], ["instrument", 80]] }, effect: { sci: 300, gold: 150 }, bonusText: "+300 науки: путь к звёздам открыт" },
];

// ===== Инопланетные расы =====
export interface AlienDef {
  id: string; name: string; icon: string; color: string;
  temper: "friend" | "trade" | "foe";
  desc: string; offer: string;
}
export const ALIENS: AlienDef[] = [
  { id: "al_kem", name: "Кемиты", icon: "Sparkles", color: "#7ae68a", temper: "friend", desc: "Кристаллические существа, поющие вместо речи.", offer: "Делятся знанием о звёздах" },
  { id: "al_rud", name: "Рудокопы Ро", icon: "Pickaxe", color: "#c9a227", temper: "trade", desc: "Приземистые копатели с семнадцатью пальцами.", offer: "Меняют редкие руды на золото" },
  { id: "al_void", name: "Порождения Пустоты", icon: "Skull", color: "#a26af2", temper: "foe", desc: "У них нет формы, только голод и направление.", offer: "Требуют дань или уничтожат базу" },
];

// ===== Боссы слоёв =====
export const LAYER_BOSSES: Record<number, { id: string; name: string; layerName: string }> = {
  1: { id: "korol_nezhiti", name: "Король нежити", layerName: "Подземелье" },
  2: { id: "vladyka_lavy", name: "Повелитель лавы", layerName: "Глубины" },
  3: { id: "ledyanaya_koroleva", name: "Ледяная королева", layerName: "Небо" },
  4: { id: "kraken", name: "Древний кракен", layerName: "Океан" },
  5: { id: "lunnyi_bog", name: "Лунный бог", layerName: "Луна" },
  6: { id: "kosmouzhas", name: "Космический ужас", layerName: "Марс" },
  7: { id: "vladyka_bezdny", name: "Владыка бездны", layerName: "Мир теней" },
  9: { id: "hаos_avatar".replace("а", "a"), name: "Аватар Хаоса", layerName: "Мир хаоса" },
};

// ===== Мобы слоёв =====
export const LAYER_MOBS: Record<string, MobDef> = Object.fromEntries((
  [
    // Глубины
    { id: "lavoviy", name: "Лавовый выползень", hp: 90, dmg: 22, speed: 1.9, xp: 30, ai: "aggro", cave: true, scale: 1.1, aggroR: 10, atkR: 1.3, atkCd: 1.2, drops: [{ id: "obsidian", n: 2, ch: 0.8 }, { id: "ugol", n: 3, ch: 0.9 }] },
    { id: "magmit", name: "Магмит", hp: 130, dmg: 28, speed: 1.4, xp: 42, ai: "aggro", cave: true, scale: 1.3, aggroR: 9, atkR: 1.4, atkCd: 1.5, drops: [{ id: "adamantit", n: 1, ch: 0.35 }, { id: "obsidian", n: 3, ch: 0.9 }] },
    // Небо
    { id: "vihrevik", name: "Вихревик", hp: 70, dmg: 18, speed: 3.4, xp: 26, ai: "aggro", scale: 0.9, aggroR: 12, atkR: 1.2, atkCd: 0.9, flying: true, drops: [{ id: "pero", n: 3, ch: 1 }, { id: "nebesnyi_kristall", n: 1, ch: 0.3 }] },
    { id: "grifon", name: "Грифон", hp: 180, dmg: 30, speed: 3, xp: 50, ai: "neutral", scale: 1.5, aggroR: 8, atkR: 1.5, atkCd: 1.2, flying: true, drops: [{ id: "pero", n: 5, ch: 1 }, { id: "kozha", n: 4, ch: 0.9 }] },
    // Океан
    { id: "murena", name: "Мурена", hp: 80, dmg: 20, speed: 3.1, xp: 28, ai: "aggro", scale: 1, aggroR: 10, atkR: 1.2, atkCd: 1, flying: true, drops: [{ id: "myaso", n: 2, ch: 1 }, { id: "zhemchug", n: 1, ch: 0.25 }] },
    { id: "rusalka", name: "Русалка", hp: 110, dmg: 16, speed: 2.6, xp: 40, ai: "neutral", scale: 1, aggroR: 7, atkR: 2, atkCd: 1.4, flying: true, drops: [{ id: "zhemchug", n: 2, ch: 0.7 }, { id: "korall", n: 3, ch: 0.8 }] },
    // Луна / Марс
    { id: "lunnyi_prizrak", name: "Лунный призрак", hp: 120, dmg: 26, speed: 2.4, xp: 48, ai: "ghost", scale: 1.1, aggroR: 13, atkR: 1.3, atkCd: 1.2, flying: true, drops: [{ id: "lunnyi_kamen", n: 2, ch: 0.8 }] },
    { id: "marsianin", name: "Марсианский страж", hp: 200, dmg: 34, speed: 2.2, xp: 66, ai: "ranged", scale: 1.2, aggroR: 14, atkR: 7, atkCd: 2, drops: [{ id: "marsianit", n: 2, ch: 0.8 }, { id: "instrument", n: 1, ch: 0.3 }] },
    // Тени / сны / хаос
    { id: "ten_ohotnik", name: "Теневой охотник", hp: 140, dmg: 30, speed: 3.2, xp: 52, ai: "aggro", night: true, scale: 1, aggroR: 14, atkR: 1.3, atkCd: 0.9, drops: [{ id: "tenevaya_sut", n: 2, ch: 0.85 }] },
    { id: "koshmar", name: "Кошмар", hp: 100, dmg: 22, speed: 2.8, xp: 44, ai: "ghost", scale: 1.1, aggroR: 12, atkR: 1.4, atkCd: 1.1, flying: true, drops: [{ id: "pyl_snov", n: 2, ch: 0.85 }] },
    { id: "hаoszver".replace("а", "a"), name: "Тварь хаоса", hp: 220, dmg: 40, speed: 3, xp: 90, ai: "aggro", scale: 1.3, aggroR: 15, atkR: 1.5, atkCd: 1, drops: [{ id: "oskolok_haosa", n: 2, ch: 0.9 }, { id: "zoloto", n: 120, ch: 0.6 }] },

    // ===== БОССЫ СЛОЁВ =====
    { id: "korol_nezhiti", name: "Король нежити", hp: 1400, dmg: 34, speed: 2, xp: 400, ai: "boss", scale: 2.4, aggroR: 20, atkR: 2.4, atkCd: 1.6, drops: [{ id: "kost", n: 20, ch: 1 }, { id: "zoloto", n: 300, ch: 1 }, { id: "mifril", n: 6, ch: 1 }] },
    { id: "vladyka_lavy", name: "Повелитель лавы", hp: 2200, dmg: 46, speed: 2.1, xp: 620, ai: "boss", scale: 2.7, aggroR: 22, atkR: 2.6, atkCd: 1.5, drops: [{ id: "adamantit", n: 10, ch: 1 }, { id: "obsidian", n: 25, ch: 1 }, { id: "zoloto", n: 500, ch: 1 }] },
    { id: "ledyanaya_koroleva", name: "Ледяная королева", hp: 1800, dmg: 40, speed: 2.6, xp: 520, ai: "boss", scale: 2.3, aggroR: 22, atkR: 3, atkCd: 1.4, flying: true, drops: [{ id: "nebesnyi_kristall", n: 12, ch: 1 }, { id: "zoloto", n: 420, ch: 1 }] },
    { id: "kraken", name: "Древний кракен", hp: 2600, dmg: 44, speed: 2.2, xp: 700, ai: "boss", scale: 3, aggroR: 22, atkR: 3.2, atkCd: 1.6, flying: true, drops: [{ id: "zhemchug", n: 20, ch: 1 }, { id: "korall", n: 25, ch: 1 }, { id: "zoloto", n: 600, ch: 1 }] },
    { id: "lunnyi_bog", name: "Лунный бог", hp: 3200, dmg: 52, speed: 2.4, xp: 900, ai: "boss", scale: 3.2, aggroR: 24, atkR: 3, atkCd: 1.4, flying: true, drops: [{ id: "lunnyi_kamen", n: 30, ch: 1 }, { id: "zoloto", n: 900, ch: 1 }, { id: "cheshuya", n: 4, ch: 1 }] },
    { id: "kosmouzhas", name: "Космический ужас", hp: 4200, dmg: 60, speed: 2.5, xp: 1200, ai: "boss", scale: 3.6, aggroR: 26, atkR: 3.4, atkCd: 1.3, flying: true, drops: [{ id: "marsianit", n: 30, ch: 1 }, { id: "zoloto", n: 1400, ch: 1 }, { id: "adamantit", n: 15, ch: 1 }] },
    { id: "vladyka_bezdny", name: "Владыка бездны", hp: 3000, dmg: 54, speed: 2.7, xp: 850, ai: "boss", scale: 2.8, aggroR: 24, atkR: 2.8, atkCd: 1.3, drops: [{ id: "tenevaya_sut", n: 25, ch: 1 }, { id: "zoloto", n: 800, ch: 1 }] },
    { id: "haos_avatar", name: "Аватар Хаоса", hp: 5000, dmg: 70, speed: 3, xp: 1600, ai: "boss", scale: 3.8, aggroR: 28, atkR: 3.2, atkCd: 1.2, drops: [{ id: "oskolok_haosa", n: 30, ch: 1 }, { id: "zoloto", n: 2000, ch: 1 }, { id: "cheshuya", n: 8, ch: 1 }] },
  ] as MobDef[]
).map((m) => [m.id, m]));

/** Таблицы спавна по слоям */
export const LAYER_SPAWN: Record<number, [string, number][]> = {
  2: [["lavoviy", 45], ["magmit", 35], ["sliz", 20]],
  3: [["vihrevik", 50], ["grifon", 22], ["mysh", 28]],
  4: [["murena", 45], ["rusalka", 25], ["sliz", 30]],
  5: [["lunnyi_prizrak", 60], ["mysh", 40]],
  6: [["marsianin", 55], ["lunnyi_prizrak", 45]],
  7: [["ten_ohotnik", 50], ["prizrak", 30], ["pauk", 20]],
  8: [["koshmar", 60], ["prizrak", 40]],
  9: [["haoszver", 50], ["koshmar", 25], ["ten_ohotnik", 25]],
};

// ===== Новые ресурсы слоёв =====
export const LAYER_ITEMS: { id: string; name: string; desc: string; icon: string; stack?: number }[] = [
  { id: "mifril", name: "Мифрил", desc: "Лёгкий, как перо, и крепче стали.", icon: "Gem" },
  { id: "adamantit", name: "Адамантин", desc: "Чёрный металл глубин. Не берёт ни огонь, ни время.", icon: "Gem" },
  { id: "obsidian", name: "Обсидиан", desc: "Застывшая ярость земли, острая как бритва.", icon: "Shapes" },
  { id: "kristall", name: "Пещерный кристалл", desc: "Светится собственным светом.", icon: "Sparkle" },
  { id: "nebesnyi_kristall", name: "Небесный кристалл", desc: "Внутри него медленно плывут облака.", icon: "Sparkles" },
  { id: "oblachnyi_hlopok", name: "Облачный хлопок", desc: "Мягче пуха, теплее шерсти.", icon: "Cable" },
  { id: "zhemchug", name: "Жемчуг", desc: "Слёзы моря в перламутровой раковине.", icon: "Gem" },
  { id: "korall", name: "Коралл", desc: "Живой камень подводных садов.", icon: "Shapes" },
  { id: "lunnyi_kamen", name: "Лунный камень", desc: "Серая пыль, спрессованная веками тишины.", icon: "Moon" },
  { id: "marsianit", name: "Марсианит", desc: "Рыжий минерал, что помнит чужие руки.", icon: "Rocket" },
  { id: "tenevaya_sut", name: "Теневая суть", desc: "Сгусток холодной тьмы, живой на ощупь.", icon: "Moon" },
  { id: "pyl_snov", name: "Пыль снов", desc: "Щепотка на язык — и явь зыбка.", icon: "Sparkles" },
  { id: "oskolok_haosa", name: "Осколок хаоса", desc: "Меняет цвет и вес, когда на него не смотришь.", icon: "Zap" },
  { id: "alien_tech", name: "Чужая деталь", desc: "Механизм, собранный не человеческой рукой.", icon: "Cpu" },
];

// ===== Снаряжение для слоёв =====
export const LAYER_GEAR: { id: string; name: string; desc: string; icon: string; cost: { gold: number; res: [string, number][] }; tech?: string }[] = [
  { id: "kostyum_ognya", name: "Огнеупорный костюм", desc: "Кожа, обшитая обсидиановой чешуёй. Держит жар бездны.", icon: "Shield", cost: { gold: 900, res: [["kozha", 20], ["obsidian", 8], ["zhel_slitok", 6]] } },
  { id: "kostyum_vody", name: "Водолазный костюм", desc: "Медный шлем и просмолённая кожа. Воздуха хватит надолго.", icon: "HardHat", cost: { gold: 1100, res: [["kozha", 18], ["med_slitok", 12], ["tkan", 10]] } },
  { id: "skafandr", name: "Скафандр", desc: "Герметичный доспех для пустоты. Ваш личный мирок.", icon: "PersonStanding", cost: { gold: 4500, res: [["instrument", 12], ["tkan", 20], ["zhel_slitok", 20]] }, tech: "t_rocketry" },
];
