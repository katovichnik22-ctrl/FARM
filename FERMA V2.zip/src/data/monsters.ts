import type { MobAI, MobDef } from "../types";
import { Biome } from "../types";

// =====================================================================
//  БЕСТИАРИЙ «ТИХОГО ПЛАМЕНИ» — 71 монстр в 10 категориях (этап 7)
//  Файл — только данные. Механики способностей (poison/burn/slow/
//  teleport/summon) и слабостей реализуются отдельно; здесь они
//  описаны декларативно, чтобы движок/баланс/UI могли их читать.
// =====================================================================

export type MonsterCategory =
  | "night" | "cave" | "swamp" | "desert" | "snow"
  | "lava" | "forest" | "water" | "magic" | "special";

export type MonsterAbility = "poison" | "burn" | "slow" | "teleport" | "summon";
export type MonsterWeakness = "fire" | "ice" | "magic" | "silver" | "none";
export type MonsterRarity = "common" | "rare" | "elite" | "legendary";
/** Где появляется монстр. night — поверхность ночью, any — где угодно (по таблицам), coast — берег/океан */
export type MonsterBiome = "night" | "cave" | "swamp" | "desert" | "snow" | "lava" | "forest" | "coast" | "any";
export type TimeOfDay = "day" | "night" | "any";

export interface MonsterDef {
  id: string;
  name: string;                    // русское имя
  gen?: "m" | "f" | "n";           // род (для приставки «Древний/Древняя/Древнее»)
  category: MonsterCategory;
  hp: number; dmg: number; speed: number;
  biome: MonsterBiome;             // в каком биоме появляется
  timeOfDay: TimeOfDay;            // время суток
  abilities: MonsterAbility[];     // декларативные способности
  weakness: MonsterWeakness;       // уязвимость
  loot: { id: string; n: number; ch: number }[]; // дроп (id предметов)
  rarity: MonsterRarity;
  spriteBase: string;              // id существующего спрайта-основы
  // --- параметры для движка (мапятся в MobDef) ---
  ai: MobAI;
  tint?: string;                   // перекраска базового спрайта
  scale?: number;                  // масштаб (множитель к базе ~1)
  xp?: number;                     // опыт (по умолчанию из hp/dmg)
  aggroR?: number; atkR?: number; atkCd?: number;
  flying?: boolean;
}

// ---------------------------------------------------------------------
//  Вспомогательный конструктор: меньше шума в записях
// ---------------------------------------------------------------------
const M = (
  id: string, name: string, category: MonsterCategory,
  hp: number, dmg: number, speed: number,
  d: Partial<MonsterDef> & { biome: MonsterBiome; spriteBase: string; ai: MobAI },
): MonsterDef => ({
  gen: "m", timeOfDay: "any", abilities: [], weakness: "none",
  loot: [], rarity: "common", scale: 1,
  id, name, category, hp, dmg, speed, ...d,
});

// =====================================================================
//  РЕЕСТР МОНСТРОВ (71 существо)
// =====================================================================
export const MONSTERS: MonsterDef[] = [
  // ==================== ОБЫЧНЫЕ НОЧНЫЕ (15) ====================
  M("m_zombi", "Зомби", "night", 46, 10, 1.6, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "zombi", tint: "#74a84c",
    weakness: "fire", loot: [{ id: "gnil", n: 2, ch: 0.9 }, { id: "kost", n: 1, ch: 0.4 }, { id: "zoloto", n: 3, ch: 0.25 }],
  }),
  M("m_skelet", "Скелет", "night", 30, 8, 2.0, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "skelet", tint: "#f0e9d4",
    weakness: "silver", loot: [{ id: "kost", n: 3, ch: 1 }, { id: "zoloto", n: 2, ch: 0.2 }],
  }),
  M("m_pauk", "Паук", "night", 32, 8, 3.1, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "pauk", tint: "#a86838",
    abilities: ["poison"], weakness: "fire", loot: [{ id: "nit", n: 3, ch: 1 }, { id: "gnil", n: 1, ch: 0.3 }],
  }),
  M("m_kriper", "Крипер", "night", 26, 30, 2.7, {
    biome: "night", timeOfDay: "night", ai: "explode", spriteBase: "kriper", tint: "#5ad84a",
    weakness: "magic", loot: [{ id: "ugol", n: 2, ch: 0.9 }, { id: "kremen", n: 1, ch: 0.4 }, { id: "zoloto", n: 5, ch: 0.4 }],
  }),
  M("m_zombi_kid", "Зомби-ребёнок", "night", 22, 7, 3.0, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "zombi", tint: "#90c860", scale: 0.55,
    weakness: "fire", loot: [{ id: "gnil", n: 1, ch: 0.9 }, { id: "zoloto", n: 4, ch: 0.35 }],
  }),
  M("m_skelet_luk", "Скелет-лучник", "night", 28, 9, 2.0, {
    biome: "night", timeOfDay: "night", ai: "ranged", spriteBase: "skelet", tint: "#c6d6e6", atkR: 7, atkCd: 2.4,
    weakness: "silver", loot: [{ id: "kost", n: 2, ch: 1 }, { id: "pero", n: 1, ch: 0.5 }, { id: "palka", n: 2, ch: 0.6 }],
  }),
  M("m_pauk_pesch", "Пещерный паук", "night", 26, 9, 3.4, {
    biome: "cave", ai: "aggro", spriteBase: "pauk", tint: "#4a68c8", scale: 0.72,
    abilities: ["poison"], weakness: "fire", loot: [{ id: "nit", n: 2, ch: 1 }, { id: "kristall", n: 1, ch: 0.15 }],
  }),
  M("m_slizen", "Слизень", "night", 40, 12, 1.4, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "sliz", tint: "#56e06a",
    weakness: "fire", loot: [{ id: "glina", n: 3, ch: 0.8 }, { id: "zoloto", n: 4, ch: 0.3 }],
  }),
  M("m_mysh_let", "Летучая мышь", "night", 14, 5, 3.2, {
    gen: "f", biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "mysh", tint: "#6a5a8c", flying: true,
    weakness: "none", loot: [{ id: "pero", n: 2, ch: 0.8 }, { id: "nit", n: 1, ch: 0.3 }],
  }),
  M("m_prizrak_n", "Призрак", "night", 24, 12, 2.2, {
    biome: "night", timeOfDay: "night", ai: "ghost", spriteBase: "prizrak", tint: "#a8c8f0", flying: true,
    abilities: ["teleport"], weakness: "silver", loot: [{ id: "zoloto", n: 7, ch: 0.6 }, { id: "pyl_snov", n: 1, ch: 0.15 }],
  }),
  M("m_zombi_ferm", "Зомби-фермер", "night", 55, 11, 1.5, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "zombi", tint: "#c09a4e",
    weakness: "fire", loot: [{ id: "gnil", n: 2, ch: 0.9 }, { id: "hleb", n: 1, ch: 0.3 }, { id: "zerno", n: 2, ch: 0.4 }],
  }),
  M("m_skelet_voin", "Скелет-воин", "night", 60, 14, 1.9, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "skelet", tint: "#d6c6a4", scale: 1.15,
    weakness: "silver", loot: [{ id: "kost", n: 3, ch: 1 }, { id: "zhel_ruda", n: 1, ch: 0.35 }, { id: "bint", n: 1, ch: 0.2 }],
  }),
  M("m_pauk_pryad", "Паук-прядильщик", "night", 40, 10, 2.6, {
    biome: "night", timeOfDay: "night", ai: "ranged", spriteBase: "pauk", tint: "#c6a4e2", atkR: 5.5, atkCd: 2.0,
    abilities: ["slow"], weakness: "fire", rarity: "rare", loot: [{ id: "nit", n: 5, ch: 1 }, { id: "tkan", n: 1, ch: 0.25 }],
  }),
  M("m_slizen_king", "Слизень-король", "night", 180, 20, 1.3, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "sliz", tint: "#42b8e8", scale: 1.7,
    abilities: ["summon"], weakness: "fire", rarity: "elite",
    loot: [{ id: "glina", n: 6, ch: 1 }, { id: "kristall", n: 2, ch: 0.5 }, { id: "zoloto", n: 18, ch: 0.8 }],
  }),
  M("m_ohotnik", "Ночной охотник", "night", 70, 17, 3.6, {
    biome: "night", timeOfDay: "night", ai: "aggro", spriteBase: "ten_ohotnik", tint: "#de4458",
    abilities: ["teleport"], weakness: "silver", rarity: "rare",
    loot: [{ id: "pero", n: 2, ch: 0.7 }, { id: "zoloto", n: 9, ch: 0.5 }, { id: "tenevaya_sut", n: 1, ch: 0.2 }],
  }),

  // ==================== ПЕЩЕРНЫЕ (10) ====================
  M("m_golem_kam", "Каменный голем", "cave", 220, 26, 1.2, {
    biome: "cave", ai: "aggro", spriteBase: "magmit", tint: "#949aa8", scale: 1.5, xp: 70,
    weakness: "magic", rarity: "elite",
    loot: [{ id: "kamen", n: 6, ch: 1 }, { id: "zhel_ruda", n: 3, ch: 0.7 }, { id: "kristall", n: 2, ch: 0.4 }],
  }),
  M("m_eye", "Летающий глаз", "cave", 30, 10, 2.6, {
    biome: "cave", ai: "ranged", spriteBase: "vihrevik", tint: "#e85a54", scale: 0.7, flying: true, atkR: 5, atkCd: 2.0,
    weakness: "silver", loot: [{ id: "kristall", n: 1, ch: 0.25 }, { id: "zoloto", n: 3, ch: 0.3 }],
  }),
  M("m_grib_chel", "Грибной человек", "cave", 65, 12, 1.5, {
    biome: "cave", ai: "neutral", spriteBase: "zombi", tint: "#c06858",
    abilities: ["poison"], weakness: "fire", loot: [{ id: "grib", n: 3, ch: 1 }, { id: "grib_zhar", n: 1, ch: 0.2 }],
  }),
  M("m_sliz_glow", "Светящийся слизень", "cave", 45, 11, 1.4, {
    biome: "cave", ai: "aggro", spriteBase: "sliz", tint: "#56f0d6",
    weakness: "none", loot: [{ id: "kristall", n: 1, ch: 0.5 }, { id: "glina", n: 2, ch: 0.7 }],
  }),
  M("m_troll_p", "Пещерный тролль", "cave", 150, 21, 1.5, {
    biome: "cave", ai: "aggro", spriteBase: "zombi", tint: "#78865a", scale: 1.4, xp: 45,
    weakness: "fire", rarity: "rare", loot: [{ id: "myaso", n: 2, ch: 0.8 }, { id: "zoloto", n: 12, ch: 0.5 }, { id: "kost", n: 2, ch: 0.6 }],
  }),
  M("m_krab_ruda", "Рудный краб", "cave", 75, 13, 1.7, {
    biome: "cave", ai: "neutral", spriteBase: "magmit", tint: "#c4885a", scale: 0.85,
    weakness: "none", loot: [{ id: "med_ruda", n: 2, ch: 0.9 }, { id: "zhel_ruda", n: 1, ch: 0.5 }, { id: "kamen", n: 2, ch: 0.7 }],
  }),
  M("m_strelok_stal", "Сталактитовый стрелок", "cave", 38, 12, 1.8, {
    biome: "cave", ai: "ranged", spriteBase: "skelet", tint: "#a698bc", atkR: 8, atkCd: 2.3,
    weakness: "silver", loot: [{ id: "kamen", n: 2, ch: 0.8 }, { id: "pero", n: 1, ch: 0.4 }, { id: "kristall", n: 1, ch: 0.2 }],
  }),
  M("m_cherv_glub", "Глубинный червь", "cave", 120, 19, 2.2, {
    biome: "cave", ai: "aggro", spriteBase: "lavoviy", tint: "#8c5cba", scale: 1.3, xp: 40,
    weakness: "ice", rarity: "rare", loot: [{ id: "myaso", n: 2, ch: 0.9 }, { id: "mifril", n: 1, ch: 0.12 }, { id: "kristall", n: 1, ch: 0.3 }],
  }),
  M("m_pauk_krist", "Кристальный паук", "cave", 60, 13, 3.0, {
    biome: "cave", ai: "aggro", spriteBase: "pauk", tint: "#62e0f2",
    abilities: ["slow"], weakness: "magic", rarity: "rare",
    loot: [{ id: "kristall", n: 2, ch: 0.7 }, { id: "nit", n: 3, ch: 1 }],
  }),
  M("m_skelet_strazh", "Страж-скелет", "cave", 95, 16, 1.7, {
    biome: "cave", ai: "guard", spriteBase: "skelet", tint: "#e6c66a", scale: 1.3, xp: 35,
    weakness: "silver", rarity: "rare",
    loot: [{ id: "kost", n: 3, ch: 1 }, { id: "zhel_slitok", n: 1, ch: 0.3 }, { id: "zoloto", n: 10, ch: 0.5 }],
  }),

  // ==================== БОЛОТНЫЕ (6) ====================
  M("m_zombi_bolot", "Болотный зомби", "swamp", 62, 13, 1.4, {
    biome: "swamp", ai: "aggro", spriteBase: "zombi", tint: "#4e7a40",
    abilities: ["poison"], weakness: "fire", loot: [{ id: "gnil", n: 3, ch: 1 }, { id: "glina", n: 2, ch: 0.6 }],
  }),
  M("m_zhaba", "Жаба-мутант", "swamp", 58, 13, 2.5, {
    gen: "f", biome: "swamp", ai: "aggro", spriteBase: "sliz", tint: "#58b848", scale: 1.08,
    abilities: ["poison"], weakness: "ice", loot: [{ id: "myaso", n: 2, ch: 1 }, { id: "grib", n: 1, ch: 0.4 }],
  }),
  M("m_piyavka", "Пиявка", "swamp", 26, 7, 2.8, {
    gen: "f", biome: "swamp", ai: "aggro", spriteBase: "murena", tint: "#463431", scale: 0.5,
    abilities: ["slow"], weakness: "none", loot: [{ id: "myaso", n: 1, ch: 0.8 }, { id: "bint", n: 1, ch: 0.2 }],
  }),
  M("m_kikimora", "Кикимора", "swamp", 42, 12, 2.3, {
    gen: "f", biome: "swamp", ai: "ghost", spriteBase: "prizrak", tint: "#7cc668", flying: true,
    abilities: ["teleport", "slow"], weakness: "silver", rarity: "rare",
    loot: [{ id: "yagoda", n: 3, ch: 0.8 }, { id: "nit", n: 2, ch: 0.6 }, { id: "pyl_snov", n: 1, ch: 0.15 }],
  }),
  M("m_troll_gnil", "Гнилой тролль", "swamp", 160, 23, 1.4, {
    biome: "swamp", ai: "aggro", spriteBase: "zombi", tint: "#5c8238", scale: 1.45, xp: 48,
    abilities: ["poison"], weakness: "fire", rarity: "rare",
    loot: [{ id: "gnil", n: 4, ch: 1 }, { id: "kost", n: 2, ch: 0.5 }, { id: "zoloto", n: 12, ch: 0.45 }],
  }),
  M("m_svetlyak", "Светлячок-обманщик", "swamp", 22, 9, 3.0, {
    biome: "swamp", timeOfDay: "night", ai: "aggro", spriteBase: "mysh", tint: "#f0e058", scale: 0.85, flying: true,
    abilities: ["teleport"], weakness: "magic", rarity: "rare",
    loot: [{ id: "kristall", n: 1, ch: 0.35 }, { id: "zoloto", n: 6, ch: 0.4 }],
  }),

  // ==================== ПУСТЫННЫЕ (6) ====================
  M("m_mumiya", "Мумия", "desert", 95, 16, 1.3, {
    gen: "f", biome: "desert", ai: "aggro", spriteBase: "zombi", tint: "#d8c498", xp: 30,
    abilities: ["slow"], weakness: "fire", loot: [{ id: "tkan", n: 2, ch: 0.8 }, { id: "kost", n: 2, ch: 0.7 }, { id: "zoloto", n: 8, ch: 0.5 }],
  }),
  M("m_skorpion", "Скорпион", "desert", 48, 12, 2.9, {
    biome: "desert", ai: "aggro", spriteBase: "pauk", tint: "#c87828", scale: 0.95,
    abilities: ["poison"], weakness: "ice", loot: [{ id: "kozha", n: 1, ch: 0.8 }, { id: "gnil", n: 1, ch: 0.4 }],
  }),
  M("m_cherv_pesok", "Песчаный червь", "desert", 125, 19, 2.4, {
    biome: "desert", ai: "aggro", spriteBase: "lavoviy", tint: "#dcba68", scale: 1.25, xp: 42,
    weakness: "ice", rarity: "rare", loot: [{ id: "pesok", n: 5, ch: 1 }, { id: "myaso", n: 2, ch: 0.9 }, { id: "kremen", n: 2, ch: 0.5 }],
  }),
  M("m_razboinik", "Пустынный разбойник", "desert", 75, 15, 3.0, {
    biome: "desert", ai: "aggro", spriteBase: "ten_ohotnik", tint: "#d8a868",
    weakness: "none", loot: [{ id: "zoloto", n: 14, ch: 0.9 }, { id: "hleb", n: 1, ch: 0.4 }, { id: "bint", n: 1, ch: 0.3 }],
  }),
  M("m_dzhinn", "Джинн", "desert", 85, 17, 2.4, {
    biome: "desert", ai: "ghost", spriteBase: "prizrak", tint: "#58d0e8", scale: 1.3, flying: true, xp: 60,
    abilities: ["teleport", "summon"], weakness: "magic", rarity: "elite",
    loot: [{ id: "zoloto", n: 24, ch: 1 }, { id: "ukrashenie", n: 1, ch: 0.25 }, { id: "pyl_snov", n: 1, ch: 0.3 }],
  }),
  M("m_strazh_pesok", "Песчаный страж", "desert", 190, 21, 1.5, {
    biome: "desert", ai: "guard", spriteBase: "magmit", tint: "#d6b472", scale: 1.35, xp: 52,
    weakness: "ice", rarity: "rare",
    loot: [{ id: "pesok", n: 6, ch: 1 }, { id: "kristall", n: 1, ch: 0.3 }, { id: "zoloto", n: 10, ch: 0.5 }],
  }),

  // ==================== СНЕЖНЫЕ (6) ====================
  M("m_zombi_led", "Ледяной зомби", "snow", 72, 14, 1.5, {
    biome: "snow", ai: "aggro", spriteBase: "zombi", tint: "#9ed2ea",
    abilities: ["slow"], weakness: "fire", loot: [{ id: "gnil", n: 2, ch: 0.9 }, { id: "sneg", n: 3, ch: 0.9 }],
  }),
  M("m_volk_sneg", "Снежный волк", "snow", 55, 13, 3.4, {
    biome: "snow", ai: "aggro", spriteBase: "kaban", tint: "#edf2f8", scale: 1.05,
    weakness: "fire", loot: [{ id: "myaso", n: 2, ch: 1 }, { id: "kozha", n: 2, ch: 0.8 }],
  }),
  M("m_yeti", "Йети", "snow", 250, 29, 1.9, {
    biome: "snow", ai: "aggro", spriteBase: "zombi", tint: "#f4f8fc", scale: 1.6, xp: 85,
    weakness: "fire", rarity: "elite",
    loot: [{ id: "kozha", n: 4, ch: 1 }, { id: "myaso", n: 4, ch: 1 }, { id: "shuba", n: 1, ch: 0.15 }],
  }),
  M("m_vedma_led", "Ледяная ведьма", "snow", 88, 17, 2.2, {
    gen: "f", biome: "snow", ai: "ranged", spriteBase: "rusalka", tint: "#b8e4f8", atkR: 6, atkCd: 2.2,
    abilities: ["slow", "summon"], weakness: "fire", rarity: "rare",
    loot: [{ id: "sneg", n: 4, ch: 1 }, { id: "kristall", n: 1, ch: 0.4 }, { id: "bint", n: 1, ch: 0.3 }],
  }),
  M("m_snegovik", "Снеговик-убийца", "snow", 135, 19, 1.8, {
    biome: "snow", ai: "aggro", spriteBase: "magmit", tint: "#f2f7fb", scale: 1.15, xp: 44,
    abilities: ["slow"], weakness: "fire", rarity: "rare",
    loot: [{ id: "sneg", n: 8, ch: 1 }, { id: "ugol", n: 3, ch: 0.8 }, { id: "zoloto", n: 8, ch: 0.4 }],
  }),
  M("m_elemental_led", "Ледяной элементаль", "snow", 105, 19, 2.6, {
    biome: "snow", ai: "aggro", spriteBase: "vihrevik", tint: "#8ae0f2", scale: 1.15, flying: true, xp: 58,
    abilities: ["slow", "teleport"], weakness: "fire", rarity: "elite",
    loot: [{ id: "kristall", n: 2, ch: 0.8 }, { id: "nebesnyi_kristall", n: 1, ch: 0.15 }, { id: "sneg", n: 5, ch: 1 }],
  }),

  // ==================== ВУЛКАНИЧЕСКИЕ (6) — Глубины (слой 2) ====================
  M("m_zombi_lava", "Лавовый зомби", "lava", 100, 19, 1.6, {
    biome: "lava", ai: "aggro", spriteBase: "zombi", tint: "#e0602a", xp: 34,
    abilities: ["burn"], weakness: "ice", loot: [{ id: "ugol", n: 3, ch: 1 }, { id: "obsidian", n: 1, ch: 0.4 }, { id: "gnil", n: 1, ch: 0.5 }],
  }),
  M("m_elemental_ogon", "Огненный элементаль", "lava", 115, 23, 2.7, {
    biome: "lava", ai: "aggro", spriteBase: "vihrevik", tint: "#f2782a", scale: 1.2, flying: true, xp: 52,
    abilities: ["burn", "teleport"], weakness: "ice", loot: [{ id: "ugol", n: 4, ch: 1 }, { id: "obsidian", n: 2, ch: 0.5 }],
  }),
  M("m_cherv_vulk", "Вулканический червь", "lava", 210, 27, 2.2, {
    biome: "lava", ai: "aggro", spriteBase: "lavoviy", tint: "#d8401a", scale: 1.55, xp: 66,
    abilities: ["burn"], weakness: "ice", rarity: "rare",
    loot: [{ id: "obsidian", n: 3, ch: 0.9 }, { id: "adamantit", n: 1, ch: 0.15 }, { id: "myaso", n: 2, ch: 0.8 }],
  }),
  M("m_byk_ogon", "Огненный бык", "lava", 175, 31, 2.9, {
    biome: "lava", ai: "aggro", spriteBase: "kaban", tint: "#c84a1a", scale: 1.4, xp: 58,
    abilities: ["burn"], weakness: "ice", rarity: "rare",
    loot: [{ id: "myaso", n: 4, ch: 1 }, { id: "kozha", n: 3, ch: 0.9 }, { id: "ugol", n: 3, ch: 0.8 }],
  }),
  M("m_prizrak_pepel", "Пепельный призрак", "lava", 72, 18, 2.3, {
    biome: "lava", ai: "ghost", spriteBase: "prizrak", tint: "#8c8c94", flying: true, xp: 40,
    abilities: ["teleport", "slow"], weakness: "silver",
    loot: [{ id: "ugol", n: 3, ch: 0.9 }, { id: "obsidian", n: 1, ch: 0.3 }, { id: "tenevaya_sut", n: 1, ch: 0.2 }],
  }),
  M("m_golem_magma", "Магма-голем", "lava", 340, 36, 1.2, {
    biome: "lava", ai: "aggro", spriteBase: "magmit", tint: "#f24a18", scale: 1.8, xp: 110,
    abilities: ["burn"], weakness: "ice", rarity: "elite",
    loot: [{ id: "obsidian", n: 5, ch: 1 }, { id: "adamantit", n: 2, ch: 0.5 }, { id: "zoloto", n: 40, ch: 0.8 }],
  }),

  // ==================== ЛЕСНЫЕ (6) ====================
  M("m_kaban_dik", "Дикий кабан", "forest", 62, 14, 2.5, {
    biome: "forest", ai: "neutral", spriteBase: "kaban", tint: "#5c4830", scale: 1.18,
    weakness: "none", loot: [{ id: "myaso", n: 3, ch: 1 }, { id: "kozha", n: 2, ch: 0.9 }],
  }),
  M("m_volk_obor", "Волк-оборотень", "forest", 88, 18, 3.6, {
    biome: "forest", timeOfDay: "night", ai: "aggro", spriteBase: "kaban", tint: "#4e5564", scale: 1.25, xp: 38,
    weakness: "silver", rarity: "rare",
    loot: [{ id: "myaso", n: 2, ch: 1 }, { id: "kozha", n: 2, ch: 0.9 }, { id: "zoloto", n: 7, ch: 0.4 }],
  }),
  M("m_pauk_yad", "Ядовитый паук", "forest", 42, 11, 3.3, {
    biome: "forest", ai: "aggro", spriteBase: "pauk", tint: "#6ac828", scale: 0.9,
    abilities: ["poison"], weakness: "fire", loot: [{ id: "nit", n: 3, ch: 1 }, { id: "gnil", n: 1, ch: 0.4 }],
  }),
  M("m_duh_les", "Лесной дух", "forest", 68, 14, 2.4, {
    biome: "forest", ai: "ghost", spriteBase: "prizrak", tint: "#7ce29c", flying: true, xp: 36,
    abilities: ["slow", "teleport"], weakness: "magic", rarity: "rare",
    loot: [{ id: "yagoda", n: 3, ch: 0.9 }, { id: "grib", n: 2, ch: 0.7 }, { id: "pyl_snov", n: 1, ch: 0.15 }],
  }),
  M("m_driada", "Дриада-изгнанница", "forest", 92, 16, 2.3, {
    gen: "f", biome: "forest", ai: "ranged", spriteBase: "rusalka", tint: "#92cc6a", atkR: 6, atkCd: 2.1, xp: 42,
    abilities: ["slow", "summon"], weakness: "fire", rarity: "rare",
    loot: [{ id: "brevno", n: 3, ch: 1 }, { id: "yagoda", n: 3, ch: 0.9 }, { id: "zoloto", n: 9, ch: 0.4 }],
  }),
  M("m_medved_mut", "Медведь-мутант", "forest", 210, 27, 2.2, {
    biome: "forest", ai: "neutral", spriteBase: "kaban", tint: "#4e3730", scale: 1.55, xp: 72,
    abilities: ["poison"], weakness: "fire", rarity: "elite",
    loot: [{ id: "myaso", n: 5, ch: 1 }, { id: "kozha", n: 4, ch: 1 }, { id: "zoloto", n: 14, ch: 0.5 }],
  }),

  // ==================== ВОДНЫЕ (5) — берег и океан (слой 4) ====================
  M("m_utoplennik", "Утопленник", "water", 68, 14, 1.8, {
    biome: "coast", ai: "aggro", spriteBase: "zombi", tint: "#3e6e78", xp: 26,
    abilities: ["slow"], weakness: "fire",
    loot: [{ id: "gnil", n: 2, ch: 0.9 }, { id: "korall", n: 1, ch: 0.25 }, { id: "zoloto", n: 5, ch: 0.3 }],
  }),
  M("m_kraken_det", "Кракен-детёныш", "water", 135, 20, 2.0, {
    biome: "coast", ai: "aggro", spriteBase: "sliz", tint: "#7a3e9c", scale: 1.3, flying: true, xp: 62,
    abilities: ["slow", "summon"], weakness: "ice", rarity: "elite",
    loot: [{ id: "korall", n: 2, ch: 0.9 }, { id: "zhemchug", n: 1, ch: 0.3 }, { id: "myaso", n: 2, ch: 0.8 }],
  }),
  M("m_sirena", "Сирена", "water", 78, 15, 2.5, {
    gen: "f", biome: "coast", ai: "ranged", spriteBase: "rusalka", tint: "#e8a2d2", flying: true, atkR: 6, atkCd: 2.3, xp: 44,
    abilities: ["slow"], weakness: "magic", rarity: "rare",
    loot: [{ id: "zhemchug", n: 1, ch: 0.4 }, { id: "pero", n: 2, ch: 0.8 }, { id: "zoloto", n: 10, ch: 0.5 }],
  }),
  M("m_chert_vod", "Водяной чёрт", "water", 95, 19, 3.0, {
    biome: "coast", ai: "aggro", spriteBase: "ten_ohotnik", tint: "#2e6248", scale: 1.1, xp: 40,
    abilities: ["teleport", "slow"], weakness: "silver", rarity: "rare",
    loot: [{ id: "gnil", n: 2, ch: 0.8 }, { id: "kost", n: 2, ch: 0.6 }, { id: "zoloto", n: 9, ch: 0.5 }],
  }),
  M("m_krab_gig", "Гигантский краб", "water", 270, 25, 1.6, {
    biome: "coast", ai: "neutral", spriteBase: "magmit", tint: "#c8563a", scale: 1.5, xp: 80,
    weakness: "ice", rarity: "elite",
    loot: [{ id: "myaso", n: 4, ch: 1 }, { id: "korall", n: 3, ch: 0.9 }, { id: "zhemchug", n: 1, ch: 0.25 }],
  }),

  // ==================== МАГИЧЕСКИЕ (6) — ночь, повсюду редко ====================
  M("m_cherep", "Летающий череп", "magic", 38, 12, 3.2, {
    biome: "any", timeOfDay: "night", ai: "ranged", spriteBase: "vihrevik", tint: "#ece2c8", scale: 0.65, flying: true, atkR: 5, atkCd: 1.8,
    abilities: ["burn"], weakness: "silver", loot: [{ id: "kost", n: 2, ch: 1 }, { id: "zoloto", n: 5, ch: 0.4 }],
  }),
  M("m_eye_mag", "Магический глаз", "magic", 42, 13, 2.7, {
    biome: "any", timeOfDay: "night", ai: "ranged", spriteBase: "vihrevik", tint: "#a45ae8", scale: 0.8, flying: true, atkR: 7, atkCd: 2.2,
    abilities: ["teleport", "slow"], weakness: "magic", rarity: "rare",
    loot: [{ id: "kristall", n: 1, ch: 0.5 }, { id: "zoloto", n: 6, ch: 0.4 }],
  }),
  M("m_dospeh", "Заколдованный доспех", "magic", 155, 19, 1.7, {
    biome: "any", timeOfDay: "night", ai: "aggro", spriteBase: "marsianin", tint: "#7e8cba", scale: 1.25, xp: 50,
    weakness: "magic", rarity: "rare",
    loot: [{ id: "zhel_slitok", n: 2, ch: 0.9 }, { id: "bron_med", n: 1, ch: 0.08 }, { id: "zoloto", n: 8, ch: 0.4 }],
  }),
  M("m_rytsar", "Призрачный рыцарь", "magic", 135, 23, 2.4, {
    biome: "any", timeOfDay: "night", ai: "aggro", spriteBase: "marsianin", tint: "#9adcf0", scale: 1.2, xp: 66,
    abilities: ["teleport"], weakness: "silver", rarity: "elite",
    loot: [{ id: "zoloto", n: 18, ch: 0.9 }, { id: "mech_m", n: 1, ch: 0.06 }, { id: "kost", n: 3, ch: 0.8 }],
  }),
  M("m_vedma", "Ведьма", "magic", 72, 16, 2.4, {
    gen: "f", biome: "any", timeOfDay: "night", ai: "ranged", spriteBase: "rusalka", tint: "#8e5ab2", atkR: 6.5, atkCd: 2.0, xp: 38,
    abilities: ["poison", "slow", "summon"], weakness: "silver", rarity: "rare",
    loot: [{ id: "grib", n: 3, ch: 1 }, { id: "bint", n: 1, ch: 0.4 }, { id: "zoloto", n: 10, ch: 0.5 }],
  }),
  M("m_kultist", "Тёмный культист", "magic", 88, 18, 2.5, {
    biome: "any", timeOfDay: "night", ai: "ranged", spriteBase: "ten_ohotnik", tint: "#3c2c4c", atkR: 6, atkCd: 2.0, xp: 42,
    abilities: ["summon", "teleport"], weakness: "silver", rarity: "rare",
    loot: [{ id: "tenevaya_sut", n: 1, ch: 0.5 }, { id: "zoloto", n: 12, ch: 0.6 }, { id: "bint", n: 1, ch: 0.3 }],
  }),

  // ==================== ОСОБЫЕ (5) — редчайшие гости ночи ====================
  M("m_klon", "Клон игрока", "special", 130, 20, 3.2, {
    biome: "any", timeOfDay: "night", ai: "aggro", spriteBase: "marsianin", tint: "#d8b89e", scale: 1.0, xp: 90,
    abilities: ["teleport"], weakness: "magic", rarity: "legendary",
    loot: [{ id: "zoloto", n: 30, ch: 1 }, { id: "hleb", n: 2, ch: 0.8 }, { id: "bint", n: 2, ch: 0.7 }],
  }),
  M("m_rebenok", "Проклятый ребёнок", "special", 32, 15, 3.5, {
    biome: "any", timeOfDay: "night", ai: "aggro", spriteBase: "zombi", tint: "#c0ace0", scale: 0.55, xp: 36,
    abilities: ["teleport", "slow"], weakness: "silver", rarity: "rare",
    loot: [{ id: "pyl_snov", n: 1, ch: 0.4 }, { id: "zoloto", n: 8, ch: 0.5 }],
  }),
  M("m_ten", "Тень игрока", "special", 110, 21, 3.0, {
    gen: "f", biome: "any", timeOfDay: "night", ai: "ghost", spriteBase: "prizrak", tint: "#26263a", flying: true, xp: 70,
    abilities: ["teleport"], weakness: "magic", rarity: "elite",
    loot: [{ id: "tenevaya_sut", n: 2, ch: 0.7 }, { id: "zoloto", n: 16, ch: 0.7 }],
  }),
  M("m_otshelnik", "Безумный отшельник", "special", 115, 19, 2.2, {
    biome: "any", timeOfDay: "night", ai: "ranged", spriteBase: "zombi", tint: "#8c7c68", scale: 1.05, atkR: 5.5, atkCd: 2.4, xp: 48,
    abilities: ["burn"], weakness: "none", rarity: "rare",
    loot: [{ id: "hleb", n: 2, ch: 0.8 }, { id: "zoloto", n: 11, ch: 0.6 }, { id: "bint", n: 1, ch: 0.4 }],
  }),
  M("m_susch", "Существо из другого измерения", "special", 190, 27, 2.9, {
    gen: "n", biome: "any", timeOfDay: "night", ai: "aggro", spriteBase: "haoszver", tint: "#e05ae8", scale: 0.95, xp: 120,
    abilities: ["teleport", "summon", "slow"], weakness: "magic", rarity: "legendary",
    loot: [{ id: "oskolok_haosa", n: 1, ch: 0.6 }, { id: "zoloto", n: 35, ch: 1 }, { id: "tenevaya_sut", n: 2, ch: 0.5 }],
  }),
];

export const MONSTER_BY_ID: Record<string, MonsterDef> = Object.fromEntries(MONSTERS.map((m) => [m.id, m]));

// =====================================================================
//  ЭЛИТНЫЕ ВЕРСИИ — «ДРЕВНИЕ» (ШАГ 3: суффикс «Древний» + иной цвет)
//  Генерируются для каждого монстра: id `<id>_drevn`, ×2.3 здоровья,
//  ×1.5 урона, ×3 опыта, масштаб ×1.22 и особая расцветка категории.
// =====================================================================
const ANC_WORD = { m: "Древний", f: "Древняя", n: "Древнее" } as const;
const ANC_TINT: Record<MonsterCategory, string> = {
  night: "#b06ae8", cave: "#e8ba56", swamp: "#e0527a", desert: "#8a5cf0", snow: "#58e4dc",
  lava: "#f2d84a", forest: "#f07a3a", water: "#4ae8b0", magic: "#f24ae0", special: "#ff5a5a",
};
export const ANCIENT_SUFFIX = "_drevn";

// ---------------------------------------------------------------------
//  КОНВЕРТАЦИЯ В MobDef (реестр движка)
// ---------------------------------------------------------------------
function toMobDef(m: MonsterDef, ancient: boolean): MobDef {
  const xpBase = m.xp ?? Math.max(4, Math.round(m.hp / 6 + m.dmg * 1.2));
  const isElite = ancient || m.rarity === "elite" || m.rarity === "legendary";
  return {
    id: ancient ? m.id + ANCIENT_SUFFIX : m.id,
    name: ancient ? `${ANC_WORD[m.gen ?? "m"]} ${m.name}` : m.name,
    hp: ancient ? Math.round(m.hp * 2.3) : m.hp,
    dmg: ancient ? Math.round(m.dmg * 1.5) : m.dmg,
    speed: Math.min(4.2, m.speed * (ancient ? 1.06 : 1)),
    xp: ancient ? xpBase * 3 : xpBase,
    ai: m.ai,
    night: m.timeOfDay === "night",
    cave: m.biome === "cave" || m.biome === "lava",
    scale: (m.scale ?? 1) * (ancient ? 1.22 : 1),
    aggroR: (m.aggroR ?? (m.ai === "ranged" ? 12 : m.ai === "guard" ? 8 : 10.5)) + (ancient ? 2.5 : 0),
    atkR: m.atkR ?? (m.ai === "ranged" ? 6.5 : m.ai === "explode" ? 1.4 : 1.3),
    atkCd: m.atkCd ?? (m.ai === "ranged" ? 2.2 : 1.2),
    flying: m.flying || undefined,
    drops: ancient
      ? [
          ...m.loot.map((d) => ({ id: d.id, n: Math.ceil(d.n * 1.5), ch: Math.min(0.95, d.ch * 1.15) })),
          { id: "zoloto", n: 12, ch: 0.9 },
          { id: "kristall", n: 1, ch: 0.3 },
        ]
      : m.loot,
    spriteBase: m.spriteBase,
    tint: ancient ? ANC_TINT[m.category] : m.tint,
    elite: isElite || undefined,
  };
}

/** Полный реестр: обычные + «древние» версии всех монстров */
export const MONSTER_MOBS: Record<string, MobDef> = (() => {
  const out: Record<string, MobDef> = {};
  for (const m of MONSTERS) {
    out[m.id] = toMobDef(m, false);
    out[m.id + ANCIENT_SUFFIX] = toMobDef(m, true);
  }
  return out;
})();

/** id обычного монстра → id древней версии (для элит-ролла при спавне) */
export const ANCIENT_ID: Record<string, string> = Object.fromEntries(
  MONSTERS.map((m) => [m.id, m.id + ANCIENT_SUFFIX]),
);
/** есть ли у id «древняя» версия */
export const ancientOf = (id: string): string | null => ANCIENT_ID[id] ?? null;

// =====================================================================
//  ТАБЛИЦЫ СПАВНА (ШАГ 3)
//  Вес редкости: common — частые гости, legendary — почти миф.
// =====================================================================
const RARITY_W: Record<MonsterRarity, number> = { common: 16, rare: 5.5, elite: 1.6, legendary: 0.5 };
const W = (m: MonsterDef): [string, number] => [m.id, RARITY_W[m.rarity]];

/** Ночная поверхность: вся ночная категория + магия + особые (по их редкости) */
export const MONSTER_NIGHT_SPAWN: [string, number][] = MONSTERS
  .filter((m) => (m.biome === "night" || m.biome === "any") && m.timeOfDay !== "day")
  .map(W);

/** Пещеры (слой 1): пещерная категория (сюда же входит «пещерный паук») */
export const MONSTER_CAVE_SPAWN: [string, number][] = MONSTERS
  .filter((m) => m.biome === "cave")
  .map(W);

/** Добавки к таблицам иных слоёв: лава → Глубины, вода → Океан, магия → Мир теней */
export const MONSTER_LAYER_SPAWN: Record<number, [string, number][]> = {
  2: MONSTERS.filter((m) => m.biome === "lava").map(W),
  4: MONSTERS.filter((m) => m.biome === "coast").map(W),
  7: MONSTERS.filter((m) => m.category === "magic").map((m) => [m.id, RARITY_W[m.rarity] * 1.6]),
};

/** Биом поверхности → ключ среды обитания монстров */
const BIOME_KEY: Partial<Record<Biome, MonsterBiome>> = {
  [Biome.Swamp]: "swamp",
  [Biome.Desert]: "desert",
  [Biome.Tundra]: "snow",
  [Biome.SnowMount]: "snow",
  [Biome.Forest]: "forest",
  [Biome.Meadow]: "forest",   // на лугу — разбавленная лесная фауна
  [Biome.Beach]: "coast",
  [Biome.Ocean]: "coast",     // тайлы у самой воды
};

/** Готовые дневные/ночные таблицы по биомам (считаются один раз при загрузке) */
const BIOME_TABLES: Partial<Record<Biome, { day: [string, number][]; night: [string, number][] }>> = {};
for (const b of Object.keys(BIOME_KEY).map(Number) as Biome[]) {
  const key = BIOME_KEY[b]!;
  const list = MONSTERS.filter((m) => m.biome === key);
  const day = list.filter((m) => m.timeOfDay !== "night").map(W);
  const night = [...day, ...list.filter((m) => m.timeOfDay === "night").map(W)];
  BIOME_TABLES[b] = { day, night };
}
// луг — редкие выходцы из леса
{
  const forest = BIOME_TABLES[Biome.Forest]!;
  BIOME_TABLES[Biome.Meadow] = {
    day: forest.day.map(([id, w]) => [id, w * 0.3] as [string, number]),
    night: forest.night.map(([id, w]) => [id, w * 0.3] as [string, number]),
  };
}

/** Биомный набор монстров для поверхности */
export function monsterBiomeSpawn(biome: Biome, night: boolean): [string, number][] {
  const t = BIOME_TABLES[biome];
  return t ? (night ? t.night : t.day) : [];
}
