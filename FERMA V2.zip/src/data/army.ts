import type { UnitDef, UnitKind } from "../types/war";

// ===== Рода войск =====
export const UNITS: Record<UnitKind, UnitDef> = {
  infantry: {
    id: "infantry", name: "Копейщик", plural: "Копейная рать", icon: "Shield",
    hp: 100, atk: 12, def: 14, rng: 1, move: 3,
    cost: { gold: 60, res: [["oruzhie", 1], ["kozha", 2]] },
    upkeepGold: 0.5, upkeepFood: 0.3, need: "kazarmy",
    desc: "Основа любого войска. Стоит насмерть, держит строй против конницы.",
    strongVs: ["cavalry"], weakVs: ["mage", "catapult"],
  },
  archer: {
    id: "archer", name: "Лучник", plural: "Лучная сотня", icon: "Target",
    hp: 75, atk: 16, def: 7, rng: 4, move: 3,
    cost: { gold: 75, res: [["palka", 4], ["nit", 3]] },
    upkeepGold: 0.6, upkeepFood: 0.3, need: "strelkovaya",
    desc: "Бьёт с дальних холмов. Слаб в ближнем бою, силён против пехоты.",
    strongVs: ["infantry", "dragon"], weakVs: ["cavalry"],
  },
  cavalry: {
    id: "cavalry", name: "Всадник", plural: "Конная дружина", icon: "Rabbit",
    hp: 120, atk: 22, def: 11, rng: 1, move: 6,
    cost: { gold: 140, res: [["kozha", 4], ["zhel_slitok", 2]] },
    upkeepGold: 1.2, upkeepFood: 0.9, need: "konyushni",
    desc: "Стремительный удар во фланг. Топчет лучников и обозы.",
    strongVs: ["archer", "catapult", "mage"], weakVs: ["infantry"],
  },
  catapult: {
    id: "catapult", name: "Катапульта", plural: "Камнемёты", icon: "Crosshair",
    hp: 90, atk: 26, def: 5, rng: 5, move: 2,
    cost: { gold: 180, res: [["brevno", 10], ["nit", 6]] },
    upkeepGold: 1.3, upkeepFood: 0.3, need: "katapulta", siege: 26,
    desc: "Крушит стены и плотный строй. Беззащитна вблизи.",
    strongVs: ["infantry"], weakVs: ["cavalry"],
  },
  mage: {
    id: "mage", name: "Чародей", plural: "Круг чародеев", icon: "Sparkles",
    hp: 70, atk: 30, def: 6, rng: 3, move: 3,
    cost: { gold: 260, res: [["cheshuya", 1], ["zoloto", 60]] },
    upkeepGold: 2.2, upkeepFood: 0.6, need: "altar", ability: "firestorm",
    desc: "Огненный вихрь бьёт по площади. Дорог и хрупок.",
    strongVs: ["infantry", "siege"], weakVs: ["cavalry"],
  },
  dragon: {
    id: "dragon", name: "Дракон", plural: "Драконье крыло", icon: "Flame",
    hp: 240, atk: 48, def: 24, rng: 2, move: 5,
    cost: { gold: 900, res: [["cheshuya", 3], ["myaso", 20]] },
    upkeepGold: 5.5, upkeepFood: 3, need: "obsidian_tron", ability: "breath",
    desc: "Живой ужас небес. Летит над стенами и водой, дышит пламенем.",
    strongVs: ["infantry", "siege", "fleet"], weakVs: ["archer"],
  },
  siege: {
    id: "siege", name: "Таран", plural: "Осадный обоз", icon: "Hammer",
    hp: 140, atk: 14, def: 10, rng: 1, move: 2,
    cost: { gold: 150, res: [["brevno", 14], ["zhel_slitok", 3]] },
    upkeepGold: 1, upkeepFood: 0.3, need: "osadnaya", siege: 40,
    desc: "Ломает ворота с одного доброго удара. В поле почти бесполезен.",
    weakVs: ["cavalry", "mage"],
  },
  fleet: {
    id: "fleet", name: "Ладья", plural: "Боевые ладьи", icon: "Ship",
    hp: 160, atk: 20, def: 16, rng: 3, move: 5,
    cost: { gold: 220, res: [["doska", 16], ["tkan", 6]] },
    upkeepGold: 1.5, upkeepFood: 0.6, need: "torg_port", water: true,
    desc: "Ходит по воде, возит войско и бьёт с реки.",
    strongVs: ["siege"], weakVs: ["dragon"],
  },
};

export const UNIT_ORDER: UnitKind[] = ["infantry", "archer", "cavalry", "catapult", "siege", "mage", "dragon", "fleet"];

// ===== Генералы =====
export const GEN_NAMES_M = [
  "Воислав", "Бранимир", "Держислав", "Ратмир", "Судислав", "Твердислав", "Ярун",
  "Крут", "Молнезар", "Огнеслав", "Стоян", "Лютобор", "Вихрь", "Горазд",
];
export const GEN_NAMES_F = [
  "Свенельда", "Ратмира", "Вратислава", "Огнеслава", "Бранислава", "Лютава", "Ярославна",
];
export const GEN_TITLES = [
  "Щит Порога", "Гроза Топей", "Волк Перевала", "Несломленный", "Хмурый",
  "Быстрый", "Костолом", "Тихий", "Багряный", "Двужильный", "Седой", "Рысь",
];
export const GEN_BIOS = [
  "Начинал простым копейщиком, выжил там, где полегла сотня.",
  "Говорит мало, но за ним идут молча и до конца.",
  "Родом из пастухов; читает поле боя, как погоду.",
  "Потерял семью на войне и с тех пор не знает страха.",
  "Учился ратному делу у заезжего чужеземца.",
  "Носит шрам через всё лицо и зовёт его «первым уроком».",
  "Трижды отказывался от золота врага. На четвёртый раз его не спрашивали.",
  "Утверждает, что видел дракона вблизи и остался жив.",
];

// ===== Названия наций =====
export const NATION_NAMES: [string, string][] = [
  ["Вельдская Марка", "вельдские"], ["Кряжевое Царство", "кряжевые"],
  ["Солёные Острова", "островные"], ["Хладный Предел", "хладные"],
  ["Златолесье", "златолесские"], ["Пепельная Орда", "ордынские"],
  ["Тихоречье", "тихореченские"], ["Гранитный Союз", "гранитные"],
  ["Лунная Митрополия", "лунные"], ["Пустоши Ашшара", "ашшарские"],
  ["Вересковый Дол", "вересковые"], ["Медное Княжество", "медные"],
  ["Стеклянная Республика", "стеклянные"], ["Обитель Девяти", "девятинские"],
  ["Дикие Ватаги", "ватажные"], ["Янтарный Берег", "янтарные"],
  ["Трёхбашенный Град", "трёхбашенные"], ["Сумеречный Клин", "сумеречные"],
];

export const NATION_CAPITALS = [
  "Вельдград", "Камнеград", "Солеград", "Стылый Двор", "Златовеж", "Пепелище",
  "Тихомирье", "Гранитник", "Луноверь", "Ашшар", "Вересков", "Меднодол",
  "Стеклоград", "Девятибашенный", "Ватажье", "Янтарёво", "Трёхбашенный", "Сумерки",
];

export const NATION_RULERS_M = ["Богдан", "Велислав", "Гордей", "Драгомир", "Казимир", "Лютомир", "Мстислав", "Остромир", "Радогост", "Славомир"];
export const NATION_RULERS_F = ["Владислава", "Добронега", "Звенислава", "Милослава", "Предслава", "Радмила", "Ясна"];

export const RELIGIONS = ["Тихое Пламя", "Древо Жизни", "Девять Ветров", "Лунный Свод", "Каменный Отец", "Пустая Длань"];
export const CULTURES = ["поречане", "горцы", "степняки", "лесовики", "поморы", "пустынники", "снежные"];
export const NATION_GOVS = ["Монархия", "Республика", "Теократия", "Диктатура", "Магократия", "Орда", "Княжество"];

export const FLAG_SYMS = ["★", "✦", "⚔", "☾", "☘", "▲", "◆", "✶", "☗", "⚑", "☀", "⚓"];
export const FLAG_BG = ["#8a2f2f", "#2f5a8a", "#2f7a52", "#7a5a2f", "#4a2f7a", "#2f7a7a", "#7a2f5a", "#3a3f4a", "#6a6a2f"];
export const FLAG_FG = ["#f2d38a", "#efe6d5", "#ffd97a", "#d8e8f0", "#f2a24d"];

// ===== Названия отрядов =====
export const SQUAD_EPITHETS = [
  "Багряные", "Северные", "Вольные", "Стальные", "Тихие", "Быстрые",
  "Дубовые", "Волчьи", "Ястребиные", "Каменные", "Пламенные", "Рассветные",
];
