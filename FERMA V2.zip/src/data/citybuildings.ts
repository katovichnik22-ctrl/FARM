import type { BuildingDef } from "../types";

// ===== Городские постройки (2-й этап). Все с уровнями, эффектами и цепочками =====
const B = (d: Partial<BuildingDef> & { id: string; name: string; desc: string; icon: string; cat: string; w: number; h: number; cost: [string, number][]; buildTime: number }): BuildingDef => ({
  hp: 200, blocks: false, maxLvl: 3, needsCity: true, ...d,
});

export const CITY_BUILDINGS: Record<string, BuildingDef> = Object.fromEntries(
  ([
    // ---------- Особые ----------
    B({ id: "ratusha", name: "Ратуша", desc: "Сердце поселения. Отсюда начинается город и власть мэра.", icon: "Landmark", cat: "Город", w: 3, h: 3, cost: [["doska", 14], ["kamen", 12], ["brevno", 8]], buildTime: 20, hp: 500, needsCity: false, townhall: true, jobs: 4, eff: { gold: 6, order: 8, culture: 4 }, maxLvl: 6, upkeep: 1 }),
    B({ id: "doroga", name: "Дорога", desc: "Утоптанный камень. Жители ходят быстрее, караваны идут дальше.", icon: "Route", cat: "Город", w: 1, h: 1, cost: [["kamen", 2]], buildTime: 1, hp: 60, needsCity: false, road: true, maxLvl: 1, eff: { gold: 0.2, happy: 0.2 } }),
    B({ id: "dvorec", name: "Дворец правителя", desc: "Мрамор, знамёна и зал приёмов. Знать при дворе, династия крепка.", icon: "Castle", cat: "Город", w: 4, h: 4, cost: [["doska", 40], ["kamen", 50], ["zhel_slitok", 12], ["zoloto", 500]], buildTime: 70, hp: 900, jobs: 10, eff: { order: 14, culture: 14, happy: 6, gold: 10 }, upkeep: 5, maxLvl: 4 }),
    B({ id: "parlament", name: "Парламент", desc: "Палата фракций. Здесь спорят знать, купцы, церковь и народ.", icon: "Scale", cat: "Город", w: 3, h: 3, cost: [["doska", 30], ["kamen", 30], ["zoloto", 260]], buildTime: 45, hp: 600, jobs: 8, eff: { order: 6, culture: 10, happy: 4 }, upkeep: 3, maxLvl: 3 }),
    B({ id: "sklad_gorod", name: "Городской склад", desc: "Общий амбар города: сюда стекается сырьё для мастерских.", icon: "Warehouse", cat: "Город", w: 2, h: 2, cost: [["doska", 12], ["kamen", 6]], buildTime: 14, jobs: 2, eff: { gold: 1 } }),
    B({ id: "pamyatnik", name: "Памятник", desc: "Камень в честь героя. Жители гордятся и вспоминают победы.", icon: "Sparkle", cat: "Город", w: 1, h: 1, cost: [["kamen", 20], ["zoloto", 80]], buildTime: 12, eff: { culture: 6, happy: 4 }, maxLvl: 3 }),

    // ---------- Жилые ----------
    B({ id: "osobnyak", name: "Особняк", desc: "Дом зажиточной семьи: резной конёк, слюдяные окна.", icon: "Building", cat: "Жильё", w: 2, h: 2, cost: [["doska", 18], ["kamen", 10], ["nit", 4]], buildTime: 18, housing: 10, eff: { happy: 2, gold: 2 }, upkeep: 1 }),
    B({ id: "zamok", name: "Замок", desc: "Толстые стены и донжон. Дом знати и убежище в лихую годину.", icon: "Castle", cat: "Жильё", w: 3, h: 3, cost: [["kamen", 45], ["doska", 20], ["zhel_slitok", 6]], buildTime: 40, hp: 800, housing: 24, eff: { order: 8, culture: 4 }, upkeep: 3 }),
    B({ id: "neboskreb", name: "Высокий дом", desc: "Многоярусная башня-общежитие. В окнах горят сотни огней.", icon: "Building2", cat: "Жильё", w: 2, h: 2, cost: [["kamen", 60], ["zhel_slitok", 14], ["doska", 30]], buildTime: 55, hp: 700, housing: 60, eff: { pollution: 2, happy: -2 }, upkeep: 4 }),

    // ---------- Производство ----------
    B({ id: "shahta", name: "Шахта", desc: "Ствол уходит в темень. Руда сама идёт наверх в бадьях.", icon: "Pickaxe", cat: "Производство", w: 2, h: 2, cost: [["doska", 14], ["kamen", 16]], buildTime: 22, jobs: 8, eff: { pollution: 3, gold: 2 }, produce: { id: "zhel_ruda", every: 60, max: 8 } }),
    B({ id: "kuznica", name: "Кузница", desc: "Молот поёт по наковальне. Руда становится слитком.", icon: "Hammer", cat: "Производство", w: 2, h: 2, cost: [["kamen", 18], ["doska", 10], ["ugol", 6]], buildTime: 20, jobs: 6, eff: { pollution: 3, gold: 3 }, chain: { in: [["zhel_ruda", 2], ["ugol", 1]], out: ["zhel_slitok", 1], every: 22 } }),
    B({ id: "pilorama", name: "Лесопильный двор", desc: "Большая пила режет брёвна в ровные доски.", icon: "Slice", cat: "Производство", w: 2, h: 2, cost: [["doska", 10], ["zhel_slitok", 2]], buildTime: 18, jobs: 5, eff: { pollution: 1, gold: 2 }, chain: { in: [["brevno", 2]], out: ["doska", 3], every: 16 } }),
    B({ id: "stolyarka", name: "Столярная", desc: "Из досок выходит мебель — товар дорогой и любимый.", icon: "Armchair", cat: "Производство", w: 2, h: 2, cost: [["doska", 16], ["nit", 4]], buildTime: 22, jobs: 6, eff: { gold: 4, culture: 2 }, chain: { in: [["doska", 3]], out: ["mebel", 1], every: 26 } }),
    B({ id: "tkackaya", name: "Ткацкая", desc: "Веретёна крутятся день-деньской, полотно ложится в рулоны.", icon: "Shirt", cat: "Производство", w: 2, h: 2, cost: [["doska", 12], ["nit", 8]], buildTime: 18, jobs: 6, eff: { gold: 3 }, chain: { in: [["nit", 3]], out: ["tkan", 2], every: 20 } }),
    B({ id: "yuvelirnaya", name: "Ювелирная", desc: "Тонкая работа с медью и золотом. Украшения уходят за морем.", icon: "Gem", cat: "Производство", w: 2, h: 2, cost: [["doska", 14], ["med_slitok", 6]], buildTime: 26, jobs: 4, eff: { gold: 7, culture: 3 }, chain: { in: [["med_slitok", 1], ["zoloto", 15]], out: ["ukrashenie", 1], every: 32 } }),
    B({ id: "pivovarnya", name: "Пивоварня", desc: "Хмель, солод и терпение. В таверне ждут не дождутся.", icon: "Beer", cat: "Производство", w: 2, h: 2, cost: [["doska", 14], ["glina", 8]], buildTime: 20, jobs: 5, eff: { happy: 4, gold: 3, health: -1 }, chain: { in: [["zerno", 2]], out: ["pivo", 2], every: 24 } }),
    B({ id: "zavod", name: "Завод", desc: "Паровые молоты и шестерни. Инструмент льётся рекой.", icon: "Factory", cat: "Производство", w: 3, h: 3, cost: [["kamen", 40], ["zhel_slitok", 12], ["doska", 20]], buildTime: 45, jobs: 18, eff: { pollution: 8, gold: 8, health: -2 }, chain: { in: [["zhel_slitok", 2], ["doska", 2]], out: ["instrument", 2], every: 24 }, upkeep: 3 }),
    B({ id: "fabrika", name: "Мануфактура", desc: "Сотни рук шьют, красят, пакуют. Товар на весь материк.", icon: "Building2", cat: "Производство", w: 3, h: 3, cost: [["kamen", 34], ["doska", 30], ["zhel_slitok", 8]], buildTime: 44, jobs: 20, eff: { pollution: 6, gold: 9 }, chain: { in: [["tkan", 2], ["ukrashenie", 1]], out: ["naryad", 1], every: 30 }, upkeep: 3 }),

    // ---------- Еда ----------
    B({ id: "teplica", name: "Теплица", desc: "Под слюдой зелено даже в стужу. Зима больше не страшна.", icon: "Sprout", cat: "Еда", w: 2, h: 2, cost: [["doska", 14], ["pesok", 10], ["glina", 6]], buildTime: 22, jobs: 4, eff: { food: 14, health: 2 } }),
    B({ id: "pole", name: "Пашня", desc: "Ровные борозды до горизонта. Хлеб — всему голова.", icon: "Wheat", cat: "Еда", w: 3, h: 3, cost: [["palka", 10], ["glina", 6]], buildTime: 16, jobs: 8, eff: { food: 10 }, produce: { id: "zerno", every: 45, max: 10 } }),
    B({ id: "melnica", name: "Мельница", desc: "Крылья ловят ветер, жернова шепчут. Зерно станет мукой.", icon: "Fan", cat: "Еда", w: 2, h: 2, cost: [["doska", 16], ["kamen", 10]], buildTime: 24, jobs: 4, eff: { food: 6, culture: 2 }, chain: { in: [["zerno", 2]], out: ["muka", 2], every: 18 } }),
    B({ id: "pekarnya", name: "Пекарня", desc: "Запах свежего каравая слышен через три улицы.", icon: "CookingPot", cat: "Еда", w: 2, h: 2, cost: [["kamen", 14], ["doska", 8], ["glina", 6]], buildTime: 18, jobs: 5, eff: { food: 8, happy: 4 }, chain: { in: [["muka", 2]], out: ["hleb", 3], every: 16 } }),
    B({ id: "ambar", name: "Амбар", desc: "Запас на чёрный день. Голод обходит город стороной.", icon: "Warehouse", cat: "Еда", w: 2, h: 2, cost: [["doska", 14], ["brevno", 8]], buildTime: 16, jobs: 2, eff: { food: 8, happy: 2 } }),
    B({ id: "kuhnya", name: "Общая кухня", desc: "Котлы на весь квартал. Никто не уходит голодным.", icon: "UtensilsCrossed", cat: "Еда", w: 2, h: 2, cost: [["doska", 10], ["kamen", 8]], buildTime: 14, jobs: 4, eff: { food: 6, happy: 5, health: 3 } }),
    B({ id: "port_ryb", name: "Рыбный порт", desc: "Сети сохнут на кольях, чайки орут. Ставить у воды.", icon: "Anchor", cat: "Еда", w: 3, h: 2, cost: [["doska", 20], ["nit", 10], ["brevno", 10]], buildTime: 28, jobs: 8, eff: { food: 16, gold: 3 } }),
    B({ id: "kolodec_gor", name: "Водокачка", desc: "Каменный резервуар и желоба. Вода в каждом дворе.", icon: "Droplet", cat: "Еда", w: 2, h: 2, cost: [["kamen", 20], ["doska", 8]], buildTime: 20, jobs: 2, eff: { water: 24, health: 3 } }),

    // ---------- Оборона ----------
    B({ id: "kazarmy", name: "Казармы", desc: "Койки, стойки с копьями и вечный крик десятника.", icon: "Swords", cat: "Оборона", w: 3, h: 2, cost: [["doska", 20], ["kamen", 18], ["zhel_slitok", 4]], buildTime: 30, hp: 500, jobs: 10, eff: { order: 14, crime: -8 }, upkeep: 2 }),
    B({ id: "strelkovaya", name: "Стрельбище лучников", desc: "Мишени в соломе. Меткий глаз — лучшая стена.", icon: "Target", cat: "Оборона", w: 2, h: 2, cost: [["doska", 14], ["palka", 12], ["nit", 6]], buildTime: 20, jobs: 6, eff: { order: 8, crime: -4 } }),
    B({ id: "konyushni", name: "Конюшни", desc: "Тёплое сено и топот копыт. Дозор объедет все дороги.", icon: "Tent", cat: "Оборона", w: 3, h: 2, cost: [["doska", 18], ["palka", 10], ["brevno", 10]], buildTime: 24, jobs: 5, eff: { order: 6, gold: 2, crime: -3 } }),
    B({ id: "oruzhejnaya", name: "Оружейная кузня", desc: "Мечи, брони и наконечники. Гарнизон в железе.", icon: "Sword", cat: "Оборона", w: 2, h: 2, cost: [["kamen", 20], ["zhel_slitok", 8], ["ugol", 8]], buildTime: 28, jobs: 6, eff: { order: 10, pollution: 2 }, chain: { in: [["zhel_slitok", 2]], out: ["oruzhie", 1], every: 28 } }),
    B({ id: "bashnya", name: "Сторожевая башня", desc: "С неё видны все дороги. Разбойник не подойдёт.", icon: "TowerControl", cat: "Оборона", w: 1, h: 1, cost: [["kamen", 16], ["doska", 6]], buildTime: 14, hp: 420, blocks: true, jobs: 2, eff: { order: 6, crime: -4 }, light: 3.4 }),
    B({ id: "vorota", name: "Городские ворота", desc: "Створы окованы железом. Днём открыты, ночью на засов.", icon: "DoorOpen", cat: "Оборона", w: 2, h: 1, cost: [["doska", 12], ["zhel_slitok", 4], ["kamen", 10]], buildTime: 18, hp: 450, blocks: true, door: true, eff: { order: 4, crime: -2 } }),
    B({ id: "katapulta", name: "Катапульта", desc: "Рычаг, канаты и добрый камень. Осада не пройдёт.", icon: "Crosshair", cat: "Оборона", w: 2, h: 2, cost: [["brevno", 20], ["nit", 10], ["zhel_slitok", 4]], buildTime: 26, hp: 300, jobs: 3, eff: { order: 10 } }),
    B({ id: "osadnaya", name: "Осадная мастерская", desc: "Тут строят тараны и башни на колёсах.", icon: "Hammer", cat: "Оборона", w: 3, h: 2, cost: [["brevno", 26], ["doska", 18], ["zhel_slitok", 6]], buildTime: 34, jobs: 8, eff: { order: 12, pollution: 2 }, upkeep: 2 }),

    // ---------- Наука ----------
    B({ id: "biblioteka", name: "Библиотека", desc: "Свитки, карты и тишина. Знание любит покой.", icon: "BookOpen", cat: "Наука", w: 2, h: 2, cost: [["doska", 18], ["kamen", 10], ["nit", 6]], buildTime: 24, jobs: 4, eff: { science: 10, culture: 6, happy: 2 } }),
    B({ id: "akademiya", name: "Академия", desc: "Ученики спорят у доски. Отсюда выходят мастера.", icon: "GraduationCap", cat: "Наука", w: 3, h: 2, cost: [["doska", 26], ["kamen", 20], ["zoloto", 120]], buildTime: 36, jobs: 10, eff: { science: 18, culture: 8 }, upkeep: 2 }),
    B({ id: "laboratoriya", name: "Лаборатория", desc: "Колбы, пар и странные запахи. Иногда что-то взрывается.", icon: "FlaskConical", cat: "Наука", w: 2, h: 2, cost: [["kamen", 18], ["med_slitok", 6], ["pesok", 10]], buildTime: 30, jobs: 6, eff: { science: 14, pollution: 2, health: -1 } }),
    B({ id: "observatoriya", name: "Обсерватория", desc: "Медная труба смотрит в звёзды. Небо подсказывает погоду.", icon: "Telescope", cat: "Наука", w: 2, h: 2, cost: [["kamen", 24], ["med_slitok", 8], ["pesok", 12]], buildTime: 34, jobs: 4, eff: { science: 16, culture: 6 } }),
    B({ id: "universitet", name: "Университет", desc: "Четыре факультета и вечные диспуты. Гордость града.", icon: "School", cat: "Наука", w: 3, h: 3, cost: [["doska", 40], ["kamen", 40], ["zoloto", 320]], buildTime: 55, jobs: 18, eff: { science: 30, culture: 14, happy: 3 }, upkeep: 4 }),

    // ---------- Магия ----------
    B({ id: "altar", name: "Алтарь", desc: "Камень в кругу свечей. Чары тихо тлеют в воздухе.", icon: "Sparkles", cat: "Магия", w: 2, h: 2, cost: [["kamen", 18], ["cheshuya", 1], ["zoloto", 90]], buildTime: 26, jobs: 2, eff: { faith: 8, science: 6, culture: 4 }, light: 3.6 }),
    B({ id: "portal", name: "Портал", desc: "Кольцо из обсидиана гудит. Товары приходят ниоткуда.", icon: "CircleDot", cat: "Магия", w: 2, h: 2, cost: [["kamen", 30], ["cheshuya", 2], ["zoloto", 260]], buildTime: 40, jobs: 4, eff: { science: 12, gold: 8, culture: 6 }, light: 4.2, upkeep: 3 }),
    B({ id: "obsidian_tron", name: "Обсидиановый трон", desc: "Чёрное стекло и багровый свет. Власть чародеев зрима.", icon: "Crown", cat: "Магия", w: 3, h: 3, cost: [["kamen", 50], ["cheshuya", 4], ["zoloto", 500]], buildTime: 60, jobs: 6, eff: { faith: 10, science: 18, order: 8, happy: -3 }, light: 5, upkeep: 5 }),

    // ---------- Экономика ----------
    B({ id: "rynok", name: "Рынок", desc: "Ряды, зазывалы, запах пряностей. Сердце торга.", icon: "Store", cat: "Экономика", w: 3, h: 2, cost: [["doska", 18], ["palka", 10], ["nit", 6]], buildTime: 20, jobs: 8, eff: { gold: 8, happy: 4, crime: 2 } }),
    B({ id: "bank", name: "Банк", desc: "Сундуки в подвале, книга долгов на столе. Вклады и займы.", icon: "Landmark", cat: "Экономика", w: 2, h: 2, cost: [["kamen", 26], ["doska", 14], ["zoloto", 180]], buildTime: 32, jobs: 6, eff: { gold: 12, crime: 2 }, upkeep: 2 }),
    B({ id: "birzha", name: "Биржа", desc: "Крики маклеров и мел на доске цен. Здесь делают состояния.", icon: "TrendingUp", cat: "Экономика", w: 2, h: 2, cost: [["doska", 24], ["kamen", 18], ["zoloto", 300]], buildTime: 38, jobs: 8, eff: { gold: 16, crime: 3, culture: 2 }, upkeep: 3 }),
    B({ id: "torg_port", name: "Торговый порт", desc: "Причалы, краны и корабли с дальних берегов.", icon: "Ship", cat: "Экономика", w: 3, h: 3, cost: [["doska", 34], ["brevno", 20], ["kamen", 16]], buildTime: 42, jobs: 14, eff: { gold: 14, pollution: 2 }, upkeep: 3 }),
    B({ id: "karavan_saray", name: "Караван-сарай", desc: "Двор с колодцем и стойлами. Отсюда уходят обозы.", icon: "Tent", cat: "Экономика", w: 3, h: 2, cost: [["doska", 20], ["kamen", 14], ["palka", 10]], buildTime: 26, jobs: 8, eff: { gold: 10, happy: 2 } }),

    // ---------- Религия ----------
    B({ id: "hram", name: "Храм", desc: "Свечи, ладан и негромкий хор. Тут утешают души.", icon: "Church", cat: "Религия", w: 2, h: 2, cost: [["kamen", 22], ["doska", 12], ["zoloto", 60]], buildTime: 26, jobs: 4, eff: { faith: 14, happy: 5, health: 2, crime: -3 } }),
    B({ id: "sobor", name: "Собор", desc: "Своды уходят ввысь, витражи ловят закат.", icon: "Church", cat: "Религия", w: 3, h: 3, cost: [["kamen", 50], ["doska", 26], ["zoloto", 280]], buildTime: 52, jobs: 10, eff: { faith: 30, happy: 8, culture: 10, crime: -6 }, upkeep: 3 }),
    B({ id: "monastyr", name: "Монастырь", desc: "Тихий двор, травник и переписчики книг.", icon: "BookOpen", cat: "Религия", w: 3, h: 2, cost: [["kamen", 28], ["doska", 18]], buildTime: 34, jobs: 8, eff: { faith: 16, health: 6, science: 6, food: 4 } }),

    // ---------- Досуг ----------
    B({ id: "taverna", name: "Таверна", desc: "Очаг, эль и песни до полуночи. Народ сюда идёт всегда.", icon: "Beer", cat: "Досуг", w: 2, h: 2, cost: [["doska", 16], ["kamen", 8], ["brevno", 8]], buildTime: 20, jobs: 6, eff: { happy: 10, gold: 4, crime: 3 }, tavern: true, light: 3.2 }),
    B({ id: "teatr", name: "Театр", desc: "Маски, свечи у рампы и слёзы в зале.", icon: "Drama", cat: "Досуг", w: 3, h: 2, cost: [["doska", 26], ["kamen", 14], ["nit", 10]], buildTime: 32, jobs: 8, eff: { happy: 12, culture: 14 }, upkeep: 2 }),
    B({ id: "arena", name: "Арена", desc: "Песок, рёв толпы и честная сталь.", icon: "Swords", cat: "Досуг", w: 3, h: 3, cost: [["kamen", 44], ["doska", 20]], buildTime: 44, jobs: 10, eff: { happy: 14, culture: 8, order: 4, crime: 2 }, upkeep: 2 }),
    B({ id: "zoopark", name: "Зверинец", desc: "Клетки с диковинами со всех восьми земель.", icon: "PawPrint", cat: "Досуг", w: 3, h: 2, cost: [["doska", 24], ["palka", 16], ["kozha", 10]], buildTime: 34, jobs: 6, eff: { happy: 10, culture: 8, health: -1 }, upkeep: 2 }),
    B({ id: "park", name: "Парк", desc: "Липы, лавочки и пруд. Здесь дышится легко.", icon: "Trees", cat: "Досуг", w: 3, h: 3, cost: [["palka", 14], ["glina", 8], ["yagoda", 6]], buildTime: 16, eff: { happy: 8, health: 6, pollution: -6, culture: 3 } }),

    // ---------- ЧУДЕСА СВЕТА (12) ----------
    W({ id: "w_kolos", name: "Медный Колосс", desc: "Исполин в гавани держит огонь над волнами.", icon: "PersonStanding", bonus: "Порядок +40, слава города растёт вдвое", cost: [["med_slitok", 40], ["kamen", 60], ["zoloto", 900]], eff: { order: 40, culture: 20, happy: 6 } }),
    W({ id: "w_mayak", name: "Великий Маяк", desc: "Луч режет туман за сто вёрст. Корабли идут на свет.", icon: "Lightbulb", bonus: "Морская торговля +50%, караваны безопаснее", cost: [["kamen", 70], ["med_slitok", 20], ["zoloto", 800]], eff: { gold: 30, culture: 14 }, light: 9 }),
    W({ id: "w_sady", name: "Висячие Сады", desc: "Ярусы зелени и водопады посреди камня.", icon: "Trees", bonus: "Еда +40, счастье +15, грязь уходит", cost: [["doska", 60], ["glina", 40], ["yagoda", 30], ["zoloto", 700]], eff: { food: 40, happy: 15, pollution: -20, health: 10 } }),
    W({ id: "w_biblio", name: "Хранилище Всех Слов", desc: "Свитки со всех земель под одной крышей.", icon: "Library", bonus: "Наука +60, учёные прибывают сами", cost: [["doska", 70], ["kamen", 50], ["zoloto", 900]], eff: { science: 60, culture: 25 } }),
    W({ id: "w_hram", name: "Храм Небесного Свода", desc: "Купол, в котором эхо живёт три вздоха.", icon: "Church", bonus: "Вера +60, преступность падает", cost: [["kamen", 90], ["zoloto", 1000], ["cheshuya", 2]], eff: { faith: 60, happy: 12, crime: -20 } }),
    W({ id: "w_most", name: "Золотой Мост", desc: "Пролёт над бездной, окованный золотом.", icon: "Route", bonus: "Все торговые пути быстрее на треть", cost: [["kamen", 80], ["zhel_slitok", 30], ["zoloto", 1200]], eff: { gold: 35, order: 10, culture: 12 } }),
    W({ id: "w_drevo", name: "Древо Жизни", desc: "Корни поят весь край, крона закрывает полнеба.", icon: "Sprout", bonus: "Вода +60, здоровье +25", cost: [["brevno", 80], ["glina", 40], ["cheshuya", 1], ["zoloto", 700]], eff: { water: 60, health: 25, happy: 10, pollution: -15 } }),
    W({ id: "w_chasy", name: "Часы Вечности", desc: "Механизм отмеряет века, не сбиваясь ни на миг.", icon: "Clock", bonus: "Стройка и производство быстрее на 25%", cost: [["zhel_slitok", 40], ["med_slitok", 30], ["zoloto", 1000]], eff: { science: 30, order: 15, gold: 15 } }),
    W({ id: "w_obelisk", name: "Обелиск Тихого Пламени", desc: "Игла камня с негасимым огнём на вершине.", icon: "Flame", bonus: "Ночь не страшна: свет на весь город", cost: [["kamen", 100], ["ugol", 40], ["zoloto", 800]], eff: { happy: 14, order: 20, culture: 20 }, light: 12 }),
    W({ id: "w_arka", name: "Арка Героев", desc: "Имена павших высечены в граните навсегда.", icon: "Landmark", bonus: "Порядок +30, армия верна до конца", cost: [["kamen", 75], ["zhel_slitok", 20], ["zoloto", 750]], eff: { order: 30, culture: 18, happy: 8 } }),
    W({ id: "w_kupol", name: "Купол Звёзд", desc: "Стеклянная полусфера, где видно небо днём.", icon: "Telescope", bonus: "Наука +45, погода предсказуема", cost: [["pesok", 60], ["med_slitok", 25], ["zoloto", 950]], eff: { science: 45, culture: 20, happy: 5 } }),
    W({ id: "w_kuznya", name: "Кузня Богов", desc: "Горн, что не гаснет с сотворения мира.", icon: "Hammer", bonus: "Все мастерские работают вдвое быстрее", cost: [["zhel_slitok", 50], ["ugol", 60], ["kamen", 60], ["zoloto", 1100]], eff: { gold: 40, order: 12, pollution: 6 } }),
  ] as BuildingDef[]).map((b) => [b.id, b])
);

// Хелпер для чудес: большие, дорогие, единственные в своём роде
function W(d: { id: string; name: string; desc: string; icon: string; bonus: string; cost: [string, number][]; eff: BuildingDef["eff"]; light?: number }): BuildingDef {
  return {
    id: d.id, name: d.name, desc: d.desc, icon: d.icon, cat: "Чудеса",
    w: 4, h: 4, cost: d.cost, buildTime: 120, hp: 2000, blocks: false,
    needsCity: true, wonder: true, maxLvl: 1, jobs: 12, eff: d.eff,
    light: d.light, upkeep: 4, bonus: d.bonus,
  };
}

// Товары производственных цепочек (дополняют ITEMS)
export const CHAIN_ITEMS: { id: string; name: string; desc: string; icon: string }[] = [
  { id: "zerno", name: "Зерно", desc: "Золотые колосья с городских пашен.", icon: "Wheat" },
  { id: "muka", name: "Мука", desc: "Тонкий помол с мельницы.", icon: "Layers" },
  { id: "hleb", name: "Хлеб", desc: "Тёплый каравай. Сытнее любой ягоды.", icon: "CookingPot" },
  { id: "pivo", name: "Эль", desc: "Тёмный, густой, с пеной до краёв.", icon: "Beer" },
  { id: "tkan", name: "Ткань", desc: "Ровное полотно из городской ткацкой.", icon: "Shirt" },
  { id: "mebel", name: "Мебель", desc: "Резные лавки и сундуки. Товар зажиточных.", icon: "Armchair" },
  { id: "ukrashenie", name: "Украшения", desc: "Броши и перстни тонкой работы.", icon: "Gem" },
  { id: "instrument", name: "Инструменты", desc: "Пилы, тиски и свёрла заводской ковки.", icon: "Wrench" },
  { id: "naryad", name: "Наряды", desc: "Платья и кафтаны для знати.", icon: "Shirt" },
  { id: "oruzhie", name: "Оружие", desc: "Мечи и копья для гарнизона.", icon: "Sword" },
];
