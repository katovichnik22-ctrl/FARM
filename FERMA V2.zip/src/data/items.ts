import type { ItemDef } from "../types";
import { LAYER_ITEMS } from "./layers";

// ===== Все предметы «Тихого Пламени» =====
const D = (d: Partial<ItemDef> & { id: string; name: string; icon: string }): ItemDef => ({
  desc: "", type: "res", stack: 99, ...d,
});

export const ITEMS: Record<string, ItemDef> = Object.fromEntries(
  [
    // --- Ресурсы ---
    D({ id: "brevno", name: "Брёвна", icon: "Log", desc: "Крепкая древесина. Основа любого дела." }),
    D({ id: "palka", name: "Палки", icon: "Wand", desc: "Рукояти, растопка, стрелы." }),
    D({ id: "doska", name: "Доски", icon: "AlignJustify", desc: "Обтёсанное дерево для строительства." }),
    D({ id: "kamen", name: "Камень", icon: "Mountain", desc: "Булыжник с речных отмелей." }),
    D({ id: "ugol", name: "Уголь", icon: "Flame", desc: "Чёрное топливо костров и плавки." }),
    D({ id: "kremen", name: "Кремень", icon: "Zap", desc: "Высекает искру даже в дождь." }),
    D({ id: "glina", name: "Глина", icon: "Layers", desc: "Липкая речная глина." }),
    D({ id: "pesok", name: "Песок", icon: "Waves", desc: "Жёлтый песок дюн." }),
    D({ id: "sneg", name: "Снег", icon: "Snowflake", desc: "Можно растопить в котелке." }),
    D({ id: "kozha", name: "Кожа", icon: "Shield", desc: "Выделанная шкура зверя." }),
    D({ id: "kost", name: "Кости", icon: "Bone", desc: "Белеют на старой земле." }),
    D({ id: "nit", name: "Нити", icon: "Cable", desc: "Паутина и лыко. Всё держится на нитках." }),
    D({ id: "pero", name: "Пёрышко", icon: "Feather", desc: "Лёгкое перо ночной мыши." }),
    D({ id: "med_ruda", name: "Медная руда", icon: "Gem", desc: "Зеленоватые прожилки. Плавится на костре." }),
    D({ id: "zhel_ruda", name: "Железная руда", icon: "Gem", desc: "Тяжёлая, рыжая. Основа доброго инструмента." }),
    D({ id: "med_slitok", name: "Медный слиток", icon: "Inbox", desc: "Тёплый розовый металл." }),
    D({ id: "zhel_slitok", name: "Железный слиток", icon: "Inbox", desc: "Серый, холодный, надёжный." }),
    D({ id: "zoloto", name: "Золото", icon: "Coins", desc: "Монеты и самородки. Идут на вес по всем землям." }),
    D({ id: "cheshuya", name: "Чешуя дракона", icon: "Shell", desc: "Тёплая даже в метель. Бесценна." }),
    D({ id: "gnil", name: "Сырая плоть", icon: "Beef", desc: "Пахнет дурно, но голод не тётка.", food: 6, poisonChance: 0.35, type: "food" }),

    // --- Еда и питьё ---
    D({ id: "yagoda", name: "Ягоды", icon: "Cherry", desc: "Сладкая лесная дань.", food: 9, drink: 4, type: "food" }),
    D({ id: "grib", name: "Грибы", icon: "Shapes", desc: "Сыроежки из-под елей. Лучше поджарить.", food: 7, poisonChance: 0.12, type: "food" }),
    D({ id: "myaso", name: "Сырое мясо", icon: "Drumstick", desc: "Сырое. На костре станет жарким.", food: 10, poisonChance: 0.3, type: "food" }),
    D({ id: "zharkoe", name: "Жаркое", icon: "FlameKindling", desc: "Хрустящая корочка. Сытость надолго.", food: 38, heal: 6, type: "food" }),
    D({ id: "grib_zhar", name: "Жареные грибы", icon: "CookingPot", desc: "С дымком. Пахнут осенью.", food: 20, type: "food" }),
    D({ id: "yagoda_zhar", name: "Печёные ягоды", icon: "Candy", desc: "Горячие и сладкие, как лето.", food: 16, heal: 3, type: "food" }),
    D({ id: "bint", name: "Бинт", icon: "Cross", desc: "Чистая ткань с травами. Лечит раны.", heal: 30, type: "misc" }),
    D({ id: "burdyuk_pust", name: "Пустой бурдюк", icon: "Milk", desc: "Наполняется у воды.", type: "misc" }),
    D({ id: "burdyuk_gryaz", name: "Бурдюк сырой воды", icon: "GlassWater", desc: "Мутновата. Рискованно пить такую.", drink: 26, poisonChance: 0.25, type: "drink" }),
    D({ id: "burdyuk_chist", name: "Бурдюк чистой воды", icon: "Droplets", desc: "Кипячёная. Холодит и спасает.", drink: 42, type: "drink" }),

    // --- Инструменты ---
    D({ id: "topor_k", name: "Каменный топор", icon: "Axe", desc: "Первый друг лесоруба.", type: "tool", tool: "axe", dmg: 6, power: 10, atkSpd: 1, stack: 1 }),
    D({ id: "kirka_k", name: "Каменная кирка", icon: "Pickaxe", desc: "Глухой стук по камню — музыка рудника.", type: "tool", tool: "pick", dmg: 5, power: 10, atkSpd: 1, stack: 1 }),
    D({ id: "lopata_k", name: "Каменная лопата", icon: "Shovel", desc: "Копает песок, глину и снег.", type: "tool", tool: "shovel", dmg: 4, power: 12, atkSpd: 1.1, stack: 1 }),
    D({ id: "mech_k", name: "Каменный меч", icon: "Sword", desc: "Грубый, но верный.", type: "weapon", dmg: 12, atkSpd: 1.15, stack: 1 }),
    D({ id: "topor_m", name: "Медный топор", icon: "Axe", desc: "Медь звенит о сучья.", type: "tool", tool: "axe", dmg: 10, power: 18, atkSpd: 1.1, stack: 1 }),
    D({ id: "kirka_m", name: "Медная кирка", icon: "Pickaxe", desc: "Руда сама идёт в руки.", type: "tool", tool: "pick", dmg: 9, power: 18, atkSpd: 1.1, stack: 1 }),
    D({ id: "mech_m", name: "Медный меч", icon: "Sword", desc: "Розоватый блеск заката.", type: "weapon", dmg: 20, atkSpd: 1.2, stack: 1 }),
    D({ id: "topor_zh", name: "Железный топор", icon: "Axe", desc: "Валит дубы с трёх взмахов.", type: "tool", tool: "axe", dmg: 15, power: 28, atkSpd: 1.15, stack: 1 }),
    D({ id: "kirka_zh", name: "Железная кирка", icon: "Pickaxe", desc: "Горы помнят её стук.", type: "tool", tool: "pick", dmg: 13, power: 28, atkSpd: 1.15, stack: 1 }),
    D({ id: "mech_zh", name: "Железный меч", icon: "Swords", desc: "Верный стальной друг.", type: "weapon", dmg: 30, atkSpd: 1.25, stack: 1 }),
    D({ id: "fakel", name: "Факел", icon: "Flame", desc: "Ставится на землю. Разгоняет тьму и страх.", type: "place", stack: 50 }),

    // --- Броня: кожа ---
    D({ id: "shlem_kozh", name: "Кожаный капюшон", icon: "HardHat", desc: "От ветра и зубов.", type: "equip", slot: "head", armor: 2, warmth: 1, stack: 1 }),
    D({ id: "bron_kozh", name: "Кожаная рубаха", icon: "Shirt", desc: "Пахнет дымом и дубильней.", type: "equip", slot: "body", armor: 3, warmth: 2, stack: 1 }),
    D({ id: "shtan_kozh", name: "Кожаные порты", icon: "Scissors", desc: "Не сносить в чаще.", type: "equip", slot: "legs", armor: 2, warmth: 1, stack: 1 }),
    D({ id: "bot_kozh", name: "Кожаные сапоги", icon: "Footprints", desc: "Тихая поступь.", type: "equip", slot: "feet", armor: 1, warmth: 3, stack: 1 }),
    D({ id: "shuba", name: "Волчья шуба", icon: "VenetianMask", desc: "В ней не страшна и белая ночь.", type: "equip", slot: "body", armor: 2, warmth: 6, stack: 1 }),
    // --- Броня: медь / железо ---
    D({ id: "shlem_med", name: "Медный шлем", icon: "HardHat", desc: "Блестит, как утренняя роса.", type: "equip", slot: "head", armor: 4, warmth: 1, stack: 1 }),
    D({ id: "bron_med", name: "Медный панцирь", icon: "Shield", desc: "Тяжёл, зато надёжен.", type: "equip", slot: "body", armor: 6, warmth: 0, stack: 1 }),
    D({ id: "shtan_med", name: "Медные поножи", icon: "Scissors", desc: "Звенят при шаге.", type: "equip", slot: "legs", armor: 4, warmth: 0, stack: 1 }),
    D({ id: "bot_med", name: "Медные сапоги", icon: "Footprints", desc: "Поступь войны.", type: "equip", slot: "feet", armor: 3, warmth: 0, stack: 1 }),
    D({ id: "shlem_zhel", name: "Железный шлем", icon: "Crown", desc: "Под ним тихо и спокойно.", type: "equip", slot: "head", armor: 6, warmth: 1, stack: 1 }),
    D({ id: "bron_zhel", name: "Железный латник", icon: "ShieldHalf", desc: "Стена из стали.", type: "equip", slot: "body", armor: 9, warmth: 0, stack: 1 }),
    D({ id: "shtan_zhel", name: "Железные поножи", icon: "Scissors", desc: "Кольчужное плетение.", type: "equip", slot: "legs", armor: 6, warmth: 0, stack: 1 }),
    D({ id: "bot_zhel", name: "Железные сапоги", icon: "Footprints", desc: "Для тех, кто идёт до конца.", type: "equip", slot: "feet", armor: 5, warmth: 0, stack: 1 }),

    // --- Товары городских цепочек (2-й этап) ---
    D({ id: "zerno", name: "Зерно", icon: "Wheat", desc: "Золотые колосья с городских пашен.", stack: 200 }),
    D({ id: "muka", name: "Мука", icon: "Layers", desc: "Тонкий помол с мельницы.", stack: 200 }),
    D({ id: "hleb", name: "Хлеб", icon: "CookingPot", desc: "Тёплый каравай. Сытнее любой ягоды.", type: "food", food: 34, heal: 4, stack: 99 }),
    D({ id: "pivo", name: "Эль", icon: "Beer", desc: "Тёмный, густой, с пеной до краёв.", type: "drink", drink: 22, food: 6, stack: 99 }),
    D({ id: "tkan", name: "Ткань", icon: "Shirt", desc: "Ровное полотно из городской ткацкой.", stack: 200 }),
    D({ id: "mebel", name: "Мебель", icon: "Armchair", desc: "Резные лавки и сундуки. Товар зажиточных.", stack: 100 }),
    D({ id: "ukrashenie", name: "Украшения", icon: "Gem", desc: "Броши и перстни тонкой работы.", stack: 100 }),
    D({ id: "instrument", name: "Инструменты", icon: "Wrench", desc: "Пилы, тиски и свёрла заводской ковки.", stack: 100 }),
    D({ id: "naryad", name: "Наряды", icon: "Shirt", desc: "Платья и кафтаны для знати.", stack: 100 }),
    D({ id: "oruzhie", name: "Оружие", icon: "Sword", desc: "Мечи и копья для гарнизона.", stack: 100 }),
  ].map((d) => [d.id, d])
);

// --- Снаряжение из материалов иных слоёв ---
const LAYER_EQUIP: ItemDef[] = [
  D({ id: "mech_mif", name: "Мифриловый клинок", icon: "Swords", desc: "Лёгок как перо, режет как мысль.", type: "weapon", dmg: 48, atkSpd: 1.4, stack: 1 }),
  D({ id: "mech_adam", name: "Адамантиновый меч", icon: "Swords", desc: "Чёрное лезвие глубин. Не тупится никогда.", type: "weapon", dmg: 72, atkSpd: 1.3, stack: 1 }),
  D({ id: "bron_mif", name: "Мифриловый доспех", icon: "ShieldHalf", desc: "Серебристая чешуя, лёгкая как рубаха.", type: "equip", slot: "body", armor: 14, warmth: 4, stack: 1 }),
  D({ id: "shlem_mif", name: "Мифриловый шлем", icon: "Crown", desc: "В нём слышно, как поют кристаллы.", type: "equip", slot: "head", armor: 9, warmth: 2, stack: 1 }),
  D({ id: "bron_adam", name: "Адамантиновый панцирь", icon: "ShieldHalf", desc: "Выдержит и драконий огонь, и взгляд бездны.", type: "equip", slot: "body", armor: 22, warmth: 6, stack: 1 }),
  D({ id: "plash_snov", name: "Плащ сновидца", icon: "VenetianMask", desc: "Ткань из снов: шаг тише, стужа мягче.", type: "equip", slot: "body", armor: 8, warmth: 10, stack: 1 }),
  D({ id: "amulet_haos", name: "Амулет хаоса", icon: "Sparkle", desc: "Меняет цвет под настроение носителя. И удачу тоже.", type: "equip", slot: "head", armor: 12, warmth: 5, stack: 1 }),
];
for (const it of LAYER_EQUIP) ITEMS[it.id] = it;

// Ресурсы слоёв 5-го этапа регистрируем в общем реестре
for (const li of LAYER_ITEMS) {
  ITEMS[li.id] = {
    id: li.id, name: li.name, desc: li.desc, icon: li.icon,
    type: "res", stack: li.stack ?? 99,
  };
}

export const START_INV: { id: string; n: number }[] = [
  { id: "yagoda", n: 4 },
  { id: "burdyuk_chist", n: 1 },
];
