import type { RecipeDef } from "../types";

// ===== Рецепты крафта (всё доступно с рук 2×2; fire=true — нужен костёр рядом) =====
export const RECIPES: RecipeDef[] = [
  // Материалы
  { id: "r_palka", name: "Палки", cat: "Материалы", out: "palka", outN: 2, needs: [["brevno", 1]], xp: 1, icon: "Wand" },
  { id: "r_doska", name: "Доски", cat: "Материалы", out: "doska", outN: 2, needs: [["brevno", 1]], xp: 1, icon: "AlignJustify" },
  { id: "r_fakel", name: "Факелы", cat: "Материалы", out: "fakel", outN: 3, needs: [["palka", 1], ["ugol", 1]], xp: 1, icon: "Flame" },
  { id: "r_burdyuk", name: "Бурдюк", cat: "Материалы", out: "burdyuk_pust", outN: 1, needs: [["kozha", 2], ["nit", 2]], xp: 3, icon: "Milk" },
  { id: "r_bint", name: "Бинт", cat: "Материалы", out: "bint", outN: 2, needs: [["nit", 2], ["kozha", 1]], xp: 2, icon: "Cross" },
  // Инструменты
  { id: "r_topor_k", name: "Каменный топор", cat: "Инструменты", out: "topor_k", outN: 1, needs: [["kamen", 3], ["palka", 2]], xp: 4, icon: "Axe" },
  { id: "r_kirka_k", name: "Каменная кирка", cat: "Инструменты", out: "kirka_k", outN: 1, needs: [["kamen", 3], ["palka", 2]], xp: 4, icon: "Pickaxe" },
  { id: "r_lopata_k", name: "Каменная лопата", cat: "Инструменты", out: "lopata_k", outN: 1, needs: [["kamen", 2], ["palka", 2]], xp: 4, icon: "Shovel" },
  { id: "r_mech_k", name: "Каменный меч", cat: "Оружие", out: "mech_k", outN: 1, needs: [["kamen", 4], ["palka", 2], ["kozha", 1]], xp: 5, icon: "Sword" },
  { id: "r_topor_m", name: "Медный топор", cat: "Инструменты", out: "topor_m", outN: 1, needs: [["med_slitok", 3], ["palka", 2]], xp: 8, icon: "Axe" },
  { id: "r_kirka_m", name: "Медная кирка", cat: "Инструменты", out: "kirka_m", outN: 1, needs: [["med_slitok", 3], ["palka", 2]], xp: 8, icon: "Pickaxe" },
  { id: "r_mech_m", name: "Медный меч", cat: "Оружие", out: "mech_m", outN: 1, needs: [["med_slitok", 4], ["palka", 2], ["nit", 2]], xp: 10, icon: "Sword" },
  { id: "r_topor_zh", name: "Железный топор", cat: "Инструменты", out: "topor_zh", outN: 1, needs: [["zhel_slitok", 3], ["palka", 2]], xp: 12, icon: "Axe" },
  { id: "r_kirka_zh", name: "Железная кирка", cat: "Инструменты", out: "kirka_zh", outN: 1, needs: [["zhel_slitok", 3], ["palka", 2]], xp: 12, icon: "Pickaxe" },
  { id: "r_mech_zh", name: "Железный меч", cat: "Оружие", out: "mech_zh", outN: 1, needs: [["zhel_slitok", 4], ["palka", 2], ["kozha", 2]], xp: 15, icon: "Swords" },
  // Костёр / плавка / еда
  { id: "r_med", name: "Плавка меди", cat: "Костёр", out: "med_slitok", outN: 1, needs: [["med_ruda", 2], ["ugol", 1]], fire: true, xp: 3, icon: "Inbox" },
  { id: "r_zhel", name: "Плавка железа", cat: "Костёр", out: "zhel_slitok", outN: 1, needs: [["zhel_ruda", 2], ["ugol", 1]], fire: true, xp: 4, icon: "Inbox" },
  { id: "r_zharkoe", name: "Жаркое", cat: "Костёр", out: "zharkoe", outN: 1, needs: [["myaso", 1]], fire: true, xp: 2, icon: "FlameKindling" },
  { id: "r_gribzh", name: "Жареные грибы", cat: "Костёр", out: "grib_zhar", outN: 1, needs: [["grib", 2]], fire: true, xp: 2, icon: "CookingPot" },
  { id: "r_yagzh", name: "Печёные ягоды", cat: "Костёр", out: "yagoda_zhar", outN: 1, needs: [["yagoda", 3]], fire: true, xp: 1, icon: "Candy" },
  { id: "r_voda", name: "Кипячение воды", cat: "Костёр", out: "burdyuk_chist", outN: 1, needs: [["burdyuk_gryaz", 1]], fire: true, xp: 1, icon: "Droplets" },
  // Снаряжение
  { id: "r_shuba", name: "Волчья шуба", cat: "Снаряжение", out: "shuba", outN: 1, needs: [["kozha", 6], ["nit", 3]], xp: 8, icon: "VenetianMask" },
  { id: "r_shlem_kozh", name: "Капюшон", cat: "Снаряжение", out: "shlem_kozh", outN: 1, needs: [["kozha", 3], ["nit", 1]], xp: 4, icon: "HardHat" },
  { id: "r_bron_kozh", name: "Кожаная рубаха", cat: "Снаряжение", out: "bron_kozh", outN: 1, needs: [["kozha", 4], ["nit", 2]], xp: 4, icon: "Shirt" },
  { id: "r_shtan_kozh", name: "Порты", cat: "Снаряжение", out: "shtan_kozh", outN: 1, needs: [["kozha", 3], ["nit", 1]], xp: 4, icon: "Scissors" },
  { id: "r_bot_kozh", name: "Сапоги", cat: "Снаряжение", out: "bot_kozh", outN: 1, needs: [["kozha", 2], ["nit", 1]], xp: 4, icon: "Footprints" },
  { id: "r_shlem_med", name: "Медный шлем", cat: "Снаряжение", out: "shlem_med", outN: 1, needs: [["med_slitok", 3]], xp: 8, icon: "HardHat" },
  { id: "r_bron_med", name: "Медный панцирь", cat: "Снаряжение", out: "bron_med", outN: 1, needs: [["med_slitok", 5]], xp: 10, icon: "Shield" },
  { id: "r_shtan_med", name: "Медные поножи", cat: "Снаряжение", out: "shtan_med", outN: 1, needs: [["med_slitok", 4]], xp: 8, icon: "Scissors" },
  { id: "r_bot_med", name: "Медные сапоги", cat: "Снаряжение", out: "bot_med", outN: 1, needs: [["med_slitok", 3]], xp: 8, icon: "Footprints" },
  { id: "r_shlem_zhel", name: "Железный шлем", cat: "Снаряжение", out: "shlem_zhel", outN: 1, needs: [["zhel_slitok", 3]], xp: 12, icon: "Crown" },
  { id: "r_bron_zhel", name: "Железный латник", cat: "Снаряжение", out: "bron_zhel", outN: 1, needs: [["zhel_slitok", 5]], xp: 14, icon: "ShieldHalf" },
  { id: "r_shtan_zhel", name: "Железные поножи", cat: "Снаряжение", out: "shtan_zhel", outN: 1, needs: [["zhel_slitok", 4]], xp: 12, icon: "Scissors" },
  { id: "r_bot_zhel", name: "Железные сапоги", cat: "Снаряжение", out: "bot_zhel", outN: 1, needs: [["zhel_slitok", 3]], xp: 12, icon: "Footprints" },
  // --- Материалы иных слоёв (5-й этап) ---
  { id: "r_mech_mif", name: "Мифриловый клинок", cat: "Оружие", out: "mech_mif", outN: 1, needs: [["mifril", 5], ["palka", 2], ["kristall", 2]], xp: 30, icon: "Swords" },
  { id: "r_mech_adam", name: "Адамантиновый меч", cat: "Оружие", out: "mech_adam", outN: 1, needs: [["adamantit", 6], ["mifril", 3], ["obsidian", 4]], xp: 45, icon: "Swords" },
  { id: "r_bron_mif", name: "Мифриловый доспех", cat: "Снаряжение", out: "bron_mif", outN: 1, needs: [["mifril", 8], ["oblachnyi_hlopok", 6]], xp: 34, icon: "ShieldHalf" },
  { id: "r_shlem_mif", name: "Мифриловый шлем", cat: "Снаряжение", out: "shlem_mif", outN: 1, needs: [["mifril", 5], ["kristall", 2]], xp: 26, icon: "Crown" },
  { id: "r_bron_adam", name: "Адамантиновый панцирь", cat: "Снаряжение", out: "bron_adam", outN: 1, needs: [["adamantit", 10], ["tenevaya_sut", 4]], xp: 55, icon: "ShieldHalf" },
  { id: "r_plash_snov", name: "Плащ сновидца", cat: "Снаряжение", out: "plash_snov", outN: 1, needs: [["pyl_snov", 6], ["oblachnyi_hlopok", 8], ["tkan", 6]], xp: 30, icon: "VenetianMask" },
  { id: "r_amulet_haos", name: "Амулет хаоса", cat: "Снаряжение", out: "amulet_haos", outN: 1, needs: [["oskolok_haosa", 4], ["zhemchug", 4], ["nebesnyi_kristall", 3]], xp: 60, icon: "Sparkle" },
];

export const RECIPE_CATS = ["Всё", "Материалы", "Инструменты", "Оружие", "Костёр", "Снаряжение"];
