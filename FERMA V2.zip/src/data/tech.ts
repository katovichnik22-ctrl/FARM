import type { TechDef } from "../types/lore";

// ===== Дерево технологий: 7 ветвей × 11 эпох =====
const T = (d: TechDef): TechDef => d;

export const TECHS: TechDef[] = [
  // ---------- КАМЕННЫЙ ВЕК ----------
  T({ id: "t_fire", name: "Укрощение огня", desc: "Искра в ладонях — начало всех начал.", icon: "Flame", branch: "sci", era: "stone", cost: 30, needs: [], effect: { sci: 2 }, bonusText: "+2 науки, костры греют сильнее" }),
  T({ id: "t_stonework", name: "Обработка камня", desc: "Кремень становится орудием.", icon: "Mountain", branch: "eco", era: "stone", cost: 35, needs: [], effect: { prod: 0.08 }, bonusText: "+8% к работе мастерских" }),
  T({ id: "t_hunt", name: "Загонная охота", desc: "Стая людей страшнее стаи волков.", icon: "Target", branch: "mil", era: "stone", cost: 40, needs: [], effect: { armyAtk: 0.05, food: 4 }, bonusText: "+5% атаки, +4 еды" }),
  T({ id: "t_totem", name: "Тотемы предков", desc: "Резной столб хранит память рода.", icon: "Sparkle", branch: "cul", era: "stone", cost: 45, needs: [], effect: { culture: 4, faith: 4 }, bonusText: "+4 культуры и веры" }),

  // ---------- БРОНЗОВЫЙ ----------
  T({ id: "t_bronze", name: "Бронзовое литьё", desc: "Медь с оловом — и рождается сплав.", icon: "Hammer", branch: "eco", era: "bronze", cost: 80, needs: ["t_stonework"], unlockB: ["kuznica"], effect: { gold: 3, prod: 0.08 }, bonusText: "Кузница, +3 золота" }),
  T({ id: "t_wheel", name: "Колесо", desc: "Круг, что везёт державу вперёд.", icon: "CircleDot", branch: "eco", era: "bronze", cost: 90, needs: ["t_stonework"], unlockB: ["doroga", "karavan_saray"], effect: { gold: 4 }, bonusText: "Дороги и караван-сарай" }),
  T({ id: "t_writing", name: "Письменность", desc: "Слово перестало умирать вместе с говорящим.", icon: "ScrollText", branch: "sci", era: "bronze", cost: 100, needs: ["t_fire"], unlockB: ["biblioteka"], effect: { sci: 6, culture: 3 }, bonusText: "Библиотека, +6 науки" }),
  T({ id: "t_phalanx", name: "Строй копейщиков", desc: "Плечом к плечу — и конница отступит.", icon: "Shield", branch: "mil", era: "bronze", cost: 95, needs: ["t_hunt"], unlockU: ["infantry"], unlockB: ["kazarmy"], effect: { armyDef: 0.1 }, bonusText: "Копейщики, казармы, +10% обороны" }),
  T({ id: "t_rites", name: "Древние обряды", desc: "Огонь, кровь и слово у камня.", icon: "Church", branch: "cul", era: "bronze", cost: 110, needs: ["t_totem"], unlockB: ["hram"], effect: { faith: 8, culture: 4 }, bonusText: "Храм, +8 веры. Открывает основание религии" }),
  T({ id: "t_ley", name: "Чтение лей-линий", desc: "Земля гудит там, где течёт сила.", icon: "Sparkles", branch: "mag", era: "bronze", cost: 130, needs: ["t_rites"], unlockB: ["altar"], effect: { mana: 20 }, bonusText: "Алтарь, +20 маны. Открывает магию" }),

  // ---------- ЖЕЛЕЗНЫЙ ----------
  T({ id: "t_iron", name: "Железо", desc: "Рыжая руда даёт серый клинок.", icon: "Sword", branch: "mil", era: "iron", cost: 180, needs: ["t_bronze"], unlockB: ["oruzhejnaya", "shahta"], effect: { armyAtk: 0.1 }, bonusText: "Оружейная и шахта, +10% атаки" }),
  T({ id: "t_plough", name: "Тяжёлый плуг", desc: "Борозда глубже — каравай больше.", icon: "Wheat", branch: "eco", era: "iron", cost: 170, needs: ["t_wheel"], unlockB: ["pole", "melnica"], effect: { food: 12 }, bonusText: "Пашня и мельница, +12 еды" }),
  T({ id: "t_archery", name: "Составной лук", desc: "Рог, жила и дерево бьют на двести шагов.", icon: "Target", branch: "mil", era: "iron", cost: 190, needs: ["t_phalanx"], unlockU: ["archer"], unlockB: ["strelkovaya"], effect: { armyAtk: 0.06 }, bonusText: "Лучники и стрельбище" }),
  T({ id: "t_math", name: "Счёт и мера", desc: "Числа укрощают хаос.", icon: "Scale", branch: "sci", era: "iron", cost: 200, needs: ["t_writing"], unlockB: ["akademiya"], effect: { sci: 10, gold: 4 }, bonusText: "Академия, +10 науки" }),
  T({ id: "t_law", name: "Свод законов", desc: "Писаный закон крепче обычая.", icon: "Gavel", branch: "soc", era: "iron", cost: 210, needs: ["t_writing"], unlockB: ["parlament"], effect: { gold: 6, culture: 5 }, bonusText: "Парламент, порядок в городе" }),
  T({ id: "t_elements", name: "Стихийные чары", desc: "Огонь и вода слушают зов.", icon: "Flame", branch: "mag", era: "iron", cost: 240, needs: ["t_ley"], unlockS: ["s_firebolt", "s_heal"], effect: { mana: 15 }, bonusText: "Заклинания: Огненная стрела, Исцеление" }),

  // ---------- СРЕДНЕВЕКОВЬЕ ----------
  T({ id: "t_chivalry", name: "Рыцарство", desc: "Конь, копьё и кодекс чести.", icon: "Rabbit", branch: "mil", era: "medieval", cost: 380, needs: ["t_iron"], unlockU: ["cavalry"], unlockB: ["konyushni"], effect: { armyAtk: 0.1 }, bonusText: "Всадники и конюшни" }),
  T({ id: "t_siegecraft", name: "Осадное дело", desc: "Рычаг ломает то, что не берёт меч.", icon: "Crosshair", branch: "mil", era: "medieval", cost: 400, needs: ["t_math", "t_iron"], unlockU: ["catapult", "siege"], unlockB: ["katapulta", "osadnaya"], effect: { armyAtk: 0.06 }, bonusText: "Катапульты, тараны, осадные мастерские" }),
  T({ id: "t_guilds", name: "Гильдии", desc: "Мастера сговорились — и цены выросли.", icon: "Coins", branch: "eco", era: "medieval", cost: 420, needs: ["t_plough"], unlockB: ["rynok", "stolyarka", "tkackaya", "pekarnya"], effect: { gold: 10 }, bonusText: "Рынок и мастерские передела" }),
  T({ id: "t_cathedral", name: "Соборное зодчество", desc: "Свод, уходящий в самое небо.", icon: "Church", branch: "cul", era: "medieval", cost: 450, needs: ["t_rites", "t_math"], unlockB: ["sobor", "monastyr"], effect: { faith: 18, culture: 10 }, bonusText: "Собор и монастырь" }),
  T({ id: "t_university", name: "Университет", desc: "Спор рождает истину, истина — державу.", icon: "School", branch: "sci", era: "medieval", cost: 480, needs: ["t_math"], unlockB: ["universitet", "observatoriya"], effect: { sci: 18 }, bonusText: "Университет и обсерватория" }),
  T({ id: "t_wards", name: "Обереги и щиты", desc: "Круг, начертанный вовремя, спасает город.", icon: "Shield", branch: "mag", era: "medieval", cost: 520, needs: ["t_elements"], unlockS: ["s_ward", "s_storm"], effect: { mana: 25, armyDef: 0.06 }, bonusText: "Заклинания: Оберег, Буря" }),
  T({ id: "t_estates", name: "Сословия", desc: "Знать, купцы, церковь и люд.", icon: "Users", branch: "soc", era: "medieval", cost: 440, needs: ["t_law"], unlockB: ["dvorec", "zamok"], effect: { gold: 8, culture: 6 }, bonusText: "Дворец и замок" }),

  // ---------- ВОЗРОЖДЕНИЕ ----------
  T({ id: "t_banking", name: "Банковское дело", desc: "Золото, что работает во сне.", icon: "Landmark", branch: "eco", era: "renaissance", cost: 760, needs: ["t_guilds"], unlockB: ["bank", "birzha"], effect: { gold: 18 }, bonusText: "Банк и биржа" }),
  T({ id: "t_navigation", name: "Навигация", desc: "Звёзды ведут корабли за горизонт.", icon: "Ship", branch: "eco", era: "renaissance", cost: 800, needs: ["t_banking"], unlockU: ["fleet"], unlockB: ["torg_port", "port_ryb"], effect: { gold: 12, food: 8 }, bonusText: "Ладьи, порты" }),
  T({ id: "t_printing", name: "Печатный станок", desc: "Тысяча книг там, где была одна.", icon: "BookOpen", branch: "sci", era: "renaissance", cost: 840, needs: ["t_university"], effect: { sci: 26, culture: 14 }, bonusText: "+26 науки, +14 культуры" }),
  T({ id: "t_arts", name: "Высокое искусство", desc: "Кисть и резец спорят с природой.", icon: "Palette", branch: "cul", era: "renaissance", cost: 820, needs: ["t_cathedral"], unlockB: ["teatr", "arena", "zoopark"], effect: { culture: 24 }, bonusText: "Театр, арена, зверинец" }),
  T({ id: "t_gunpowder", name: "Огневой припас", desc: "Гром в бочонке меняет войну.", icon: "Bomb", branch: "mil", era: "renaissance", cost: 880, needs: ["t_siegecraft", "t_chivalry"], effect: { armyAtk: 0.16 }, bonusText: "+16% атаки войска" }),
  T({ id: "t_alchemy", name: "Алхимия", desc: "Что сгорает — то и очищает.", icon: "FlaskConical", branch: "mag", era: "renaissance", cost: 900, needs: ["t_wards"], unlockB: ["laboratoriya"], unlockS: ["s_curse", "s_bless"], effect: { mana: 30, sci: 10 }, bonusText: "Лаборатория, Проклятие и Благословение" }),
  T({ id: "t_diplomacy", name: "Посольское право", desc: "Слово посла весит как полк.", icon: "Handshake", branch: "soc", era: "renaissance", cost: 780, needs: ["t_estates"], effect: { gold: 10, culture: 8 }, bonusText: "Дипломатия дешевле, отношения крепче" }),

  // ---------- ИНДУСТРИАЛЬНАЯ ----------
  T({ id: "t_steam", name: "Паровая машина", desc: "Пар делает работу сотни рук.", icon: "Factory", branch: "eco", era: "industrial", cost: 1400, needs: ["t_navigation", "t_printing"], unlockB: ["zavod", "fabrika"], effect: { prod: 0.3, gold: 22 }, bonusText: "Завод и мануфактура, +30% производства" }),
  T({ id: "t_railway", name: "Железные пути", desc: "Обозы летят быстрее вести.", icon: "Route", branch: "eco", era: "industrial", cost: 1500, needs: ["t_steam"], effect: { gold: 26 }, bonusText: "Торговые пути на треть быстрее" }),
  T({ id: "t_chemistry", name: "Химия", desc: "Вещество раскрывает состав.", icon: "FlaskConical", branch: "sci", era: "industrial", cost: 1600, needs: ["t_printing"], effect: { sci: 40, food: 10 }, bonusText: "+40 науки, +10 еды" }),
  T({ id: "t_conscript", name: "Всеобщий призыв", desc: "Держава ставит под знамёна всех.", icon: "Swords", branch: "mil", era: "industrial", cost: 1550, needs: ["t_gunpowder"], effect: { armyAtk: 0.12, armyDef: 0.12 }, bonusText: "+12% атаки и обороны, больше рекрутов" }),
  T({ id: "t_museums", name: "Музеи", desc: "Память народа под одной крышей.", icon: "Landmark", branch: "cul", era: "industrial", cost: 1450, needs: ["t_arts"], effect: { culture: 34, borders: 2 }, bonusText: "+34 культуры, границы шире" }),
  T({ id: "t_thaumaturgy", name: "Тавматургия", desc: "Чары, поставленные на расчёт.", icon: "Sparkles", branch: "mag", era: "industrial", cost: 1700, needs: ["t_alchemy"], unlockB: ["portal"], unlockS: ["s_summon", "s_teleport"], effect: { mana: 45 }, bonusText: "Портал, Призыв и Перенос" }),
  T({ id: "t_rights", name: "Права сословий", desc: "Голос простого человека услышан.", icon: "Users", branch: "soc", era: "industrial", cost: 1480, needs: ["t_diplomacy"], effect: { culture: 12, gold: 14 }, bonusText: "+счастье, республика доступнее" }),

  // ---------- НОВОЕ ВРЕМЯ ----------
  T({ id: "t_electric", name: "Электричество", desc: "Молния в проводах служит людям.", icon: "Zap", branch: "sci", era: "modern", cost: 2400, needs: ["t_chemistry"], unlockB: ["neboskreb"], effect: { sci: 55, prod: 0.2 }, bonusText: "Высокие дома, +55 науки" }),
  T({ id: "t_medicine", name: "Медицина", desc: "Смерть отступает перед знанием.", icon: "HeartPulse", branch: "sci", era: "modern", cost: 2500, needs: ["t_chemistry"], effect: { food: 18, sci: 25 }, bonusText: "Раненые выздоравливают вдвое быстрее" }),
  T({ id: "t_massprod", name: "Поточное дело", desc: "Одинаковое — значит дешёвое.", icon: "Building2", branch: "eco", era: "modern", cost: 2600, needs: ["t_railway"], effect: { prod: 0.35, gold: 40 }, bonusText: "+35% производства, +40 золота" }),
  T({ id: "t_artillery", name: "Тяжёлая артиллерия", desc: "Стены больше не спасают.", icon: "Crosshair", branch: "mil", era: "modern", cost: 2700, needs: ["t_conscript"], effect: { armyAtk: 0.2 }, bonusText: "+20% атаки, осада вдвое злее" }),
  T({ id: "t_radio", name: "Дальняя весть", desc: "Голос летит без гонца.", icon: "Cpu", branch: "cul", era: "modern", cost: 2550, needs: ["t_museums"], effect: { culture: 45, borders: 2 }, bonusText: "+45 культуры, вера шире расходится" }),
  T({ id: "t_arcanotech", name: "Чарометрия", desc: "Мана измерена и разлита по сосудам.", icon: "Sparkles", branch: "mag", era: "modern", cost: 2800, needs: ["t_thaumaturgy"], unlockS: ["s_revive", "s_timewarp"], effect: { mana: 70 }, bonusText: "Воскрешение и Искажение времени" }),

  // ---------- ЭПОХА ЗНАНИЙ ----------
  T({ id: "t_computing", name: "Вычислители", desc: "Машина считает быстрее тысячи писцов.", icon: "Cpu", branch: "sci", era: "information", cost: 3900, needs: ["t_electric"], effect: { sci: 90, gold: 30 }, bonusText: "+90 науки" }),
  T({ id: "t_networks", name: "Сети связи", desc: "Мир стягивается в одну площадь.", icon: "Globe2", branch: "cul", era: "information", cost: 4000, needs: ["t_radio", "t_computing"], effect: { culture: 70, gold: 35 }, bonusText: "+70 культуры, дипломатия сильнее" }),
  T({ id: "t_automation", name: "Самодвижущие станки", desc: "Труд без устали и жалоб.", icon: "Factory", branch: "eco", era: "information", cost: 4200, needs: ["t_massprod", "t_computing"], effect: { prod: 0.5, gold: 60 }, bonusText: "+50% производства" }),
  T({ id: "t_genetics", name: "Наследие живого", desc: "Зерно и плоть переписаны.", icon: "Sprout", branch: "soc", era: "information", cost: 4100, needs: ["t_medicine"], effect: { food: 45, sci: 30 }, bonusText: "+45 еды, город растёт быстрее" }),

  // ---------- КОСМОС ----------
  T({ id: "t_rocketry", name: "Ракетное дело", desc: "Небо перестало быть пределом.", icon: "Rocket", branch: "space", era: "space", cost: 6000, needs: ["t_computing", "t_artillery"], effect: { sci: 80, armyAtk: 0.18 }, bonusText: "+80 науки, ракетные удары" }),
  T({ id: "t_orbital", name: "Орбитальные верфи", desc: "Держава строит в пустоте.", icon: "Rocket", branch: "space", era: "space", cost: 6800, needs: ["t_rocketry", "t_automation"], effect: { sci: 120, gold: 90 }, bonusText: "+120 науки, +90 золота" }),
  T({ id: "t_starlore", name: "Звёздное знание", desc: "Карта небес — карта судьбы.", icon: "Telescope", branch: "sci", era: "space", cost: 7200, needs: ["t_orbital"], effect: { sci: 150, culture: 60 }, bonusText: "+150 науки, +60 культуры" }),

  // ---------- ЭПОХА ЧАР ----------
  T({ id: "t_manacore", name: "Ядро маны", desc: "Сила стихий заперта в кристалл.", icon: "Sparkles", branch: "mag", era: "arcane", cost: 9000, needs: ["t_arcanotech", "t_orbital"], effect: { mana: 160, sci: 60 }, bonusText: "+160 маны, ритуалы вдвое быстрее" }),
  T({ id: "t_worldweave", name: "Ткань мира", desc: "Пространство складывается, как холст.", icon: "CircleDot", branch: "mag", era: "arcane", cost: 9800, needs: ["t_manacore"], unlockB: ["obsidian_tron"], unlockS: ["s_meteor"], effect: { mana: 140, armyAtk: 0.2 }, bonusText: "Обсидиановый трон, Метеор" }),
  T({ id: "t_lifebind", name: "Узы жизни", desc: "Смерть становится переговорной.", icon: "Sprout", branch: "mag", era: "arcane", cost: 10200, needs: ["t_manacore", "t_genetics"], effect: { food: 60, mana: 80, culture: 40 }, bonusText: "Воскрешение дешевле, город цветёт" }),

  // ---------- ПОСТ-СИНГУЛЯРНОСТЬ ----------
  T({ id: "t_ascend", name: "Вознесение разума", desc: "Мысль пережила своего носителя.", icon: "Infinity", branch: "sci", era: "singularity", cost: 14000, needs: ["t_starlore", "t_worldweave"], effect: { sci: 300, culture: 150, mana: 200 }, bonusText: "+300 науки, +150 культуры, +200 маны" }),
  T({ id: "t_eternal", name: "Вечное Пламя", desc: "Огонь, который не гаснет никогда.", icon: "Flame", branch: "cul", era: "singularity", cost: 16000, needs: ["t_ascend", "t_lifebind"], effect: { culture: 400, faith: 200, gold: 200 }, bonusText: "Венец державы: культурная победа близка" }),
];

export const TECH_BY_ID: Record<string, TechDef> = Object.fromEntries(TECHS.map((t) => [t.id, t]));
