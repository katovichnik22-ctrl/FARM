import type { SpellDef, RitualDef, ArtifactDef, BeastDef } from "../types/lore";

// ===== Заклинания =====
export const SPELLS: SpellDef[] = [
  { id: "s_firebolt", name: "Огненная стрела", desc: "Сгусток пламени выжигает строй врага.", icon: "Flame", school: "fire", mana: 18, lvl: 1, kind: "attack", battle: true, power: 55, radius: 1, cd: 2 },
  { id: "s_heal", name: "Исцеление", desc: "Раны затягиваются на глазах.", icon: "HeartPulse", school: "life", mana: 22, lvl: 1, kind: "heal", battle: true, world: true, power: 40, cd: 3 },
  { id: "s_ward", name: "Оберег", desc: "Мерцающий круг держит удары.", icon: "Shield", school: "order", mana: 26, lvl: 2, kind: "shield", battle: true, world: true, power: 30, cd: 4 },
  { id: "s_storm", name: "Буря", desc: "Ветер и град рвут знамёна.", icon: "Wind", school: "air", mana: 34, lvl: 2, kind: "weather", battle: true, world: true, power: 45, radius: 2, cd: 5 },
  { id: "s_curse", name: "Проклятие", desc: "Мужество врага вытекает, как вода.", icon: "Skull", school: "dark", mana: 30, lvl: 2, kind: "curse", battle: true, world: true, power: 35, cd: 4 },
  { id: "s_bless", name: "Благословение", desc: "Свет укрепляет сердце и руку.", icon: "Sun", school: "light", mana: 28, lvl: 2, kind: "bless", battle: true, world: true, power: 30, cd: 4 },
  { id: "s_summon", name: "Призыв защитника", desc: "Из воздуха соткан каменный страж.", icon: "Sparkles", school: "earth", mana: 48, lvl: 3, kind: "summon", battle: true, power: 8, cd: 6 },
  { id: "s_teleport", name: "Перенос", desc: "Шаг сквозь складку мира.", icon: "CircleDot", school: "space", mana: 40, lvl: 3, kind: "teleport", battle: true, world: true, cd: 5 },
  { id: "s_revive", name: "Воскрешение", desc: "Павшие поднимаются из лазарета.", icon: "Sprout", school: "life", mana: 70, lvl: 4, kind: "revive", world: true, power: 60, cd: 8 },
  { id: "s_timewarp", name: "Искажение времени", desc: "Час работы — за один вздох.", icon: "Clock", school: "time", mana: 65, lvl: 4, kind: "bless", world: true, power: 50, cd: 8 },
  { id: "s_meteor", name: "Метеор", desc: "Небо роняет камень величиной с дом.", icon: "Flame", school: "chaos", mana: 95, lvl: 5, kind: "attack", battle: true, power: 140, radius: 2, cd: 9 },
];
export const SPELL_BY_ID: Record<string, SpellDef> = Object.fromEntries(SPELLS.map((s) => [s.id, s]));

// ===== Ритуалы =====
export const RITUALS: RitualDef[] = [
  { id: "r_harvest", name: "Ритуал Урожая", desc: "Зерно тучнеет, сады ломятся от плодов.", icon: "Wheat", school: "life", mana: 60, days: 2, comps: [["yagoda", 10], ["zerno", 12]], gold: 200, bonusText: "+45 еды городу на 6 дней", effect: { kind: "food", value: 45 } },
  { id: "r_rain", name: "Зов Дождя", desc: "Тучи сгущаются по слову волхва.", icon: "CloudRain", school: "water", mana: 50, days: 1, comps: [["glina", 8]], gold: 150, bonusText: "Ливень по всему краю, поля оживают", effect: { kind: "weather", value: 1 } },
  { id: "r_bastion", name: "Каменный Оплот", desc: "Стены обрастают невидимой бронёй.", icon: "Shield", school: "earth", mana: 80, days: 3, comps: [["kamen", 30], ["zhel_slitok", 4]], gold: 350, bonusText: "+25% обороны войска на 8 дней", effect: { kind: "def", value: 0.25 } },
  { id: "r_wargod", name: "Клич Войны", desc: "Барабаны бьют в самой крови.", icon: "Swords", school: "fire", mana: 90, days: 3, comps: [["oruzhie", 3], ["ugol", 12]], gold: 400, bonusText: "+30% атаки войска на 8 дней", effect: { kind: "atk", value: 0.3 } },
  { id: "r_goldflow", name: "Золотой Поток", desc: "Монета липнет к монете сама.", icon: "Coins", school: "order", mana: 75, days: 2, comps: [["ukrashenie", 2], ["med_slitok", 6]], gold: 300, bonusText: "+60% дохода казны на 6 дней", effect: { kind: "gold", value: 0.6 } },
  { id: "r_insight", name: "Озарение", desc: "Мысли учёных сходятся в одну нить.", icon: "FlaskConical", school: "time", mana: 85, days: 2, comps: [["pero", 6], ["nit", 10]], gold: 380, bonusText: "Мгновенно +400 науки", effect: { kind: "sci", value: 400 } },
  { id: "r_veil", name: "Покров Тьмы", desc: "Границы тонут в тумане для чужих глаз.", icon: "Moon", school: "dark", mana: 70, days: 2, comps: [["ugol", 10], ["kost", 8]], gold: 260, bonusText: "Враги не найдут вас 8 дней", effect: { kind: "veil", value: 8 } },
  { id: "r_ascension", name: "Великое Вознесение", desc: "Город на миг касается небес.", icon: "Sparkles", school: "space", mana: 180, days: 5, comps: [["cheshuya", 3], ["zoloto", 500]], gold: 900, bonusText: "+200 культуры, +150 веры, праздник", effect: { kind: "ascend", value: 200 } },
];

// ===== Артефакты =====
export const ARTIFACTS: ArtifactDef[] = [
  { id: "a_ember", name: "Уголёк Первого Костра", desc: "Тёплый даже в лютый мороз.", icon: "Flame", school: "fire", rarity: 1, effect: { spellPow: 0.15, mana: 20 }, bonusText: "+15% силы чар, +20 маны" },
  { id: "a_tear", name: "Слеза Озера", desc: "Капля, что не высыхает.", icon: "Droplets", school: "water", rarity: 1, effect: { manaRegen: 0.5, hp: 20 }, bonusText: "+0.5 маны в секунду, +20 здоровья" },
  { id: "a_root", name: "Корень Древа", desc: "Живая древесина, что растёт в руке.", icon: "Sprout", school: "life", rarity: 2, effect: { manaRegen: 0.3, faith: 12, culture: 10 }, bonusText: "Вера и культура крепнут" },
  { id: "a_crown", name: "Венец Порядка", desc: "Тяжёл, но спину держит прямо.", icon: "Crown", school: "order", rarity: 2, effect: { gold: 20, armyDef: 0.1 }, bonusText: "+20 золота, +10% обороны" },
  { id: "a_shard", name: "Осколок Пустоты", desc: "Смотреть в него дольше вдоха опасно.", icon: "CircleDot", school: "space", rarity: 3, effect: { mana: 80, spellPow: 0.3 }, bonusText: "+80 маны, +30% силы чар" },
  { id: "a_scale", name: "Чешуя Предвечного", desc: "Броня, что помнит драконий огонь.", icon: "Shell", school: "earth", rarity: 3, effect: { armyDef: 0.22, hp: 40 }, bonusText: "+22% обороны войска" },
  { id: "a_blade", name: "Клинок Зари", desc: "Светится перед битвой.", icon: "Sword", school: "light", rarity: 3, effect: { armyAtk: 0.25, spellPow: 0.1 }, bonusText: "+25% атаки войска" },
  { id: "a_hourglass", name: "Часы Без Песка", desc: "Стрелка идёт, песок не кончается.", icon: "Clock", school: "time", rarity: 3, effect: { sci: 60, manaRegen: 0.8 }, bonusText: "+60 науки, быстрая мана" },
];
export const ARTIFACT_BY_ID: Record<string, ArtifactDef> = Object.fromEntries(ARTIFACTS.map((a) => [a.id, a]));

// ===== Мифические существа =====
export const BEASTS: BeastDef[] = [
  { id: "dragon", name: "Древний дракон", icon: "Flame", desc: "Крылья закрывают полнеба, дыхание плавит камень.", hp: 900, power: 320, tameCost: 2500, tameMana: 220, school: "fire", bonusText: "+25% атаки войска, +40 золота в день", effect: { armyAtk: 0.25, gold: 40 } },
  { id: "phoenix", name: "Феникс", icon: "Sparkles", desc: "Умирает в пламени и восстаёт из пепла.", hp: 480, power: 210, tameCost: 1800, tameMana: 260, school: "light", bonusText: "+60 маны, войско восстаёт быстрее", effect: { mana: 60, armyDef: 0.1 } },
  { id: "unicorn", name: "Единорог", icon: "Rabbit", desc: "Копыта не мнут траву, рог лечит любую рану.", hp: 300, power: 120, tameCost: 1200, tameMana: 180, school: "life", bonusText: "+30 еды, +25 культуры", effect: { food: 30, culture: 25 } },
  { id: "griffon", name: "Грифон", icon: "Feather", desc: "Орлиный взор и львиная хватка.", hp: 420, power: 180, tameCost: 1500, tameMana: 160, school: "air", bonusText: "+15% атаки, дозор видит далеко", effect: { armyAtk: 0.15 } },
  { id: "kraken", name: "Кракен", icon: "Waves", desc: "Щупальца утягивают корабли в глубину.", hp: 760, power: 280, tameCost: 2200, tameMana: 240, school: "water", bonusText: "+18% обороны, флот непобедим", effect: { armyDef: 0.18, gold: 25 } },
  { id: "titan", name: "Титан", icon: "Mountain", desc: "Шагает — и земля отзывается гулом.", hp: 1400, power: 420, tameCost: 3500, tameMana: 320, school: "earth", bonusText: "+30% обороны, +20% атаки", effect: { armyDef: 0.3, armyAtk: 0.2 } },
];
export const BEAST_BY_ID: Record<string, BeastDef> = Object.fromEntries(BEASTS.map((b) => [b.id, b]));

// ===== Религия: генерация имён =====
export const RELIGION_PREFIX = ["Путь", "Свет", "Круг", "Завет", "Слово", "Пламя", "Око", "Длань"];
export const RELIGION_SUFFIX = ["Тихого Пламени", "Девяти Ветров", "Первой Зари", "Вечного Древа", "Каменного Отца", "Ясного Неба", "Дальних Троп", "Немеркнущих"];
export const RELIGION_SYMS = ["✦", "☀", "☘", "◈", "☾", "⚶", "✧", "⌘", "✹"];
export const RELIGION_COLORS = ["#ffd97a", "#7ae68a", "#8fa2f2", "#e08ac9", "#f2a24d", "#c9c2b2"];

export const PROPHET_NAMES = ["Аввакум", "Серафим", "Иоанн", "Мелхиседек", "Варлаам", "Пелагея", "Феодора", "Иринарх", "Досифей", "Гликерия"];
export const PROPHET_TRAITS = ["Молчальник", "Огнеслов", "Странник", "Прозорливый", "Босоногий", "Затворник", "Целитель"];

// ===== Великие люди =====
export const GREAT_NAMES = [
  "Андрей Рублёв-Тихий", "Евфросиния Светлая", "Кирилл Книжник", "Гамаюн Певчая",
  "Феофан Пёстрый", "Софья Звездочёт", "Никита Ладожский", "Марфа Пламенная",
  "Даниил Резчик", "Агафья Травница", "Прокопий Зодчий", "Василиса Вещая",
];
export const GREAT_BIOS = [
  "Говорят, работал по три дня без сна и еды.",
  "Начинал подмастерьем и превзошёл всех учителей.",
  "Утверждал, что видел замысел мира целиком.",
  "Оставил после себя школу и сотню учеников.",
  "Творил только на рассвете, считая это единственно верным.",
  "Отказался от золота князя, попросив взамен свободу.",
];
