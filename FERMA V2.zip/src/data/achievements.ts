import type { AchDef, AchCtx, CollectEntry } from "../types/meta";

// ===== Достижения =====
const A = (
  id: string, name: string, desc: string, icon: string,
  cat: AchDef["cat"], tier: 1 | 2 | 3, stars: number,
  check: (s: AchCtx) => boolean
): AchDef => ({ id, name, desc, icon, cat, tier, stars, check });

/** Порождает набор ступенчатых достижений по одному показателю */
function steps(
  base: string, name: string, icon: string, cat: AchDef["cat"],
  get: (s: AchCtx) => number, vals: number[], unit: string
): AchDef[] {
  return vals.map((v, i) =>
    A(`${base}${i}`, `${name} ${["I", "II", "III", "IV", "V", "VI"][i] ?? i + 1}`,
      `Достичь ${v} ${unit}`, icon, cat, (i < 2 ? 1 : i < 4 ? 2 : 3) as 1 | 2 | 3,
      i + 1, (s) => get(s) >= v)
  );
}

export const ACHIEVEMENTS: AchDef[] = [
  // ---- Выживание ----
  ...steps("a_day", "Долгожитель", "Sun", "survive", (s) => s.day, [2, 5, 10, 20, 40, 80], "дней"),
  ...steps("a_lvl", "Возвышение", "Star", "survive", (s) => s.level, [5, 10, 20, 35, 50, 75], "уровня"),
  ...steps("a_kill", "Истребитель", "Swords", "survive", (s) => s.killed, [10, 50, 150, 400, 1000, 2500], "побед над тварями"),
  ...steps("a_craft", "Ремесленник", "Hammer", "survive", (s) => s.crafted, [5, 25, 75, 200, 500, 1200], "изделий"),
  ...steps("a_build", "Зодчий", "Landmark", "survive", (s) => s.built, [3, 15, 40, 100, 250, 600], "построек"),
  A("a_dragon", "Драконоборец", "Повергнуть Древнего Дракона", "Flame", "survive", 3, 8, (s) => s.dragonDead),

  // ---- Город ----
  ...steps("a_pop", "Град растёт", "Users", "city", (s) => s.cityPop, [10, 30, 75, 150, 300, 600], "жителей"),
  ...steps("a_gold", "Богатство", "Coins", "city", (s) => s.gold, [500, 5000, 25000, 100000, 500000, 2000000], "золота"),
  A("a_city", "Основатель", "Основать свой первый город", "Landmark", "city", 1, 2, (s) => s.cityFounded),
  ...steps("a_wonder", "Чудеса света", "Sparkle", "city", (s) => s.wondersBuilt, [1, 3, 6, 9, 12], "чудес"),

  // ---- Война ----
  ...steps("a_army", "Полководец", "Shield", "war", (s) => s.armyMen, [5, 20, 50, 100, 200], "бойцов"),
  ...steps("a_battle", "Победитель", "Trophy", "war", (s) => s.battlesWon, [1, 5, 15, 40, 100], "побед в битвах"),
  ...steps("a_vassal", "Сюзерен", "Crown", "war", (s) => s.nationsVassal, [1, 3, 6, 10], "вассалов"),
  ...steps("a_ally", "Дипломат", "Handshake", "war", (s) => s.nationsAlly, [1, 3, 6, 10], "союзников"),

  // ---- Знание, чары, вера ----
  ...steps("a_tech", "Мыслитель", "FlaskConical", "lore", (s) => s.techs, [3, 10, 20, 35, 50, 58], "технологий"),
  ...steps("a_era", "Сквозь эпохи", "Clock", "lore", (s) => s.era, [1, 3, 5, 7, 9, 10], "эпох пройдено"),
  ...steps("a_cult", "Покровитель искусств", "Palette", "lore", (s) => s.culture, [500, 3000, 10000, 25000, 45000], "культуры"),
  ...steps("a_great", "Созвездие гениев", "Sparkles", "lore", (s) => s.greats, [1, 3, 8, 15, 30], "великих людей"),
  A("a_mage", "Путь чародея", "Встать на путь мага", "Sparkles", "lore", 1, 3, (s) => s.mage),
  ...steps("a_spell", "Чернокнижник", "Wand", "lore", (s) => s.spells, [3, 6, 9, 11], "заклинаний"),
  ...steps("a_art", "Собиратель реликвий", "Gem", "lore", (s) => s.artifacts, [1, 3, 5, 8], "артефактов"),
  ...steps("a_beast", "Укротитель", "Rabbit", "lore", (s) => s.beasts, [1, 2, 4, 6], "мифических тварей"),
  A("a_rel", "Основатель веры", "Основать свою религию", "Church", "lore", 2, 4, (s) => s.religion),
  ...steps("a_faith", "Свет над миром", "Sun", "lore", (s) => s.followers, [10, 25, 50, 75, 100], "% последователей"),

  // ---- Миры ----
  ...steps("a_layer", "Странник миров", "Layers3", "worlds", (s) => s.layers, [3, 5, 7, 9, 10], "слоёв открыто"),
  ...steps("a_boss", "Владыка владык", "Skull", "worlds", (s) => s.bosses, [1, 3, 5, 8], "боссов слоёв"),
  ...steps("a_space", "Космическая держава", "Rocket", "worlds", (s) => s.spaceBuilds, [1, 3, 6], "космических построек"),

  // ---- Мета ----
  ...steps("a_quest", "Летопись дел", "ScrollText", "meta", (s) => s.questsDone, [3, 10, 30, 75, 150], "заданий"),
  ...steps("a_coll", "Коллекционер", "Boxes", "meta", (s) => s.collection, [10, 30, 60, 100, 150], "записей в коллекции"),
  ...steps("a_prestige", "Перерождение", "Infinity", "meta", (s) => s.prestige, [1, 3, 5, 10], "перерождений"),
];

export const ACH_CATS: { id: AchDef["cat"]; name: string; icon: string }[] = [
  { id: "survive", name: "Выживание", icon: "Flame" },
  { id: "city", name: "Город", icon: "Landmark" },
  { id: "war", name: "Война", icon: "Swords" },
  { id: "lore", name: "Знание", icon: "FlaskConical" },
  { id: "worlds", name: "Миры", icon: "Layers3" },
  { id: "meta", name: "Наследие", icon: "Star" },
];

// ===== Коллекция =====
export const COLLECTION: CollectEntry[] = [
  // Флора
  { id: "col_oak", name: "Дуб", cat: "flora", icon: "Trees", desc: "Кряжистый исполин с жёлудями." },
  { id: "col_pine", name: "Сосна", cat: "flora", icon: "Trees", desc: "Смолистая, прямая как копьё." },
  { id: "col_birch", name: "Берёза", cat: "flora", icon: "Trees", desc: "Белый ствол, шёпот листвы." },
  { id: "col_bush", name: "Ягодный куст", cat: "flora", icon: "Cherry", desc: "Первая еда всякого путника." },
  { id: "col_grib", name: "Грибы", cat: "flora", icon: "Shapes", desc: "Сыроежки из-под елей." },
  { id: "col_glow", name: "Светлячник", cat: "flora", icon: "Sparkles", desc: "Гриб, что светится в темноте." },
  { id: "col_cactus", name: "Кактус", cat: "flora", icon: "Sprout", desc: "Хранит воду в колючем теле." },
  { id: "col_reeds", name: "Камыш", cat: "flora", icon: "Wheat", desc: "Шелестит на берегу." },
  { id: "col_cloudtree", name: "Облачное древо", cat: "flora", icon: "Wind", desc: "Растёт из тумана на летающих островах." },
  { id: "col_shadowtree", name: "Теневое древо", cat: "flora", icon: "Moon", desc: "Не отбрасывает тени. Само и есть тень." },
  { id: "col_dreamflower", name: "Цветок снов", cat: "flora", icon: "Sparkles", desc: "Лепестки меняют цвет, если моргнуть." },
  { id: "col_coral", name: "Коралл", cat: "flora", icon: "Shapes", desc: "Живой камень подводных садов." },
  { id: "col_seaweed", name: "Водоросли", cat: "flora", icon: "Waves", desc: "Танцуют в течении." },
  // Фауна
  { id: "col_olen", name: "Олень", cat: "fauna", icon: "Rabbit", desc: "Гордый рогач лесных полян." },
  { id: "col_krolik", name: "Заяц", cat: "fauna", icon: "Rabbit", desc: "Быстрее, чем кажется." },
  { id: "col_kaban", name: "Кабан", cat: "fauna", icon: "Beef", desc: "Не трогай — и он не тронет." },
  { id: "col_grifon", name: "Грифон", cat: "fauna", icon: "Feather", desc: "Орёл и лев в одном теле." },
  { id: "col_rusalka", name: "Русалка", cat: "fauna", icon: "Waves", desc: "Поёт так, что забываешь дышать." },
  { id: "col_murena", name: "Мурена", cat: "fauna", icon: "Waves", desc: "Выстреливает из расщелины." },
  { id: "col_unicorn", name: "Единорог", cat: "fauna", icon: "Rabbit", desc: "Копыта не мнут траву." },
  { id: "col_phoenix", name: "Феникс", cat: "fauna", icon: "Flame", desc: "Умирает и восстаёт из пепла." },
  { id: "col_kraken_t", name: "Кракен", cat: "fauna", icon: "Waves", desc: "Щупальца длиннее корабля." },
  { id: "col_titan", name: "Титан", cat: "fauna", icon: "Mountain", desc: "Шагает — земля отзывается." },
  // Монстры
  { id: "col_zombi", name: "Утопленник", cat: "monster", icon: "Skull", desc: "Идёт медленно, но не устаёт никогда." },
  { id: "col_skelet", name: "Костяной стрелок", cat: "monster", icon: "Bone", desc: "Целится пустыми глазницами." },
  { id: "col_pauk", name: "Теневой паук", cat: "monster", icon: "Bug", desc: "Восемь ног, восемь красных огней." },
  { id: "col_kriper", name: "Мшистый грохотун", cat: "monster", icon: "Bomb", desc: "Шипит — беги." },
  { id: "col_prizrak", name: "Белая кикимора", cat: "monster", icon: "Moon", desc: "Проходит сквозь стены и надежды." },
  { id: "col_mysh", name: "Кожаная мышь", cat: "monster", icon: "Feather", desc: "Мелкая, но кусачая." },
  { id: "col_sliz", name: "Пещерный слизень", cat: "monster", icon: "Droplets", desc: "Оставляет светящийся след." },
  { id: "col_lavoviy", name: "Лавовый выползень", cat: "monster", icon: "Flame", desc: "Плавает в камне как в воде." },
  { id: "col_magmit", name: "Магмит", cat: "monster", icon: "Flame", desc: "Сгусток живого жара." },
  { id: "col_vihrevik", name: "Вихревик", cat: "monster", icon: "Wind", desc: "Вихрь, у которого есть намерение." },
  { id: "col_ten", name: "Теневой охотник", cat: "monster", icon: "Moon", desc: "Видит вас раньше, чем вы его." },
  { id: "col_koshmar", name: "Кошмар", cat: "monster", icon: "Sparkles", desc: "Принимает облик того, чего боишься." },
  { id: "col_haoszver", name: "Тварь хаоса", cat: "monster", icon: "Zap", desc: "Каждый раз выглядит иначе." },
  { id: "col_lunprizrak", name: "Лунный призрак", cat: "monster", icon: "Moon", desc: "Молчит даже когда бьёт." },
  { id: "col_marsianin", name: "Марсианский страж", cat: "monster", icon: "Rocket", desc: "Стоял здесь до нас и будет стоять после." },
  // Боссы
  { id: "col_drakon", name: "Древний Дракон", cat: "boss", icon: "Flame", desc: "Первый враг, достойный песни." },
  { id: "col_korol", name: "Король нежити", cat: "boss", icon: "Skull", desc: "Корона вросла в череп." },
  { id: "col_lava", name: "Повелитель лавы", cat: "boss", icon: "Flame", desc: "Сердце глубин бьётся в его груди." },
  { id: "col_ledy", name: "Ледяная королева", cat: "boss", icon: "Snowflake", desc: "Её дыхание останавливает ветер." },
  { id: "col_kraken_b", name: "Древний кракен", cat: "boss", icon: "Waves", desc: "Топил флоты до того, как их построили." },
  { id: "col_lunbog", name: "Лунный бог", cat: "boss", icon: "Moon", desc: "Спал в кратере тысячу лет." },
  { id: "col_kosmo", name: "Космический ужас", cat: "boss", icon: "Skull", desc: "У него нет формы, только голод." },
  { id: "col_bezdna", name: "Владыка бездны", cat: "boss", icon: "Moon", desc: "Правит там, где нет света." },
  { id: "col_haos", name: "Аватар Хаоса", cat: "boss", icon: "Zap", desc: "Последний и самый безумный." },
  // Ресурсы
  { id: "col_mifril", name: "Мифрил", cat: "resource", icon: "Gem", desc: "Лёгок как перо, крепче стали." },
  { id: "col_adamant", name: "Адамантин", cat: "resource", icon: "Gem", desc: "Чёрный металл глубин." },
  { id: "col_kristall", name: "Кристалл", cat: "resource", icon: "Sparkle", desc: "Светится собственным светом." },
  { id: "col_nebkrist", name: "Небесный кристалл", cat: "resource", icon: "Sparkles", desc: "Внутри плывут облака." },
  { id: "col_zhemchug", name: "Жемчуг", cat: "resource", icon: "Gem", desc: "Слёзы моря." },
  { id: "col_lunkamen", name: "Лунный камень", cat: "resource", icon: "Moon", desc: "Спрессованная тишина." },
  { id: "col_marsianit", name: "Марсианит", cat: "resource", icon: "Rocket", desc: "Помнит чужие руки." },
  { id: "col_tensut", name: "Теневая суть", cat: "resource", icon: "Moon", desc: "Живая на ощупь тьма." },
  { id: "col_pylsnov", name: "Пыль снов", cat: "resource", icon: "Sparkles", desc: "Щепотка — и явь зыбка." },
  { id: "col_oskolok", name: "Осколок хаоса", cat: "resource", icon: "Zap", desc: "Меняется, когда не смотришь." },
  { id: "col_alientech", name: "Чужая деталь", cat: "resource", icon: "Cpu", desc: "Собрана не человеческой рукой." },
  { id: "col_cheshuya", name: "Чешуя дракона", cat: "resource", icon: "Shell", desc: "Тёплая даже в метель." },
];

/** Соответствие «источник → запись коллекции» */
export const COLLECT_MAP: Record<string, string> = {
  // объекты мира (по id объекта O.*)
  "o1": "col_oak", "o2": "col_pine", "o3": "col_birch", "o4": "col_bush", "o9": "col_grib",
  "o18": "col_glow", "o21": "col_cactus", "o22": "col_reeds", "o29": "col_cloudtree",
  "o37": "col_shadowtree", "o38": "col_dreamflower", "o31": "col_coral", "o32": "col_seaweed",
  // мобы (по id моба)
  "olen": "col_olen", "krolik": "col_krolik", "kaban": "col_kaban", "grifon": "col_grifon",
  "rusalka": "col_rusalka", "murena": "col_murena",
  "zombi": "col_zombi", "skelet": "col_skelet", "pauk": "col_pauk", "kriper": "col_kriper",
  "prizrak": "col_prizrak", "mysh": "col_mysh", "sliz": "col_sliz",
  "lavoviy": "col_lavoviy", "magmit": "col_magmit", "vihrevik": "col_vihrevik",
  "ten_ohotnik": "col_ten", "koshmar": "col_koshmar", "haoszver": "col_haoszver",
  "lunnyi_prizrak": "col_lunprizrak", "marsianin": "col_marsianin",
  "drakon": "col_drakon", "korol_nezhiti": "col_korol", "vladyka_lavy": "col_lava",
  "ledyanaya_koroleva": "col_ledy", "kraken": "col_kraken_b", "lunnyi_bog": "col_lunbog",
  "kosmouzhas": "col_kosmo", "vladyka_bezdny": "col_bezdna", "haos_avatar": "col_haos",
  // приручённые твари
  "tame_unicorn": "col_unicorn", "tame_phoenix": "col_phoenix", "tame_kraken": "col_kraken_t", "tame_titan": "col_titan",
  // ресурсы (по id предмета)
  "mifril": "col_mifril", "adamantit": "col_adamant", "kristall": "col_kristall",
  "nebesnyi_kristall": "col_nebkrist", "zhemchug": "col_zhemchug", "lunnyi_kamen": "col_lunkamen",
  "marsianit": "col_marsianit", "tenevaya_sut": "col_tensut", "pyl_snov": "col_pylsnov",
  "oskolok_haosa": "col_oskolok", "alien_tech": "col_alientech", "cheshuya": "col_cheshuya",
};

export const COLLECT_CATS: { id: CollectEntry["cat"]; name: string; icon: string }[] = [
  { id: "flora", name: "Растения", icon: "Trees" },
  { id: "fauna", name: "Звери", icon: "Rabbit" },
  { id: "monster", name: "Чудища", icon: "Skull" },
  { id: "boss", name: "Владыки", icon: "Crown" },
  { id: "resource", name: "Материалы", icon: "Gem" },
];

// ===== Задания дня =====
export const DAILY_POOL: { id: string; kind: string; text: string; min: number; max: number; reward: number }[] = [
  { id: "d_gather", kind: "gather", text: "Собрать ресурсов", min: 20, max: 60, reward: 3 },
  { id: "d_kill", kind: "kill", text: "Одолеть тварей", min: 5, max: 20, reward: 4 },
  { id: "d_craft", kind: "craft", text: "Смастерить изделий", min: 3, max: 10, reward: 3 },
  { id: "d_build", kind: "build", text: "Возвести построек", min: 1, max: 4, reward: 4 },
  { id: "d_quest", kind: "quest", text: "Выполнить заданий", min: 1, max: 3, reward: 5 },
  { id: "d_walk", kind: "walk", text: "Пройти вёрст", min: 30, max: 90, reward: 2 },
];
