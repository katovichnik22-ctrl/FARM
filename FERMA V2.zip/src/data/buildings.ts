import type { BuildingDef } from "../types";
import { CITY_BUILDINGS } from "./citybuildings";

// ===== Здания и постройки =====
const BASE_BUILDINGS: Record<string, BuildingDef> = Object.fromEntries(
  (
    [
      // Жильё
      { id: "koster", name: "Костёр", desc: "Свет, тепло, готовка и плавка. Сердце любой стоянки.", icon: "Flame", cat: "Жильё", w: 1, h: 1, cost: [["brevno", 3], ["kamen", 2]], buildTime: 2, hp: 60, blocks: false, light: 6.5, warmth: 22, cook: true },
      { id: "shalash", name: "Шалаш", desc: "Крыша из ветвей. Можно спать, если рядом нет чудищ.", icon: "Tent", cat: "Жильё", w: 2, h: 2, cost: [["brevno", 6], ["palka", 4]], buildTime: 6, hp: 120, blocks: false, sleep: true },
      { id: "dom", name: "Домик", desc: "Тёплые стены, настоящий очаг. Спится спокойно.", icon: "Home", cat: "Жильё", w: 3, h: 3, cost: [["doska", 12], ["kamen", 6]], buildTime: 14, hp: 320, blocks: false, sleep: true, warmth: 4 },
      { id: "fakel_st", name: "Факел стоячий", desc: "Малый огонёк на столбе.", icon: "Candle", cat: "Жильё", w: 1, h: 1, cost: [["fakel", 1]], buildTime: 0.5, hp: 20, blocks: false, light: 4.2 },

      // Производство
      { id: "lesopilka", name: "Лесопилка", desc: "Сама тесает брёвна в доски. Забирай доски вовремя.", icon: "Saw", cat: "Производство", w: 2, h: 2, cost: [["brevno", 8], ["kamen", 4]], buildTime: 10, hp: 200, blocks: false, produce: { id: "doska", every: 50, max: 6 } },
      { id: "kamenolom", name: "Каменотёс", desc: "Дробит скальник в добрый булыжник.", icon: "Hammer", cat: "Производство", w: 2, h: 2, cost: [["doska", 6], ["kamen", 8]], buildTime: 10, hp: 220, blocks: false, produce: { id: "kamen", every: 55, max: 6 } },

      // Еда
      { id: "ferma", name: "Грядка", desc: "Ягодный куст в уходе. Плодоносит каждую пару минут.", icon: "Sprout", cat: "Еда", w: 2, h: 2, cost: [["palka", 4], ["yagoda", 5], ["glina", 2]], buildTime: 8, hp: 80, blocks: false, produce: { id: "yagoda", every: 90, max: 8 } },
      { id: "kolodec", name: "Колодец", desc: "Чистая вода без дна. И пить, и бурдюки полнить.", icon: "Droplet", cat: "Еда", w: 1, h: 1, cost: [["kamen", 8], ["doska", 2]], buildTime: 10, hp: 160, blocks: false, well: true },

      // Оборона
      { id: "chastokol", name: "Частокол", desc: "Заострённые колья. Зверьё обойдёт стороной.", icon: "Fence", cat: "Оборона", w: 1, h: 1, cost: [["brevno", 2]], buildTime: 1.5, hp: 140, blocks: true },
      { id: "stena", name: "Каменная стена", desc: "Крепкий камень — крепкий сон.", icon: "BrickWall", cat: "Оборона", w: 1, h: 1, cost: [["kamen", 3]], buildTime: 2.5, hp: 300, blocks: true },
      { id: "dver", name: "Дверь", desc: "Впускает хозяина, держит стужу.", icon: "DoorOpen", cat: "Оборона", w: 1, h: 1, cost: [["doska", 3]], buildTime: 2, hp: 120, blocks: true, door: true },
      { id: "vyshka", name: "Вышка", desc: "С неё видно дым врага за три версты.", icon: "TowerControl", cat: "Оборона", w: 1, h: 1, cost: [["doska", 6], ["palka", 4]], buildTime: 8, hp: 200, blocks: true, light: 2 },
    ] as BuildingDef[]
  ).map((b) => [b.id, b])
);

// Базовые постройки 1-го этапа дополняем городскими
export const BUILDINGS: Record<string, BuildingDef> = { ...BASE_BUILDINGS, ...CITY_BUILDINGS };

export const BUILD_CATS = [
  "Всё", "Жильё", "Производство", "Еда", "Оборона",
  "Город", "Экономика", "Наука", "Религия", "Магия", "Досуг", "Чудеса",
];

// Небольшие бонусы жилья базовым постройкам (чтобы старые здания жили в городе)
BASE_BUILDINGS.shalash.housing = 2;
BASE_BUILDINGS.dom.housing = 5;
BASE_BUILDINGS.dom.eff = { happy: 1 };
BASE_BUILDINGS.ferma.eff = { food: 6 };
BASE_BUILDINGS.ferma.jobs = 2;
BASE_BUILDINGS.kolodec.eff = { water: 10 };
BASE_BUILDINGS.lesopilka.jobs = 3;
BASE_BUILDINGS.lesopilka.eff = { gold: 1, pollution: 1 };
BASE_BUILDINGS.kamenolom.jobs = 3;
BASE_BUILDINGS.kamenolom.eff = { gold: 1, pollution: 1 };
BASE_BUILDINGS.koster.eff = { happy: 1 };
BASE_BUILDINGS.vyshka.eff = { order: 3, crime: -2 };
BASE_BUILDINGS.stena.eff = { order: 1 };
BASE_BUILDINGS.chastokol.eff = { order: 0.5 };
