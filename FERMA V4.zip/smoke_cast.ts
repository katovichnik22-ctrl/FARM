// Валидатор 8-го этапа: каст NPC, сцены и события
import { NPCS, CITY_PERSONAS, WORLD_PERSONAS, ROMANCEABLE, PERSONA_BY_ID, GREET_POOL, CHAT_POOL, GIFT_POOL, ROMANCE_POOL, type NpcCharacter } from "./src/data/npcs";
import { NPC_ROLES, type NpcRole } from "./src/types/city";
import { ITEMS } from "./src/data/items";
import { CUTSCENES, CINE_EVENTS, SCENE_BY_ID, EVENT_BY_ID } from "./src/game/cutscenes";

const ok: string[] = [];
const err: string[] = [];

// 1. Состав
const ids = new Set(NPCS.map((p) => p.id));
if (ids.size !== NPCS.length) err.push("Дубли id персонажей!");
if (CITY_PERSONAS.length >= 20 && CITY_PERSONAS.length <= 30) ok.push(`Город: ${CITY_PERSONAS.length} NPC (20-30)`);
else err.push(`Город: ${CITY_PERSONAS.length} — вне 20-30`);
if (NPCS.length >= 40 && NPCS.length <= 60) ok.push(`Мир: ${NPCS.length} NPC (40-60)`);
else err.push(`Мир: ${NPCS.length} — вне 40-60`);
if (ROMANCEABLE.length >= 33) ok.push(`Брак: ${ROMANCEABLE.length} доступно (>=33)`);
else err.push(`Брак: ${ROMANCEABLE.length} — меньше 33`);

// категории не-брачных
const nonRom = NPCS.filter((p) => !p.romance);
const nonRomRoles = new Set(nonRom.map((p) => p.spriteBase));
ok.push(`Не для брака: ${nonRom.length} (роли: ${[...nonRomRoles].join(", ")})`);

// 2. Поля персонажей
const chars: NpcCharacter[] = ["dobryi", "vorchlivyi", "veselyi", "zagadochnyi", "zloi"];
const PLACES = new Set(["home", "work", "square", "tavern", "market", "temple", "gate", "port", "wild"]);
for (const p of NPCS) {
  if (!chars.includes(p.character)) err.push(`${p.id}: характер ${p.character}`);
  if (!NPC_ROLES[p.spriteBase as NpcRole]) err.push(`${p.id}: нет спрайта ${p.spriteBase}`);
  for (const pl of Object.values(p.schedule)) if (!PLACES.has(pl)) err.push(`${p.id}: место ${pl}`);
  for (const g of [...p.likedGifts, ...p.dislikedGifts]) if (!ITEMS[g]) err.push(`${p.id}: нет предмета ${g}`);
  if (p.likedGifts.some((g) => p.dislikedGifts.includes(g))) err.push(`${p.id}: предмет и любим и нелюбим`);
  if (!p.problem || p.problem.length < 20) err.push(`${p.id}: короткая problem`);
  if (!p.story || p.story.length < 20) err.push(`${p.id}: короткая story`);
  for (const r of Object.keys(p.relations)) if (!PERSONA_BY_ID[r]) err.push(`${p.id}: связь с несуществующим ${r}`);
  for (const t of [...Object.values(PERSONA_BY_ID).filter(o => o.id !== p.id && o.relations[p.id])]) void t;
  if (p.age < 4 || p.age > 90) err.push(`${p.id}: возраст ${p.age}`);
}
// взаимность не проверяем — отношения могут быть односторонними

// 3. Пулы реплик
for (const c of chars) {
  for (const tier of ["enemy", "stranger", "known", "pal", "friend"] as const)
    if (!GREET_POOL[c][tier]?.length) err.push(`GREET_POOL ${c}/${tier} пуст`);
  if (!CHAT_POOL[c]?.length) err.push(`CHAT_POOL ${c} пуст`);
  for (const k of ["like", "neutral", "dislike"] as const) if (!GIFT_POOL[c][k]?.length) err.push(`GIFT_POOL ${c}/${k} пуст`);
}
for (const k of ["cold", "warm", "inlove"] as const) if (!ROMANCE_POOL[k]?.length) err.push(`ROMANCE_POOL ${k} пуст`);

// 4. Сцены
const wantScenes = ["first_sunset","first_night","first_fire","first_house","first_city","first_battle","first_boss","first_death","first_respawn","first_space","first_portal","finale"];
if (CUTSCENES.length === 12) ok.push("Сцен: 12"); else err.push(`Сцен: ${CUTSCENES.length}`);
for (const id of wantScenes) if (!SCENE_BY_ID[id]) err.push(`Нет сцены ${id}`);
for (const s of CUTSCENES) {
  if (s.dur < 6 || s.dur > 20) err.push(`${s.id}: длительность ${s.dur}`);
  if (!s.title || !s.triggerDesc) err.push(`${s.id}: пустые поля`);
  if (s.credits.length < 3) err.push(`${s.id}: титров мало (${s.credits.length})`);
  if (s.effects.slowmo && (s.effects.slowmo < 0.1 || s.effects.slowmo >= 1)) err.push(`${s.id}: slowmo ${s.effects.slowmo}`);
}

// 5. События
const wantEvents = ["earthquake","nashat","koronaciya","svadba","pokhorony","zatmenie","krovavaya_luna","meteor_rain","prazdnik","alien_invasion"];
if (CINE_EVENTS.length === 10) ok.push("Событий: 10"); else err.push(`Событий: ${CINE_EVENTS.length}`);
for (const id of wantEvents) if (!EVENT_BY_ID[id]) err.push(`Нет события ${id}`);
for (const ev of CINE_EVENTS) {
  if (!ev.banner.omen || !ev.banner.main || !ev.banner.after) err.push(`${ev.id}: пустой баннер`);
  if (ev.dur < 5) err.push(`${ev.id}: слишком короткое`);
}

console.log("\x1b[32m" + ok.map((s) => "OK  " + s).join("\n") + "\x1b[0m");
if (err.length) { console.log("\x1b[31m" + err.map((s) => "ERR " + s).join("\n") + "\x1b[0m"); process.exit(1); }
console.log("ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ");
