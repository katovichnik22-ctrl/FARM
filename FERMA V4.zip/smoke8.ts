import { BOSSES, BOSS_MOBS, TROPHY_BY_ID, bossesForZ } from "./src/data/bosses";
import { ANOMALIES, ANOMALY_BY_ID, LEGENDARY_FINDS } from "./src/data/anomalies";
import { ITEMS } from "./src/data/items";
import { anomalyAt, anomalyCenter } from "./src/world/anomalies";
import { tileAt } from "./src/world/worldgen";

const ok: string[] = [];
const err: string[] = [];

// 1. Боссы: количество и поля
if (BOSSES.length >= 30) ok.push(`Боссов: ${BOSSES.length} (>=30)`); else err.push(`Боссов мало: ${BOSSES.length}`);
const SPRITES = new Set(["drakon","grifon","haos_avatar","haoszver","kaban","korol_nezhiti","koshmar","kosmouzhas","kraken","kriper","krolik","lavoviy","ledyanaya_koroleva","lunnyi_bog","lunnyi_prizrak","magmit","marsianin","murena","mysh","olen","pauk","prizrak","rusalka","skelet","sliz","ten_ohotnik","vihrevik","vladyka_bezdny","vladyka_lavy","zombi"]);
const uniq = new Set(BOSSES.map(b => b.id));
if (uniq.size !== BOSSES.length) err.push("Дубли id боссов!");
for (const b of BOSSES) {
  if (!SPRITES.has(b.spriteBase)) err.push(`${b.id}: нет спрайта ${b.spriteBase}`);
  if (b.scale < 2 || b.scale > 4) err.push(`${b.id}: scale ${b.scale} вне 2-4`);
  if (b.phases < 2 || b.phases > 4) err.push(`${b.id}: phases ${b.phases}`);
  if (!b.abilities.length) err.push(`${b.id}: нет способностей`);
  for (const l of b.loot) if (!TROPHY_BY_ID[l]) err.push(`${b.id}: нет трофея ${l}`);
  if (!BOSS_MOBS[b.id]) err.push(`${b.id}: нет MobDef`);
  if (!b.arena || !b.name) err.push(`${b.id}: пустые поля`);
}
const groups: Record<string, number> = {};
for (const b of BOSSES) groups[b.layer] = (groups[b.layer] ?? 0) + 1;
const want: Record<string, number> = { surface: 5, cave: 6, depths: 5, sky: 4, ocean: 4, space: 5, magic: 4, final: 1 };
for (const [g, n] of Object.entries(want)) {
  if ((groups[g] ?? 0) === n) ok.push(`Слой ${g}: ровно ${n} шт`);
  else err.push(`Слой ${g}: ${groups[g] ?? 0} вместо ${n}`);
}

// 2. Аномалии и находки
if (ANOMALIES.length === 12) ok.push("Аномалий: 12"); else err.push(`Аномалий: ${ANOMALIES.length}`);
for (const f of LEGENDARY_FINDS) {
  if (!ANOMALY_BY_ID[f.zone]) err.push(`Находка ${f.id}: нет зоны ${f.zone}`);
  if (!ITEMS[f.id]) err.push(`Находка ${f.id}: не в ITEMS`);
}
const cats = new Set(LEGENDARY_FINDS.map(f => f.cat));
const wantCats = ["weapon","armor","artifact","egg","seed","map","diary","key"];
for (const c of wantCats) if (!cats.has(c as never)) err.push(`Нет категории находки: ${c}`);
ok.push(`Находок: ${LEGENDARY_FINDS.length}, категорий: ${cats.size}/8`);
for (const b of BOSSES) for (const l of b.loot) if (!ITEMS[l]) err.push(`Трофей ${l} не в ITEMS`);
ok.push(`Трофеев в ITEMS: ${BOSS_OK()}`);
function BOSS_OK() { let n = 0; for (const b of BOSSES) for (const l of b.loot) if (ITEMS[l]) n++; return n; }

// 3. Структуры: сердца и покрытие на четырёх сидах
const seeds = [1, 42, 777, 31337];
for (const zone of ANOMALIES) {
  let hearts = 0, tiles = 0;
  for (const seed of seeds) {
    const c = anomalyCenter(seed, zone.id);
    for (let dy = -zone.radius; dy <= zone.radius; dy++)
      for (let dx = -zone.radius; dx <= zone.radius; dx++) {
        const ax = c.x + dx, ay = c.y + dy;
        const h = anomalyAt(seed, ax, ay, zone.z);
        if (h) { tiles++; if (h.heart) hearts++; }
      }
  }
  if (tiles === 0) err.push(`Зона ${zone.id}: пустая структура`);
  if (hearts < seeds.length) err.push(`Зона ${zone.id}: сердец ${hearts}/${seeds.length}`);
}
ok.push("Структуры: сердце и площадь есть у всех 12 зон на 4 сидах");

// 4. tileAt применяет структуру: сердце crystal_cave — RuinChest на CaveFloor
{
  const seed = 42;
  const zone = ANOMALY_BY_ID["crystal_cave"];
  const c = anomalyCenter(seed, zone.id);
  const t = tileAt(seed, c.x, c.y, 1);
  if (t.o === 42 && t.g === 12) ok.push("Сердце пещеры кристаллов: RuinChest на CaveFloor через tileAt");
  else err.push(`Сердце crystal_cave: o=${t.o} g=${t.g}`);
}
// и детерминизм
{
  const seed = 7;
  const a = tileAt(seed, 100, 100, 0);
  const b = tileAt(seed, 100, 100, 0);
  if (a.g === b.g && a.o === b.o) ok.push("tileAt детерминирован");
  else err.push("tileAt недетерминирован!");
}

// 5. покрытие слоёв боссами
const zl = [0,1,2,3,4,5,6,7,8,9].map(z => bossesForZ(z).length);
ok.push(`Боссы по z: ${zl.join(",")}`);
if (zl[0] !== 5 || zl[1] !== 6 || zl[2] !== 5 || zl[3] !== 4 || zl[4] !== 4) err.push("Раскладка боссов по z неверна (0-4)");
if (zl[5] !== 5 || zl[6] !== 5 || zl[7] !== 4 || zl[8] !== 4 || zl[9] !== 4 + 1) err.push("Раскладка боссов по z неверна (5-9)");

console.log("==== OK ====");
ok.forEach(s => console.log(" ✓", s));
if (err.length) { console.log("==== ОШИБКИ ===="); err.forEach(s => console.log(" ✗", s)); throw new Error("FAILED"); }
console.log("==== ВСЕ ПРОВЕРКИ ПРОШЛИ ====");
