// Быстрый безголовый прогон: движок + персонажи + кинематографика (без канваса)
import { Engine } from "./src/game/engine";
import { BUILDINGS } from "./src/data/buildings";
import { PERSONA_BY_ID } from "./src/data/npcs";

const e = new Engine();
e.newGame(12345, 1, "Тестовая земля");
console.log("newGame OK, спавн:", Math.round(e.player.x), Math.round(e.player.y));

// ставим ратушу и 4 здания рядом, основываем город
let uid = 1;
const mk = (def: string, tx: number, ty: number) => {
  const b = { uid: uid++, def, tx, ty, progress: BUILDINGS[def].buildTime, done: true, store: 0, prodT: 0 };
  e.buildings.push(b as never);
  e["bIndex"].set(`${tx},${ty}`, b as never);
  return b;
};
const px = Math.floor(e.player.x / 40), py = Math.floor(e.player.y / 40);
mk("ratusha", px + 2, py);
mk("dom", px - 4, py + 2);
mk("dom", px - 4, py - 2);
mk("taverna", px + 4, py + 4);
mk("rynok", px + 4, py - 4);
mk("hram", px - 2, py + 6);
mk("koster", px + 1, py - 2);
mk("kuznica", px + 6, py);
mk("kazarmy", px - 6, py);
const ok = e.city.found(e, "Пробный Град");
console.log("Город основан:", ok);

// персонажи должны появиться
e.personae.dayTick(e);
const personas = e.npcs.npcs.filter((n) => n.persona);
console.log("Именных на улицах:", personas.length, personas.length >= 28 ? "OK" : "FAIL");

// крутим время: час за цикл, 3 игровых часа шагами по минуте
let err: unknown = null;
try {
  for (let i = 0; i < 720 * 3; i++) e.update(0.03); // ~21.6 игр. минут? нет: dt 0.03с реального; время игры: 0.03/720 суток
} catch (ex) { err = ex; }
console.log("update 3 реал-мин прогнан:", err ? `FAIL ${err}` : "OK");

// тикаем дни: гости, праздники
for (let d = 0; d < 5; d++) {
  e.day += 1;
  e.onNewDay();
  for (let i = 0; i < 400; i++) e.update(0.03);
}
const guests = e.npcs.npcs.filter((n) => n.persona && !PERSONA_BY_ID[n.persona!]);
console.log("дней прожито OK; persona-npc всего:", personas.length, "неизвестных id:", guests.length);

// диалог/подарок/брак
const taras = e.npcs.npcs.find((n) => n.persona === "taras");
if (taras) {
  e.activeNpc = taras;
  const d1 = e.personae.dialog(e, taras);
  console.log("dialog:", d1.tier, "lines:", d1.lines.length);
  e.give("zhel_slitok", 2, true);
  const g = e.personae.gift(e, taras, "zhel_slitok");
  console.log("gift:", g.kind, "| f:", e.personae.bond("taras").f);
  const bond = e.personae.bond("taras");
  bond.h = 85;
  const yes = e.personae.propose(e, taras);
  console.log("propose:", yes.startsWith("Да") ? "OK" : "FAIL", "| событие:", e.cine.event?.id ?? "нет");
}

// сцены: форсируем
e.stats.killed = 1;
e.cine.update(e, 1);
console.log("first_battle сцена:", e.cine.scene?.id ?? "FAIL");
e.cine.skip(e);
console.log("skip OK, timeScale:", e.timeScale);

// сериализация и загрузка
const s = e.serialize();
const e2 = new Engine();
e2.applySave(s);
console.log("save/load OK; bonds:", Object.keys(e2.personae.bonds).length, "seen:", [...e2.cine.seen].join(","));
const p2 = e2.npcs.npcs.filter((n) => n.persona).length;
console.log("после загрузки persona-npc:", p2);
console.log("ГОТОВО");
