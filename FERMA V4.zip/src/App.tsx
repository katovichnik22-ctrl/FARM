import { useEffect, useRef, useState } from "react";
import { Engine } from "./game/engine";
import { useEngineSnap } from "./lib/hooks";
import { getMuted, loadSlotAsync } from "./lib/save";
import { snd } from "./lib/sound";
import type { SaveData } from "./types";
import type { GameMode } from "./types/meta";
import { deleteSlot } from "./lib/save";
import { GameCanvas } from "./components/GameCanvas";
import { HUD } from "./components/HUD";
import { Minimap } from "./components/Minimap";
import { Toasts } from "./components/Toasts";
import { BottomBar, type PanelId } from "./components/BottomBar";
import { Inventory } from "./components/Inventory";
import { CraftMenu } from "./components/CraftMenu";
import { BuildMenu, BuildBar } from "./components/BuildMenu";
import { ContextMenu } from "./components/ContextMenu";
import { Tutorial } from "./components/Tutorial";
import { MainMenu } from "./components/MainMenu";
import { GameMenu } from "./components/GameMenu";
import { CityPanel } from "./components/CityPanel";
import { EconomyPanel } from "./components/EconomyPanel";
import { RealmPanel } from "./components/RealmPanel";
import { NpcDialog, BuildingInfo } from "./components/CityDialogs";
import { ArmyPanel } from "./components/ArmyPanel";
import { DiplomacyPanel } from "./components/DiplomacyPanel";
import { BattleView, BattlePrompt } from "./components/BattleView";
import { TechPanel } from "./components/TechPanel";
import { MagicPanel } from "./components/MagicPanel";
import { FaithPanel } from "./components/FaithPanel";
import { LayerPanel } from "./components/LayerPanel";
import { QuestPanel, ChoiceModal } from "./components/QuestPanel";
import { LegacyPanel } from "./components/LegacyPanel";
import { CutsceneOverlay } from "./components/CutsceneOverlay";
import { Skull } from "lucide-react";

export default function App() {
  const [screen, setScreen] = useState<"menu" | "game">("menu");
  const engineRef = useRef<Engine | null>(null);
  const [engineState, setEngineState] = useState<Engine | null>(null);
  const [panel, setPanel] = useState<PanelId>(null);
  const [ctxOpts, setCtxOpts] = useState<{ label: string; act: string }[] | null>(null);
  const snap = useEngineSnap(engineState);

  const boot = (e: Engine) => {
    snd.muted = getMuted();
    e.onOpenPanel = (p) => setPanel((p === "" ? null : p) as PanelId);
    engineRef.current = e;
    setEngineState(e);
    setScreen("game");
  };

  const startNew = (slot: number, seed: number, name: string, mode: GameMode = "normal") => {
    const e = new Engine();
    e.mode = mode;
    e.newGame(seed, slot, name);
    e.save(true);
    boot(e);
  };

  const continueGame = async (slot: number) => {
    const e = new Engine();
    const d = await loadSlotAsync(slot);
    if (d) { e.applySave(d); boot(e); }
  };

  const importGame = (d: SaveData) => {
    const e = new Engine();
    e.applySave(d);
    e.save(true);
    boot(e);
  };

  // пауза при скрытой вкладке / открытом меню
  useEffect(() => {
    if (!engineState) return;
    engineState.paused = panel === "menu";
  }, [engineState, panel]);
  useEffect(() => {
    const vis = () => {
      if (engineRef.current) {
        engineRef.current.paused = document.hidden || panel === "menu";
        if (document.hidden && screen === "game") engineRef.current.save(true);
      }
    };
    document.addEventListener("visibilitychange", vis);
    return () => document.removeEventListener("visibilitychange", vis);
  }, [engineRef, panel, screen]);

  if (screen === "menu" || !engineState || !snap) {
    return <MainMenu onStart={startNew} onContinue={(s) => void continueGame(s)} onImport={importGame} />;
  }

  const engine = engineState;

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#171219]">
      <GameCanvas engine={engine} onContext={setCtxOpts} />
      <HUD engine={engine} snap={snap} />
      <Minimap engine={engine} snap={snap} />
      <Toasts engine={engine} />
      <Tutorial engine={engine} snap={snap} />
      <BottomBar engine={engine} snap={snap} panel={panel} setPanel={setPanel} />
      <BuildBar engine={engine} snap={snap} />

      {panel === "inv" && <Inventory engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "craft" && <CraftMenu engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "build" && <BuildMenu engine={engine} onClose={() => setPanel(null)} />}
      {panel === "city" && <CityPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "econ" && <EconomyPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "dyn" && <RealmPanel engine={engine} snap={snap} onClose={() => setPanel(null)} startTab="Род" />}
      {panel === "parl" && <RealmPanel engine={engine} snap={snap} onClose={() => setPanel(null)} startTab="Парламент" />}
      {panel === "npc" && <NpcDialog engine={engine} onClose={() => { engine.activeNpc = null; setPanel(null); }} />}
      {panel === "binfo" && <BuildingInfo engine={engine} onClose={() => { engine.activeBuilding = null; setPanel(null); }} />}
      {panel === "army" && <ArmyPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "diplo" && <DiplomacyPanel engine={engine} snap={snap} onClose={() => { engine.activeNation = null; setPanel(null); }} />}
      {panel === "tech" && <TechPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "magic" && <MagicPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "faith" && <FaithPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "layers" && <LayerPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "quests" && <QuestPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {panel === "legacy" && <LegacyPanel engine={engine} snap={snap} onClose={() => setPanel(null)} />}
      {(panel === "choice" || snap.pendingChoice) && <ChoiceModal engine={engine} onClose={() => setPanel(null)} />}
      {panel === "battleStart" && <BattlePrompt engine={engine} onClose={() => setPanel(null)} />}
      {(panel === "battle" || (snap.battleActive && panel !== "battleStart")) && (
        <BattleView engine={engine} snap={snap} onClose={() => setPanel(null)} />
      )}
      {panel === "menu" && (
        <GameMenu
          engine={engine}
          snap={snap}
          onClose={() => setPanel(null)}
          onExit={() => { setPanel(null); setScreen("menu"); setEngineState(null); engineRef.current = null; }}
        />
      )}
      {ctxOpts && <ContextMenu engine={engine} opts={ctxOpts} onClose={() => setCtxOpts(null)} />}

      {/* Кинематографика: титры сцен и баннеры мировых событий */}
      <CutsceneOverlay engine={engine} />

      {/* Экран гибели */}
      {snap.playerDead && (
        <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black/70 backdrop-blur-sm">
          <div className="glass mx-4 flex w-full max-w-xs flex-col items-center p-6 text-center">
            <div className="mb-2 flex h-14 w-14 items-center justify-center rounded-full bg-rose-500/15">
              <Skull size={30} className="text-rose-300" />
            </div>
            {snap.hardcoreDeath ? (
              <>
                <h2 className="font-display text-2xl font-bold text-rose-100">Конец пути</h2>
                <p className="mt-2 text-[13px] leading-relaxed text-white/55">
                  Хардкор не прощает. Этот мир погас навсегда — но звёзды, достижения и коллекция остались с вами.
                </p>
                <div className="mt-2 rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-[12px] text-white/60">
                  Прожито дней: <b className="text-amber-200">{snap.day}</b> · уровень <b className="text-amber-200">{snap.level}</b> · рейтинг <b className="text-amber-200">{snap.rating}</b>
                </div>
                <button className="btn mt-4 w-full !py-3" onClick={() => {
                  deleteSlot(engine.slot);
                  setPanel(null); setScreen("menu"); setEngineState(null); engineRef.current = null;
                }}>
                  Принять судьбу
                </button>
              </>
            ) : (
              <>
                <h2 className="font-display text-2xl font-bold text-rose-100">Тьма забрала вас</h2>
                <p className="mt-2 text-[13px] leading-relaxed text-white/55">
                  Часть добра осталась лежать в пыли. Но пламя не гаснет — путник очнётся у родного порога.
                </p>
                <button className="btn mt-4 w-full !py-3" onClick={() => engine.respawn()}>
                  Очнуться у порога
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
