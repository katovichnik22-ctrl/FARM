import { G, O, Biome } from "../types";
import { hash2, fbm } from "../lib/noise";
import { ANOMALIES, type AnomalyZone } from "../data/anomalies";
// Циклический импорт (worldgen ↔ anomalies) безопасен: функции вызываются
// только во время генерации, а не при инициализации модулей.
import { objMaxHp, ZONE_STEP, inArena } from "./worldgen";

// =====================================================================
//  АНОМАЛЬНЫЕ СТРУКТУРЫ МИРА (этап 8)
//  Каждая из 12 зон — уникальная детерминированная структура: центр,
//  площадка, кольца и рассыпь строятся чистой функцией от сида.
//  В сердце структуры стоит древний сундук с легендарной находкой.
// =====================================================================

export interface TileInfoLike { g: number; o: number; hp: number }
const mk = (g: number, o: number): TileInfoLike => ({ g, o, hp: objMaxHp(o as 0) });

/** Числовая соль из строки id (детерминированная) */
function saltOf(id: string): number {
  let h = 7;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  return h >>> 0;
}

/** Зеркало worldgen.heightN — нужно, чтобы не тянуть цикл на уровень сида */
function heightLocal(seed: number, x: number, y: number): number {
  return fbm((seed ^ 0x1a2b3c) | 0, x / 420, y / 420, 4);
}

/** Детерминированный центр аномалии (в тайлах) */
export function anomalyCenter(seed: number, zoneId: string): { x: number; y: number } {
  const zone = ANOMALIES.find((z) => z.id === zoneId);
  const s = saltOf(zoneId);
  if (!zone) return { x: 0, y: 0 };
  if (zone.z === 0) {
    // на поверхности: глубоко в мир (зоны 2-4) и обязательно на суше
    const baseR = ZONE_STEP * (zoneId === "arena_drevnih" ? 3.2 : 2.4);
    let ang = hash2(seed ^ s, 311, 17) * Math.PI * 2;
    for (let i = 0; i < 14; i++) {
      const cx = Math.round(Math.cos(ang) * baseR);
      const cy = Math.round(Math.sin(ang) * baseR);
      if (heightLocal(seed, cx, cy) > 0.37) return { x: cx, y: cy };
      ang += 2.39996; // золотой угол — пробуем следующую дугу
    }
    const ang0 = hash2(seed ^ s, 311, 17) * Math.PI * 2;
    return { x: Math.round(Math.cos(ang0) * baseR), y: Math.round(Math.sin(ang0) * baseR) };
  }
  // на слоях: 52-96 тайлов от точки входа (за чертой пробуждения боссов)
  const ang = hash2(seed ^ s, 177, 29) * Math.PI * 2;
  const dist = 52 + hash2(seed ^ s, 881, 43) * 44;
  return { x: Math.round(Math.cos(ang) * dist), y: Math.round(Math.sin(ang) * dist) };
}

export interface AnomalyHit { zone: AnomalyZone; dx: number; dy: number; dist: number; heart: boolean }

/** Какая аномалия (если есть) накрывает тайл в слое z */
export function anomalyAt(seed: number, tx: number, ty: number, z: number): AnomalyHit | null {
  for (const zone of ANOMALIES) {
    if (zone.z !== z) continue;
    const c = anomalyCenter(seed, zone.id);
    const dx = tx - c.x, dy = ty - c.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) > zone.radius + 2) continue; // быстрый отсев
    const dist = Math.hypot(dx, dy);
    if (dist > zone.radius) continue;
    return { zone, dx, dy, dist, heart: dist < 0.5 };
  }
  return null;
}

/** Сердце аномалии: здесь лежит легендарная находка */
export function anomalyHeartAt(seed: number, tx: number, ty: number, z: number): AnomalyZone | null {
  const h = anomalyAt(seed, tx, ty, z);
  return h && h.heart ? h.zone : null;
}

// ---------------------------------------------------------------------
//  РАСКЛАДКИ СТРУКТУР
// ---------------------------------------------------------------------
function layout(seed: number, hit: AnomalyHit, tx: number, ty: number): TileInfoLike | null {
  const { zone, dx, dy, dist } = hit;
  const s = saltOf(zone.id);
  const jr = hash2(seed ^ s ^ 0xa1, tx * 3 + 11, ty * 7 + 5);   // дрожь рассыпи
  const ang = Math.atan2(dy, dx);
  const sec = Math.floor(((ang + Math.PI) / (Math.PI * 2)) * 8); // 8 секторов

  // сердце — всегда древний сундук с находкой
  if (hit.heart) {
    const heartGround: Record<string, number> = {
      zab_laba: G.MetalFloor, alien_ship: G.VoidFloor, cursed_village: G.Stone,
      sanctuary: G.SkyGrass, rift: G.VoidFloor, titan_graveyard: G.Obsidian,
      sunken_city: G.CoralBed, flying_island: G.SkyGrass, crystal_cave: G.CaveFloor,
      forgotten_library: G.ShadowGround, arena_drevnih: G.Stone, temple_stihii: G.DreamGround,
    };
    return mk(heartGround[zone.id] ?? G.Stone, O.RuinChest);
  }

  switch (zone.id) {
    case "zab_laba": { // Заброшенная лаборатория: металлическая площадка и рёбра механизмов
      if (dist > 7.2) return null;
      if (dist > 5.2) return dist < 5.9 && jr < 0.42 ? mk(G.MetalFloor, O.Mechanism) : mk(G.MetalFloor, O.None);
      if ((sec === 0 || sec === 2 || sec === 4 || sec === 6) && dist > 3.4 && jr < 0.4) return mk(G.MetalFloor, O.AlienRelic);
      if (jr < 0.055) return mk(G.MetalFloor, O.Mechanism);
      return mk(G.MetalFloor, O.None);
    }
    case "alien_ship": { // Корабль пришельцев: эллиптический корпус в реголите
      const rr = Math.hypot(dx * 0.55, dy * 1.55);
      if (rr > 6.4) return null;
      if (rr > 5.2 && jr < 0.4) return mk(G.VoidFloor, O.Mechanism);
      if (jr < 0.085) return mk(G.VoidFloor, O.AlienRelic);
      if (jr > 0.94) return mk(G.MoonDust, O.MoonOre);
      return mk(G.VoidFloor, O.None);
    }
    case "cursed_village": { // Проклятая деревня: улицы земли, руины стен, кости
      if (dist > 8) return null;
      if (dist > 6.4) return mk(jr < 0.5 ? G.Dirt : G.Grass, O.None);
      if (dist > 5 && dist < 6.4 && jr < 0.46) return mk(G.Dirt, O.Rock);           // обрушенные стены
      if (Math.abs(dx) < 1 || Math.abs(dy) < 1) {                                     // «улицы» к сердцу
        if (jr < 0.05) return mk(G.Dirt, O.Bones);
        return mk(G.Dirt, O.None);
      }
      if (jr < 0.07) return mk(G.Dirt, O.Bones);
      if (jr < 0.14) return mk(G.Dirt, O.DeadBush);
      if (jr < 0.165 && dist > 3) return mk(G.Dirt, O.Trap);
      return mk(G.Dirt, O.None);
    }
    case "sanctuary": { // Святилище древних: колонны кристаллов вокруг алтаря
      if (dist > 7) return null;
      if (dist > 5.4 && dist < 6.6 && jr < 0.5) return mk(G.SkyGrass, O.Crystal);   // кольцо колонн
      if (jr < 0.06) return mk(G.SkyGrass, O.GlowShroom);
      if (jr > 0.93) return mk(G.SkyGrass, O.DreamFlower);
      return mk(G.SkyGrass, O.None);
    }
    case "rift": { // Разлом: мешанина миров вокруг пустоты
      if (dist > 6.4) return null;
      const mix: number[] = [G.ChaosGround, G.ShadowGround, G.DreamGround];
      const g = mix[sec % 3];
      if (dist > 4.6 && dist < 5.8 && jr < 0.42) return mk(g, O.ChaosOrb);
      if (jr < 0.07) return mk(g, O.Crystal);
      if (jr > 0.94) return mk(g, O.ShadowTree);
      return mk(g, O.None);
    }
    case "titan_graveyard": { // Кладбище титанов: холмы костей в красной породе
      if (dist > 8) return null;
      if (dist > 6.2 && jr < 0.4) return mk(G.HellRock, O.Rock);
      if (jr < 0.15) return mk(G.HellRock, O.Bones);
      if (jr > 0.965) return mk(G.HellRock, O.Adamant);
      return mk(G.HellRock, O.None);
    }
    case "sunken_city": { // Затонувший город: коралловые кварталы и упавшие башни
      if (dist > 8) return null;
      const street = ((tx % 3 + 3) % 3 === 0) || ((ty % 3 + 3) % 3 === 0);
      if (dist > 5.6 && dist < 6.8 && jr < 0.44) return mk(G.SeaFloor, O.Rock);      // руины колонн
      if (jr < 0.05) return mk(street ? G.SeaFloor : G.CoralBed, O.Wreck);
      if (street) return jr < 0.08 ? mk(G.SeaFloor, O.Pearl) : mk(G.SeaFloor, O.None);
      if (jr < 0.12) return mk(G.CoralBed, O.CoralObj);
      if (jr > 0.9) return mk(G.CoralBed, O.Seaweed);
      return mk(G.CoralBed, O.None);
    }
    case "flying_island": { // Летающий остров: клочок лета над облаками
      if (dist > 7.4) return null;
      if (dist > 6.2) return mk(G.Cloud, O.None);
      if (jr < 0.08) return mk(G.SkyGrass, O.CloudTree);
      if (jr > 0.88) return mk(G.SkyGrass, O.FlowerY);
      if (jr > 0.42 && jr < 0.455) return mk(G.SkyGrass, O.SkyCrystal);
      return mk(G.SkyGrass, O.None);
    }
    case "crystal_cave": { // Пещера кристаллов: прорубленный грот света
      if (dist > 7) return null;
      if (dist > 5 && dist < 6.4 && jr < 0.4) return mk(G.CaveFloor, O.Crystal);     // кольцо кристаллов
      if (jr < 0.13) return mk(G.CaveFloor, O.Crystal);
      if (jr > 0.88) return mk(G.CaveFloor, O.GlowShroom);
      return mk(G.CaveFloor, O.None);                                                // стены отступают
    }
    case "forgotten_library": { // Забытая библиотека: ряды стеллажей из теневых древ
      if (dist > 7.2) return null;
      const row = ((ty % 3) + 3) % 3 === 0;
      if (dist > 2 && row && jr < 0.6) return mk(G.ShadowGround, O.ShadowTree);      // стеллажи
      if (jr < 0.06) return mk(G.ShadowGround, O.Bones);
      if (jr > 0.95) return mk(G.ShadowGround, O.Crystal);
      return mk(G.ShadowGround, O.None);
    }
    case "arena_drevnih": { // Арена древних: пепельный круг, каменные трибуны
      if (dist > 8) return null;
      if (dist > 6.4 && dist < 7.6 && jr < 0.5) return mk(G.Ash, O.Rock);            // трибуны
      if (Math.abs(dist - 4.2) < 0.4 && jr < 0.5) return mk(G.Stone, O.None);        // боевая дорожка
      if (jr < 0.07) return mk(G.Ash, O.Bones);
      return mk(G.Ash, O.None);
    }
    case "temple_stihii": { // Храм четырёх стихий: четыре четверти земли
      if (dist > 7) return null;
      const quarter = sec < 2 ? G.HellRock : sec < 4 ? G.CoralBed : sec < 6 ? G.SkyGrass : G.Swamp;
      if (Math.abs(dist - 3.8) < 0.5 && jr < 0.34) return mk(quarter, O.Crystal);    // алтарное кольцо
      if (jr < 0.06) return mk(quarter, O.DreamFlower);
      return mk(quarter, O.None);
    }
    default:
      return null;
  }
}

/**
 * Накладывает аномальную структуру на тайл. Чистая функция от сида —
 * вызывается из worldgen.tileAt после базовой генерации.
 */
export function applyAnomaly(seed: number, tx: number, ty: number, z: number, base: TileInfoLike): TileInfoLike {
  const hit = anomalyAt(seed, tx, ty, z);
  if (!hit) return base;
  // ничего порядочного не ломаем: входы/выходы пещер и арена дракона неприкосновенны
  if (base.o === O.CaveIn || base.o === O.CaveOut) return base;
  if (z === 0 && inArena(seed, tx, ty)) return base;
  const laid = layout(seed, hit, tx, ty);
  if (!laid) return base;
  return laid;
}

/** поверхностный биом у точки (для UI-подсказок): зеркало worldgen.biomeAt без слоёв */
export function surfaceBiomeAt(seed: number, tx: number, ty: number): Biome {
  const h = heightLocal(seed, tx, ty);
  if (h < 0.3) return Biome.Ocean;
  if (h < 0.348) return Biome.Beach;
  if (h > 0.74) return Biome.SnowMount;
  return Biome.Meadow;
}
