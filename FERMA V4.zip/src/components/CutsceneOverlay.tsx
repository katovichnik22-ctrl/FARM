// ===== Кинематографический слой: титры сцен, баннеры событий, эффекты неба =====
import { useEffect, useState } from "react";
import type { Engine } from "../game/engine";
import { SCENE_BY_ID, EVENT_BY_ID } from "../game/cutscenes";
import {
  Activity, Skull, Crown, Heart, Flower2, Eclipse, Moon, Sparkles, PartyPopper, Rocket,
  type LucideIcon,
} from "lucide-react";

const EV_ICONS: Record<string, LucideIcon> = {
  Activity, Skull, Crown, Heart, Flower2, Eclipse, Moon, Sparkles, PartyPopper, Rocket,
};

const ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];

function useCineTick(engine: Engine) {
  const [, setTick] = useState(0);
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      setTick((t) => t + 1);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [engine]);
}

export function CutsceneOverlay({ engine }: { engine: Engine }) {
  useCineTick(engine);
  const cine = engine.cine;
  const scene = cine.scene ? SCENE_BY_ID[cine.scene.id] : null;
  const ev = cine.event ? EVENT_BY_ID[cine.event.id] : null;

  if (!scene && !ev) return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-[66] overflow-hidden">
      {/* ---- виньетка события ---- */}
      {ev?.tint && (
        <div className="absolute inset-0 transition-opacity duration-1000"
          style={{ background: `radial-gradient(ellipse at 50% 45%, transparent 30%, ${ev.tint} 130%)`, opacity: (ev.tintA ?? 0.25) * 2.2 }} />
      )}
      {/* кровавая луна: диск в небе */}
      {cine.event?.id === "krovavaya_luna" && (
        <div className="absolute right-[12%] top-[8%] h-24 w-24 rounded-full transition-all duration-1000"
          style={{ background: "radial-gradient(circle at 40% 38%, #ff6a5a, #b01c22 62%, #5a0d16)", boxShadow: "0 0 60px 22px rgba(220,40,40,0.35)" }} />
      )}
      {/* затмение: чёрный диск */}
      {cine.event?.id === "zatmenie" && (
        <div className="absolute right-[14%] top-[9%] h-24 w-24 rounded-full transition-all duration-1000"
          style={{ background: "#05060f", boxShadow: "0 0 46px 12px rgba(255,230,180,0.5), inset 0 0 22px 6px #000" }} />
      )}
      {/* метеоритный дождь */}
      {cine.event?.id === "meteor_rain" && (
        <div className="absolute inset-0">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className="cine-meteor" style={{ left: `${8 + i * 11}%`, animationDelay: `${(i * 0.9) % 4}s`, animationDuration: `${2.1 + (i % 3) * 0.7}s` }} />
          ))}
        </div>
      )}

      {/* ---- баннер события ---- */}
      {ev && !scene && (
        <EventBanner icon={EV_ICONS[ev.icon] ?? Sparkles} title={ev.name}
          text={cine.eventPhase() === 0 ? ev.banner.omen : cine.eventPhase() === 1 ? ev.banner.main : ev.banner.after}
          phase={cine.eventPhase()} extra={cine.event?.extra} tint={ev.tint} />
      )}

      {/* ---- полная сцена ---- */}
      {scene && <SceneView engine={engine} sceneId={cine.scene!.id} t={cine.scene!.t} />}
      {/* баннер события виден и под сценой (например, свадьба) */}
      {ev && scene && (
        <EventBanner icon={EV_ICONS[ev.icon] ?? Sparkles} title={ev.name}
          text={cine.eventPhase() === 0 ? ev.banner.omen : cine.eventPhase() === 1 ? ev.banner.main : ev.banner.after}
          phase={cine.eventPhase()} extra={cine.event?.extra} tint={ev.tint} small />
      )}
    </div>
  );
}

function EventBanner({ icon: Icon, title, text, phase, extra, tint, small }: {
  icon: LucideIcon; title: string; text: string; phase: 0 | 1 | 2; extra?: string; tint?: string; small?: boolean;
}) {
  return (
    <div className={`absolute left-1/2 -translate-x-1/2 ${small ? "top-3" : "top-[9%]"} cine-banner`}>
      <div className={`glass flex max-w-[86vw] items-center gap-3 border px-4 py-2.5 ${phase === 1 ? "border-white/25" : "border-white/10"}`}
        style={{ boxShadow: `0 10px 40px -12px ${tint ?? "#000"}66` }}>
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full"
          style={{ background: `${tint ?? "#888"}26`, color: tint ?? "#ffd97a" }}>
          <Icon size={18} className={phase === 1 ? "cine-icon-pulse" : undefined} />
        </div>
        <div className="min-w-0">
          <div className="font-display text-[13px] font-bold tracking-wide text-amber-50">
            {title}{extra ? <span className="text-amber-200/80"> · {extra}</span> : null}
          </div>
          <div className="text-[12px] leading-snug text-white/65">{text}</div>
        </div>
      </div>
    </div>
  );
}

function SceneView({ engine, sceneId, t }: { engine: Engine; sceneId: string; t: number }) {
  const def = SCENE_BY_ID[sceneId];
  const dur = def.dur;
  const fx = def.effects;
  const lines = def.credits;
  // заголовок: первые 1.6с; далее титры по очереди
  const headT = 1.7, tailT = 1.4;
  const bodyDur = dur - headT - tailT;
  const lineIdx = Math.min(lines.length - 1, Math.max(0, Math.floor(((t - headT) / bodyDur) * lines.length)));
  const lineT = (t - headT) - (lineIdx * bodyDur) / lines.length;
  const lineDur = bodyDur / lines.length;
  // плавность появления строки
  const lineOp = t < headT ? 0 : Math.min(1, lineT / 0.8, Math.max(0, (lineDur - lineT) / 0.8));
  const headOp = t < headT ? Math.min(1, t / 0.9, (headT - t) / 0.7) : 0;
  const barIn = Math.min(1, t / 1.1, (dur - t) / 1.2);

  return (
    <div className="absolute inset-0">
      {/* тонировка */}
      {fx.tint && <div className="absolute inset-0 transition-opacity duration-700"
        style={{ background: `radial-gradient(ellipse at 50% 42%, ${fx.tint}22 0%, ${fx.tint}${Math.round((fx.tintA ?? 0.25) * 255).toString(16).padStart(2, "0")} 100%)` }} />}
      {/* кинескопные полосы */}
      <div className="absolute inset-x-0 top-0 bg-black transition-all duration-500" style={{ height: `${barIn * 11}vh` }} />
      <div className="absolute inset-x-0 bottom-0 bg-black transition-all duration-500" style={{ height: `${barIn * 11}vh` }} />
      {/* верхний ярлык */}
      <div className="absolute inset-x-0 top-[12.5vh] flex justify-center" style={{ opacity: barIn }}>
        <div className="text-[10.5px] font-semibold uppercase tracking-[0.42em] text-amber-200/70">
          {ROMAN[def.no - 1] ?? def.no} · {def.triggerDesc}
        </div>
      </div>
      {/* заголовок */}
      <div className="absolute inset-0 flex items-center justify-center" style={{ opacity: headOp }}>
        <div className="text-center">
          <div className="font-display text-[clamp(30px,6vw,64px)] font-bold tracking-tight text-amber-50"
            style={{ textShadow: "0 4px 60px rgba(0,0,0,0.7), 0 0 24px rgba(255,220,150,0.25)" }}>
            {def.title}
          </div>
          <div className="mx-auto mt-3 h-px w-40 bg-gradient-to-r from-transparent via-amber-200/70 to-transparent" />
        </div>
      </div>
      {/* титры */}
      {t >= headT && (
        <div className="absolute inset-x-0 bottom-[15vh] flex justify-center px-6">
          <p key={lineIdx} className="cine-credit max-w-2xl text-center font-display text-[clamp(15px,2.3vw,24px)] italic leading-relaxed text-amber-50/95"
            style={{ opacity: lineOp, textShadow: "0 2px 30px rgba(0,0,0,0.85)" }}>
            {lines[lineIdx]}
          </p>
        </div>
      )}
      {/* прогресс */}
      <div className="absolute bottom-[12vh] left-1/2 h-px w-56 -translate-x-1/2 bg-white/15">
        <div className="h-px bg-amber-300/80 transition-[width] duration-200" style={{ width: `${Math.min(100, (t / dur) * 100)}%` }} />
      </div>
      {/* пропуск */}
      <button
        className="btn-ghost pointer-events-auto absolute bottom-[3vh] right-4 !py-1.5 text-[11px] opacity-70 hover:opacity-100"
        onClick={() => engine.cine.skip(engine)}
      >
        Пропустить ▸
      </button>
    </div>
  );
}
