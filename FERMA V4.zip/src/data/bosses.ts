import type { MobDef } from "../types";

// =====================================================================
//  ВЛАДЫКИ «ТИХОГО ПЛАМЕНИ» — 34 босса всех земель (этап 8)
//  Файл — только данные. Фазы, способности и арены описаны декларативно
//  (по образцу data/monsters.ts): движок использует их поведенческую
//  часть, а UI/лор — описательную. Сами стихийные механики фаз
//  реализуются отдельно поверх этих объявлений.
// =====================================================================

/** Массив миров, где обитает босс */
export type BossLayer =
  | "surface"   // Поверхность  (z 0)
  | "cave"      // Подземелье   (z 1)
  | "depths"    // Глубины      (z 2)
  | "sky"       // Небо         (z 3)
  | "ocean"     // Океан        (z 4)
  | "space"     // Космос       (z 5-6)
  | "magic"     // Магические измерения (z 7-9)
  | "final";    // Финальный босс (является на стыке миров)

/** Стихии и приёмы боссов (декларативно) */
export type BossAbility =
  | "fire" | "ice" | "summon" | "meteor" | "freeze"        // базовые пять
  | "storm" | "lightning" | "shadow" | "poison" | "drain"
  | "teleport" | "heal" | "spores" | "quake" | "void"
  | "dream" | "time" | "chaos" | "flood" | "moonlight"
  | "curse" | "swarm" | "sandstorm" | "gravity" | "scream";

export interface BossDef {
  id: string;
  /** русское имя с титулом */
  name: string;
  /** мир обитания */
  layer: BossLayer;
  /** строка: где проходит бой (будущие арены) */
  arena: string;
  /** число фаз боя (2-4) */
  phases: number;
  /** приёмы: "fire", "ice", "summon", "meteor", "freeze" … */
  abilities: BossAbility[];
  /** id уникальных предметов-трофеев (см. BOSS_TROPHIES) */
  loot: string[];
  /** id существующего спрайта-основы (drawMobBody / drawBossBody) */
  spriteBase: string;
  /** масштаб спрайта (2-4) */
  scale: number;

  // --- интеграционные поля (как у MonsterDef: мапятся в MobDef) ---
  desc: string;                 // короткий лор для коллекции/энциклопедии
  hp: number; dmg: number; speed: number; xp: number;
  tint?: string;                // перекраска базового спрайта
  flying?: boolean;             // парит над землёй/водой/пустотой
  aggroR?: number; atkR?: number; atkCd?: number;
}

// ---------------------------------------------------------------------
//  Конструктор: дефолты, чтобы записи читались легко
// ---------------------------------------------------------------------
const B = (
  id: string, name: string, layer: BossLayer,
  hp: number, dmg: number, speed: number,
  d: { arena: string; phases: number; abilities: BossAbility[]; loot: string[]; spriteBase: string; scale: number; desc: string } & Partial<BossDef>,
): BossDef => ({
  xp: Math.round(hp / 5), tint: undefined, flying: undefined,
  aggroR: 24, atkR: 2.6, atkCd: 1.4,
  id, name, layer, hp, dmg, speed, ...d,
});

// =====================================================================
//  РЕЕСТР БОССОВ (34)
// =====================================================================
export const BOSSES: BossDef[] = [
  // ==================== ПОВЕРХНОСТЬ (5) ====================
  B("wb_arkanos", "Древний дракон Арканос", "surface", 2400, 38, 2.4, {
    arena: "Пепельный круг в Краю Дракона", phases: 3,
    abilities: ["fire", "meteor", "summon"],
    loot: ["tr_serdtse_arkanosa"], spriteBase: "drakon", scale: 3.6, flying: true,
    desc: "Первый пепел мира остывает под его крыльями. Брат того дракона, что спит в арене.",
  }),
  B("wb_morteus", "Король нежити Мортеус", "surface", 1900, 34, 2.1, {
    arena: "Чёрное капище в мёртвом лесу", phases: 3,
    abilities: ["summon", "curse", "drain"],
    loot: ["tr_korona_morteusa"], spriteBase: "korol_nezhiti", scale: 2.6,
    desc: "Корона вросла в череп тысячу лет назад. Он не умирает — он вспоминает.",
  }),
  B("wb_silvana", "Ледяная королева Сильвана", "surface", 1700, 32, 2.6, {
    arena: "Замёрзшее озеро Белых гор", phases: 3,
    abilities: ["ice", "freeze", "storm"],
    loot: ["tr_sleza_silvany"], spriteBase: "ledyanaya_koroleva", scale: 2.4, flying: true,
    desc: "Её дыхание останавливает ветер, а слёзы падают алмазами.",
  }),
  B("wb_terragon", "Владыка леса Террагон", "surface", 2600, 40, 1.8, {
    arena: "Сердце вековой рощи", phases: 2,
    abilities: ["spores", "summon", "quake"],
    loot: ["tr_semya_terragona"], spriteBase: "magmit", scale: 3.2, tint: "#4f8a3c",
    desc: "Ходячая роща. Птицы гнездятся в его плечах и не знают, что горят.",
  }),
  B("wb_khalid", "Песчаный фараон Кхалид", "surface", 1800, 36, 2.2, {
    arena: "Затерянная пирамида Рыжей пустыни", phases: 3,
    abilities: ["sandstorm", "curse", "summon"],
    loot: ["tr_skarabej_khalida"], spriteBase: "skelet", scale: 2.6, tint: "#e0c060",
    desc: "Пески помнят его имя лучше, чем камни пирамиды.",
  }),

  // ==================== ПОДЗЕМЕЛЬЕ (6) ====================
  B("wb_griznok", "Король гоблинов Гризнок", "cave", 1500, 30, 2.7, {
    arena: "Тронная пещера гоблинского племени", phases: 2,
    abilities: ["summon", "swarm"],
    loot: ["tr_korona_griznoka"], spriteBase: "zombi", scale: 2.0, tint: "#7abe5a",
    aggroR: 22, atkCd: 1.1,
    desc: "Маленький, злой и невероятно богатый. Трон сбит из краденых сундуков.",
  }),
  B("wb_arahnia", "Мать пауков Арахния", "cave", 2100, 34, 2.4, {
    arena: "Сотканный провал в чреве земли", phases: 3,
    abilities: ["poison", "summon", "swarm"],
    loot: ["tr_zhvala_arahnii"], spriteBase: "pauk", scale: 2.8, tint: "#6a2a78",
    desc: "Все пауки мира — её дети. Она помнит каждую разодранную паутину.",
  }),
  B("wb_golemus", "Каменный титан Големус", "cave", 3100, 44, 1.5, {
    arena: "Гранитный зал Старых Рудников", phases: 2,
    abilities: ["quake", "summon"],
    loot: ["tr_yadro_golemusa"], spriteBase: "magmit", scale: 3.4, tint: "#8a9099",
    aggroR: 20, atkR: 2.8, atkCd: 1.7,
    desc: "Гора, которой надоело лежать. Встаёт раз в тысячу лет.",
  }),
  B("wb_grindkor", "Пожиратель руды Гриндкор", "cave", 2400, 38, 2.0, {
    arena: "Золотые жилы Глубокой шахты", phases: 2,
    abilities: ["quake", "drain"],
    loot: ["tr_zub_grindkora"], spriteBase: "kriper", scale: 2.6, tint: "#b08442",
    desc: "Прогрыз горы от края до края. Его зубы — чистое золото.",
  }),
  B("wb_kristallos", "Кристальный страж Кристаллос", "cave", 2600, 40, 2.2, {
    arena: "Пещера кристаллов", phases: 3,
    abilities: ["lightning", "freeze", "summon"],
    loot: ["tr_prizma_kristallosa"], spriteBase: "prizrak", scale: 2.6, tint: "#8ae8ff", flying: true,
    desc: "Рождён светом, запертой в камне. Светится собственной болью.",
  }),
  B("wb_skolopendr", "Древний червь Сколопендр", "cave", 2800, 42, 2.3, {
    arena: "Червоточина под Волчьими Тропами", phases: 3,
    abilities: ["quake", "poison", "summon"],
    loot: ["tr_hitin_skolopendra"], spriteBase: "sliz", scale: 3.2, tint: "#c25a4a",
    desc: "Рыл эти туннели, когда поверхность ещё была морем.",
  }),

  // ==================== ГЛУБИНЫ (5) ====================
  B("wb_ignis", "Повелитель лавы Игнис", "depths", 3200, 46, 2.1, {
    arena: "Озеро магмы у первого лифта", phases: 3,
    abilities: ["fire", "meteor", "summon"],
    loot: ["tr_zhar_ignisa"], spriteBase: "vladyka_lavy", scale: 3.2,
    desc: "Сердце глубин бьётся в его груди. Он и есть глубины.",
  }),
  B("wb_lilit", "Королева суккубов Лилит", "depths", 2600, 40, 2.6, {
    arena: "Обсидиановый будуар за реками огня", phases: 3,
    abilities: ["drain", "curse", "dream"],
    loot: ["tr_potzeluy_lilit"], spriteBase: "rusalka", scale: 2.2, tint: "#e04a7a", flying: true,
    aggroR: 26, atkCd: 1.2,
    desc: "Крадёт не жизнь — желание жить. Возвращает изменить не может.",
  }),
  B("wb_helforg", "Демон-кузнец Хелфордж", "depths", 3000, 48, 2.0, {
    arena: "Пылающая кузница адского пламени", phases: 2,
    abilities: ["fire", "quake", "summon"],
    loot: ["tr_molot_helforga"], spriteBase: "magmit", scale: 2.8, tint: "#c23a2a",
    desc: "Ковал оружие богам и всадил его им же в спину.",
  }),
  B("wb_abiss", "Владыка бездны Абисс", "depths", 3600, 52, 2.4, {
    arena: "Чёрный провал под миром теней", phases: 4,
    abilities: ["void", "shadow", "drain", "summon"],
    loot: ["tr_glaz_abissa"], spriteBase: "vladyka_bezdny", scale: 3.0,
    desc: "Смотрит в вас — и вы смотрите в себя тем же взглядом.",
  }),
  B("wb_cerber", "Адский цербер Церберус", "depths", 2800, 44, 2.9, {
    arena: "Врата преисподней", phases: 2,
    abilities: ["fire", "summon", "swarm"],
    loot: ["tr_klyk_cerbera"], spriteBase: "kaban", scale: 3.0, tint: "#5a2a2a",
    desc: "Три головы — три голода. Ни одна не спит одновременно с другой.",
  }),

  // ==================== НЕБО (4) ====================
  B("wb_aeros", "Грифон-титан Аэрос", "sky", 3400, 46, 3.0, {
    arena: "Ржавое гнездо на краю неба", phases: 3,
    abilities: ["storm", "lightning", "summon"],
    loot: ["tr_pero_aerosa"], spriteBase: "grifon", scale: 3.2, flying: true,
    desc: "Отец всех грифонов. Его крыло закрывает солнце целиком.",
  }),
  B("wb_garpiya", "Леди-птица Гарпия", "sky", 2800, 42, 3.2, {
    arena: "Гнездо над облачным морем", phases: 2,
    abilities: ["storm", "scream", "swarm"],
    loot: ["tr_serga_garpii"], spriteBase: "rusalka", scale: 2.4, tint: "#e8c85a", flying: true,
    aggroR: 26, atkCd: 1.1,
    desc: "Её песня слышна за три дня лёта. Выжившие не могут её забыть.",
  }),
  B("wb_leviafan", "Небесный кит Левиафан", "sky", 4200, 50, 2.2, {
    arena: "Облачное море", phases: 3,
    abilities: ["storm", "flood", "summon"],
    loot: ["tr_us_leviafana"], spriteBase: "murena", scale: 3.8, tint: "#a8d8f0", flying: true,
    aggroR: 28,
    desc: "Плывёт над миром с первого дня творения. Облака — его след.",
  }),
  B("wb_lucifer", "Ангел-отступник Люцифер", "sky", 3600, 52, 2.7, {
    arena: "Павший собор на пустом острове", phases: 4,
    abilities: ["fire", "lightning", "drain", "curse"],
    loot: ["tr_nimb_lyutsifera"], spriteBase: "prizrak", scale: 2.6, tint: "#ffd97a", flying: true,
    desc: "Нёс свет и уронил его. Теперь несёт только ожоги.",
  }),

  // ==================== ОКЕАН (4) ====================
  B("wb_triton", "Кракен-владыка Тритон", "ocean", 3800, 50, 2.3, {
    arena: "Водоворот у Коралловых садов", phases: 3,
    abilities: ["flood", "summon", "quake"],
    loot: ["tr_trezubets_tritona"], spriteBase: "kraken", scale: 3.6, flying: true,
    desc: "Топил флоты до того, как их построили. Море — его аквариум.",
  }),
  B("wb_amfitrita", "Королева сирен Амфитрита", "ocean", 3000, 44, 2.7, {
    arena: "Поющие рифы", phases: 3,
    abilities: ["scream", "dream", "drain"],
    loot: ["tr_rakovina_amfitrity"], spriteBase: "rusalka", scale: 2.4, tint: "#4ae8b0", flying: true,
    desc: "Голос, ради которого капитаны жгли карты и вели корабли на скалы.",
  }),
  B("wb_neptun", "Морской дракон Нептун", "ocean", 3400, 48, 2.5, {
    arena: "Глубоководная впадина", phases: 3,
    abilities: ["flood", "storm", "freeze"],
    loot: ["tr_cheshuya_neptuna"], spriteBase: "drakon", scale: 3.4, tint: "#3a8ac9", flying: true,
    desc: "Змей, что обнимает землю под водой. Когда вздыхает — случаются штормы.",
  }),
  B("wb_davy", "Затонувший капитан Дейви Джонс", "ocean", 3200, 46, 2.2, {
    arena: "Трюм проклятого флагмана", phases: 3,
    abilities: ["curse", "summon", "drain"],
    loot: ["tr_kompas_davy"], spriteBase: "skelet", scale: 2.4, tint: "#4a8a7a",
    desc: "Считает души должников в сундуке. Ваша уже присчитана.",
  }),

  // ==================== КОСМОС (5) ====================
  B("wb_selena", "Лунный бог Селена", "space", 4400, 56, 2.4, {
    arena: "Кратер Тишины", phases: 3,
    abilities: ["moonlight", "freeze", "summon"],
    loot: ["tr_siyanie_seleny"], spriteBase: "lunnyi_bog", scale: 3.4, flying: true,
    desc: "Спала в кратере тысячу лет. Лунные приливы — её дыхание.",
  }),
  B("wb_ares", "Марсианский титан Арес", "space", 4800, 62, 2.2, {
    arena: "Каналы древней войны", phases: 3,
    abilities: ["quake", "meteor", "fire"],
    loot: ["tr_kopyo_aresa"], spriteBase: "marsianin", scale: 3.0, tint: "#ff5a3a",
    aggroR: 28, atkCd: 1.3,
    desc: "Последний пехотинец войны, которую никто не объявлял.",
  }),
  B("wb_ktulhu", "Космический ужас Ктулху", "space", 5600, 64, 2.5, {
    arena: "Звёздный склеп за орбитой", phases: 4,
    abilities: ["void", "dream", "summon", "gravity"],
    loot: ["tr_shchupaltse_ktulhu"], spriteBase: "kosmouzhas", scale: 3.8, flying: true,
    desc: "У него нет формы — только голод и направление.",
  }),
  B("wb_zenon", "Инопланетный король Зенон", "space", 4600, 58, 2.6, {
    arena: "Зал тысячи солнц", phases: 3,
    abilities: ["lightning", "teleport", "summon"],
    loot: ["tr_skipetr_zenona"], spriteBase: "lunnyi_prizrak", scale: 2.6, tint: "#5fe8c0", flying: true,
    desc: "Правит галактикой, о которой вы не знаете. Ещё недавно не знал и о вас.",
  }),
  B("wb_singul", "Чёрная дыра Сингулярность", "space", 6800, 70, 2.3, {
    arena: "Горизонт событий", phases: 4,
    abilities: ["gravity", "void", "drain", "summon"],
    loot: ["tr_yadro_singul"], spriteBase: "koshmar", scale: 2.8, tint: "#2a1840", flying: true,
    aggroR: 30,
    desc: "Не существо — место, где существо не может быть. И оно злится.",
  }),

  // ==================== МАГИЧЕСКИЕ ИЗМЕРЕНИЯ (4) ====================
  B("wb_umbra", "Повелитель теней Умбра", "magic", 5400, 60, 2.9, {
    arena: "Изнанка мира", phases: 3,
    abilities: ["shadow", "drain", "teleport"],
    loot: ["tr_klinok_umbry"], spriteBase: "ten_ohotnik", scale: 2.6, tint: "#4a3a6a",
    aggroR: 28, atkCd: 1.1,
    desc: "Ваша тень рассказала ему о вас всё. Он пришёл за подробностями.",
  }),
  B("wb_morfei", "Владыка снов Морфей", "magic", 5000, 56, 2.4, {
    arena: "Холм из мыслей, что сбывается", phases: 3,
    abilities: ["dream", "teleport", "curse"],
    loot: ["tr_pyl_morfei"], spriteBase: "koshmar", scale: 2.8, tint: "#e08ac9", flying: true,
    desc: "Знает, что вам снилось прошлой ночью. И почему вы проснулись.",
  }),
  B("wb_diskord", "Король хаоса Дискорд", "magic", 6200, 68, 2.8, {
    arena: "Разлом правил", phases: 4,
    abilities: ["chaos", "summon", "teleport", "meteor"],
    loot: ["tr_kubik_diskorda"], spriteBase: "haoszver", scale: 3.2,
    aggroR: 30, atkCd: 1.1,
    desc: "Каждую секунду другой. Ненавидит закономерности — включая вашу победу.",
  }),
  B("wb_hronos", "Хранитель времени Хронос", "magic", 5800, 62, 2.5, {
    arena: "Башня часов на стыке минут", phases: 4,
    abilities: ["time", "freeze", "lightning", "heal"],
    loot: ["tr_pesok_hronosa"], spriteBase: "prizrak", scale: 2.9, tint: "#c9a227",
    desc: "Уже видел этот бой. Вы проиграли сто сорок восемь раз из ста пятидесяти.",
  }),

  // ==================== ФИНАЛЬНЫЙ (1) ====================
  B("wb_absolut", "Древний бог Абсолют", "final", 16000, 90, 2.6, {
    arena: "Трон на краю всего сущего", phases: 4,
    abilities: ["fire", "ice", "summon", "meteor", "freeze", "void", "time", "chaos"],
    loot: ["tr_iskra_absolyuta"], spriteBase: "haos_avatar", scale: 4.0, flying: true,
    aggroR: 32, atkR: 3.2, atkCd: 1.1,
    desc: "Всё, что было, и всё, что будет. Финальная запятая вашей летописи.",
  }),
];

export const BOSS_BY_ID: Record<string, BossDef> = Object.fromEntries(BOSSES.map((b) => [b.id, b]));

// =====================================================================
//  УНИКАЛЬНЫЕ ТРОФЕИ (loot) — регистрируются в предметы через items.ts
// =====================================================================
export interface TrophyDef { id: string; name: string; desc: string; icon: string }

export const BOSS_TROPHIES: TrophyDef[] = [
  { id: "tr_serdtse_arkanosa", name: "Сердце Арканоса", desc: "Пылает, не обжигая. Драконья гроза спит внутри.", icon: "Flame" },
  { id: "tr_korona_morteusa", name: "Корона Мортеуса", desc: "Холодное золото, вросшее в память о троне.", icon: "Crown" },
  { id: "tr_sleza_silvany", name: "Слеза Сильваны", desc: "Алмаз, что никогда не тает. Внутри — маленькая метель.", icon: "Snowflake" },
  { id: "tr_semya_terragona", name: "Семя Террагона", desc: "Посаженное в добрую землю, поднимет рощу за один год.", icon: "Sprout" },
  { id: "tr_skarabej_khalida", name: "Скарабей Кхалида", desc: "Золотой жук с сердцем из солнечного камня.", icon: "Shapes" },
  { id: "tr_korona_griznoka", name: "Стеклянная корона Гризнока", desc: "Гоблинская вершина ювелирной мысли. Очень колючая.", icon: "Crown" },
  { id: "tr_zhvala_arahnii", name: "Жвала Арахнии", desc: "Отсюда шла вся паутина мира. Ещё чуть липкие.", icon: "Bone" },
  { id: "tr_yadro_golemusa", name: "Ядро Големуса", desc: "Валун, который думал. Теперь думает о вас.", icon: "Mountain" },
  { id: "tr_zub_grindkora", name: "Золотой зуб Гриндкора", desc: "Прогрызенная им дорога уходит через полмира.", icon: "Gem" },
  { id: "tr_prizma_kristallosa", name: "Призма Кристаллоса", desc: "Светит всеми цветами, которых у мира ещё нет.", icon: "Sparkles" },
  { id: "tr_hitin_skolopendra", name: "Хитин Сколопендра", desc: "Панцирная пластина, не берущая кислотой и временем.", icon: "Shell" },
  { id: "tr_zhar_ignisa", name: "Жар-камень Игниса", desc: "Кусочек сердца глубин. Тлеет тысячу лет.", icon: "FlameKindling" },
  { id: "tr_potzeluy_lilit", name: "Поцелуй Лилит", desc: "Невидимый на губах, вечный в памяти.", icon: "VenetianMask" },
  { id: "tr_molot_helforga", name: "Молот Хелфорджа", desc: "Им ковали оружие богов. Рабочий инструмент.", icon: "Hammer" },
  { id: "tr_glaz_abissa", name: "Глаз Абисса", desc: "Смотрит на вас даже в кармане. Привыкайте.", icon: "Eye" },
  { id: "tr_klyk_cerbera", name: "Клык Цербера", desc: "Средней головы. Две другие рычат до сих пор.", icon: "Bone" },
  { id: "tr_pero_aerosa", name: "Перо Аэроса", desc: "Одно перо — как целое крыло. Весит как меч.", icon: "Feather" },
  { id: "tr_serga_garpii", name: "Серьга Гарпии", desc: "Слегка звенит, когда рядом песня.", icon: "Gem" },
  { id: "tr_us_leviafana", name: "Ус Левиафана", desc: "Девять шагов длиной. Тянется к облакам.", icon: "Cable" },
  { id: "tr_nimb_lyutsifera", name: "Нимб Люцифера", desc: "Тусклое кольцо света. Падает только вверх.", icon: "Sun" },
  { id: "tr_trezubets_tritona", name: "Трезубец Тритона", desc: "Каждый зубец помнит по одному потопленному флоту.", icon: "Anchor" },
  { id: "tr_rakovina_amfitrity", name: "Раковина Амфитриты", desc: "Приложите к уху — услышите голос, который нельзя забыть.", icon: "Shell" },
  { id: "tr_cheshuya_neptuna", name: "Чешуя Нептуна", desc: "Синяя как глубина. Холодит руку всегда.", icon: "Shield" },
  { id: "tr_kompas_davy", name: "Компас Дейви Джонса", desc: "Стрелка указывает на то, чего вы боитесь больше всего.", icon: "CircleDot" },
  { id: "tr_siyanie_seleny", name: "Сияние Селены", desc: "Сгусток лунного света. Ночью чуть теплее дня.", icon: "Moon" },
  { id: "tr_kopyo_aresa", name: "Копьё Ареса", desc: "Наконечник последней войны. Рыжий, как планета.", icon: "Swords" },
  { id: "tr_shchupaltse_ktulhu", name: "Щупальце Ктулху", desc: "Шевелится, если не смотреть. Не смотрите.", icon: "Shapes" },
  { id: "tr_skipetr_zenona", name: "Скипетр Зенона", desc: "Внутри — маленькая галактика. С ней всё в порядке.", icon: "Rocket" },
  { id: "tr_yadro_singul", name: "Ядро Сингулярности", desc: "Тяжелее горы. Падает в любую сторону сразу.", icon: "Infinity" },
  { id: "tr_klinok_umbry", name: "Клинок Умбры", desc: "Не отбрасывает тени. Сам её и отбрасывает.", icon: "Sword" },
  { id: "tr_pyl_morfei", name: "Пыль Морфея", desc: "Щепотка — и явь сделается мягче сна.", icon: "Sparkles" },
  { id: "tr_kubik_diskorda", name: "Кубик Дискорда", desc: "Всегда выпадает ребром. Всегда.", icon: "Zap" },
  { id: "tr_pesok_hronosa", name: "Песок Хроноса", desc: "Сыплется вверх. Не поддавайте в удивление — он этого ждёт.", icon: "Clock" },
  { id: "tr_iskra_absolyuta", name: "Искра Абсолюта", desc: "Тихое пламя всего сущего. Теперь — в ваших руках.", icon: "Sparkle" },
];
export const TROPHY_BY_ID: Record<string, TrophyDef> = Object.fromEntries(BOSS_TROPHIES.map((t) => [t.id, t]));

// =====================================================================
//  КАРТЫ СЛОЁВ МИРА → z-координаты движка
// =====================================================================
/** BossLayer → слои движка, где босс может пробудиться */
export const BOSS_LAYER_Z: Record<BossLayer, number[]> = {
  surface: [0],
  cave: [1],
  depths: [2],
  sky: [3],
  ocean: [4],
  space: [5, 6],
  magic: [7, 8, 9],
  final: [9], // Абсолют является в Мире хаоса — на стыке миров
};

/** Боссы, доступные в слое z движка */
export function bossesForZ(z: number): BossDef[] {
  return BOSSES.filter((b) => BOSS_LAYER_Z[b.layer].includes(z));
}

/** Сколько мировых владык нужно повергнуть, чтобы Абсолют открыл глаза */
export const FINAL_GATE_KILLS = 15;
/** Сколько игровых дней владыка восстанавливает силы после поражения */
export const WILD_BOSS_RESPAWN_DAYS = 3;

// =====================================================================
//  КОНВЕРТАЦИЯ В MobDef (реестр движка)
// =====================================================================
/** Золото и материалы добычи по миру обитания */
const LAYER_DROPS: Record<BossLayer, { id: string; n: number; ch: number }[]> = {
  surface: [{ id: "zoloto", n: 350, ch: 1 }, { id: "kost", n: 12, ch: 0.9 }, { id: "kristall", n: 3, ch: 0.7 }, { id: "cheshuya", n: 2, ch: 0.5 }],
  cave:    [{ id: "zoloto", n: 400, ch: 1 }, { id: "mifril", n: 4, ch: 1 }, { id: "kristall", n: 6, ch: 1 }],
  depths:  [{ id: "zoloto", n: 600, ch: 1 }, { id: "adamantit", n: 6, ch: 1 }, { id: "obsidian", n: 14, ch: 1 }],
  sky:     [{ id: "zoloto", n: 550, ch: 1 }, { id: "nebesnyi_kristall", n: 10, ch: 1 }, { id: "pero", n: 12, ch: 1 }],
  ocean:   [{ id: "zoloto", n: 650, ch: 1 }, { id: "zhemchug", n: 12, ch: 1 }, { id: "korall", n: 14, ch: 1 }],
  space:   [{ id: "zoloto", n: 900, ch: 1 }, { id: "lunnyi_kamen", n: 14, ch: 1 }, { id: "marsianit", n: 8, ch: 0.8 }, { id: "alien_tech", n: 1, ch: 0.5 }],
  magic:   [{ id: "zoloto", n: 1000, ch: 1 }, { id: "tenevaya_sut", n: 12, ch: 1 }, { id: "pyl_snov", n: 10, ch: 0.8 }, { id: "oskolok_haosa", n: 4, ch: 0.6 }],
  final:   [{ id: "zoloto", n: 4000, ch: 1 }, { id: "cheshuya", n: 10, ch: 1 }, { id: "oskolok_haosa", n: 30, ch: 1 }],
};

/** Мир обитания → режим «ночной» (в темноте слоя боссы не дремлют) */
const isDarkLayer = (l: BossLayer) => l === "cave" || l === "depths";

/** Боссы как MobDef: мощные редкие мобы с ИИ «boss» и элитной аурой */
export const BOSS_MOBS: Record<string, MobDef> = Object.fromEntries(
  BOSSES.map((b) => {
    const def: MobDef = {
      id: b.id,
      name: b.name,
      hp: b.hp, dmg: b.dmg, speed: b.speed, xp: b.xp,
      ai: "boss",
      night: isDarkLayer(b.layer) || undefined,
      cave: isDarkLayer(b.layer) || undefined,
      scale: b.scale,
      aggroR: b.aggroR ?? 24,
      atkR: b.atkR ?? 2.6,
      atkCd: b.atkCd ?? 1.4,
      flying: b.flying || undefined,
      drops: LAYER_DROPS[b.layer],
      spriteBase: b.spriteBase,
      tint: b.tint,
      elite: true,
    };
    return [b.id, def];
  }),
);

/** Краткая строка для коллекции/энциклопедии */
export function bossLoreLine(b: BossDef): string {
  return `${b.desc} Арена: ${b.arena}. Фаз: ${b.phases}. Заклятия: ${b.abilities.join(", ")}.`;
}
