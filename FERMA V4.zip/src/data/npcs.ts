// ===== Персонажи «Тихого Пламени»: именные NPC мира =====
// 28 жителей города игрока + 24 персонажа мира = 52. Доступны для брака: 34.
// spriteBase — id существующего NPC-спрайта (роль из drawNpc / NPC_ROLES).
import type { NpcRole } from "../types/city";

// ---- Характеры ----
export type NpcCharacter = "dobryi" | "vorchlivyi" | "veselyi" | "zagadochnyi" | "zloi";
export const CHARACTER_RU: Record<NpcCharacter, { name: string; color: string; icon: string }> = {
  dobryi: { name: "Добрый", color: "#7ae68a", icon: "HeartHandshake" },
  vorchlivyi: { name: "Ворчливый", color: "#f2b45c", icon: "CloudRainWind" },
  veselyi: { name: "Весёлый", color: "#ffd34d", icon: "Laugh" },
  zagadochnyi: { name: "Загадочный", color: "#a78bfa", icon: "MoonStar" },
  zloi: { name: "Злой", color: "#e05a5a", icon: "Flame" },
};

// ---- Места расписания ----
export type PersonaPlace = "home" | "work" | "square" | "tavern" | "market" | "temple" | "gate" | "port" | "wild";
export const PLACE_RU: Record<PersonaPlace, string> = {
  home: "Дом", work: "Работа", square: "Площадь", tavern: "Таверна",
  market: "Рынок", temple: "Храм", gate: "Ворота", port: "Пристань", wild: "За стеной",
};

// ---- Поселения мира ----
export type HomeId = "city" | "pristan" | "kochevya" | "kapishe" | "shahta" | "zastava" | "logovo" | "dorogi" | "top" | "vyshka_gora";
export const HOME_RU: Record<HomeId, string> = {
  city: "Ваш город", pristan: "Янтарная Пристань", kochevya: "Кочевья", kapishe: "Лесное капище",
  shahta: "Шахтёрский посёлок", zastava: "Верхняя застава", logovo: "Разбойничье логово",
  dorogi: "Большие дороги", top: "Топь", vyshka_gora: "Горная вышка",
};

// ---- Определение персонажа ----
export interface PersonaDef {
  id: string;
  name: string;
  age: number;
  sex: 0 | 1;
  profession: string;
  character: NpcCharacter;
  romance: boolean;
  spriteBase: NpcRole;
  home: HomeId;
  schedule: { morning: PersonaPlace; day: PersonaPlace; evening: PersonaPlace; night: PersonaPlace };
  likedGifts: string[];
  dislikedGifts: string[];
  problem: string;
  story: string;
  relations: Record<string, number>;
}

const sch = (morning: PersonaPlace, day: PersonaPlace, evening: PersonaPlace, night: PersonaPlace) =>
  ({ morning, day, evening, night });

// ===== ЖИТЕЛИ ГОРОДА (28) =====
const CITY: PersonaDef[] = [
  { id: "avdotya", name: "Авдотья Медовая", age: 26, sex: 1, profession: "Трактирщица", character: "veselyi", romance: true, spriteBase: "kupec", home: "city",
    schedule: sch("square", "tavern", "tavern", "home"),
    likedGifts: ["pivo", "hleb", "zharkoe", "muka"], dislikedGifts: ["gnil", "kost"],
    problem: "Пивоварня нынче пустует — хмель на корню скупили кочевники, а без эля таверна не таверна.",
    story: "Пришла с Южных трактов за компанию с обозом, да так и осталась: поняла, что люди без доброго стола — как поле без дождя.",
    relations: { taras: 1, nezhdana: 1, voivoda_rodan: -1, prokhor: 0 } },
  { id: "taras", name: "Тарас Дубинин", age: 32, sex: 0, profession: "Кузнец", character: "dobryi", romance: true, spriteBase: "remeslennik", home: "city",
    schedule: sch("work", "work", "tavern", "home"),
    likedGifts: ["zhel_slitok", "ugol", "oruzhie", "med_ruda"], dislikedGifts: ["gnil", "kost", "pero"],
    problem: "Кувалда треснула по рукояти — работе воинов нестерпимо медлить, а на новую нет златой руды.",
    story: "Отец ковал подковы, дед — мечи княжьей дружине. Тарас куёт всё подряд и втайне мечтает о клинке, который споёт.",
    relations: { avdotya: 1, ostap: 1, voivoda_rodan: 0, prorab_stog: -1 } },
  { id: "dunya", name: "Дуняша Купырка", age: 24, sex: 1, profession: "Травница", character: "zagadochnyi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("wild", "wild", "home", "home"),
    likedGifts: ["yagoda", "grib", "tkan", "zhemchug"], dislikedGifts: ["myaso", "oruzhie", "zharkoe"],
    problem: "Лунная трава, что лечит горячку, пропала со всех пригорков — будто кто-то срывает её с корнем в полнолуние.",
    story: "Говорят, её выходила сама лесная хозяйка. Дуняша не спорит — смеётся и незримо подливает отвар приходящим.",
    relations: { otets_kliment: -1, lyubava: 1, vedma_marya: 0 } },
  { id: "prokhor", name: "Прохор Теслов", age: 40, sex: 0, profession: "Плотник", character: "vorchlivyi", romance: true, spriteBase: "remeslennik", home: "city",
    schedule: sch("work", "work", "home", "home"),
    likedGifts: ["brevno", "doska", "instrument", "kozha"], dislikedGifts: ["pivo", "gnil"],
    problem: "Лес рядом с городом стал чужим: каждый третий ствол ночью кто-то подтачивает — к строю нельзя.",
    story: "Срубил тридцать домов и одну церквушку на крайнем севере. Ворчит, но работу его боги принимают без слов.",
    relations: { ratmir: -1, taras: 1, avdotya: 0 } },
  { id: "marfa", name: "Марфа Хлебина", age: 29, sex: 1, profession: "Пекарша", character: "dobryi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("work", "work", "market", "home"),
    likedGifts: ["zerno", "muka", "yagoda", "hleb"], dislikedGifts: ["gnil", "myaso"],
    problem: "Печь-матушка просела — греет вкось. Пока строят новую, подаёт лепёшки вполцены и худеет сама.",
    story: "Прибежала девчонкой из спалённой деревни, держа над головой квашню с опарой. С тех пор кормит весь город.",
    relations: { miron: 1, avdotya: 1, gonets_shcheka: 1 } },
  { id: "semyon", name: "Семён Рогач", age: 27, sex: 0, profession: "Охотник", character: "veselyi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("wild", "wild", "tavern", "home"),
    likedGifts: ["myaso", "zharkoe", "kozha", "mech_k"], dislikedGifts: ["muka", "pivo", "nit"],
    problem: "В угодья за рекой завёлся зверь, что не боится ни капкана, ни факела. Уже две собаки не вернулись.",
    story: "Убил первого кабана в десять лет и с тех пор говорит с лесом на ты. Хвастается, что дрался с медведем — врёт красиво.",
    relations: { yasenka: 0, dunya: 0, ostap: 1 } },
  { id: "vasilisa", name: "Василиса Ткачиха", age: 22, sex: 1, profession: "Ткачиха", character: "dobryi", romance: true, spriteBase: "remeslennik", home: "city",
    schedule: sch("work", "work", "home", "home"),
    likedGifts: ["nit", "tkan", "naryad", "pero"], dislikedGifts: ["kost", "ugol", "gnil"],
    problem: "Стан стар, на новые рейки нет добротного дерева, а наряды для ярмарки ждать не станут.",
    story: "Её полотно узнают на трёх трактах. Говорят, вплетает в кромку имя того, кто нравится, — но кому, никому не скажет.",
    relations: { oksana: 1, milana: 0, yaropolk: 1 } },
  { id: "gordei", name: "Гордей Глина", age: 35, sex: 0, profession: "Гончар", character: "vorchlivyi", romance: true, spriteBase: "remeslennik", home: "city",
    schedule: sch("work", "work", "tavern", "home"),
    likedGifts: ["glina", "instrument", "ugol"], dislikedGifts: ["pivo", "yagoda", "pero"],
    problem: "Печ для обжига дымит так, что соседи грозят проклятьем. Нужен новый кладочный камень, а глина уже не та.",
    story: "Сын кирпичников из пригорска. Любит, когда горшок выходит ровным, — тогда даже ворчать перестаёт на час.",
    relations: { prokhor: 0, starosta_yudin: -1 } },
  { id: "ulita", name: "Улита Плотва", age: 25, sex: 1, profession: "Рыбачка", character: "veselyi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("port", "port", "home", "home"),
    likedGifts: ["yagoda", "zhemchug", "tkan"], dislikedGifts: ["grib", "kost", "muka"],
    problem: "Лодку проломило у старых свай. На новую досок нет — ловит с берега и нынче кормит только кошек.",
    story: "Умеет читать воду, как прочие — письмена. Рассказывает, что однажды выудила ключ от подводного дворца.",
    relations: { kapitan_bronislav: 1, korable_chernysh: 0, semyon: 0 } },
  { id: "miron", name: "Мирон Жернов", age: 45, sex: 0, profession: "Мельник", character: "dobryi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("work", "work", "home", "home"),
    likedGifts: ["zerno", "muka", "hleb", "instrument"], dislikedGifts: ["gnil", "pivo"],
    problem: "Крыло мельницы тянет из стороны в сторону при ветре — как бы не спалило искрой жёрнова.",
    story: "Вдовец; поднял мельницу с пепелища вместе с городом. Тихо помогает бедным мукой — из-за этого и спорит со старостой.",
    relations: { marfa: 1, starosta_yudin: -1 } },
  { id: "oksana", name: "Оксана Нитечка", age: 30, sex: 1, profession: "Портниха", character: "veselyi", romance: true, spriteBase: "remeslennik", home: "city",
    schedule: sch("work", "work", "market", "home"),
    likedGifts: ["nit", "tkan", "naryad", "kozha"], dislikedGifts: ["myaso", "kost"],
    problem: "Игольница с бабушкиными иглами пропала на смотринах — подозревает злую зависть, а гонец врёт как дышит.",
    story: "Шила шатры для караванов и свадебное для княжны. Говорит, что игла — единственный честный человек в городе.",
    relations: { vasilisa: 1, gonets_shcheka: -1, milana: 0 } },
  { id: "ratmir", name: "Ратмир Боровой", age: 28, sex: 0, profession: "Лесоруб", character: "dobryi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("wild", "wild", "home", "home"),
    likedGifts: ["topor_k", "topor_m", "kozha", "hleb"], dislikedGifts: ["pero", "zhemchug", "naryad"],
    problem: "Артель бросило рубку у ручья — говорят, там деревья шепчут по-людски. Прохор ворчит без брёвен.",
    story: "Голосом может расколоть колокол, но поёт тихо, только в бане. Деревья валит с извинением — и никому объяснить.",
    relations: { prokhor: -1, lesnichy_bor: 0, ostap: 1 } },
  { id: "zlata", name: "Злата Камешкова", age: 33, sex: 1, profession: "Ювелир", character: "zagadochnyi", romance: true, spriteBase: "remeslennik", home: "city",
    schedule: sch("market", "work", "market", "home"),
    likedGifts: ["zoloto", "zhemchug", "ukrashenie", "nebesnyi_kristall"], dislikedGifts: ["myaso", "glina", "kost"],
    problem: "Гранёный горный хрусталь для заказа купцов исчез из обоза — либо разбойники, либо соперники из биржи.",
    story: "Никто не видел её без перчаток. Говорят, под правой — след от огня, под левой — половинка старой печати.",
    relations: { yaropolk: -1, volhv_veleslav: 0, soroka: 0 } },
  { id: "kuzma", name: "Кузьма Бортник", age: 38, sex: 0, profession: "Пчеловод", character: "vorchlivyi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("wild", "wild", "home", "home"),
    likedGifts: ["yagoda", "zerno", "instrument"], dislikedGifts: ["myaso", "pivo", "gnil"],
    problem: "Пчёлы бесятся с каждым новым холодом — роем летят на город. Винит жар-камень у старой шахты.",
    story: "С пчелами разговаривал раньше, чем с людьми. Укусов не боится: «Кто трудится, тот и жилится».",
    relations: { lyubava: 1, starosta_yudin: 0 } },
  { id: "nezhdana", name: "Неждана Гуслицкая", age: 21, sex: 1, profession: "Певица таверны", character: "veselyi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("home", "square", "tavern", "tavern"),
    likedGifts: ["pivo", "pero", "tkan", "yagoda_zhar"], dislikedGifts: ["gnil", "kost"],
    problem: "Гусли разбил пьяный наездник. Новые струны стоят дорого, а голос без струн — только половина чуда.",
    story: "Приблудная: нашлась в корзине у таверны, где и выросла. Песни её длиннее дорог, и все — с выдумкой.",
    relations: { avdotya: 1, guslyar: 0, voivoda_rodan: -1 } },
  { id: "feofan", name: "Феофан Скоропись", age: 50, sex: 0, profession: "Писец ратуши", character: "vorchlivyi", romance: true, spriteBase: "uchenyi", home: "city",
    schedule: sch("square", "work", "home", "home"),
    likedGifts: ["pero", "ukrashenie", "zerno"], dislikedGifts: ["myaso", "pivo", "gnil"],
    problem: "Грамота о городской меже куда-то делась, а без неё соседи приберут лучший луг. Подозревает покупателя.",
    story: "Из дьяков княжьей казны; бежал от интриги, переписавшись сам. Кропотлив как муравей и честен как зеркало.",
    relations: { starosta_yudin: 1, aristarh: 0, gordei: -1 } },
  { id: "lyubava", name: "Любава Садовая", age: 20, sex: 1, profession: "Садовница", character: "dobryi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("work", "work", "square", "home"),
    likedGifts: ["yagoda", "zerno", "pero", "zhemchug"], dislikedGifts: ["myaso", "kost", "pivo"],
    problem: "Плодовый сад под стеной города болеет — листья чернеют изнутри, словно земля под ним стряхнула забытьё.",
    story: "Ведёт сад от прапрабабки. Помнит каждое дерево по имени; с вишней Гордевна жалеется на жизнь.",
    relations: { kuzma: 1, dunya: 1, gonets_shcheka: 1 } },
  { id: "ostap", name: "Остап Породный", age: 34, sex: 0, profession: "Шахтёр", character: "veselyi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("work", "work", "tavern", "home"),
    likedGifts: ["kirka_k", "kirka_m", "ugol", "hleb", "pivo"], dislikedGifts: ["pero", "naryad"],
    problem: "Нижний ярус шахты дышит теплом и дымом — кирки плавятся. Боится, что добудились до чего-то живого.",
    story: "Середина двадцати восьми забоев. Знал четырёх Королей-подземных и любого из них обхитрит в орлянку.",
    relations: { taras: 1, ratmir: 1, prorab_stog: -1 } },
  { id: "velimira", name: "Велимира Хлопотуха", age: 37, sex: 1, profession: "Прачка", character: "vorchlivyi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("port", "port", "home", "home"),
    likedGifts: ["nit", "yagoda", "zerno", "hleb"], dislikedGifts: ["pivo", "gnil", "kost"],
    problem: "После бури унесло корыто и половину чужого белья — придётся платить, а день рождения у снастьи под угрозой.",
    story: "Все чужие тайны в её тазах — но она молчит и поёт. Прославилась тем, что ворчит ласково даже о засранцах.",
    relations: { marfa: 0, voivoda_rodan: -1 } },
  { id: "yaropolk", name: "Ярополк Суконный", age: 31, sex: 0, profession: "Меняла-купец", character: "veselyi", romance: true, spriteBase: "kupec", home: "city",
    schedule: sch("market", "market", "tavern", "home"),
    likedGifts: ["tkan", "naryad", "ukrashenie", "zoloto"], dislikedGifts: ["gnil", "kost"],
    problem: "Караван с летним сукном застрял у волока — перепохители запросили сверху. Ни зима, ни биржа не ждут.",
    story: "Сбыл крапивное полотно за шёлк — и выжил. С тех пор верит: ртуть его крови, а ярмарка — его храм.",
    relations: { zlata: -1, vasilisa: 1, soroka: 0 } },
  { id: "radmila", name: "Радмила Кружевница", age: 26, sex: 1, profession: "Кружевница", character: "zagadochnyi", romance: true, spriteBase: "remeslennik", home: "city",
    schedule: sch("home", "work", "home", "home"),
    likedGifts: ["nit", "tkan", "pero", "zhemchug"], dislikedGifts: ["myaso", "ugol", "kost"],
    problem: "Ей заказали покрывало к бракосочетанию знати, но узор «Древо жизни» не даётся — сон снится один и тот же, тёмный.",
    story: "Пришла с заставы, где научилась паутинной вязке у одной молчаливой вдовы. Говорит, что узоры — это записанная память.",
    relations: { vasilisa: 0, nezhdana: 1, vesta: 0 } },
  { id: "bogdan", name: "Богдан Конюхов", age: 29, sex: 0, profession: "Конюх", character: "dobryi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("work", "work", "gate", "home"),
    likedGifts: ["kozha", "zerno", "hleb", "yagoda"], dislikedGifts: ["pivo", "gnil", "ukrashenie"],
    problem: "Два жеребёнка пропали из ночного. След оборван у болота — будто копыта поднялись в воздух.",
    story: "Вырезал свистульки для пастухов и плакал, когда Сивку продали кочевникам. Конский язык понимает буквально.",
    relations: { semyon: 1, lesnichy_bor: -1 } },
  { id: "mavra", name: "Мавра Свечная", age: 27, sex: 1, profession: "Свечница", character: "zagadochnyi", romance: true, spriteBase: "remeslennik", home: "city",
    schedule: sch("work", "work", "temple", "home"),
    likedGifts: ["nit", "yagoda", "pero"], dislikedGifts: ["myaso", "gnil", "kost"],
    problem: "Воск становится редкостью — дикие ульи заброшены. Без свечей и храм, и зима тёмная.",
    story: "Верит, что каждая свеча — спасённая душа. На колокольне соборного праздника впервые и увидела город целиком.",
    relations: { otets_kliment: 1, kuzma: 1, dunya: -1 } },
  { id: "milana", name: "Милана Ярмарочная", age: 23, sex: 1, profession: "Артистка театра", character: "veselyi", romance: true, spriteBase: "krestyanin", home: "city",
    schedule: sch("square", "square", "tavern", "home"),
    likedGifts: ["naryad", "ukrashenie", "pero", "pivo"], dislikedGifts: ["gnil", "kost", "kozha"],
    problem: "Подмостки перед площадью обветшали: на представлении у князя балаган может сложиться вместе с королём-героем.",
    story: "Играет и царей, и нищих — людям, говорит, нужны оба. В детстве ушла из дома за балаганом и не пожалела.",
    relations: { nezhdana: 1, oksana: 0, voivoda_rodan: -1 } },
  // ---- горожане не для брака ----
  { id: "voivoda_rodan", name: "Воевода Родан", age: 46, sex: 0, profession: "Капитан стражи", character: "zloi", romance: false, spriteBase: "strazhnik", home: "city",
    schedule: sch("gate", "work", "gate", "home"),
    likedGifts: ["oruzhie", "mech_zh", "zoloto", "zhel_slitok"], dislikedGifts: ["yagoda", "pero", "nit"],
    problem: "У стены ночью стража слышит скрёб под землёй. Станицах людей не хватает, а паника страшнее нечисти.",
    story: "За правое плечо у него бой под Кривым Рогом, за левое — долгий мир, который он ненавидит. Замок жена назвала занудным.",
    relations: { nezhdana: -1, taras: 0, sotnik_peresvet: 1, velimira: -1 } },
  { id: "otets_kliment", name: "Отец Климент", age: 58, sex: 0, profession: "Священник", character: "dobryi", romance: false, spriteBase: "svyashennik", home: "city",
    schedule: sch("temple", "temple", "temple", "home"),
    likedGifts: ["hleb", "yagoda", "pero", "zerno"], dislikedGifts: ["pivo", "oruzhie", "gnil"],
    problem: "Колокол храма треснул после недавней грозы, и звон по умершим стал хриплым. Без голоса у Божьего дома беда одна.",
    story: "Раздаёт милостыню так тихо, что бедняки думают о чуде. Знает наизусть жития и вполголоса — всех жителей города.",
    relations: { mavra: 1, dunya: -1, zhrica_dobrava: 1 } },
  { id: "starosta_yudin", name: "Староста Юдин", age: 66, sex: 0, profession: "Староста", character: "vorchlivyi", romance: false, spriteBase: "starik", home: "city",
    schedule: sch("square", "square", "home", "home"),
    likedGifts: ["pero", "zerno", "ukrashenie"], dislikedGifts: ["gnil", "myaso", "pivo"],
    problem: "Межа с соседним селом ползёт всё ближе к городу. Грамоту о земле потеряли, а сам он стар для судов.",
    story: "Помнит город стояночным лагерем. Хранит в каморке старый жезл первого воеводы — вместе с его тайной.",
    relations: { feofan: 1, prokhor: -1, miron: -1, gordei: -1 } },
  { id: "gonets_shcheka", name: "Гонец Щека", age: 9, sex: 0, profession: "Гонец-шкет", character: "veselyi", romance: false, spriteBase: "rebenok", home: "city",
    schedule: sch("square", "square", "tavern", "home"),
    likedGifts: ["yagoda", "hleb", "yagoda_zhar", "pero"], dislikedGifts: ["pivo", "myaso", "gnil"],
    problem: "Его начинают догонять стражники реже, но сам он боится подземного лаза у старой башни.",
    story: "Приблудный быстроногий: гоношится за хлеб и за сказку. Знает все переулки, норы и карты сокровищ, которых нет.",
    relations: { marfa: 1, oksana: -1, voivoda_rodan: -1 } },
];

// ===== ПЕРСОНАЖИ МИРА (24) =====
const WORLD: PersonaDef[] = [
  // Янтарная Пристань
  { id: "kapitan_bronislav", name: "Бронислав Причалов", age: 49, sex: 0, profession: "Начальник порта", character: "vorchlivyi", romance: false, spriteBase: "pirat", home: "pristan",
    schedule: sch("port", "port", "port", "home"),
    likedGifts: ["zerno", "tkan", "instrument", "zoloto"], dislikedGifts: ["gnil", "kost"],
    problem: "Форватер заилился — три купеческих корабля ревут на рейде. Ворчит, что молодёжь шумит, а не дно драит.",
    story: "Боцман флота эскадр, потерявший корабль — но не его команду. С тех пор говорит: причал надёжнее паруса.",
    relations: { ulita: 1, korable_chernysh: 1, soroka: -1 } },
  { id: "glafira", name: "Глафира Траля", age: 24, sex: 1, profession: "Рыбачка пристани", character: "veselyi", romance: true, spriteBase: "krestyanin", home: "pristan",
    schedule: sch("port", "port", "tavern", "home"),
    likedGifts: ["zhemchug", "yagoda", "pero"], dislikedGifts: ["muka", "kost", "gnil"],
    problem: "Море стало дарить всё меньше: сети приходят с ветхим грузом и одной странной чешуёй вместо рыбы.",
    story: "Лучшая проводница шхун по каменным банкам. Говорит, шторм — это просто море сердится на плохие песни.",
    relations: { ulita: 1, kapitan_bronislav: 0 } },
  { id: "korable_chernysh", name: "Черныш Корабел", age: 41, sex: 0, profession: "Корабельный мастер", character: "vorchlivyi", romance: false, spriteBase: "remeslennik", home: "pristan",
    schedule: sch("port", "port", "home", "home"),
    likedGifts: ["brevno", "doska", "instrument", "med_slitok"], dislikedGifts: ["gnil", "pivo"],
    problem: "На новую верфь не хватает смолы и добрых боковых досок, а третий сезон недосдача — только вороньё.",
    story: "Построил двенадцать посудин; утопленников из них — ни одного. Пятнисто гордится и ворчит на гвозди.",
    relations: { prokhor: 1, kapitan_bronislav: 1 } },
  { id: "soroka", name: "Сорока", age: 28, sex: 1, profession: "Контрабандистка", character: "zagadochnyi", romance: true, spriteBase: "pirat", home: "pristan",
    schedule: sch("home", "port", "tavern", "port"),
    likedGifts: ["zoloto", "ukrashenie", "pivo", "zhemchug"], dislikedGifts: ["hleb", "pero", "zerno"],
    problem: "Тайник под скалой заметили чужие глаза — нужен тихий посредник, чтобы переправить 'подарки' дальше.",
    story: "Три имени, два исчезнувших корабля и ни одной улики. Говорят, врёт всегда, кроме новолуния.",
    relations: { yaropolk: 0, zlata: 0, kapitan_bronislav: -1 } },
  { id: "mayachnik_egor", name: "Егор Светлый", age: 63, sex: 0, profession: "Маячник", character: "dobryi", romance: false, spriteBase: "starik", home: "pristan",
    schedule: sch("port", "port", "port", "port"),
    likedGifts: ["hleb", "yagoda", "ugol"], dislikedGifts: ["pivo", "naryad", "myaso"],
    problem: "Зеркало маяка побудило время: в шторм свет больше не бьёт до крайней отмели. Просить новое — стыдно.",
    story: "Сорок лет не проспал ни одной бурю. Спасённых считает внуками, всех — по именам и рассортированным по годам.",
    relations: { kapitan_bronislav: 1 } },
  // Кочевья
  { id: "ataman_kalaida", name: "Атаман Калайда", age: 44, sex: 0, profession: "Атаман кочевников", character: "veselyi", romance: false, spriteBase: "kochevnik", home: "kochevya",
    schedule: sch("gate", "gate", "tavern", "home"),
    likedGifts: ["pivo", "zharkoe", "kozha", "oruzhie"], dislikedGifts: ["gnil", "pero"],
    problem: "В степи нынче вервольф: погибли два табуна за луну. Атаман не верит, но ночью не спит — правда не верит.",
    story: "Сел на коня раньше, чем пошёл. Усмехается: «Наш дом — весь мир, а потолок — что у богов на чердаке».",
    relations: { shamanka_mava: 1, yasenka: 1, voivoda_rodan: -1 } },
  { id: "shamanka_mava", name: "Вещая Мава", age: 31, sex: 1, profession: "Шаманка", character: "zagadochnyi", romance: true, spriteBase: "kochevnik", home: "kochevya",
    schedule: sch("wild", "wild", "tavern", "home"),
    likedGifts: ["zhemchug", "pero", "yagoda", "nebesnyi_kristall"], dislikedGifts: ["myaso", "pivo", "oruzhie"],
    problem: "Духи степи молчат третью луну — как будто небо закрыли ставнями. Этого не бывало даже у её бабки.",
    story: "Слушает траву по-прежнему. Говорит, что видела вас во сне: «Ты приносишь огонь, который не жжёт».",
    relations: { ataman_kalaida: 0, volhv_veleslav: 0, vedma_marya: -1 } },
  { id: "yasenka", name: "Ясенка-Соколиха", age: 23, sex: 1, profession: "Охотница", character: "veselyi", romance: true, spriteBase: "kochevnik", home: "kochevya",
    schedule: sch("wild", "wild", "tavern", "home"),
    likedGifts: ["myaso", "zharkoe", "pero", "kozha"], dislikedGifts: ["muka", "nit", "gnil"],
    problem: "Её сокол Гром не вернулся с охоты: в степи опасно теперь даже небу. Хочет найти его сама — или с провожатым.",
    story: "Стреляет на скаку влетевшее перо. Помнит каждого зверя, которого пощадила, — всех троих.",
    relations: { semyon: 0, ataman_kalaida: 1 } },
  { id: "guslyar", name: "Гусляр", age: 30, sex: 0, profession: "Странствующий песенник", character: "veselyi", romance: true, spriteBase: "strannik", home: "dorogi",
    schedule: sch("square", "tavern", "tavern", "tavern"),
    likedGifts: ["pivo", "yagoda_zhar", "pero", "hleb"], dislikedGifts: ["gnil", "kost"],
    problem: "Его песни об утраченной Золотой заставе кого-то разозлили всерьёз — гонец в гуслях порвал струны.",
    story: "Не помнит родного села: вырос на обозном колесе. Собрал былин полный воз и некуда складывать новые.",
    relations: { nezhdana: 1, molchan: 1, milana: 0 } },
  // Лесное капище
  { id: "volhv_veleslav", name: "Волхв Велеслав", age: 55, sex: 0, profession: "Волхв капища", character: "zagadochnyi", romance: false, spriteBase: "mag", home: "kapishe",
    schedule: sch("temple", "temple", "temple", "temple"),
    likedGifts: ["yagoda", "grib", "pero", "zhemchug"], dislikedGifts: ["pivo", "oruzhie", "kost"],
    problem: "Огонь на капище гаснет не по людской воле — кто-то черпает из чаши сил. Ссориться не с кем, сила не спорит.",
    story: "Владеет словом снов и дымом. Изгнан из города трижды, и трижды возвращался — уже при свечах и по просьбе.",
    relations: { shamanka_mava: 0, otets_kliment: -1, aristarh: 0 } },
  { id: "zhrica_dobrava", name: "Жрица Добрава", age: 34, sex: 1, profession: "Жрица рощи", character: "dobryi", romance: false, spriteBase: "svyashennik", home: "kapishe",
    schedule: sch("temple", "wild", "temple", "temple"),
    likedGifts: ["yagoda", "hleb", "zerno", "tkan"], dislikedGifts: ["myaso", "oruzhie", "pivo"],
    problem: "Колосовой венок на лето осквернили: кто-то ночью перешёл межу с серпом. Роще нужен новый обет.",
    story: "Из крестьянок; ушла в рощу, когда боги отозвались на её голос. Носит на груди три зерна первого урожая.",
    relations: { otets_kliment: 1, mavra: 0, lesnichy_bor: 0 } },
  { id: "lesnichy_bor", name: "Лесничий Бор", age: 39, sex: 0, profession: "Лесничий", character: "vorchlivyi", romance: true, spriteBase: "krestyanin", home: "kapishe",
    schedule: sch("wild", "wild", "home", "home"),
    likedGifts: ["topor_k", "kozha", "hleb", "myaso"], dislikedGifts: ["pivo", "pero", "naryad"],
    problem: "Люди режут капищевы дубы под пользу. Не может быть на двух тропах сразу — нужен честный глаз.",
    story: "Знает лучшую зорю каждого оврага. Не поэт, но ворчит как одуванчик: «Без леса, небось, селянин как без рубахи».",
    relations: { ratmir: 0, volhv_veleslav: 0, bogdan: -1 } },
  // Шахтёрский посёлок
  { id: "prorab_stog", name: "Прораб Стог", age: 47, sex: 0, profession: "Прораб шахты", character: "zloi", romance: false, spriteBase: "remeslennik", home: "shahta",
    schedule: sch("work", "work", "home", "home"),
    likedGifts: ["zoloto", "instrument", "pivo"], dislikedGifts: ["pero", "yagoda", "nit"],
    problem: "Выработки проседают над новой жилой. Гонит людей вниз, сам внизу не был со вчерашнего гула.",
    story: "Пробил двенадцать штолен чужими руками. Золото считает лучше рифмачей и спит на счетоводстве.",
    relations: { ostap: -1, taras: -1, ora: -1 } },
  { id: "ora", name: "Ора Пластовая", age: 26, sex: 1, profession: "Проходчица", character: "veselyi", romance: true, spriteBase: "krestyanin", home: "shahta",
    schedule: sch("work", "work", "tavern", "home"),
    likedGifts: ["kirka_m", "hleb", "pivo", "ugol"], dislikedGifts: ["pero", "naryad", "gnil"],
    problem: "Нашла в забое древний ход с лестницей, куда прораб не велит ходить. Ей уже снится, что там зовут по имени.",
    story: "Спускается первой и выходит с шуткой. Говорит камень слушает, если кричать вежливо.",
    relations: { ostap: 1, prorab_stog: -1 } },
  { id: "gorynya", name: "Мастер Горыня", age: 52, sex: 0, profession: "Рудознатец-учёный", character: "vorchlivyi", romance: false, spriteBase: "uchenyi", home: "shahta",
    schedule: sch("work", "work", "home", "home"),
    likedGifts: ["med_slitok", "zhel_slitok", "instrument", "nebesnyi_kristall"], dislikedGifts: ["gnil", "pivo", "kost"],
    problem: "Образец с зелёной чешуёй из пласта семь «не горит и не врёт». Лаборатория просит безопасную доставку.",
    story: "Когда-то был главным ассэйщиком Лиги. Слишком честным — поэтому теперь у него место у клетки, а не у свиты.",
    relations: { aristarh: 1, prorab_stog: 0, zlata: 0 } },
  // Верхняя застава
  { id: "sotnik_peresvet", name: "Сотник Пересвет", age: 42, sex: 0, profession: "Сотник заставы", character: "vorchlivyi", romance: false, spriteBase: "strazhnik", home: "zastava",
    schedule: sch("gate", "gate", "gate", "gate"),
    likedGifts: ["oruzhie", "zhel_slitok", "myaso", "hleb"], dislikedGifts: ["gnil", "pivo", "pero"],
    problem: "На тракте пропал третий обоз. Не разбойники — те хоть вестку шлют. Верит, что вернёт всех домой.",
    story: "Младший из девяти братьев-дружинников; единственный, кто дожил до седин. Списал из уставов все, кроме «бросить».",
    relations: { voivoda_rodan: 1, vesta: 1, krykunja: -1 } },
  { id: "vesta", name: "Лучница Веста", age: 25, sex: 1, profession: "Лучница заставы", character: "zagadochnyi", romance: true, spriteBase: "strazhnik", home: "zastava",
    schedule: sch("gate", "gate", "home", "home"),
    likedGifts: ["pero", "kozha", "yagoda", "ukrashenie"], dislikedGifts: ["pivo", "gnil", "kost"],
    problem: "Стрела, что взяла на метлу ворожее око, пошла боком: утраченная точность — страх, который ей не по себе.",
    story: "Молчит лучше большинства лекторов. Стреляла до лука — писала до слов. Между буквами на метле — зарубки.",
    relations: { sotnik_peresvet: 1, radmila: 0 } },
  { id: "sekach", name: "Фёдор Секач", age: 36, sex: 0, profession: "Оружейник", character: "vorchlivyi", romance: true, spriteBase: "remeslennik", home: "zastava",
    schedule: sch("work", "work", "home", "home"),
    likedGifts: ["zhel_slitok", "ugol", "instrument", "mech_k"], dislikedGifts: ["pero", "gnil", "yagoda"],
    problem: "По контракту — триста клинков к месяцу, а железо с юга не доезжает. Воевода щурится, прораб язвит.",
    story: "Служил при двух заставах и одной осаде. Говорит, добрый клинок слышно по сну кузнеца.",
    relations: { taras: 0, sotnik_peresvet: 1 } },
  // Разбойничье логово
  { id: "krykunja", name: "Атаманша Крикунья", age: 33, sex: 1, profession: "Атаманша логова", character: "zloi", romance: true, spriteBase: "razbojnik", home: "logovo",
    schedule: sch("wild", "wild", "tavern", "home"),
    likedGifts: ["zoloto", "ukrashenie", "oruzhie", "pivo"], dislikedGifts: ["pero", "hleb", "nit"],
    problem: "Сводня требует дели́ть добытый караван поровну, хотя план был её. Грядёт либо подкуп, либо ночная резня.",
    story: "Обобрала княжеского сборщика на его же весах. Кличка — за то, что смеётся громче вертухая в пыточной.",
    relations: { bystryj: -1, sotnik_peresvet: -1, soroka: 0 } },
  { id: "bystryj", name: "Атаман Быстрый", age: 45, sex: 0, profession: "Старший логова", character: "zloi", romance: false, spriteBase: "razbojnik", home: "logovo",
    schedule: sch("wild", "wild", "home", "home"),
    likedGifts: ["zoloto", "pivo", "zharkoe", "mech_zh"], dislikedGifts: ["pero", "yagoda", "nit"],
    problem: "Люди бегут из логова к Крикунье: воры тоже любят красивые злые речи. Нужно доказать старшим, кто тут батя.",
    story: "Дважды на каторге, дважды из неё. «Порядок» — думает — это просто расстановка для нового грабежа.",
    relations: { krykunja: -1, voivoda_rodan: -1 } },
  // Странники и отшельники
  { id: "molchan", name: "Слепой Молчан", age: 60, sex: 0, profession: "Странник", character: "zagadochnyi", romance: false, spriteBase: "strannik", home: "dorogi",
    schedule: sch("square", "square", "tavern", "home"),
    likedGifts: ["hleb", "yagoda", "pivo", "tkan"], dislikedGifts: ["gnil", "kost"],
    problem: "С каждой новой луной забывает по одному имени. Последнее, что помнит: «моё». Да оно скоро уйдёт за остальными.",
    story: "Видел обе старушки-реки и трёх воевод. Говорит, что глаза оставил там, где обещали сказку — и не соврали.",
    relations: { guslyar: 1, otets_kliment: 0 } },
  { id: "bagrijan", name: "Отшельник Багриян", age: 70, sex: 0, profession: "Отшельник скалы", character: "zloi", romance: false, spriteBase: "starik", home: "dorogi",
    schedule: sch("wild", "wild", "wild", "wild"),
    likedGifts: ["hleb", "zerno", "yagoda"], dislikedGifts: ["pivo", "naryad", "myaso", "ukrashenie"],
    problem: "Кто-то вскрыл его схрон под скалой и забрал бересту с «ненужными пророчествами». Теперь будущее бродит без присмотра.",
    story: "Пятнадцать лет молчал, потом проклял погодой целый торг. Говорят, слушает гору, пока та не признаётся.",
    relations: { molchan: -1, volhv_veleslav: 0 } },
  { id: "vedma_marya", name: "Топяная Марья", age: 48, sex: 1, profession: "Ведьма топи", character: "zloi", romance: false, spriteBase: "mag", home: "top",
    schedule: sch("wild", "wild", "wild", "wild"),
    likedGifts: ["grib", "kost", "zhemchug", "gnil"], dislikedGifts: ["hleb", "pero", "yagoda_zhar"],
    problem: "Кто-то распугал купавы у её хутора. Подозревает невинных; на самом деле нужны нити из глубинной воды.",
    story: "Трижды утопленница — по слухам. Знает все имена топяных огней, но не тех, что мерещатся прохожим.",
    relations: { dunya: -1, shamanka_mava: -1 } },
  { id: "aristarh", name: "Учёный Аристарх", age: 56, sex: 0, profession: "Звездочёт", character: "zagadochnyi", romance: false, spriteBase: "uchenyi", home: "vyshka_gora",
    schedule: sch("work", "work", "work", "work"),
    likedGifts: ["pero", "instrument", "nebesnyi_kristall", "lunnyi_kamen"], dislikedGifts: ["myaso", "pivo", "gnil"],
    problem: "Новая звезда, что встала над морем, приближается. Чертёж траектории у него один, а время — у всех.",
    story: "Двадцать лет у вышки, семь теремов список и одна карта неведомого. Считает судьбу поправкой к орбите.",
    relations: { gorynya: 1, feofan: 0, volhv_veleslav: 0 } },
];

export const NPCS: PersonaDef[] = [...CITY, ...WORLD];
export const PERSONA_BY_ID: Record<string, PersonaDef> = Object.fromEntries(NPCS.map((p) => [p.id, p]));
export const CITY_PERSONAS = NPCS.filter((p) => p.home === "city");
export const WORLD_PERSONAS = NPCS.filter((p) => p.home !== "city");
export const ROMANCEABLE = NPCS.filter((p) => p.romance);
// контроль: горожан 28, всего 52, доступны для брака 34

// ---- Ступени отношений ----
export type BondTier = "enemy" | "stranger" | "known" | "pal" | "friend";
export function tierOf(f: number): BondTier {
  if (f <= -20) return "enemy";
  if (f < 12) return "stranger";
  if (f < 42) return "known";
  if (f < 72) return "pal";
  return "friend";
}
export const TIER_RU: Record<BondTier, string> = {
  enemy: "Недоброжелатель", stranger: "Незнакомец", known: "Знакомый", pal: "Приятель", friend: "Друг",
};

// ---- Реплики по характеру и ступени ----
export const GREET_POOL: Record<NpcCharacter, Record<BondTier, string[]>> = {
  dobryi: {
    enemy: ["Я вам не враг… хоть вы и стараетесь.", "Прости тебя боги. Иди своей дорогой."],
    stranger: ["Здравствуйте, добрый человек. Редко к нам заглядывают новые лица.", "Доброго дня! Чем свет Божий поможет путнику?"],
    known: ["А, это снова вы. Проходите, не стойте на ветру.", "Рада вас видеть. Хлеба ли, совета?"],
    pal: ["О, гость дорогой! Садитесь, рассказывайте, что в большом мире.", "Ваш приход — как солнце из-за туч."],
    friend: ["Брат мой сердечный! Дом без вас скучает, и я тоже.", "За вашими плечами — добрая слава, за моими — всегда открытая дверь."],
  },
  vorchlivyi: {
    enemy: ["Ты? Опять ты? Ноги бы твои не было в этом краю.", "Пшел прочь, пока я вежливый."],
    stranger: ["Ну? Чего пришёл-то? Говори быстрее, работа стоит.", "И чего глазеешь? Здесь трудятся, а не сказки слушают."],
    known: ["А… это ты. Ну, подходи, раз уж пришёл.", "Опять по делу? Или просто так — тогда молчи пока."],
    pal: ["Живой ещё, путник? Удивляешь ты меня. Проходи.", "Тебя хоть ждать можно. Иди, присядь."],
    friend: ["Садись, чего стоишь. Чаю нет, но есть разговор.", "Тебе даже ворчать приятно. Что надо — говори."],
  },
  veselyi: {
    enemy: ["О-о, само несчастье пожаловало! Валяй, смеши меня дальше.", "Ха! Да ты терпения моего худший враг."],
    stranger: ["Здорово, путник! Новое лицо — новая история, выкладывай!", "Ха! Гляньте, кого ветром к нам занесло!"],
    known: ["Ёжики, да это же мой тёзка по удаче!", "Опять вы! День сразу светлее."],
    pal: ["А вот и баловень судьбы! Садись, шутей, живей!"],
    friend: ["Идёт мой лучший закажчик улыбок! Обниматься? Обниматься!"],
  },
  zagadochnyi: {
    enemy: ["Я чую твою тень, чужак. Уходи, пока она тебя не слышит.", "Между нами — пепел. Не веертуй его."],
    stranger: ["Ты ступил на землю старых троп. Скажи, зачем позвал.", "Луна была круглой, когда ты родился… или покажется?"],
    known: ["Приход твой был виден мне в дыму. Присядь, слушай внимательно.", "Второй визит — уже узор. Что скажешь?"],
    pal: ["Редкий гость открывает редкую дверь. Входи, спрашивай."],
    friend: ["Для тебя даже туман говорит внятно. Будь благословен."],
  },
  zloi: {
    enemy: ["Сгинь, пока терпение у меня как у собаки — короткое.", "Твоя физия мне уже должна."],
    stranger: ["Чего надо? Золото? Жизнь? Первое — не дам, второе — продаётся.", "Говори дело или катись."],
    known: ["О, опять ты… Ладно. Минута твоя.", "Пользуйся моментом: я в редком расположении."],
    pal: ["Ты мне почти не противен. Почти — цени́й.", "Для своих я зол наполовину."],
    friend: ["С тобой можно не орать. Это — комплимент, дурак."],
  },
};

// разное «про жизнь» от характера (для поговорить)
export const CHAT_POOL: Record<NpcCharacter, string[]> = {
  dobryi: ["Возьми хлебушка, дорога длинная.", "Если беда — приходи, не стесняйся.", "Мир держится на малых добротах."],
  vorchlivyi: ["Дел по горло, языки короче.", "Не мешайся под ногами — вот и вся любовь.", "Раньше трава была зеленее, а люди работливей."],
  veselyi: ["Слушай байку: вчера чуть не женил огород!", "Смех — бесплатный хлеб, налегай.", "Если нальют — смеюсь громче."],
  zagadochnyi: ["Снятся ли тебе открытые двери? Это предупреждение.", "Не все дороги ведут туда, куда ведут.", "Тень у стены сегодня старше тебя."],
  zloi: ["Не нравится — не ешь, не нравлюсь — не смотри.", "Здесь выживают злые. Добрые хоронят.", "Вежливость — налог дураков."],
};

// ---- Реакция на подарок ----
export const GIFT_POOL: Record<NpcCharacter, { like: string[]; neutral: string[]; dislike: string[] }> = {
  dobryi: {
    like: ["Ой, да что вы! Такое сокровище — мне? Благослови вас боги!", "Какая прелесть… Я припрячу и буду любоваться."],
    neutral: ["Спасибо, добрый человек. В хозяйстве сгодится.", "От чистого сердца — приму с благодарностью."],
    dislike: ["Это… не по мне, простите. Подарите кому-то другому.", "Нет-нет, не смогу. Не обижайтесь."],
  },
  vorchlivyi: {
    like: ["Гм. Неплохо. Очень даже. Не жди, что скажу дважды.", "Вот это по делу. Умеешь угадать, путник."],
    neutral: ["Ладно, беру. Вон туда положи.", "Сойдёт. Бесплатно — даже камень хлеб."],
    dislike: ["Ты издеваешься? Забери эту дрянь.", "Вот этим меня решил обрадовать? Проваливай."],
  },
  veselyi: {
    like: ["Ха-а! Да это же лучшее, что видели мои руки!", "Ого! За такое я тебе спою. И даже хорошо!"],
    neutral: ["О, гостинец! Спасибо, сгодится для дела или для смеха.", "Принято! Теперь ты должен мне шутку."],
    dislike: ["Ха-ха. Нет. Серьёзно — нет, забери.", "Дружище, это подарок… врагу моего врага."],
  },
  zagadochnyi: {
    like: ["Вещь с отметиной… Она выбрала меня, как и ты выбрал путь.", "Это старше, чем кажется. Я услышал(а). Благодарю."],
    neutral: ["Приму. Всё приходит к тому, кто умеет ждать.", "Да оставит оно намек, а не запах."],
    dislike: ["Эта вещь злится у меня в ладони. Не оставляй.", "Унеси, пока она не рассказала лишнего."],
  },
  zloi: {
    like: ["Ну наконец-то дельный подарок. Засчитано.", "Вот это я понимаю. Можешь заходить ещё."],
    neutral: ["Хм. Ладно, возьму — из жалости к вещи.", "Тащи сюда, не стой столбом."],
    dislike: ["Мусор. Убирайся вместе с ним.", "Ты даришь отстой нарочно? Запомню."],
  },
};

// ---- Романтические реплики ----
export const ROMANCE_POOL: Record<"cold" | "warm" | "inlove", string[]> = {
  cold: ["Мне нельзя думать о таком. Прости.", "Сердце — не товар с ярмарки. Отведи его домой."],
  warm: ["Ты смотришь так, что в голове теплеет. Не балуй меня надеждой…", "Приходи завтра. И послезавтра тоже, если что."],
  inlove: ["Моё сердце давно уже гадает на твоё имя. Боишься? Я тоже.", "Если позовёшь — пойду хоть за край карты."],
};
export const PROPOSE_ACCEPT = "Да. Тысячу раз — да. Пусть весь город слышит, пусть все земли знают: теперь мы — один очаг!";
export const ROMANCE_TIER_RU = (h: number) => h >= 70 ? "Влюблённость" : h >= 35 ? "Симпатия" : "Холод";
