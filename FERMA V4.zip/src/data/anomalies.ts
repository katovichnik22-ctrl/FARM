import type { EquipSlot, ItemDef } from "../types";

// =====================================================================
//  АНОМАЛЬНЫЕ ЗОНЫ «ТИХОГО ПЛАМЕНИ» — 12 редких структур (этап 8)
//  Зоны существуют в мире как уникальные детерминированные структуры
//  (генерация — world/anomalies.ts). В сердце каждой зоны спрятана
//  легендарная находка.
// =====================================================================

export interface AnomalyZone {
  id: string;
  name: string;
  icon: string;
  color: string;
  /** слой движка (z), где стоит структура */
  z: number;
  /** опасность 1..10 */
  danger: number;
  /** радиус структуры в тайлах */
  radius: number;
  desc: string;
  /** короткая атмосферная строка — всплывает при обнаружении */
  ambience: string;
}

export const ANOMALIES: AnomalyZone[] = [
  {
    id: "zab_laba", name: "Заброшенная лаборатория", icon: "FlaskConical", color: "#7ae68a",
    z: 6, danger: 8, radius: 8,
    desc: "Чужие колбы, мёртвые экраны и формулы, написанные до того, как человек встал на ноги.",
    ambience: "Воздух пахнет озоном и брошенными надеждами",
  },
  {
    id: "alien_ship", name: "Корабль пришельцев", icon: "Rocket", color: "#5fe8c0",
    z: 5, danger: 7, radius: 9,
    desc: "Упал на Луну до первой людской речи. Двигатель ещё слышит команду, которой не было.",
    ambience: "Металл поёт неслышную ноту",
  },
  {
    id: "cursed_village", name: "Проклятая деревня", icon: "Home", color: "#8a5cf0",
    z: 0, danger: 4, radius: 9,
    desc: "Дома стоят, очаги холодны, а жителей нет уже триста лет. Колодец помнит всех по именам.",
    ambience: "Тишина здесь звонкая, как разбитое стекло",
  },
  {
    id: "sanctuary", name: "Святилище древних", icon: "Sun", color: "#ffd97a",
    z: 3, danger: 5, radius: 8,
    desc: "Алтарь на пустом небесном острове. Тут молились тем, кто старше слов.",
    ambience: "Свет падает сюда раньше, чем восходит солнце",
  },
  {
    id: "rift", name: "Разлом в другое измерение", icon: "CircleDot", color: "#f24ae0",
    z: 9, danger: 10, radius: 7,
    desc: "Трещина в законе мира. Смотреть туда — значит разрешить смотреть в ответ.",
    ambience: "Гравитация здесь — лишь совет, а не правило",
  },
  {
    id: "titan_graveyard", name: "Кладбище титанов", icon: "Mountain", color: "#c9754a",
    z: 2, danger: 7, radius: 9,
    desc: "Кости исполинов, лежащие холмами. Каждый позвонок — с рудничный штрек.",
    ambience: "Здесь горят не факелы — память камня",
  },
  {
    id: "sunken_city", name: "Затонувший город", icon: "Anchor", color: "#4ab8e8",
    z: 4, danger: 6, radius: 9,
    desc: "Купола, башни и мостовые под водой. Колокола звонят раз в столетие — сегодня может быть тот день.",
    ambience: "Течения здесь ходят улицами",
  },
  {
    id: "flying_island", name: "Летающий остров", icon: "Wind", color: "#a8d8f0",
    z: 3, danger: 4, radius: 8,
    desc: "Клочок земли, что забыл упасть. Трава на нём зеленее любой пущи.",
    ambience: "Ветер здесь работает хозяином",
  },
  {
    id: "crystal_cave", name: "Пещера кристаллов", icon: "Sparkle", color: "#8ae8ff",
    z: 1, danger: 3, radius: 8,
    desc: "Каменный сад света. Кристаллы растут здесь медленнее травы, но вернее весны.",
    ambience: "Каждый шаг отзывается тихим пением",
  },
  {
    id: "forgotten_library", name: "Забытая библиотека", icon: "Library", color: "#c9c2b2",
    z: 7, danger: 6, radius: 8,
    desc: "Полки из тени, книги из пепла. Тут хранятся все истории, которые никто не дожил.",
    ambience: "Страницы шуршат сами — по расписанию",
  },
  {
    id: "arena_drevnih", name: "Арена древних", icon: "Gavel", color: "#f2a24d",
    z: 0, danger: 5, radius: 9,
    desc: "Каменный круг, где боги решали споры первым в мире поединком. Кровь давно вросла в камень.",
    ambience: "Эхо помнит счёт всех боёв",
  },
  {
    id: "temple_stihii", name: "Храм четырёх стихий", icon: "Sparkles", color: "#e08ac9",
    z: 8, danger: 6, radius: 8,
    desc: "Четыре алтаря: огню, воде, воздуху и земле. Сны здесь снятся сразу во всех мирах.",
    ambience: "Земля дышит, вода думает, ветер слушает, огонь помнит",
  },
];
export const ANOMALY_BY_ID: Record<string, AnomalyZone> = Object.fromEntries(ANOMALIES.map((a) => [a.id, a]));

// =====================================================================
//  ЛЕГЕНДАРНЫЕ НАХОДКИ — восьмь категорий реликвий
// =====================================================================
export type FindCat = "weapon" | "armor" | "artifact" | "egg" | "seed" | "map" | "diary" | "key";

export const FIND_CAT_NAMES: Record<FindCat, string> = {
  weapon: "Оружие с именем", armor: "Броня с историей", artifact: "Артефакт",
  egg: "Яйцо существа", seed: "Семя редкого растения", map: "Карта сокровищ",
  diary: "Дневник древних", key: "Ключ от порталов",
};

export interface LegendaryFind {
  /** id предмета (регистрируется в ITEMS) */
  id: string;
  name: string;
  cat: FindCat;
  icon: string;
  /** аномальная зона, где лежит находка */
  zone: string;
  /** история предмета */
  desc: string;
  // --- статы для оружия/брони ---
  dmg?: number; atkSpd?: number;
  tool?: "axe" | "pick" | "shovel"; power?: number;
  slot?: EquipSlot; armor?: number; warmth?: number;
  /** сколько опыта даёт сама находка */
  xpBonus?: number;
}

export const LEGENDARY_FINDS: LegendaryFind[] = [
  // --- Оружие с именем (2) ---
  {
    id: "find_groza", name: "Меч «Гроза драконов»", cat: "weapon", icon: "Sword", zone: "arena_drevnih",
    desc: "Выкован из когтя первого дракона и отпущен молнией. Клинок гудит, когда над миром собирается гроза — то есть всегда.",
    dmg: 96, atkSpd: 1.45, xpBonus: 500,
  },
  {
    id: "find_krushitel", name: "Топор «Крушитель гор»", cat: "weapon", icon: "Axe", zone: "titan_graveyard",
    desc: "Рабочий инструмент титанов-строителей. Валит дерево за взмах и гору — за утро.",
    dmg: 70, atkSpd: 0.95, tool: "axe", power: 62, xpBonus: 400,
  },
  // --- Броня с историей (2) ---
  {
    id: "find_obet", name: "Панцирь «Обет павшего короля»", cat: "armor", icon: "ShieldHalf", zone: "cursed_village",
    desc: "Король поклялся стоять, пока стоит его деревня. Деревня стоит до сих пор. Панцирь держит клятву.",
    slot: "body", armor: 30, warmth: 8, xpBonus: 400,
  },
  {
    id: "find_sapogi_vetra", name: "Сапоги семи ветров", cat: "armor", icon: "Footprints", zone: "flying_island",
    desc: "Сшиты из шкуры попутного бриза. Шаг в них короче на полгоризонта.",
    slot: "feet", armor: 12, warmth: 6, xpBonus: 350,
  },
  // --- Артефакты (3) ---
  {
    id: "find_glaz", name: "Глаз Пророка", cat: "artifact", icon: "Eye", zone: "temple_stihii",
    desc: "Кристалл-зенки, видевшие все четыре стихии мирясяще. Открывает глаза там, где вы ещё не смотрели.",
    xpBonus: 600,
  },
  {
    id: "find_serdtse_titana", name: "Сердце титана", cat: "artifact", icon: "HeartPulse", zone: "titan_graveyard",
    desc: "Камень размером с дом, бьющийся раз в год. Вы пришли в день удара — слышите?",
    xpBonus: 500,
  },
  {
    id: "find_yadro", name: "Ядро вечной машины", cat: "artifact", icon: "Cpu", zone: "zab_laba",
    desc: "Механизм, работающий без топлива, воли и цели. Инженеры трёх эпох сошли с ума, пытаясь его остановить.",
    xpBonus: 600,
  },
  // --- Яйца существ (2) ---
  {
    id: "find_feniks", name: "Яйцо феникса", cat: "egg", icon: "Flame", zone: "sanctuary",
    desc: "Тёплое, как костёр, и тяжёлое, как решимость. Внутри кто-то стучит — должно быть, клювом будущего.",
    xpBonus: 550,
  },
  {
    id: "find_yaytso_pustoty", name: "Яйцо пустоты", cat: "egg", icon: "Shapes", zone: "rift",
    desc: "Из другого измерения. Не греется, не светится, не торопится. Лучше не знать, когда проклюнётся.",
    xpBonus: 650,
  },
  // --- Семена редких растений (1) ---
  {
    id: "find_semya", name: "Семя мирового древа", cat: "seed", icon: "Sprout", zone: "crystal_cave",
    desc: "Посаженное под звёздным светом, поднимет древо до облаков. Упаковано в вечность.",
    xpBonus: 450,
  },
  // --- Карты сокровищ (1) ---
  {
    id: "find_karta", name: "Карта первых морей", cat: "map", icon: "ScrollText", zone: "sunken_city",
    desc: "Рисована, когда морей было четыре. Все кресты совпадают с местами, где вы ещё не были.",
    xpBonus: 450,
  },
  // --- Дневники древних (1) ---
  {
    id: "find_dnevnik", name: "Дневник последнего стража", cat: "diary", icon: "BookOpen", zone: "forgotten_library",
    desc: "Триста лет записей одним почерком. Последняя строка: «Смена так и не пришла. Читаю дальше».",
    xpBonus: 500,
  },
  // --- Ключи от порталов (1) ---
  {
    id: "find_klyuch", name: "Ключ-звезда", cat: "key", icon: "Sparkle", zone: "alien_ship",
    desc: "Пятилучевая звезда из света, спрессованного до веса. Открывает двери, которых пока нет в этом мире.",
    xpBonus: 700,
  },
];
export const FIND_BY_ID: Record<string, LegendaryFind> = Object.fromEntries(LEGENDARY_FINDS.map((f) => [f.id, f]));

/** Находки аномальной зоны */
export function findsOfZone(zoneId: string): LegendaryFind[] {
  return LEGENDARY_FINDS.filter((f) => f.zone === zoneId);
}

// =====================================================================
//  КОНВЕРТАЦИЯ НАХОДОК В ПРЕДМЕТЫ (регистрируются в ITEMS)
// =====================================================================
export const ANOMALY_ITEM_DEFS: ItemDef[] = LEGENDARY_FINDS.map((f) => {
  const type = f.cat === "weapon" ? "weapon" : f.cat === "armor" ? "equip" : "misc";
  return {
    id: f.id,
    name: f.name,
    desc: f.desc,
    icon: f.icon,
    type: type as ItemDef["type"],
    stack: 1,
    dmg: f.dmg, atkSpd: f.atkSpd,
    tool: f.tool, power: f.power,
    slot: f.slot, armor: f.armor, warmth: f.warmth,
  };
});
