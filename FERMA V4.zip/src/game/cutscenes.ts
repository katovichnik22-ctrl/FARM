// ===== Кинематографика «Тихого Пламени»: скриптовые сцены и мировые события =====
// ШАГ 3: 12 одноразовых вау-моментов (CUTSCENES).
// ШАГ 4: 10 повторяющихся кинематографичных событий (CINE_EVENTS).
import type { Engine } from "./engine";
import { TILE } from "../types";
import { BUILDINGS } from "../data/buildings";
import { snd, type MusicMood } from "../lib/sound";
import { clamp } from "../lib/noise";

// ---------- Типы сцен ----------
export type SceneTrigger =
  | "first_sunset" | "first_night" | "first_fire" | "first_house" | "first_city" | "first_battle"
  | "first_boss" | "first_death" | "first_respawn" | "first_space" | "first_portal" | "finale";

export interface SceneEffects {
  slowmo?: number;        // масштаб времени (0.15 — сильное замедление)
  music?: MusicMood;      // музыкальная тема
  tint?: string;          // цвет виньетки поверх экрана
  tintA?: number;         // сила виньетки 0..1
  shake?: number;         // встряска камеры в начале
  flash?: string;         // вспышка цветом в начале
}
export interface CutsceneDef {
  id: SceneTrigger;
  no: number;             // порядковый номер момента
  title: string;          // заголовок титра
  triggerDesc: string;    // описание условия
  dur: number;            // длительность, секунды
  effects: SceneEffects;
  credits: string[];      // текст титров (строки выводятся по очереди)
}

export const CUTSCENES: CutsceneDef[] = [
  { id: "first_sunset", no: 1, title: "Первый закат", triggerDesc: "Дождаться первого вечера в этих землях", dur: 9,
    effects: { slowmo: 0.35, music: "calm", tint: "#ff8a3c", tintA: 0.22 },
    credits: ["Солнце опускается в золотую пыль…", "Тени тянутся, как пальцы уходящего дня.", "Ты ещё здесь. Это — уже победа.", "Запомни этот свет: он будет возвращаться."] },
  { id: "first_night", no: 2, title: "Первая ночь", triggerDesc: "Встретить первую ночь", dur: 9,
    effects: { slowmo: 0.4, music: "night", tint: "#1a2450", tintA: 0.34 },
    credits: ["Небо потемнело, будто оно знает твоё имя.", "В траве зашевелилось то, что прячется днём.", "Держи огонь ближе. Держи себя — ещё ближе.", "До рассвета дожить — вот вся наука первых суток."] },
  { id: "first_fire", no: 3, title: "Первый костёр", triggerDesc: "Развести первый костёр", dur: 9,
    effects: { slowmo: 0.3, music: "calm", tint: "#ffb04d", tintA: 0.2, shake: 0.15 },
    credits: ["Искра, дыхание — и мир вокруг стал теплее.", "Люди тысячи лет начинали именно так.", "Огонь — это дом, который можно носить с собой.", "Пусть он горит. Пусть тьма смотрит со стороны."] },
  { id: "first_house", no: 4, title: "Первый дом", triggerDesc: "Построить первое жилище", dur: 10,
    effects: { slowmo: 0.35, music: "victory", tint: "#ffd97a", tintA: 0.16, shake: 0.2 },
    credits: ["Стены. Крыша. Порог.", "Кажется немногим — но с этого начинались все города мира.", "Теперь здесь можно не просто выживать. Теперь здесь можно возвращаться.", "Дом там, где заперта за тобой дверь."] },
  { id: "first_city", no: 5, title: "Первый город", triggerDesc: "Основать собственный город", dur: 11,
    effects: { slowmo: 0.35, music: "victory", tint: "#ffe9a8", tintA: 0.2, shake: 0.25 },
    credits: ["Знамя поднято. Название сказано вслух.", "Люди пойдут сюда за надеждой, хлебом и кровом.", "Их лица — твоя ответственность. Их судьба — твоя история.", "Пусть стоит тысячу лет. Начиная с этого дня."] },
  { id: "first_battle", no: 6, title: "Первый бой", triggerDesc: "Одержать первую победу в бою", dur: 8,
    effects: { slowmo: 0.25, music: "war", tint: "#c22", tintA: 0.22, shake: 0.4, flash: "#fff" },
    credits: ["Сердце стучит громче врага.", "Страх не ушёл — он просто встал за твоё плечо.", "Ты выстоял. И мир это заметил.", "Мечи помнят первых."] },
  { id: "first_boss", no: 7, title: "Первый босс", triggerDesc: "Повергнуть первого владыку земель", dur: 12,
    effects: { slowmo: 0.2, music: "victory", tint: "#f2d38a", tintA: 0.24, shake: 0.65, flash: "#ffdf8a" },
    credits: ["Легенда упала к твоим ногам — и земля вздохнула.", "Такого не видели здесь никогда. И ты — тоже.", "Песни родятся завтра. А сейчас — просто дыши.", "Имя твоё вошло в камень этих земель."] },
  { id: "first_death", no: 8, title: "Первая смерть", triggerDesc: "Впервые погибнуть", dur: 10,
    effects: { slowmo: 0.18, music: "deep", tint: "#0a0a12", tintA: 0.5 },
    credits: ["Тьма забрала тебя на мгновение.", "Но пламя не умирает — оно ждёт, когда его раздуют снова.", "Боль отступит. Урок — останется.", "Встань. Мир ещё не закончен с тобой."] },
  { id: "first_respawn", no: 9, title: "Первое возрождение", triggerDesc: "Очнуться после гибели", dur: 9,
    effects: { slowmo: 0.3, music: "calm", tint: "#9fd4f2", tintA: 0.22, flash: "#fff" },
    credits: ["Воздух. Свет. Порог родной земли.", "Смерть подержала тебя в ладонях — и вернула обратно.", "Что-то утрачено. Но не главное: не ты сам.", "Второе рождение даётся однажды. Третьего не обещают."] },
  { id: "first_space", no: 10, title: "Первый полёт в космос", triggerDesc: "Впервые шагнуть на Луну", dur: 12,
    effects: { slowmo: 0.25, music: "space", tint: "#8fb8ff", tintA: 0.24, shake: 0.5, flash: "#cfe4ff" },
    credits: ["Земля осталась внизу. Вся — целиком.", "Ты держал меч и кайло… а теперь держишься за звёзды.", "Реголит скрипит под сапогом, и это — голос вечности.", "Человек из грязи вышел к Луне. Помни этот шаг."] },
  { id: "first_portal", no: 11, title: "Первый портал", triggerDesc: "Впервые пройти сквозь врата миров", dur: 10,
    effects: { slowmo: 0.3, music: "deep", tint: "#a26af2", tintA: 0.3, shake: 0.4, flash: "#d9baff" },
    credits: ["Пространство согнулось — и пропустило тебя.", "По ту сторону нет вчера: врата стирают привычные законы.", "То, что было невозможным, стало дорогой.", "Теперь мир один — но с множеством дверей."] },
  { id: "finale", no: 12, title: "Финал. Путь к звёздам", triggerDesc: "Построить варп-двигатель — вершину пути", dur: 16,
    effects: { slowmo: 0.4, music: "space", tint: "#e8d9ff", tintA: 0.26, shake: 0.35, flash: "#fff" },
    credits: ["Костёр, с которого всё началось, по-прежнему горит где-то там, внизу.",
      "Ты выживал. Строил. Терял. Возвращался. Любил. Правил.",
      "От примитивной палки — до двигателя, сгибающего саму ткань мироздания.",
      "Земли, небеса, бездна и глубь вод — все они знают твоё имя.",
      "Складки пространства открываются. Галактика — впереди.",
      "ТИХОЕ ПЛАМЯ будет гореть. Всегда."] },
];
export const SCENE_BY_ID: Record<string, CutsceneDef> = Object.fromEntries(CUTSCENES.map((c) => [c.id, c]));

// ---------- Типы повторяющихся событий ----------
export type CineEventId =
  | "earthquake" | "nashat" | "koronaciya" | "svadba" | "pokhorony"
  | "zatmenie" | "krovavaya_luna" | "meteor_rain" | "prazdnik" | "alien_invasion";

export interface CineEventDef {
  id: CineEventId;
  name: string;
  icon: string;            // Lucide icon
  night?: boolean;         // только ночью
  day?: boolean;           // только днём
  needsCity?: boolean;
  minDay?: number;
  chance: number;          // шанс при дневном броске
  cooldown: number;        // дней до повторного выпадения
  dur: number;             // длительность основной фазы, сек
  music?: MusicMood;
  tint?: string; tintA?: number;
  shake?: number;
  spawn?: { ids: string[]; n: number };  // кого призвать
  happy?: number;          // дельта счастья города
  banner: { omen: string; main: string; after: string };
}

export const CINE_EVENTS: CineEventDef[] = [
  { id: "earthquake", name: "Землетрясение", icon: "Activity", day: true, minDay: 4, chance: 0.07, cooldown: 4, dur: 12,
    music: "deep", shake: 0.7, tint: "#c98a4b", tintA: 0.12,
    banner: { omen: "Где-то под ногами прокатился низкий гул. Птицы смолкли разом.", main: "ЗЕМЛЕТРЯСЕНИЕ! Земля ходит ходуном!", after: "Гул ушёл вглубь. Земля снова твёрдая — будто и не дрожала." } },
  { id: "nashat", name: "Нашествие чудищ", icon: "Skull", night: true, needsCity: true, minDay: 6, chance: 0.08, cooldown: 4, dur: 25,
    music: "war", tint: "#5a1020", tintA: 0.28, shake: 0.3,
    spawn: { ids: ["zombi", "skelet", "pauk"], n: 8 },
    banner: { omen: "Земля за стеной шевелится. Ночью что-то идёт к огням города.", main: "НАШЕСТВИЕ! Твари ломятся к стенам!", after: "Отбились. Утро сочтёт тела — и храбрецов." } },
  { id: "koronaciya", name: "Коронация", icon: "Crown", needsCity: true, minDay: 3, chance: 0, cooldown: 10, dur: 14,
    music: "victory", tint: "#ffd34d", tintA: 0.2, happy: 3,
    banner: { omen: "Колокола собирают людей на площадь. Говорят — венчание на царство.", main: "КОРОНАЦИЯ! Да здравствует новый правитель!", after: "Присяга дана. Знамёна не опускают до самой ночи." } },
  { id: "svadba", name: "Свадьба", icon: "Heart", needsCity: true, minDay: 2, chance: 0, cooldown: 0, dur: 14,
    music: "victory", tint: "#ff9ec4", tintA: 0.18, happy: 5,
    banner: { omen: "Город гудит: готовят столы, венки и ленты.", main: "СВАДЬБА! Горько! Пусть молодым живётся сладко!", after: "Дом новой семьи светится до утра. Город счастлив за вас." } },
  { id: "pokhorony", name: "Похороны", icon: "Flower2", needsCity: true, minDay: 3, chance: 0, cooldown: 0, dur: 12,
    music: "deep", tint: "#3a3f4a", tintA: 0.34, happy: -2,
    banner: { omen: "Колокол бьёт редко и глухо. Люди снимают шапки.", main: "ПОХОРОНЫ. Город провожает своего.", after: "Земля приняла своё. Живым — жить дальше." } },
  { id: "zatmenie", name: "Затмение", icon: "Eclipse", day: true, minDay: 5, chance: 0.06, cooldown: 6, dur: 22,
    music: "night", tint: "#0c0f22", tintA: 0.5,
    banner: { omen: "Свет стал ровным и мёртвым, будто сквозь сахарную голову.", main: "ЗАТМЕНИЕ. Диск ночи закрыл солнце!", after: "Солнце вернулось. Люди переводят дыхание и крестят тени." } },
  { id: "krovavaya_luna", name: "Кровавая луна", icon: "Moon", night: true, minDay: 5, chance: 0.09, cooldown: 4, dur: 30,
    music: "war", tint: "#8a1220", tintA: 0.3,
    spawn: { ids: ["prizrak", "zombi", "kriper"], n: 4 },
    banner: { omen: "Луна поднимается багровой, как незажившая рана.", main: "КРОВАВАЯ ЛУНА. Нечисть сильнее обычного!", after: "Луна побледнела. Ночь отпустила." } },
  { id: "meteor_rain", name: "Метеоритный дождь", icon: "Sparkles", night: true, minDay: 4, chance: 0.08, cooldown: 3, dur: 20,
    music: "space", tint: "#3a5a9a", tintA: 0.2, shake: 0.15,
    banner: { omen: "Небо вспороли первые белые нити света.", main: "МЕТЕОРИТНЫЙ ДОЖДЬ. Загадай желание — да побыстрее!", after: "На холмах дымятся свежие россыпи. Что-то из них уже ваше." } },
  { id: "prazdnik", name: "Народный праздник", icon: "PartyPopper", needsCity: true, minDay: 4, chance: 0.11, cooldown: 3, dur: 16,
    music: "victory", tint: "#ffd97a", tintA: 0.16, happy: 4,
    banner: { omen: "С площади пахнет жареным. Кто-то уже строит хоровод.", main: "ПРАЗДНИК! Город гуляет, поёт и пляшет!", after: "Устали счастливо. Завтра будет легче, чем вчера." } },
  { id: "alien_invasion", name: "Вторжение пришельцев", icon: "Rocket", night: true, minDay: 8, chance: 0.06, cooldown: 6, dur: 26,
    music: "space", tint: "#6a2aa2", tintA: 0.3, shake: 0.3,
    spawn: { ids: ["oskolok_haosa", "marsianin", "lunnyi_prizrak"], n: 5 },
    banner: { omen: "Над горизонтом завис медленный гул — чужой и неправильный.", main: "ВТОРЖЕНИЕ! Небо отдало то, что не должно ходить по земле!", after: "Гул растворился. То, что осталось, лежит среди воронок." } },
];
export const EVENT_BY_ID: Record<string, CineEventDef> = Object.fromEntries(CINE_EVENTS.map((c) => [c.id, c]));

// ---------- Сохранение ----------
export interface CineSave {
  seen: string[];
  cooldowns: Record<string, number>;
  lastRuler: number;
  lastRoyals: number;
}

// ---------- Симуляция кинематографики ----------
export class CineSim {
  seen = new Set<string>();
  scene: { id: SceneTrigger; t: number } | null = null;
  event: { id: CineEventId; t: number; extra?: string } | null = null;
  cooldowns: Record<string, number> = {};
  private checkT = 0;
  private lastRuler = -1;
  private lastRoyals = -1;
  private mobUid = 900_000;

  reset() {
    this.seen = new Set(); this.scene = null; this.event = null;
    this.cooldowns = {}; this.checkT = 0; this.lastRuler = -1; this.lastRoyals = -1;
  }

  // ===== Одноразовые сцены =====
  startScene(e: Engine, id: SceneTrigger) {
    if (this.seen.has(id) || this.scene) return;
    const def = SCENE_BY_ID[id];
    this.scene = { id, t: 0 };
    this.seen.add(id);
    if (def.effects.music) snd.playMusic(def.effects.music);
    if (def.effects.shake) e.shake = Math.max(e.shake, def.effects.shake);
    if (def.effects.flash) e.dmgFlash = Math.min(0.35, e.dmgFlash + 0.15);
    e.timeScale = def.effects.slowmo ?? 1;
    e.meta.progress(e, "story", `scene_${id}`, 1);
    e.stats.scenes = (e.stats.scenes ?? 0) + 1;
    e.poke();
  }
  private endScene(e: Engine) {
    this.scene = null;
    e.timeScale = 1;
    e.save(true);
    e.poke();
  }
  skip(e: Engine) { if (this.scene) this.endScene(e); }

  private triggers(e: Engine) {
    const hour = (6 + e.time * 24) % 24;
    const t: [SceneTrigger, boolean][] = [
      ["first_sunset", hour >= 18.25 && hour < 19 && e.day >= 1],
      ["first_night", e.z === 0 && e.isNight()],
      ["first_fire", (e.stats.fire ?? 0) >= 1 || e.nearFire()],
      ["first_house", e.buildings.some((b) => b.done && !!BUILDINGS[b.def]?.sleep)],
      ["first_city", e.city.s.founded],
      ["first_battle", (e.stats.killed ?? 0) >= 1],
      ["first_boss", (e.stats.bossKilled ?? 0) >= 1],
      ["first_death", (e.stats.deaths ?? 0) >= 1],
      ["first_respawn", (e.stats.respawns ?? 0) >= 1],
      ["first_space", (e.layers.visits[5] ?? 0) >= 1],
      ["first_portal", Object.entries(e.layers.visits).some(([z, n]) => +z > 0 && (n as number) > 0)],
      ["finale", e.layers.spaceBuilds.has("sb_warp")],
    ];
    for (const [id, cond] of t) {
      if (!this.seen.has(id) && cond) { this.startScene(e, id); return; }
    }
  }

  // ===== Повторяющиеся события =====
  fireEvent(e: Engine, id: CineEventId, extra?: string) {
    if (this.event) return;
    const def = EVENT_BY_ID[id];
    this.event = { id, t: 0, extra };
    if (def.music) snd.playMusic(def.music);
    if (def.shake) e.shake = Math.max(e.shake, def.shake);
    if (def.happy && e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness + def.happy, 0, 100);
    // боевые события: призыв в фазе «main» (см. update)
    if (def.id === "koronaciya" || def.id === "svadba" || def.id === "prazdnik") {
      e.city.s.paradeT = Math.max(e.city.s.paradeT, 20);
    }
    e.nations.log(e, `Событие: ${def.name}`, def.id === "koronaciya" || def.id === "svadba" || def.id === "prazdnik" ? "good" : "warn");
    e.poke();
  }

  private spawnedFlag = "";
  private spawnFor(e: Engine, def: CineEventDef) {
    if (!def.spawn) return;
    if (this.spawnedFlag === `${def.id}_${e.day}`) return;
    this.spawnedFlag = `${def.id}_${e.day}`;
    const c = e.city.s.founded ? e.city.s : null;
    const cx = c ? c.cx * TILE : e.player.x, cy = c ? c.cy * TILE : e.player.y;
    let n = def.spawn.n;
    if (e.city.s.founded) n = Math.min(n, 4 + Math.floor(e.city.s.pop / 6));
    for (let i = 0; i < n; i++) {
      const id = def.spawn.ids[Math.floor(Math.random() * def.spawn.ids.length)];
      const d = e.mobDef(id);
      if (!d) continue;
      const a = Math.random() * Math.PI * 2;
      const r = (9 + Math.random() * 7) * TILE;
      const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
      if (e.isBlocked(Math.floor(x / TILE), Math.floor(y / TILE), true, d.flying)) continue;
      const lvl = 1 + Math.floor(e.day / 7);
      const hp = Math.round(d.hp * (1 + (lvl - 1) * 0.25) * (def.id === "krovavaya_luna" ? 1.35 : 1));
      e.mobs.push({
        uid: this.mobUid++, def: id, x, y, hp, maxHp: hp,
        state: "wander", t: 2, cd: 0, flash: 0, lvl, tx: x, ty: y, breathe: 0, hitT: 0,
      });
    }
    snd.monster();
  }

  private rollEvents(e: Engine) {
    const night = e.isNight();
    for (const def of CINE_EVENTS) {
      if (def.chance <= 0) continue;
      if ((this.cooldowns[def.id] ?? 0) > e.day) continue;
      if (def.minDay && e.day < def.minDay) continue;
      if (def.needsCity && !e.city.s.founded) continue;
      if (def.night && !night) continue;
      if (def.day && night) continue;
      if (def.id === "zatmenie" && e.weather !== "clear" && e.weather !== "fog") continue;
      if (def.id === "alien_invasion" && (e.layers.visits[5] ?? 0) < 1) continue;
      if (def.id === "prazdnik" && e.city.s.happiness < 60) continue;
      if (Math.random() < def.chance) {
        this.cooldowns[def.id] = e.day + def.cooldown;
        this.fireEvent(e, def.id);
        return;
      }
    }
  }

  // ===== Циклы =====
  dayTick(e: Engine) {
    // коронация: сменился правитель династии
    const ruler = e.dynasty.ruler();
    if (ruler) {
      if (this.lastRuler === -1) this.lastRuler = ruler.uid;
      else if (this.lastRuler !== ruler.uid) {
        this.lastRuler = ruler.uid;
        if (!this.event) this.fireEvent(e, "koronaciya", ruler.name);
      }
    }
    // похороны: кто-то из рода умер
    const alive = e.dynasty.royals.filter((r) => r.alive).length;
    if (this.lastRoyals === -1) this.lastRoyals = alive;
    else if (alive < this.lastRoyals) {
      this.lastRoyals = alive;
      if (!this.event) this.fireEvent(e, "pokhorony");
    }
    this.rollEvents(e);
  }

  update(e: Engine, dt: number) {
    // одноразовая сцена
    if (this.scene) {
      this.scene.t += dt;
      const def = SCENE_BY_ID[this.scene.id];
      if (this.scene.t >= def.dur) this.endScene(e);
    } else {
      this.checkT -= dt;
      if (this.checkT <= 0) { this.checkT = 0.4; this.triggers(e); }
    }
    // повторяющееся событие
    if (this.event) {
      this.event.t += dt;
      const def = EVENT_BY_ID[this.event.id];
      const t = this.event.t;
      // фаза движения: призыв при входе в main
      if (t > 4 && def.spawn) this.spawnFor(e, def);
      // землетрясение: пульсации тряски в основной фазе
      if (def.id === "earthquake" && t > 4 && t < 4 + def.dur) {
        if (Math.random() < dt * 5) e.shake = Math.max(e.shake, 0.55 + Math.random() * 0.3);
        if (Math.random() < dt * 0.7) { snd.thunder(); }
      }
      if (def.id === "meteor_rain" && t > 4 && t < 4 + def.dur && Math.random() < dt * 1.4) {
        snd.thunder();
        const a = Math.random() * Math.PI * 2;
        e.spawnHitParticles(e.player.x + Math.cos(a) * 300, e.player.y - 200 - Math.random() * 200, "#cfe4ff", 12, "star");
        e.shake = Math.max(e.shake, 0.2);
      }
      if (t >= def.dur + 8) {
        // награда метеоритного дождя
        if (def.id === "meteor_rain") {
          e.give("lunnyi_kamen", 1);
          e.toast("Среди дымящихся россыпей нашлась крошка неба: +1 лунный камень", "good");
        }
        this.event = null;
        e.poke();
      }
    }
  }

  /** Фаза текущего события для баннера: 0 знамение, 1 пик, 2 отзвук */
  eventPhase(): 0 | 1 | 2 {
    if (!this.event) return 0;
    const def = EVENT_BY_ID[this.event.id];
    const t = this.event.t;
    if (t < 4) return 0;
    if (t < 4 + def.dur) return 1;
    return 2;
  }

  // ===== Сохранение =====
  serialize(): CineSave {
    return { seen: [...this.seen], cooldowns: { ...this.cooldowns }, lastRuler: this.lastRuler, lastRoyals: this.lastRoyals };
  }
  load(d: CineSave | undefined) {
    if (!d) return;
    this.seen = new Set(d.seen ?? []);
    this.cooldowns = d.cooldowns ?? {};
    this.lastRuler = d.lastRuler ?? -1;
    this.lastRoyals = d.lastRoyals ?? -1;
  }

  sceneProgress(): number {
    if (!this.scene) return 0;
    return this.scene.t / SCENE_BY_ID[this.scene.id].dur + 0;
  }
}
