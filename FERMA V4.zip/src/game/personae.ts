// ===== Симуляция именных персонажей: расписания, отношения, подарки, брак =====
import type { Engine } from "./engine";
import type { Npc, NpcState } from "../types/city";
import { TILE } from "../types";
import { BUILDINGS } from "../data/buildings";
import { ITEMS } from "../data/items";
import {
  PERSONA_BY_ID, CITY_PERSONAS, WORLD_PERSONAS, HOME_RU,
  type PersonaDef, type PersonaPlace, tierOf, type BondTier,
  GREET_POOL, CHAT_POOL, GIFT_POOL, ROMANCE_POOL, PROPOSE_ACCEPT,
} from "../data/npcs";
import { clamp } from "../lib/noise";
import { snd } from "../lib/sound";

export interface Bond {
  f: number;        // дружба -100..100
  h: number;        // романтика 0..100
  met: boolean;
  talkDay: number;  // в какой день последний раз говорили
  giftDay: number;  // последний день подарка
}

export interface PersonaSave {
  bonds: Record<string, Bond>;
  playerSpouse: string | null;
}

const rndPick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
/** Детерминированный выбор реплики на сегодня — чтобы текст не мигал при перерисовке */
function dayPick<T>(arr: T[], seedStr: string, day: number): T {
  let h = day * 2654435761;
  for (let i = 0; i < seedStr.length; i++) h = ((h ^ seedStr.charCodeAt(i)) * 16777619) >>> 0;
  return arr[h % arr.length];
}

export class PersonaSim {
  bonds: Record<string, Bond> = {};
  playerSpouse: string | null = null;
  private guestIds = new Set<string>();  // мирные гости, сейчас в городе
  private guestUntil = 0;

  reset() {
    this.bonds = {}; this.playerSpouse = null;
    this.guestIds = new Set(); this.guestUntil = 0;
  }

  bond(id: string): Bond {
    let b = this.bonds[id];
    if (!b) { b = { f: 0, h: 0, met: false, talkDay: -1, giftDay: -1 }; this.bonds[id] = b; }
    return b;
  }
  defOf(n: Npc): PersonaDef | null { return n.persona ? (PERSONA_BY_ID[n.persona] ?? null) : null; }

  // ---------- Появление городского состава ----------
  ensureCast(e: Engine) {
    if (!e.city.s.founded) return;
    const have = new Set(e.npcs.npcs.filter((n) => n.persona).map((n) => n.persona!));
    for (const p of CITY_PERSONAS) {
      if (have.has(p.id)) continue;
      const n = e.npcs.spawnOne(e, p.spriteBase);
      this.bind(n, p);
    }
  }

  private bind(n: Npc, p: PersonaDef) {
    n.persona = p.id;
    n.name = p.name;
    n.age = p.age;
    n.sex = p.sex;
    n.quest = null; // у именных — своя линия просьб/проблем
    n.mood = 15;
    if (this.playerSpouse === p.id) n.spouse = -1;
  }

  /** Гость из мира заезжает на денёк */
  private inviteGuest(e: Engine) {
    const present = new Set(e.npcs.npcs.filter((n) => n.persona).map((n) => n.persona!));
    const cands = WORLD_PERSONAS.filter((p) => !present.has(p.id) && p.home !== "city");
    if (!cands.length) return;
    const p = rndPick(cands);
    const n = e.npcs.spawnOne(e, p.spriteBase);
    this.bind(n, p);
    // гость живёт у таверны/площади
    const c = e.city.s;
    n.hx = (c.cx + (Math.random() - 0.5) * 8) * TILE;
    n.hy = (c.cy + (Math.random() - 0.5) * 8) * TILE;
    n.x = n.hx; n.y = n.hy; n.tx = n.hx; n.ty = n.hy;
    this.guestIds.add(p.id);
    this.guestUntil = e.day + 1;
    e.toast(`В город прибыл(а) ${p.name} — ${p.profession.toLowerCase()} из «${HOME_RU[p.home]}»`, "info");
    e.nations.log(e, `Гость города: ${p.name} (${HOME_RU[p.home]})`, "info");
  }

  // ---------- Расписание ----------
  placeFor(p: PersonaDef, hour: number): PersonaPlace {
    const guest = this.guestIds.has(p.id);
    if (guest && hour >= 21) return "tavern";
    if (hour >= 6 && hour < 9) return p.schedule.morning;
    if (hour >= 9 && hour < 18) return p.schedule.day;
    if (hour >= 18 && hour < 23) return p.schedule.evening;
    return p.schedule.night;
  }

  private bld(e: Engine, ids: string[]): { x: number; y: number } | null {
    const list = e.buildings.filter((b) => b.done && ids.includes(b.def));
    if (!list.length) return null;
    const b = list[Math.floor(Math.random() * list.length)];
    const d = BUILDINGS[b.def];
    return { x: (b.tx + d.w / 2) * TILE, y: (b.ty + d.h / 2) * TILE };
  }

  /** Точка назначения по месту расписания */
  anchor(e: Engine, n: Npc, place: PersonaPlace): { x: number; y: number; state: NpcState } {
    const c = e.city.s;
    const sq = () => ({
      x: (c.cx + (Math.random() - 0.5) * 10) * TILE,
      y: (c.cy + (Math.random() - 0.5) * 10) * TILE,
      state: "walk" as NpcState,
    });
    switch (place) {
      case "home": return { x: n.hx, y: n.hy, state: "home" };
      case "work": return { x: n.wx, y: n.wy, state: "work" };
      case "tavern": {
        const t = this.bld(e, ["taverna", "kuhnya"]) ?? this.bld(e, ["dom", "osobnyak"]);
        return t ? { ...t, state: "tavern" } : { x: n.hx, y: n.hy, state: "home" };
      }
      case "market": {
        const m = this.bld(e, ["rynok", "birzha", "bank", "karavan_saray"]);
        return m ? { ...m, state: "walk" } : sq();
      }
      case "temple": {
        const t = this.bld(e, ["hram", "sobor", "monastyr", "altar"]);
        return t ? { ...t, state: "walk" } : sq();
      }
      case "gate": {
        const g = this.bld(e, ["vorota", "bashnya", "vyshka", "kazarmy"]);
        if (g) return { ...g, state: "walk" };
        const a = Math.random() * Math.PI * 2;
        return { x: (c.cx + Math.cos(a) * 12) * TILE, y: (c.cy + Math.sin(a) * 12) * TILE, state: "walk" };
      }
      case "port": {
        const p = this.bld(e, ["torg_port", "karavan_saray", "rynok"]);
        return p ? { ...p, state: "walk" } : sq();
      }
      case "wild": {
        const a = Math.random() * Math.PI * 2, r = 14 + Math.random() * 8;
        return { x: (c.cx + Math.cos(a) * r) * TILE, y: (c.cy + Math.sin(a) * r) * TILE, state: "walk" };
      }
      case "square": default: return sq();
    }
  }

  /** Вызывается из NpcSim при пересмотре расписания персоны */
  applySchedule(e: Engine, n: Npc, hour: number) {
    const p = this.defOf(n);
    if (!p) return;
    const place = this.placeFor(p, hour);
    // ночью чудища гонят всех внутрь (кроме стражи); бунт важнее
    if (n.state === "riot" || n.state === "flee") return;
    const t = this.anchor(e, n, place);
    n.state = t.state;
    n.tx = t.x; n.ty = t.y;
  }

  // ---------- Диалог ----------
  dialog(e: Engine, n: Npc): {
    def: PersonaDef; bond: Bond; tier: BondTier;
    lines: string[]; romanceTier: "cold" | "warm" | "inlove" | null;
    canChat: boolean; canGift: boolean; canPropose: boolean;
  } {
    const def = this.defOf(n)!;
    const bond = this.bond(def.id);
    if (!bond.met) {
      bond.met = true;
      bond.f = clamp(bond.f + 4, -100, 100);
      e.addXp(3);
      e.stats.met = (e.stats.met ?? 0) + 1;
    }
    const tier = tierOf(bond.f);
    const lines: string[] = [];
    lines.push(dayPick(GREET_POOL[def.character][tier], def.id + tier, e.day));
    if (bond.talkDay === e.day) lines.push(dayPick(CHAT_POOL[def.character], def.id + "c", e.day));
    const romanceTier = def.romance ? (bond.h >= 70 ? "inlove" : bond.h >= 35 ? "warm" : "cold") : null;
    if (def.romance && bond.h >= 35) lines.push(dayPick(ROMANCE_POOL[romanceTier as "warm" | "inlove"], def.id + "r", e.day));
    return {
      def, bond, tier, lines, romanceTier,
      canChat: bond.talkDay !== e.day,
      canGift: bond.giftDay !== e.day,
      canPropose: !!def.romance && !this.playerSpouse && bond.h >= 80,
    };
  }

  /** Поговорить: +дружба раз в день */
  chat(e: Engine, n: Npc): string {
    const def = this.defOf(n)!;
    const bond = this.bond(def.id);
    if (bond.talkDay === e.day) return rndPick(CHAT_POOL[def.character]);
    bond.talkDay = e.day;
    bond.f = clamp(bond.f + (def.character === "zloi" ? 4 : 6), -100, 100);
    if (def.romance && bond.f >= 12) bond.h = clamp(bond.h + 2, 0, 100);
    n.talkT = 2.5;
    e.addXp(2);
    if (e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness + 0.1, 0, 100);
    e.poke();
    return rndPick(CHAT_POOL[def.character]);
  }

  /** Подарок из инвентаря */
  gift(e: Engine, n: Npc, itemId: string): { text: string; kind: "like" | "neutral" | "dislike" } {
    const def = this.defOf(n)!;
    const bond = this.bond(def.id);
    if (bond.giftDay === e.day) return { text: "Сегодня подарков уже достаточно. Приходи завтра.", kind: "neutral" };
    if (e.count(itemId) < 1) return { text: "У вас нет такой вещи.", kind: "neutral" };
    e.take(itemId, 1);
    bond.giftDay = e.day;
    let kind: "like" | "neutral" | "dislike";
    if (def.likedGifts.includes(itemId)) {
      kind = "like";
      bond.f = clamp(bond.f + 22, -100, 100);
      if (def.romance) bond.h = clamp(bond.h + 11, 0, 100);
      n.mood = clamp(n.mood + 15, -100, 100);
      e.addXp(5);
      e.spawnHitParticles(n.x, n.y - 18, "#ff8ab2", 10, "star");
      snd.levelup();
    } else if (def.dislikedGifts.includes(itemId)) {
      kind = "dislike";
      bond.f = clamp(bond.f - 16, -100, 100);
      if (def.romance) bond.h = clamp(bond.h - 6, 0, 100);
      n.mood = clamp(n.mood - 10, -100, 100);
      snd.hurt();
    } else {
      kind = "neutral";
      bond.f = clamp(bond.f + 6, -100, 100);
      if (def.romance) bond.h = clamp(bond.h + 2, 0, 100);
      n.mood = clamp(n.mood + 6, -100, 100);
      snd.pickup();
    }
    const text = rndPick(GIFT_POOL[def.character][kind]);
    e.toast(`${def.name}: ${kind === "like" ? "в восторге" : kind === "dislike" ? "расстроен(а)" : "принимает подарок"}`, kind === "dislike" ? "warn" : "good");
    e.poke();
    return { text, kind };
  }

  /** Предложение руки и сердца */
  propose(e: Engine, n: Npc): string {
    const def = this.defOf(n)!;
    const bond = this.bond(def.id);
    if (!def.romance || this.playerSpouse || bond.h < 80) return "…";
    this.playerSpouse = def.id;
    bond.h = 100; bond.f = 100;
    n.spouse = -1; // пометка «за игроком», чтобы горожане не женили его/её
    e.addXp(60);
    e.stats.married = (e.stats.married ?? 0) + 1;
    e.nations.log(e, `Свадьба: ${def.name} и правитель ${e.worldName}`, "good");
    e.dynasty.support("narod", 6);
    if (e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness + 6, 0, 100);
    snd.playMusic("victory");
    if (e.cine) e.cine.fireEvent(e, "svadba");
    e.poke();
    return PROPOSE_ACCEPT;
  }

  /** Кто сейчас в городе (для UI/панелей) */
  present(e: Engine): { def: PersonaDef; n: Npc; bond: Bond }[] {
    return e.npcs.npcs
      .map((n) => ({ n, def: this.defOf(n) }))
      .filter((x): x is { n: Npc; def: PersonaDef } => !!x.def)
      .map((x) => ({ def: x.def, n: x.n, bond: this.bond(x.def.id) }));
  }

  // ---------- Циклы ----------
  dayTick(e: Engine) {
    if (!e.city.s.founded) return;
    this.ensureCast(e);
    // гости приезжают/уезжают
    if (this.guestUntil < e.day && this.guestIds.size) {
      this.guestIds.clear();
      e.npcs.npcs = e.npcs.npcs.filter((n) => {
        if (!n.persona) return true;
        if (CITY_PERSONAS.some((p) => p.id === n.persona)) return true;
        return this.playerSpouse === n.persona; // супруг(а) остаётся
      });
    }
    if (Math.random() < 0.45) this.inviteGuest(e);
    // лёгкая переадресация маршрутов
    for (const n of e.npcs.npcs) if (n.persona && Math.random() < 0.3) {
      const hour = (6 + e.time * 24) % 24;
      this.applySchedule(e, n, hour);
    }
  }

  update(e: Engine, _dt: number) {
    if (e.city.s.founded) this.ensureCast(e);
    void _dt;
  }

  // ---------- Сохранение ----------
  serialize(): PersonaSave {
    return { bonds: JSON.parse(JSON.stringify(this.bonds)), playerSpouse: this.playerSpouse };
  }
  load(d: PersonaSave | undefined) {
    if (!d) return;
    this.bonds = d.bonds ?? {};
    this.playerSpouse = d.playerSpouse ?? null;
  }
}

/** Подпись для диалога: характер, возраст, профессия */
export function personaSub(def: PersonaDef, tier: BondTier): string {
  const t = { enemy: "недоброжелатель", stranger: "незнакомец", known: "знакомый", pal: "приятель", friend: "друг" }[tier];
  return `${def.profession} · ${def.age} лет · ${t}`;
}
/** Название предмета для gift-списка */
export function itemName(id: string): string { return ITEMS[id]?.name ?? id; }
