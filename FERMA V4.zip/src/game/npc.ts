import type { Engine } from "./engine";
import type { Npc, NpcRole } from "../types";
import { NPC_ROLES } from "../types/city";
import { BUILDINGS } from "../data/buildings";
import { NAMES_M, NAMES_F, SURNAMES } from "../data/citydata";
import { ITEMS } from "../data/items";
import { TILE } from "../types";
import { clamp, pickW } from "../lib/noise";
import { snd } from "../lib/sound";

const MAX_NPC = 30;
const QUEST_ITEMS = ["brevno", "kamen", "yagoda", "kozha", "grib", "nit", "ugol", "myaso", "glina", "zerno"];

export class NpcSim {
  npcs: Npc[] = [];
  uid = 1;
  private t = 0;
  private roadT = 0;

  reset() { this.npcs = []; this.uid = 1; }

  private rnd(): number { return Math.random(); }
  private name(sex: 0 | 1): string {
    const first = sex === 0 ? NAMES_M[Math.floor(this.rnd() * NAMES_M.length)] : NAMES_F[Math.floor(this.rnd() * NAMES_F.length)];
    const sur = SURNAMES[Math.floor(this.rnd() * SURNAMES.length)];
    return `${first} ${sex === 1 ? sur.replace(/(ов|ев|ин|ый|ой|ик|ь|р|л|н|ц|т)$/, (m) => (m === "ов" || m === "ев" || m === "ин" ? m + "а" : m + "а")) : sur}`;
  }

  private roleFor(e: Engine): NpcRole {
    const has = (id: string) => e.buildings.some((b) => b.done && b.def === id);
    const table: [NpcRole, number][] = [
      ["krestyanin", 30],
      ["remeslennik", e.buildings.some((b) => b.done && BUILDINGS[b.def]?.chain) ? 22 : 8],
      ["kupec", has("rynok") || has("birzha") || has("bank") ? 18 : 6],
      ["strazhnik", has("kazarmy") || has("bashnya") ? 16 : 5],
      ["uchenyi", has("biblioteka") || has("akademiya") || has("universitet") ? 14 : 2],
      ["svyashennik", has("hram") || has("sobor") || has("monastyr") ? 12 : 1],
      ["mag", has("altar") || has("portal") ? 10 : 1],
      ["rebenok", 14],
      ["starik", 8],
      ["strannik", 5],
    ];
    return pickW(this.rnd(), table);
  }

  private pickBuilding(e: Engine, filter: (id: string) => boolean): { x: number; y: number } | null {
    const list = e.buildings.filter((b) => b.done && filter(b.def));
    if (!list.length) return null;
    const b = list[Math.floor(this.rnd() * list.length)];
    const def = BUILDINGS[b.def];
    return { x: (b.tx + def.w / 2) * TILE, y: (b.ty + def.h / 2) * TILE };
  }

  spawnOne(e: Engine, role?: NpcRole) {
    const c = e.city.s;
    const sex: 0 | 1 = this.rnd() < 0.5 ? 0 : 1;
    const r = role ?? this.roleFor(e);
    const home = this.pickBuilding(e, (id) => (BUILDINGS[id]?.housing ?? 0) > 0)
      ?? { x: c.cx * TILE, y: c.cy * TILE };
    const work = this.pickBuilding(e, (id) => (BUILDINGS[id]?.jobs ?? 0) > 0) ?? home;
    const age = r === "rebenok" ? 4 + Math.floor(this.rnd() * 10)
      : r === "starik" ? 58 + Math.floor(this.rnd() * 20)
        : 18 + Math.floor(this.rnd() * 34);
    const npc: Npc = {
      uid: this.uid++, name: this.name(sex), role: r, sex, age,
      x: home.x + (this.rnd() - 0.5) * 60, y: home.y + (this.rnd() - 0.5) * 60,
      tx: home.x, ty: home.y, hx: home.x, hy: home.y, wx: work.x, wy: work.y,
      state: "walk", t: this.rnd() * 4, mood: 10 + Math.floor(this.rnd() * 30),
      spouse: 0, children: [], anim: this.rnd() * 6, talkT: 0,
      quest: this.rnd() < 0.22 ? {
        item: QUEST_ITEMS[Math.floor(this.rnd() * QUEST_ITEMS.length)],
        n: 3 + Math.floor(this.rnd() * 8),
        reward: 40 + Math.floor(this.rnd() * 120),
      } : null,
      bob: this.rnd() * 6,
    };
    this.npcs.push(npc);
    return npc;
  }

  /** Держим число жителей на улицах в соответствии с населением.
   *  Именные персонажи (persona) неудаляемы и не в счёт лимита толпы. */
  syncPopulation(e: Engine) {
    if (!e.city.s.founded) {
      if (this.npcs.length) this.npcs = this.npcs.filter((n) => !!n.persona);
      return;
    }
    const personas = this.npcs.filter((n) => n.persona).length;
    const target = clamp(Math.round(e.city.s.pop * 0.55), 2, MAX_NPC);
    while (this.npcs.length - personas < target) this.spawnOne(e);
    while (this.npcs.length - personas > target) {
      // убираем только безымянных
      const i = this.npcs.findIndex((n) => !n.persona);
      if (i === -1) break;
      this.npcs.splice(i, 1);
    }
  }

  startRiot(e: Engine) {
    for (const n of this.npcs) {
      if (n.role === "strazhnik") continue;
      if (Math.random() < 0.7) { n.state = "riot"; n.t = 30 + Math.random() * 40; n.mood -= 25; }
    }
    void e;
  }
  calmRiot() {
    for (const n of this.npcs) if (n.state === "riot") { n.state = "walk"; n.t = 2; n.mood += 12; }
  }

  /** Диалог с жителем */
  greet(e: Engine, n: Npc): { title: string; lines: string[]; quest: Npc["quest"]; canGive: boolean } {
    const mood = n.mood;
    const role = NPC_ROLES[n.role].name;
    const lines: string[] = [];
    if (e.city.s.rioting) lines.push("Нам нечего терять! Народ вышел на площадь!");
    else if (mood > 60) lines.push("Долгих лет вам, благодетель! Город помнит добро.");
    else if (mood > 25) lines.push("Доброго дня. Дела идут, слава небесам.");
    else if (mood > -10) lines.push("Здравствуйте. Живём помаленьку.");
    else if (mood > -45) lines.push("А, это вы… Налоги-то немалые нынче.");
    else lines.push("Уйдите прочь. От вашей власти одни беды.");

    if (e.city.s.founded) {
      const m = e.city.s.metrics;
      if (m.food < 80) lines.push("В амбарах пусто, дети просят хлеба.");
      else if (m.water < 80) lines.push("За водой ходим далеко, колодцев мало.");
      else if (m.crime > 45) lines.push("По ночам страшно — лихие люди шалят.");
      else if (e.city.s.happiness > 70) lines.push("Хорошо в нашем городе. И ярмарка, и праздники.");
    }
    if (n.spouse) lines.push(n.sex === 0 ? "Жена ждёт дома, надо поспешить." : "Муж с работы вернётся — ужин греть.");
    if (n.children.length) lines.push(`Детишек у нас ${n.children.length}. Растут не по дням.`);
    if (n.role === "razbojnik") lines.push("Дорога нынче опасна… для тех, у кого кошель тугой.");
    return { title: `${n.name}, ${role}, ${n.age} лет`, lines, quest: n.quest, canGive: !!n.quest && e.count(n.quest.item) >= n.quest.n };
  }

  completeQuest(e: Engine, n: Npc) {
    if (!n.quest) return;
    if (e.count(n.quest.item) < n.quest.n) { e.toast("Не хватает припасов", "warn"); return; }
    e.take(n.quest.item, n.quest.n);
    e.player.gold += n.quest.reward;
    n.mood = clamp(n.mood + 35, -100, 100);
    e.addXp(10);
    e.toast(`${n.name} благодарит вас: +${n.quest.reward} золота`, "good");
    snd.levelup();
    if (e.city.s.founded) e.city.s.happiness = clamp(e.city.s.happiness + 1.2, 0, 100);
    e.dynasty.support("narod", 2);
    n.quest = null;
    e.poke();
  }

  // ---------- Обновление ----------
  update(e: Engine, dt: number) {
    if (!this.npcs.length) return;
    this.t -= dt;
    this.roadT -= dt;
    const reSchedule = this.t <= 0;
    if (reSchedule) this.t = 1.2;
    const night = e.isNight();
    const hour = (6 + e.time * 24) % 24;

    for (const n of this.npcs) {
      n.anim += dt;
      n.bob += dt;
      if (n.talkT > 0) n.talkT -= dt;

      // расписание
      if (reSchedule && n.state !== "riot" && n.state !== "flee") {
        const rioting = e.city.s.rioting;
        if (n.persona && !rioting) { e.personae.applySchedule(e, n, hour); } // именные — по своему распорядку
        else if (rioting) { /* обработано в startRiot */ }
        else if (night && hour > 21) { n.state = "home"; n.tx = n.hx; n.ty = n.hy; }
        else if (hour >= 8 && hour < 18 && n.role !== "rebenok" && n.role !== "starik") { n.state = "work"; n.tx = n.wx; n.ty = n.wy; }
        else if (hour >= 18 && hour < 21) {
          const tav = this.pickBuilding(e, (id) => !!BUILDINGS[id]?.tavern);
          if (tav && Math.random() < 0.6) { n.state = "tavern"; n.tx = tav.x; n.ty = tav.y; }
          else { n.state = "home"; n.tx = n.hx; n.ty = n.hy; }
        } else if (Math.random() < 0.4) {
          n.state = "walk";
          const c = e.city.s;
          n.tx = (c.cx + (Math.random() - 0.5) * 16) * TILE;
          n.ty = (c.cy + (Math.random() - 0.5) * 16) * TILE;
        }
      }
      if (n.state === "riot") {
        n.t -= dt;
        const c = e.city.s;
        n.tx = (c.cx + Math.cos(n.anim * 0.7 + n.uid) * 4) * TILE;
        n.ty = (c.cy + Math.sin(n.anim * 0.7 + n.uid) * 4) * TILE;
        if (n.t <= 0) { n.state = "walk"; }
      }
      // ночью подальше от чудищ
      if (night && e.enemiesNear(8) > 0 && n.role !== "strazhnik") { n.state = "home"; n.tx = n.hx; n.ty = n.hy; }

      // движение
      const dx = n.tx - n.x, dy = n.ty - n.y;
      const d = Math.hypot(dx, dy);
      if (d > 8) {
        let sp = (n.role === "rebenok" ? 1.9 : n.role === "starik" ? 0.9 : 1.45) * TILE;
        if (n.state === "riot") sp *= 1.3;
        // дороги ускоряют
        if (this.roadT <= 0) {
          const b = e.buildingAt(Math.floor(n.x / TILE), Math.floor(n.y / TILE));
          n.talkT = n.talkT; // no-op
          if (b && BUILDINGS[b.def]?.road) sp *= 1.5;
        }
        const nx = n.x + (dx / d) * sp * dt;
        const ny = n.y + (dy / d) * sp * dt;
        if (!e.isBlocked(Math.floor(nx / TILE), Math.floor(n.y / TILE), true)) n.x = nx;
        if (!e.isBlocked(Math.floor(n.x / TILE), Math.floor(ny / TILE), true)) n.y = ny;
      } else if (n.state === "walk" && Math.random() < dt * 0.4) {
        // болтовня с соседом
        const other = this.npcs.find((o) => o !== n && Math.abs(o.x - n.x) < 46 && Math.abs(o.y - n.y) < 46);
        if (other) { n.talkT = 2.5; other.talkT = 2.5; }
      }
    }
    if (this.roadT <= 0) this.roadT = 0.5;
  }

  dayTick(e: Engine) {
    if (!e.city.s.founded) return;
    const c = e.city.s;
    for (const n of [...this.npcs]) {
      // именные персонажи вечны: не стареют, не женятся на горожанах, не умирают
      if (n.persona) {
        n.mood = clamp(n.mood + (c.happiness - 50) * 0.12, -100, 100);
        continue;
      }
      n.age += 1;
      // настроение тянется к счастью города
      n.mood = clamp(n.mood + (c.happiness - 50) * 0.12, -100, 100);
      // взросление
      if (n.role === "rebenok" && n.age >= 16) {
        n.role = this.roleFor(e);
        e.toast(`${n.name} вырос и стал: ${NPC_ROLES[n.role].name}`, "info");
      }
      if (n.age > 62 && n.role !== "starik" && Math.random() < 0.3) n.role = "starik";
      // свадьбы
      if (!n.spouse && n.age >= 18 && n.age < 55 && Math.random() < 0.16) {
        const cand = this.npcs.find((o) => o !== n && !o.spouse && o.sex !== n.sex && o.age >= 18 && o.age < 55);
        if (cand) {
          n.spouse = cand.uid; cand.spouse = n.uid;
          n.mood = clamp(n.mood + 18, -100, 100);
          cand.mood = clamp(cand.mood + 18, -100, 100);
          e.toast(`Свадьба: ${n.name} и ${cand.name} сыграли пир`, "good");
          c.happiness = clamp(c.happiness + 1.5, 0, 100);
        }
      }
      // дети
      if (n.spouse && n.sex === 1 && n.age < 44 && Math.random() < 0.14 && this.npcs.length < MAX_NPC) {
        const baby = this.spawnOne(e, "rebenok");
        baby.age = 0;
        baby.hx = n.hx; baby.hy = n.hy; baby.x = n.x; baby.y = n.y;
        n.children.push(baby.uid);
        const sp = this.npcs.find((o) => o.uid === n.spouse);
        if (sp) sp.children.push(baby.uid);
        c.pop += 1;
        e.toast(`В семье ${n.name} родился ребёнок — ${baby.name}`, "good");
      }
      // смерть от старости
      if (n.age > 68 && Math.random() < (n.age - 68) * 0.035 + 0.05) {
        this.npcs = this.npcs.filter((x) => x.uid !== n.uid);
        const sp = this.npcs.find((o) => o.uid === n.spouse);
        if (sp) { sp.spouse = 0; sp.mood -= 20; }
        c.pop = Math.max(0, c.pop - 1);
        e.toast(`${n.name} отошёл к предкам в ${n.age} лет`, "info");
      }
    }
    this.syncPopulation(e);
  }

  /** Житель под курсором */
  at(wx: number, wy: number): Npc | undefined {
    return this.npcs.find((n) => (n.x - wx) ** 2 + (n.y - wy) ** 2 < 22 * 22);
  }

  questText(n: Npc): string {
    if (!n.quest) return "";
    return `Просит принести ${ITEMS[n.quest.item]?.name ?? n.quest.item} ×${n.quest.n}. Обещает ${n.quest.reward} золота.`;
  }
}
