import { G, O, TILE, CHUNK, SOLID_GROUND, SOLID_OBJ, DIGGABLE, Biome, BIOME_NAMES } from "../types";
import type {
  PlayerState, Mob, Particle, Floater, Building, SaveData, WeatherId,
  TileMod, Vec, Toast, Projectile, InvSlot, EquipSlot,
} from "../types";
import { ITEMS, START_INV } from "../data/items";
import { RECIPES } from "../data/recipes";
import { BUILDINGS } from "../data/buildings";
import { MOBS, NIGHT_SPAWN, CAVE_SPAWN, DAY_SPAWN } from "../data/mobs";
import {
  MONSTER_MOBS, MONSTER_NIGHT_SPAWN, MONSTER_CAVE_SPAWN,
  MONSTER_LAYER_SPAWN, monsterBiomeSpawn, ANCIENT_ID,
} from "../data/monsters";
import { BOSS_MOBS } from "../data/bosses";
import {
  getChunk, touchChunk, tileAt, objMaxHp, chestLoot, zoneAt, ZONE_NAMES,
  zoneHpMult, zoneDmgMult, biomeAt, arenaCenter, tempN,
} from "../world/worldgen";
import { clamp, clamp01, lerp, hash2, mulberry32, pickW } from "../lib/noise";
import { saveSlot, loadSlotSync } from "../lib/save";
import { snd } from "../lib/sound";
import { CitySim, freshCity } from "./city";
import { EconomySim } from "./economy";
import { NpcSim } from "./npc";
import { DynastySim } from "./dynasty";
import { ArmySim } from "./army";
import { NationSim } from "./nations";
import { BattleSim } from "./battle";
import { LoreSim } from "./lore";
import { LayerSim } from "./layers";
import { MetaSim } from "./meta";
import { PersonaSim } from "./personae";
import { CineSim } from "./cutscenes";
import type { MetaSave, GameMode } from "../types/meta";
import { MODE_BY_ID } from "../types/meta";
import type { LayerSave } from "./layers";
import { LAYER_MOBS, LAYER_BY_ID, L } from "../data/layers";
import { layerDrop } from "../world/layergen";
import type { LoreSave } from "../types/lore";
import { SCHOOLS } from "../types/lore";
import { TECHS, TECH_BY_ID } from "../data/tech";
import { RITUALS } from "../data/magic";
import type { Npc, TradeRoute, CitySave } from "../types";
import type { WarSave } from "../types/war";

export const DAY_LEN = 720; // секунд на полные сутки
const REACH = 2.25;
const ATK_REACH = 1.75;
const PLAYER_SPEED = 3.35; // тайлов/сек

type PendingAction = {
  kind: "harvest" | "attack" | "dig" | "drink" | "interact" | "enter" | "exit" | "collect" | "hammer" | "sleep" | "demolish";
  tx: number; ty: number; mobUid?: number; bUid?: number;
};

export interface UiSnapshot {
  hp: number; maxHp: number; food: number; water: number; stamina: number; temp: number;
  xp: number; xpNeed: number; level: number; gold: number;
  inv: InvSlot[]; equip: Partial<Record<EquipSlot, string>>;
  hours: number; minutes: number; isNight: boolean; day: number; season: number; weather: WeatherId;
  z: number; zone: number; zoneName: string; biomeName: string; tx: number; ty: number;
  enemiesNear: number; nearFire: boolean; dmgFlash: number; playerDead: boolean;
  buildDef: string | null; buildValid: boolean; buildReason: string;
  poisoned: boolean; tutorialDone: boolean; stats: Record<string, number>;
  dragonAlive: boolean; weatherT: number; time: number;
  // --- город и держава (2-й этап) ---
  cityFounded: boolean; cityName: string; cityPop: number; cityCap: number;
  cityHappy: number; cityTier: string; cityRiot: number; cityRioting: boolean;
  cityIncome: number; canFoundCity: boolean; foundHint: string;
  npcNear: number; govName: string; support: number; routeCount: number;
  uiTick: number;
  // --- война и держава (3-й этап) ---
  armyPower: number; armyMen: number; armyCap: number; squadCount: number;
  generalCount: number; upkeepGold: number; woundedCount: number;
  warCount: number; allyCount: number; vassalCount: number; envoyCount: number;
  battleActive: boolean; battleTurn: number; battleSide: 0 | 1; battleOver: boolean;
  inviteBattle: boolean; fame: number; leagueMember: boolean; incomingWar: boolean;
  // --- знание, чары, вера, культура (4-й этап) ---
  eraName: string; eraIcon: string; eraColor: string;
  science: number; sciTotal: number; sciRate: number;
  researching: string | null; researchName: string; researchProgress: number;
  techCount: number; techTotal: number;
  isMage: boolean; magicUnlocked: boolean; schoolName: string; magicLvl: number;
  mana: number; manaMax: number; spellCount: number; artifactCount: number;
  beastCount: number; ritualName: string | null; ritualLeft: number;
  religionFounded: boolean; religionName: string; religionSymbol: string;
  religionColor: string; followers: number; doctrineCount: number; inquisition: boolean;
  culture: number; cultureTotal: number; greatsReady: number; borders: number;
  cultureVictory: number;
  // --- слои мира (5-й этап) ---
  layerName: string; layerShort: string; layerIcon: string; layerColor: string;
  layerDanger: number; layerHazard: string; oxygen: number; hasGearForLayer: boolean;
  unlockedLayers: number; gateBuilding: string | null; gateLeft: number;
  spaceBuilds: number; bossHere: string | null; bossAliveHere: boolean;
  chaosRule: string;
  // --- мета (6-й этап) ---
  mode: string; modeName: string; act: number;
  questCount: number; storyTitle: string | null; questsDone: number;
  stars: number; prestige: number; rating: number;
  achCount: number; collCount: number;
  dailyStreak: number; dailyReady: boolean; dailyTasksLeft: number;
  pendingChoice: boolean; hardcoreDeath: boolean;
}

const OBJ_NAMES: Partial<Record<number, string>> = {
  [O.Oak]: "Дуб", [O.Pine]: "Сосна", [O.Birch]: "Берёза", [O.Bush]: "Ягодный куст",
  [O.Rock]: "Валун", [O.Coal]: "Угольная жила", [O.Copper]: "Медная жила", [O.Iron]: "Железная жила",
  [O.Gold]: "Золотая жила", [O.Mushroom]: "Грибы", [O.Clay]: "Глина", [O.Chest]: "Старинный сундук",
  [O.CaveIn]: "Провал в пещеру", [O.CaveOut]: "Лестница наверх", [O.GlowShroom]: "Светлячник",
  [O.Cactus]: "Кактус", [O.Reeds]: "Камыш", [O.DeadBush]: "Сухостой", [O.Bones]: "Старые кости",
};

export class Engine {
  seed = 1;
  z: number = 0;
  time = 0.055;
  day = 1;
  weather: WeatherId = "clear";
  weatherT = 200;
  player: PlayerState = this.freshPlayer();
  mobs: Mob[] = [];
  buildings: Building[] = [];
  bIndex = new Map<string, Building>();
  particles: Particle[] = [];
  floaters: Floater[] = [];
  projectiles: Projectile[] = [];
  mods = new Map<string, TileMod>();
  cam = { x: 0, y: 0, zoom: 1.15, panX: 0, panY: 0, follow: true };
  pointer: Vec = { x: 0, y: 0 };
  moveTarget: Vec | null = null;
  pending: PendingAction | null = null;
  keys = new Set<string>();
  buildDef: string | null = null;
  buildGhost = { tx: 0, ty: 0, valid: false, reason: "" };
  dragonDead = false;
  stats: Record<string, number> = {};
  tutorialStep = 0;
  dmgFlash = 0;
  shake = 0;
  freeze = 0;
  paused = false;
  slot = 1;
  worldName = "Новая земля";
  swingCd = 0;
  hammerCd = 0;
  bumpFx = { tx: 0, ty: 0, t: 0 }; // подсветка тайла ствола, в который уперлись
  crownFade = 0; // 0..1 — плавная растворённость кроны над головой героя
  private bumpCd = 0;
  private uid = 1;
  private rng = mulberry32(12345);
  private autosaveT = 30;
  private spawnT = 2;
  private uiT = 0;
  private dragonCheckT = 2;
  private uiListeners = new Set<() => void>();
  private toastListeners = new Set<(t: Toast) => void>();
  private toastId = 1;
  onOpenPanel: ((p: string) => void) | null = null;

  // ---- Системы 2-го этапа ----
  city = new CitySim();
  economy = new EconomySim();
  npcs = new NpcSim();
  dynasty = new DynastySim();
  // ---- Системы 3-го этапа ----
  army = new ArmySim();
  nations = new NationSim();
  battle = new BattleSim();
  // ---- Система 4-го этапа ----
  lore = new LoreSim();
  layers = new LayerSim();
  meta = new MetaSim();
  mode: GameMode = "normal";
  hardcoreDeath = false;
  personae = new PersonaSim();
  cine = new CineSim();
  timeScale = 1; // замедление времени для кинематографики
  activeNation: string | null = null;
  activeNpc: Npc | null = null;
  activeBuilding: Building | null = null;
  private lastDay = 1;
  private uiTick = 0;

  // ---------- База ----------
  private freshPlayer(): PlayerState {
    return {
      x: 0, y: 0, dir: 0, moving: false,
      hp: 100, maxHp: 100, food: 82, water: 78, stamina: 100, temp: 18,
      xp: 0, level: 1, gold: 0, inv: [], equip: {}, dead: false,
      swing: 0, swingDir: 1, poisonT: 0,
    };
  }

  newGame(seed: number, slot: number, name: string) {
    this.seed = seed; this.slot = slot; this.worldName = name;
    this.z = 0; this.time = 0.055; this.day = 1; this.weather = "clear"; this.weatherT = 260;
    this.player = this.freshPlayer();
    for (const s of START_INV) this.give(s.id, s.n, true);
    this.mobs = []; this.buildings = []; this.bIndex.clear();
    this.particles = []; this.floaters = []; this.projectiles = [];
    this.mods.clear(); this.dragonDead = false;
    this.stats = {}; this.tutorialStep = 0; this.dmgFlash = 0;
    this.rng = mulberry32(seed ^ 0x9e37);
    // системы города
    this.city = new CitySim();
    this.city.s = freshCity();
    this.economy = new EconomySim();
    this.economy.init(seed);
    this.npcs = new NpcSim();
    this.npcs.reset();
    this.dynasty = new DynastySim();
    this.dynasty.init(1);
    this.army = new ArmySim();
    this.army.reset();
    this.nations = new NationSim();
    this.nations.init(seed);
    this.battle = new BattleSim();
    this.battle.reset();
    this.lore = new LoreSim();
    this.lore.init(seed);
    this.layers = new LayerSim();
    this.layers.reset();
    this.personae = new PersonaSim();
    this.personae.reset();
    this.cine = new CineSim();
    this.cine.reset();
    this.timeScale = 1;
    const keepMode = this.mode;
    this.meta = new MetaSim();
    this.meta.init(keepMode);
    this.player.gold = this.meta.startGold();
    this.player.maxHp += this.meta.bonusHp();
    this.player.hp = this.player.maxHp;
    this.lore.magic.manaMax += this.meta.bonusMana();
    if (MODE_BY_ID[keepMode].freeBuild) {
      for (const lid of [0, 1, 2, 3, 4]) this.layers.unlocked.add(lid);
    }
    this.lastDay = 1;
    const sp = this.findSpawn();
    this.player.x = sp.x * TILE + TILE / 2; this.player.y = sp.y * TILE + TILE / 2;
    this.cam.x = this.player.x; this.cam.y = this.player.y;
    this.cam.follow = true; this.cam.panX = 0; this.cam.panY = 0;
    this.toast(`Вы просыпаетесь в земле «${ZONE_NAMES[0]}»`, "info");
    this.meta.startStory(this);
    this.meta.log(this, `Начало пути в землях «${ZONE_NAMES[0]}». Режим: ${MODE_BY_ID[this.mode].name}`, "story");
  }

  private findSpawn(): Vec {
    for (let r = 0; r < 90; r++) {
      for (let a = 0; a < Math.max(1, r * 8); a++) {
        const ang = (a / Math.max(1, r * 8)) * Math.PI * 2;
        const tx = Math.round(Math.cos(ang) * r), ty = Math.round(Math.sin(ang) * r);
        const t = tileAt(this.seed, tx, ty, 0);
        if (!SOLID_GROUND.has(t.g) && !SOLID_OBJ.has(t.o) && zoneAt(tx, ty) === 0) return { x: tx, y: ty };
      }
    }
    return { x: 0, y: 0 };
  }

  // ---------- Доступ к миру ----------
  chunkAt(tx: number, ty: number) {
    return getChunk(this.seed, Math.floor(tx / CHUNK), Math.floor(ty / CHUNK), this.z, this.mods);
  }
  tileOf(tx: number, ty: number): { g: number; o: number; hp: number } {
    const c = this.chunkAt(tx, ty);
    const i = (ty - Math.floor(ty / CHUNK) * CHUNK) * CHUNK + (tx - Math.floor(tx / CHUNK) * CHUNK);
    return { g: c.g[i], o: c.o[i], hp: c.hp[i] };
  }
  setTile(tx: number, ty: number, o: number, hp?: number, g?: number) {
    const key = `${tx},${ty},${this.z}`;
    const prev: TileMod = this.mods.get(key) ?? {};
    this.mods.set(key, { ...prev, o, g: g ?? prev.g, hp });
    const c = this.chunkAt(tx, ty);
    const i = (ty - Math.floor(ty / CHUNK) * CHUNK) * CHUNK + (tx - Math.floor(tx / CHUNK) * CHUNK);
    c.o[i] = o; if (g !== undefined) c.g[i] = g;
    c.hp[i] = hp ?? objMaxHp(o as 0);
    touchChunk(c);
  }

  buildingAt(tx: number, ty: number): Building | undefined {
    for (let dy = 0; dy < 4; dy++) for (let dx = 0; dx < 4; dx++) {
      const b = this.bIndex.get(`${tx - dx},${ty - dy}`);
      if (b) {
        const def = BUILDINGS[b.def];
        if (tx - (b.tx) >= 0 && tx - b.tx < def.w && ty - b.ty >= 0 && ty - b.ty < def.h) return b;
      }
    }
    return undefined;
  }

  isBlocked(tx: number, ty: number, forMob = false, flying = false): boolean {
    const t = this.tileOf(tx, ty);
    if (SOLID_GROUND.has(t.g)) return !flying;
    if (SOLID_OBJ.has(t.o)) return true;
    const b = this.buildingAt(tx, ty);
    if (b && b.done) {
      const def = BUILDINGS[b.def];
      if (def.blocks) {
        if (def.door) return forMob ? true : !b.open;
        return true;
      }
    }
    return false;
  }

  // ---------- Инвентарь ----------
  count(id: string): number {
    if (id === "zoloto") return this.player.gold;
    return this.player.inv.filter((s) => s.id === id).reduce((a, s) => a + s.n, 0);
  }
  give(id: string, n: number, silent = false) {
    const def = ITEMS[id];
    if (!def) return;
    if (id === "zoloto") {
      this.player.gold += n;
      if (!silent) this.addFloater(`+${n} золота`, "#f2c14e", this.player.x, this.player.y - 30);
      this.poke();
      return;
    }
    let left = n;
    for (const s of this.player.inv) {
      if (s.id === id && s.n < def.stack) {
        const add = Math.min(left, def.stack - s.n);
        s.n += add; left -= add;
        if (left <= 0) break;
      }
    }
    while (left > 0) {
      const add = Math.min(left, def.stack);
      this.player.inv.push({ id, n: add });
      left -= add;
    }
    if (!silent) {
      this.addFloater(`+${n} ${def.name}`, "#a8e68a", this.player.x, this.player.y - 30);
      snd.pickup();
    }
    this.meta.collect(this, id);
    this.meta.progress(this, "gather", id, n);
    this.poke();
  }
  take(id: string, n: number): boolean {
    if (this.count(id) < n) return false;
    if (id === "zoloto") { this.player.gold -= n; this.poke(); return true; }
    let left = n;
    for (let i = this.player.inv.length - 1; i >= 0 && left > 0; i--) {
      const s = this.player.inv[i];
      if (s.id !== id) continue;
      const sub = Math.min(left, s.n);
      s.n -= sub; left -= sub;
      if (s.n <= 0) this.player.inv.splice(i, 1);
    }
    this.poke();
    return true;
  }
  bestTool(kind: "axe" | "pick" | "shovel"): { power: number; id: string | null } {
    let best = 4, id: string | null = null;
    for (const s of this.player.inv) {
      const d = ITEMS[s.id];
      if (d?.tool === kind && (d.power ?? 1) > best) { best = d.power!; id = s.id; }
    }
    return { power: best, id };
  }
  weaponDmg(): { dmg: number; spd: number } {
    const wId = this.player.equip.weapon;
    if (wId && this.count(wId) > 0) {
      const d = ITEMS[wId];
      return { dmg: (d.dmg ?? 4) + (this.player.level - 1) * 1.2, spd: d.atkSpd ?? 1 };
    }
    let dmg = 4, spd = 1;
    for (const s of this.player.inv) {
      const d = ITEMS[s.id];
      if (d?.dmg && d.dmg > dmg) { dmg = d.dmg; spd = d.atkSpd ?? 1; }
    }
    return { dmg: dmg + (this.player.level - 1) * 1.2, spd };
  }
  armorSum(): number {
    let a = 0;
    for (const k of ["head", "body", "legs", "feet"] as EquipSlot[]) {
      const id = this.player.equip[k];
      if (id && this.count(id) > 0) a += ITEMS[id]?.armor ?? 0;
    }
    return a;
  }
  warmthSum(): number {
    let w = 0;
    for (const k of ["head", "body", "legs", "feet"] as EquipSlot[]) {
      const id = this.player.equip[k];
      if (id && this.count(id) > 0) w += ITEMS[id]?.warmth ?? 0;
    }
    return w;
  }

  // ---------- Ввод ----------
  tap(wx: number, wy: number) {
    if (this.player.dead) return;
    const tx = Math.floor(wx / TILE), ty = Math.floor(wy / TILE);
    if (this.buildDef) {
      this.buildGhost.tx = tx; this.buildGhost.ty = ty;
      this.validateBuild();
      this.poke();
      return;
    }
    // жители города
    const npc = this.npcs.at(wx, wy);
    if (npc) {
      if (this.distTo(npc.x, npc.y) <= 3) { this.activeNpc = npc; this.onOpenPanel?.("npc"); snd.uiOpen(); }
      else { this.moveTarget = { x: npc.x, y: npc.y }; this.toast(`Идём к ${npc.name}`, "info"); }
      return;
    }
    // чужой караван — можно ограбить
    const car = this.economy.foreign.find((r) => (r.x - wx) ** 2 + (r.y - wy) ** 2 < 30 * 30);
    if (car) {
      if (this.distTo(car.x, car.y) <= 2.6) this.economy.raid(this, car);
      else { this.moveTarget = { x: car.x, y: car.y }; this.toast("Подкрадываемся к каравану…", "warn"); }
      return;
    }
    // мобы
    const mob = this.mobs.find((m) => (m.x - wx) ** 2 + (m.y - wy) ** 2 < (TILE * (this.mobDef(m.def)?.scale ?? 1) * 0.75) ** 2);
    if (mob) {
      if (this.distTo(mob.x, mob.y) <= ATK_REACH) this.attackMob(mob);
      else { this.moveTarget = { x: mob.x, y: mob.y }; this.pending = { kind: "attack", tx, ty, mobUid: mob.uid }; }
      return;
    }
    const dist = this.distTo(tx * TILE + TILE / 2, ty * TILE + TILE / 2);
    const t = this.tileOf(tx, ty);
    const b = this.buildingAt(tx, ty);
    if (b) {
      const act: PendingAction = (() => {
        const def = BUILDINGS[b.def];
        if (!b.done) return { kind: "hammer", tx, ty, bUid: b.uid };
        if (def.produce && b.store > 0) return { kind: "collect", tx, ty, bUid: b.uid };
        if (def.well) return { kind: "interact", tx, ty, bUid: b.uid };
        if (def.sleep) return { kind: "sleep", tx, ty, bUid: b.uid };
        if (def.door) return { kind: "interact", tx, ty, bUid: b.uid };
        if (def.cook) return { kind: "interact", tx, ty, bUid: b.uid };
        return { kind: "interact", tx, ty, bUid: b.uid };
      })();
      if (dist <= REACH) this.doAction(act);
      else { this.moveTarget = { x: tx * TILE + TILE / 2, y: ty * TILE + TILE / 2 }; this.pending = act; }
      return;
    }
    if (t.o !== O.None) {
      const kind: PendingAction["kind"] =
        t.o === O.CaveIn ? "enter" : t.o === O.CaveOut ? "exit" : "harvest";
      if (dist <= REACH) this.doAction({ kind, tx, ty });
      else { this.moveTarget = { x: tx * TILE + TILE / 2, y: ty * TILE + TILE / 2 }; this.pending = { kind, tx, ty }; }
      return;
    }
    if ((t.g === G.Water || t.g === G.DeepWater) && dist <= REACH + 0.6) {
      this.doAction({ kind: "drink", tx, ty });
      return;
    }
    if (DIGGABLE.has(t.g) && diggOk(t.g)) {
      const tool = this.bestTool("shovel");
      if (tool.id && dist <= REACH) { this.doAction({ kind: "dig", tx, ty }); return; }
      if (tool.id) { this.moveTarget = { x: tx * TILE + TILE / 2, y: ty * TILE + TILE / 2 }; this.pending = { kind: "dig", tx, ty }; return; }
    }
    // просто идти
    this.moveTarget = { x: wx, y: wy };
    this.pending = null;
    this.stats.moved = (this.stats.moved ?? 0) + 1;
  }

  longPress(wx: number, wy: number): { label: string; act: string }[] {
    const tx = Math.floor(wx / TILE), ty = Math.floor(wy / TILE);
    const t = this.tileOf(tx, ty);
    const b = this.buildingAt(tx, ty);
    const mob = this.mobs.find((m) => Math.floor(m.x / TILE) === tx && Math.floor(m.y / TILE) === ty);
    const mobName = mob ? (this.mobDef(mob.def)?.name ?? "тварь") : "";
    const opts: { label: string; act: string }[] = [];
    opts.push({ label: "Идти сюда", act: "go" });
    if (mob) opts.push({ label: `Атаковать (${mobName})`, act: "attack" });
    if (t.o !== O.None && t.o !== O.CaveIn && t.o !== O.CaveOut) opts.push({ label: `Добыть (${OBJ_NAMES[t.o] ?? "объект"})`, act: "harvest" });
    if (t.o === O.CaveIn) opts.push({ label: "Спуститься в пещеру", act: "harvest" });
    if (t.o === O.CaveOut) opts.push({ label: "Подняться наверх", act: "harvest" });
    if ((t.g === G.Water || t.g === G.DeepWater)) opts.push({ label: "Напиться", act: "drink" });
    if (DIGGABLE.has(t.g) && this.bestTool("shovel").id) opts.push({ label: "Копать лопатой", act: "dig" });
    if (b) {
      const def = BUILDINGS[b.def];
      opts.push({ label: def && b.done ? `${def.name}` : "Достроить", act: "interact" });
      if (b.done && (b.lvl ?? 1) < (def.maxLvl ?? 3)) {
        opts.push({ label: `Улучшить до ур. ${(b.lvl ?? 1) + 1}`, act: "upgrade" });
      }
      opts.push({ label: "Снести (вернуть ½)", act: "demolish" });
    } else {
      opts.push({ label: "Осмотреть", act: "inspect" });
    }
    this.ctxTarget = { tx, ty, mobUid: mob?.uid, bUid: b?.uid };
    return opts;
  }
  ctxTarget: { tx: number; ty: number; mobUid?: number; bUid?: number } | null = null;
  contextAction(act: string) {
    const c = this.ctxTarget;
    if (!c) return;
    const { tx, ty } = c;
    const center = { x: tx * TILE + TILE / 2, y: ty * TILE + TILE / 2 };
    const dist = this.distTo(center.x, center.y);
    const goOrDo = (a: PendingAction) => {
      if (dist <= REACH) this.doAction(a);
      else { this.moveTarget = center; this.pending = a; }
    };
    switch (act) {
      case "go": this.moveTarget = center; this.pending = null; break;
      case "attack": {
        const mob = this.mobs.find((m) => m.uid === c.mobUid);
        if (mob) { this.moveTarget = { x: mob.x, y: mob.y }; this.pending = { kind: "attack", tx, ty, mobUid: mob.uid }; }
        break;
      }
      case "harvest": goOrDo({ kind: "harvest", tx, ty }); break;
      case "drink": goOrDo({ kind: "drink", tx, ty }); break;
      case "dig": goOrDo({ kind: "dig", tx, ty }); break;
      case "interact": goOrDo({ kind: "interact", tx, ty, bUid: c.bUid }); break;
      case "demolish": goOrDo({ kind: "demolish", tx, ty, bUid: c.bUid }); break;
      case "upgrade": {
        const b = this.buildings.find((x) => x.uid === c.bUid);
        if (b) this.city.upgrade(this, b);
        break;
      }
      case "inspect": {
        const t = this.tileOf(tx, ty);
        const biome = biomeAt(this.seed, tx, ty, this.z);
        const parts = [BIOME_NAMES[biome]];
        if (t.o !== O.None) parts.push(OBJ_NAMES[t.o] ?? "");
        this.toast(parts.filter(Boolean).join(" · "), "info");
        snd.ui();
        break;
      }
    }
  }

  // ---------- Действия ----------
  doAction(a: PendingAction) {
    switch (a.kind) {
      case "harvest": this.harvest(a.tx, a.ty); break;
      case "dig": this.dig(a.tx, a.ty); break;
      case "drink": this.drinkFrom(a.tx, a.ty); break;
      case "enter": this.enterCave(a.tx, a.ty); break;
      case "exit": this.exitCave(a.tx, a.ty); break;
      case "attack": {
        const mob = this.mobs.find((m) => m.uid === a.mobUid);
        if (mob) this.attackMob(mob);
        break;
      }
      case "collect": {
        const b = this.buildings.find((x) => x.uid === a.bUid);
        if (b && b.store > 0) {
          const def = BUILDINGS[b.def];
          this.give(def.produce!.id, b.store);
          this.addXp(1);
          this.toast(`${def.name}: собрано ${b.store} × ${ITEMS[def.produce!.id].name}`, "good");
          b.store = 0;
          snd.craft();
        }
        break;
      }
      case "hammer": {
        const b = this.buildings.find((x) => x.uid === a.bUid);
        if (b && !b.done && this.hammerCd <= 0) {
          b.progress += 1.1;
          this.hammerCd = 0.32;
          snd.buildHammer();
          this.spawnHitParticles(a.tx * TILE + 20, a.ty * TILE + 20, "#cbb27a", 5);
          this.shake = Math.max(this.shake, 0.08);
          if (b.progress >= BUILDINGS[b.def].buildTime) this.finishBuild(b);
        }
        break;
      }
      case "interact": {
        const b = this.buildings.find((x) => x.uid === a.bUid);
        if (!b) break;
        const def = BUILDINGS[b.def];
        if (!b.done) { this.doAction({ ...a, kind: "hammer" }); break; }
        if (def.townhall) { this.activeBuilding = b; this.onOpenPanel?.("city"); snd.uiOpen(); break; }
        if (def.cat === "Экономика") { this.activeBuilding = b; this.onOpenPanel?.("econ"); snd.uiOpen(); break; }
        if (def.id === "parlament") { this.activeBuilding = b; this.onOpenPanel?.("parl"); snd.uiOpen(); break; }
        if (def.id === "dvorec") { this.activeBuilding = b; this.onOpenPanel?.("dyn"); snd.uiOpen(); break; }
        if (def.cat === "Город" || def.chain || def.wonder || (def.jobs ?? 0) > 0) {
          this.activeBuilding = b; this.onOpenPanel?.("binfo"); snd.uiOpen(); break;
        }
        if (def.well) { this.drinkWell(); break; }
        if (def.sleep) { this.trySleep(); break; }
        if (def.door) { b.open = !b.open; snd.ui(); this.toast(b.open ? "Дверь открыта" : "Дверь закрыта", "info"); break; }
        if (def.cook) { this.onOpenPanel?.("craft"); break; }
        if (def.produce) { this.doAction({ ...a, kind: "collect" }); break; }
        this.toast(def.name, "info");
        break;
      }
      case "sleep": {
        const b = this.buildings.find((x) => x.uid === a.bUid);
        if (b && b.done) this.trySleep();
        else if (b) this.doAction({ ...a, kind: "hammer" });
        break;
      }
      case "demolish": {
        const b = this.buildings.find((x) => x.uid === a.bUid);
        if (!b) break;
        const def = BUILDINGS[b.def];
        for (const [id, n] of def.cost) this.give(id, Math.floor(n / 2));
        this.removeBuilding(b);
        this.toast(`${def.name} снесён`, "info");
        snd.dig();
        break;
      }
    }
  }

  private harvest(tx: number, ty: number) {
    if (this.swingCd > 0) return;
    const t = this.tileOf(tx, ty);
    if (t.o === O.None) return;
    if (this.player.stamina < 6) { this.toast("Вы задыхаетесь от усталости — отдохните", "warn"); return; }
    const o = t.o;
    const isTree = o === O.Oak || o === O.Pine || o === O.Birch || o === O.CloudTree || o === O.ShadowTree || o === O.Wreck;
    const isOre = o === O.Rock || o === O.Coal || o === O.Copper || o === O.Iron || o === O.Gold || o === O.Clay
      || o === O.Mithril || o === O.Adamant || o === O.Crystal || o === O.SkyCrystal
      || o === O.MoonOre || o === O.MarsOre || o === O.AlienRelic || o === O.Mechanism || o === O.LavaVent;
    const noTool = o === O.Bush || o === O.Mushroom || o === O.GlowShroom || o === O.Reeds ||
      o === O.DeadBush || o === O.Cactus || o === O.Chest || o === O.GrassTuft || o === O.FlowerR || o === O.FlowerY ||
      o === O.RuinChest || o === O.Trap || o === O.Seaweed || o === O.DreamFlower || o === O.Pearl ||
      o === O.CoralObj || o === O.ChaosOrb;
    let power = 6;
    let kind: "axe" | "pick" | null = null;
    if (isTree) { kind = "axe"; power = this.bestTool("axe").power; }
    else if (isOre) {
      kind = "pick"; power = this.bestTool("pick").power;
      if (!this.bestTool("pick").id && o !== O.Clay) { this.toast("Нужна кирка — скрафтите каменную", "warn"); return; }
      if (o === O.Clay) power = Math.max(this.bestTool("pick").power, this.bestTool("shovel").power, 6);
    } else if (!noTool) power = 4;
    this.player.stamina = Math.max(0, this.player.stamina - (kind ? 5 : 3));
    this.player.swing = 0.28;
    this.swingCd = 0.42;
    const cx = tx * TILE + TILE / 2, cy = ty * TILE + TILE / 2;
    this.player.dir = Math.atan2(cy - this.player.y, cx - this.player.x);
    const newHp = t.hp - power * this.meta.mGather();
    const hitColor = isTree ? "#8a6238" : isOre ? "#a8a29e" : "#7a9b5c";
    this.spawnHitParticles(cx, cy, hitColor, isTree ? 8 : 6, isTree ? "chip" : isOre ? "spark" : "leaf");
    this.shake = Math.max(this.shake, 0.1);
    if (isTree) snd.chop(); else if (isOre) snd.mine(); else snd.dig();
    if (newHp <= 0) {
      this.setTile(tx, ty, O.None, 0);
      this.dropOf(o, tx, ty);
      this.shake = Math.max(this.shake, 0.22);
      this.freeze = 0.045;
    } else {
      this.setTile(tx, ty, o, newHp);
    }
  }

  private dropOf(o: number, tx: number, ty: number) {
    this.meta.collect(this, `o${o}`);
    const r = (k: number) => hash2(this.seed ^ 0xd0, tx * 3 + k, ty * 7 + k);
    const zone = zoneAt(tx, ty);
    const gi = (id: string, n: number) => { if (n > 0) this.give(id, n, true); };
    const roll = (n: number, extra = 0) => n + Math.floor(r(1) * (2 + extra));
    switch (o) {
      case O.Oak: gi("brevno", roll(2, 1)); gi("palka", r(2) < 0.5 ? 1 : 0); this.giveLater("brevno"); break;
      case O.Pine: gi("brevno", roll(2)); gi("palka", r(2) < 0.6 ? 1 : 0); this.giveLater("brevno"); break;
      case O.Birch: gi("brevno", roll(1, 1)); gi("palka", 1); this.giveLater("brevno"); break;
      case O.Bush: gi("yagoda", roll(2, 1)); gi("palka", r(2) < 0.3 ? 1 : 0); this.giveLater("yagoda"); break;
      case O.Rock: gi("kamen", roll(2, 1)); gi("kremen", r(2) < 0.3 ? 1 : 0); this.markStone(); break;
      case O.Coal: gi("kamen", 1); gi("ugol", roll(1, 1)); this.markStone(); break;
      case O.Copper: gi("kamen", 1); gi("med_ruda", 1 + Math.floor(r(2) * (1 + zone * 0.3))); this.markStone(); break;
      case O.Iron: gi("kamen", 1); gi("zhel_ruda", 1 + Math.floor(r(2) * (1 + zone * 0.3))); this.markStone(); break;
      case O.Gold: gi("zoloto", 4 + Math.floor(r(2) * (6 + zone * 3))); this.markStone(); break;
      case O.Mushroom: gi("grib", roll(1, 1)); break;
      case O.GlowShroom: gi("grib", 1); gi("nit", r(2) < 0.4 ? 1 : 0); break;
      case O.Clay: gi("glina", roll(2, 1)); break;
      case O.Reeds: gi("palka", roll(1, 1)); break;
      case O.DeadBush: gi("palka", roll(1)); break;
      case O.Cactus: this.player.water = clamp(this.player.water + 5, 0, 100); gi("palka", 1); this.addFloater("+5 вода", "#7fd4f2", this.player.x, this.player.y - 24); break;
      case O.GrassTuft: gi("nit", r(2) < 0.5 ? 1 : 0); break;
      case O.FlowerR: case O.FlowerY: gi("nit", r(2) < 0.35 ? 1 : 0); break;
      case O.Trap: { this.layers.triggerTrap(this, tx, ty); break; }
      case O.RuinChest: { this.layers.openRuinChest(this, tx, ty); break; }
      case O.Chest: {
        const loot = chestLoot(this.seed, tx, ty);
        for (const l of loot) gi(l.id, l.n);
        this.toast("Сундук вскрыт — древние сокровища ваши!", "good");
        snd.chest();
        this.addXp(10);
        break;
      }
      default: {
        // руды и растения иных слоёв
        const drops = layerDrop(o, (k: number) => hash2(this.seed ^ 0xd0, tx * 3 + k, ty * 7 + k));
        for (const dd of drops) gi(dd.id, dd.n);
        if (drops.length) snd.pickup();
        break;
      }
    }
    this.poke();
  }
  private giveLater(kind: string) {
    if (kind === "brevno") this.stats.wood = (this.stats.wood ?? 0) + 1;
    snd.pickup();
  }
  private markStone() { this.stats.stone = (this.stats.stone ?? 0) + 1; snd.pickup(); }

  private dig(tx: number, ty: number) {
    if (this.swingCd > 0) return;
    if (this.player.stamina < 6) { this.toast("Вы задыхаетесь — отдохните", "warn"); return; }
    const t = this.tileOf(tx, ty);
    this.player.stamina -= 5;
    this.player.swing = 0.28;
    this.swingCd = 0.5;
    const power = this.bestTool("shovel").power;
    const rolls = power >= 12 ? 2 : 1;
    snd.dig();
    this.spawnHitParticles(tx * TILE + 20, ty * TILE + 20, "#a98962", 6);
    for (let i = 0; i < rolls; i++) {
      if (t.g === G.Sand || t.g === G.Desert) this.give("pesok", 1, true);
      else if (t.g === G.Snow) this.give("sneg", 1, true);
      else if (t.g === G.Dirt) this.give("glina", 1, true);
    }
    snd.pickup(); this.poke();
  }

  private drinkFrom(tx: number, ty: number) {
    const biome = biomeAt(this.seed, tx, ty, this.z);
    this.player.water = clamp(this.player.water + 24, 0, 100);
    this.stats.drank = (this.stats.drank ?? 0) + 1;
    this.addFloater("+24 вода", "#7fd4f2", this.player.x, this.player.y - 24);
    snd.drink(); snd.splash();
    const swampy = biome === Biome.Swamp;
    if (Math.random() < (swampy ? 0.4 : 0.18)) {
      this.player.poisonT = 10;
      this.toast(swampy ? "Топкая вода скверная — вас мутит!" : "Вода была нечистой — вас мутит!", "bad");
    } else {
      this.toast("Вы напились", "good");
    }
    this.poke();
  }

  private drinkWell() {
    this.player.water = clamp(this.player.water + 40, 0, 100);
    let filled = 0;
    while (this.take("burdyuk_pust", 1)) { this.give("burdyuk_chist", 1, true); filled++; }
    this.stats.drank = (this.stats.drank ?? 0) + 1;
    this.addFloater("+40 вода", "#7fd4f2", this.player.x, this.player.y - 24);
    this.toast(filled > 0 ? `Напились и наполнили бурдюки: ${filled}` : "Свежая колодезная вода", "good");
    snd.drink();
    this.poke();
  }

  // ---------- Предметы/еда ----------
  useItem(idx: number) {
    const s = this.player.inv[idx];
    if (!s) return;
    const def = ITEMS[s.id];
    if (!def) return;
    if (def.type === "equip" || def.type === "weapon" || (def.type === "tool" && !def.slot)) {
      this.equipItem(idx);
      return;
    }
    if (def.type === "place") {
      this.startBuild("fakel_st");
      return;
    }
    let used = false;
    if (def.food) {
      this.player.food = clamp(this.player.food + def.food, 0, 100);
      this.addFloater(`+${def.food} сытость`, "#f2b45c", this.player.x, this.player.y - 24);
      this.stats.ate = (this.stats.ate ?? 0) + 1;
      snd.eat(); used = true;
    }
    if (def.drink) {
      this.player.water = clamp(this.player.water + def.drink, 0, 100);
      this.addFloater(`+${def.drink} вода`, "#7fd4f2", this.player.x, this.player.y - 24);
      this.stats.drank = (this.stats.drank ?? 0) + 1;
      snd.drink(); used = true;
    }
    if (def.heal) {
      this.player.hp = clamp(this.player.hp + def.heal, 0, this.player.maxHp);
      this.addFloater(`+${def.heal}`, "#8ae6a0", this.player.x, this.player.y - 24);
      used = true;
    }
    if (used && def.poisonChance && Math.random() < def.poisonChance) {
      this.player.poisonT = 12;
      this.toast("Отравление! Тело жжёт изнутри", "bad");
    }
    if (used) { s.n--; if (s.n <= 0) this.player.inv.splice(idx, 1); }
    this.poke();
  }

  quickEat() {
    let best = -1, bestV = 0;
    this.player.inv.forEach((s, i) => {
      const v = ITEMS[s.id]?.food ?? 0;
      if (v > bestV) { bestV = v; best = i; }
    });
    if (best >= 0) this.useItem(best);
    else this.toast("Еды нет — поищите ягоды или поохотьтесь", "warn");
  }
  quickDrink() {
    // рядом вода?
    const ptx = Math.floor(this.player.x / TILE), pty = Math.floor(this.player.y / TILE);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const g = this.tileOf(ptx + dx, pty + dy).g;
      if (g === G.Water || g === G.DeepWater) { this.drinkFrom(ptx + dx, pty + dy); return; }
    }
    let best = -1, bestV = 0;
    this.player.inv.forEach((s, i) => {
      const v = ITEMS[s.id]?.drink ?? 0;
      if (v > bestV) { bestV = v; best = i; }
    });
    if (best >= 0) this.useItem(best);
    else this.toast("Воды нет — найдите озеро или выройте колодец", "warn");
  }

  equipItem(idx: number) {
    const s = this.player.inv[idx];
    if (!s) return;
    const def = ITEMS[s.id];
    if (!def) return;
    const slot: EquipSlot = def.slot ?? "weapon";
    this.player.equip[slot] = s.id;
    this.toast(`${def.name} — в руках`, "info");
    snd.ui();
    this.poke();
  }
  unequip(slot: EquipSlot) {
    if (this.player.equip[slot]) {
      delete this.player.equip[slot];
      snd.ui();
      this.poke();
    }
  }
  dropItem(idx: number) {
    const s = this.player.inv[idx];
    if (!s) return;
    this.toast(`Выброшено: ${ITEMS[s.id].name} ×${s.n}`, "info");
    this.player.inv.splice(idx, 1);
    this.poke();
  }

  // ---------- Крафт ----------
  nearFire(): boolean {
    return this.buildings.some((b) => b.done && BUILDINGS[b.def].cook &&
      (this.distTo((b.tx + 0.5) * TILE, (b.ty + 0.5) * TILE) < 3.2));
  }
  canCraft(recipeId: string): { ok: boolean; reason: string } {
    const r = RECIPES.find((x) => x.id === recipeId);
    if (!r) return { ok: false, reason: "?" };
    if (r.fire && !this.nearFire()) return { ok: false, reason: "Нужен костёр рядом" };
    for (const [id, n] of r.needs) if (this.count(id) < n) return { ok: false, reason: "Не хватает материалов" };
    return { ok: true, reason: "" };
  }
  craft(recipeId: string) {
    const c = this.canCraft(recipeId);
    const r = RECIPES.find((x) => x.id === recipeId)!;
    if (!c.ok) { this.toast(c.reason, "warn"); return; }
    for (const [id, n] of r.needs) this.take(id, n);
    this.give(r.out, r.outN, true);
    this.addFloater(`+${r.outN} ${ITEMS[r.out].name}`, "#f2d38a", this.player.x, this.player.y - 30);
    this.addXp(r.xp);
    this.stats.crafted = (this.stats.crafted ?? 0) + 1;
    if (r.out === "topor_k") this.stats.topor = 1;
    snd.craft();
    this.meta.progress(this, "craft", r.out, r.outN);
    this.toast(`Создано: ${r.name}`, "good");
    this.poke();
  }

  // ---------- Строительство ----------
  startBuild(defId: string) {
    this.buildDef = defId;
    const ptx = Math.floor(this.player.x / TILE), pty = Math.floor(this.player.y / TILE);
    this.buildGhost.tx = ptx + 2; this.buildGhost.ty = pty;
    this.validateBuild();
    this.poke();
  }
  cancelBuild() { this.buildDef = null; this.poke(); }
  validateBuild() {
    if (!this.buildDef) return;
    const def = BUILDINGS[this.buildDef];
    const g = this.buildGhost;
    if (this.z !== 0) { g.valid = false; g.reason = `В слое «${LAYER_BY_ID[this.z]?.name ?? "иной"}» не построить`; return; }
    if (def.needsCity && !this.city.s.founded) { g.valid = false; g.reason = "Сначала основайте город"; return; }
    if (this.lore.buildingLocked(def.id)) { g.valid = false; g.reason = `Нужна технология: ${this.lore.buildingTech(def.id)}`; return; }
    if (def.wonder && this.buildings.some((b) => b.def === def.id)) { g.valid = false; g.reason = "Такое чудо уже строится"; return; }
    if (def.townhall && this.buildings.some((b) => BUILDINGS[b.def]?.townhall)) { g.valid = false; g.reason = "Ратуша в городе одна"; return; }
    for (let dy = 0; dy < def.h; dy++) for (let dx = 0; dx < def.w; dx++) {
      const t = this.tileOf(g.tx + dx, g.ty + dy);
      if (SOLID_GROUND.has(t.g)) { g.valid = false; g.reason = "Нельзя на воду и скалу"; return; }
      if (SOLID_OBJ.has(t.o)) { g.valid = false; g.reason = "Место занято — расчистите"; return; }
      if (this.buildingAt(g.tx + dx, g.ty + dy)) { g.valid = false; g.reason = "Тут уже стоит постройка"; return; }
    }
    g.valid = true; g.reason = "";
  }
  confirmBuild() {
    if (!this.buildDef) return;
    const def = BUILDINGS[this.buildDef];
    this.validateBuild();
    if (!this.buildGhost.valid) { this.toast(this.buildGhost.reason || "Сюда нельзя", "warn"); return; }
    for (const [id, n] of def.cost) {
      if (this.count(id) < n) { this.toast(`Не хватает: ${ITEMS[id].name}`, "warn"); return; }
    }
    for (const [id, n] of def.cost) this.take(id, n);
    const g = this.buildGhost;
    const b: Building = { uid: this.uid++, def: this.buildDef, tx: g.tx, ty: g.ty, progress: 0, done: false, store: 0, prodT: 0, open: false };
    this.buildings.push(b);
    this.bIndex.set(`${g.tx},${g.ty}`, b);
    // снос мелкой растительности
    for (let dy = 0; dy < def.h; dy++) for (let dx = 0; dx < def.w; dx++) {
      const t = this.tileOf(g.tx + dx, g.ty + dy);
      if (t.o !== O.None && !SOLID_OBJ.has(t.o)) this.setTile(g.tx + dx, g.ty + dy, O.None, 0);
    }
    snd.place();
    this.stats.built = (this.stats.built ?? 0) + 1;
    this.addXp(3);
    if (def.buildTime <= 0.6) this.finishBuild(b);
    else this.toast(`${def.name}: стройка началась. Стучите по ней, чтобы ускорить`, "info");
    if (this.buildDef === "koster") this.stats.fire = 1;
    this.poke();
  }
  private finishBuild(b: Building) {
    this.meta.progress(this, "build", b.def, 1);
    b.done = true; b.progress = BUILDINGS[b.def].buildTime;
    const def = BUILDINGS[b.def];
    this.toast(`${def.name} достроен!`, "good");
    snd.craft();
    this.spawnHitParticles((b.tx + 0.5) * TILE, (b.ty + 0.5) * TILE, "#f2d38a", 12, "star");
    this.addXp(4);
    this.poke();
  }
  removeBuilding(b: Building) {
    this.buildings = this.buildings.filter((x) => x.uid !== b.uid);
    this.bIndex.delete(`${b.tx},${b.ty}`);
    this.poke();
  }

  private trySleep() {
    if (!this.isNight()) { this.toast("Спать ложатся ночью", "info"); return; }
    const enemies = this.mobs.filter((m) => this.mobDef(m.def)?.night && this.distTo(m.x, m.y) < 10).length;
    if (enemies > 0) { this.toast("Нельзя спать — рядом чудища!", "warn"); snd.monster(); return; }
    // сон до утра
    this.time = 0.02;
    this.day += 1;
    this.player.stamina = 100;
    this.player.hp = clamp(this.player.hp + 16, 0, this.player.maxHp);
    this.player.food = clamp(this.player.food - 12, 0, 100);
    this.player.water = clamp(this.player.water - 10, 0, 100);
    this.stats.slept = (this.stats.slept ?? 0) + 1;
    snd.sleep();
    this.toast(`Наступил день ${this.day}. Вы выспались`, "good");
    this.mobs = this.mobs.filter((m) => !this.mobDef(m.def)?.night);
    this.rollWeather(true);
    this.save(true);
    this.poke();
  }

  // ---------- Пещеры ----------
  private enterCave(tx: number, ty: number) {
    // ищем ближайший пол пещеры
    for (let r = 0; r < 40; r++) {
      for (let a = 0; a < Math.max(1, r * 10); a++) {
        const ang = (a / Math.max(1, r * 10)) * Math.PI * 2;
        const cx = tx + Math.round(Math.cos(ang) * r), cy = ty + Math.round(Math.sin(ang) * r);
        if (tileAt(this.seed, cx, cy, 1).g === G.CaveFloor) {
          this.z = 1;
          this.player.x = cx * TILE + TILE / 2; this.player.y = cy * TILE + TILE / 2;
          this.setTile(cx, cy, O.CaveOut, objMaxHp(O.CaveOut));
          this.moveTarget = null; this.pending = null;
          this.mobs = []; this.projectiles = [];
          this.toast("Вы спускаетесь в чрево земли…", "info");
          snd.splash();
          this.poke();
          return;
        }
      }
    }
    this.toast("Пещера обвалилась — прохода нет", "warn");
  }
  private exitCave(_tx: number, _ty: number) {
    this.z = 0;
    this.layers.oxygen = 100;
    this.moveTarget = null; this.pending = null;
    this.mobs = []; this.projectiles = [];
    this.toast("Свежий воздух! Вы наверху", "good");
    this.poke();
    // ставим игрока на ближайший проходимый тайл
    const ptx = Math.floor(this.player.x / TILE), pty = Math.floor(this.player.y / TILE);
    if (this.isBlocked(ptx, pty)) {
      outer: for (let r = 1; r < 10; r++) {
        for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
          if (!this.isBlocked(ptx + dx, pty + dy)) {
            this.player.x = (ptx + dx) * TILE + 20; this.player.y = (pty + dy) * TILE + 20;
            break outer;
          }
        }
      }
    }
  }

  // ---------- Бой ----------
  private attackMob(mob: Mob) {
    if (this.swingCd > 0 || this.player.dead) return;
    if (!this.mobDef(mob.def)) return;
    const w = this.weaponDmg();
    this.swingCd = 0.46 / w.spd;
    this.player.swing = 0.3;
    this.player.dir = Math.atan2(mob.y - this.player.y, mob.x - this.player.x);
    const crit = Math.random() < 0.12;
    const dmg = Math.round(w.dmg * (crit ? 2 : 1) * (0.85 + Math.random() * 0.3));
    mob.hp -= dmg;
    mob.flash = 0.1;
    mob.hitT = 6;
    const def = this.mobDef(mob.def)!;
    this.addFloater(`${dmg}${crit ? "!" : ""}`, crit ? "#ffd34d" : "#f2ede2", mob.x, mob.y - 26 * def.scale, crit);
    this.spawnHitParticles(mob.x, mob.y, def.night ? "#5d8a5c" : "#a8553c", crit ? 10 : 6, "drop");
    this.shake = Math.max(this.shake, crit ? 0.3 : 0.12);
    if (crit) { this.freeze = 0.055; snd.crit(); } else snd.hit();
    if (mob.hp <= 0) this.killMob(mob);
    else {
      const kb = 0.35;
      mob.x += Math.cos(this.player.dir) * kb * TILE * 0.5;
      mob.y += Math.sin(this.player.dir) * kb * TILE * 0.5;
      if (def.ai === "flee") { mob.state = "flee"; mob.t = 4; }
      else if (mob.state === "idle" || mob.state === "wander") mob.state = "chase";
    }
  }

  private killMob(mob: Mob) {
    const def = this.mobDef(mob.def);
    if (!def) { this.mobs = this.mobs.filter((m) => m.uid !== mob.uid); return; }
    this.mobs = this.mobs.filter((m) => m.uid !== mob.uid);
    this.freeze = 0.06;
    this.shake = Math.max(this.shake, 0.34);
    snd.mobDie();
    this.spawnHitParticles(mob.x, mob.y, "#c94f5d", 14, "drop");
    this.stats.killed = (this.stats.killed ?? 0) + 1;
    if (def.ai === "boss") this.stats.bossKilled = (this.stats.bossKilled ?? 0) + 1;
    this.addXp(Math.round(def.xp * (1 + (mob.lvl - 1) * 0.3)));
    const r = mulberry32((this.seed ^ mob.uid * 7919) >>> 0);
    for (const d of def.drops) {
      if (r() < d.ch) this.give(d.id, Math.max(1, Math.round(d.n * (0.75 + r() * 0.5))));
    }
    this.meta.collect(this, mob.def);
    this.meta.progress(this, "kill", mob.def, 1);
    if (def.ai === "boss") this.meta.progress(this, "kill", "boss", 1);
    this.layers.onBossKilled(this, mob.def);
    this.layers.onWildBossKilled(this, mob.def); // владыки и их трофеи (8-й этап)
    if (mob.def === "drakon") {
      this.dragonDead = true;
      this.toast("ДРЕВНИЙ ДРАКОН ПОВЕРЖЕН! Земли тысячу лет будут петь об этом!", "good");
      this.addXp(300);
      snd.levelup();
      this.shake = 0.9;
    } else {
      this.addFloater(def.name, "#c9b8a8", mob.x, mob.y - 40);
    }
  }

  hurtPlayer(dmg: number, fromX: number, fromY: number) {
    if (this.player.dead) return;
    const armor = this.armorSum();
    const final = Math.max(1, Math.round(dmg * (100 / (100 + armor * 9))));
    this.player.hp -= final;
    this.dmgFlash = 0.5;
    this.shake = Math.max(this.shake, 0.3);
    snd.hurt();
    this.addFloater(`-${final}`, "#ff7a6b", this.player.x, this.player.y - 30, true);
    this.spawnHitParticles(this.player.x, this.player.y, "#c94f5d", 8, "drop");
    this.player.dir = Math.atan2(this.player.y - fromY, this.player.x - fromX);
    if (this.player.hp <= 0) this.die();
  }

  private die() {
    if (MODE_BY_ID[this.mode].id === "creative") { this.player.hp = this.player.maxHp; return; }
    this.player.dead = true;
    this.player.hp = 0;
    this.stats.deaths = (this.stats.deaths ?? 0) + 1;
    this.hardcoreDeath = MODE_BY_ID[this.mode].permadeath;
    snd.death();
    // теряем 35% ресурсов
    for (const s of this.player.inv) {
      if (ITEMS[s.id]?.type === "res" || ITEMS[s.id]?.type === "misc") {
        s.n = Math.floor(s.n * 0.65);
      }
    }
    this.player.inv = this.player.inv.filter((s) => s.n > 0);
    this.player.gold = Math.floor(this.player.gold * 0.75);
    this.poke();
  }
  respawn() {
    const sp = this.findSpawn();
    this.player.x = sp.x * TILE + 20; this.player.y = sp.y * TILE + 20;
    this.player.hp = Math.round(this.player.maxHp * 0.6);
    this.player.food = Math.max(this.player.food, 30);
    this.player.water = Math.max(this.player.water, 35);
    this.player.poisonT = 0;
    this.player.dead = false;
    this.z = 0;
    this.time = clamp(this.time + 0.1, 0, 0.98);
    this.cam.x = this.player.x; this.cam.y = this.player.y;
    this.stats.respawns = (this.stats.respawns ?? 0) + 1;
    this.toast("Вы очнулись у родного порога. Часть добра утрачена…", "warn");
    this.save(true);
    this.poke();
  }

  addXp(n: number) {
    this.player.xp += Math.round(n * this.meta.mXp());
    const need = xpNeed(this.player.level);
    if (this.player.xp >= need) {
      this.player.xp -= need;
      this.player.level += 1;
      this.player.maxHp += 8;
      this.player.hp = this.player.maxHp;
      snd.levelup();
      this.toast(`Уровень ${this.player.level}! Сила растёт`, "good");
      this.spawnHitParticles(this.player.x, this.player.y - 10, "#ffd34d", 16, "star");
    }
  }

  // ---------- Окружение ----------
  isNight(): boolean { return (LAYER_BY_ID[this.z]?.light ?? 1) < 0.5 || this.time >= 0.52; }
  daylight(): number {
    const ld = LAYER_BY_ID[this.z];
    if (this.z !== 0) return ld ? ld.light : 0;
    if (this.time >= 0.5) return 0;
    return clamp01(Math.sin((Math.PI * this.time) / 0.5) * 1.35);
  }
  season(): number { return Math.floor((this.day - 1) / 4) % 4; }

  private rollWeather(force = false) {
    const season = this.season();
    const ptx = Math.floor(this.player.x / TILE), pty = Math.floor(this.player.y / TILE);
    const biome = biomeAt(this.seed, ptx, pty, 0);
    const cold = season === 3 || biome === Biome.SnowMount || biome === Biome.Tundra;
    const r = this.rng();
    let next: WeatherId = "clear";
    if (r < 0.5 && !force) next = "clear";
    else if (r < 0.72) next = cold ? "snow" : "rain";
    else if (r < 0.85) next = "fog";
    else if (r < 0.94) next = cold ? "snow" : "storm";
    else next = "clear";
    if (force && this.weather !== "clear") next = this.rng() < 0.6 ? "clear" : this.weather;
    if (next !== this.weather) {
      this.weather = next;
      const names: Record<WeatherId, string> = { clear: "Небо проясняется", rain: "Начинается дождь", snow: "Пошёл снег", storm: "Гроза надвигается — берегитесь!", fog: "Туман стелется по земле" };
      this.toast(names[next], "info");
      if (next === "storm") snd.thunder();
    }
    this.weatherT = 200 + this.rng() * 280;
  }

  private updateTemperature() {
    const ptx = Math.floor(this.player.x / TILE), pty = Math.floor(this.player.y / TILE);
    let base: number;
    if (this.z === L.Cave) base = 8;
    else if (this.z === L.Deep) base = 64;
    else if (this.z === L.Sky) base = -12;
    else if (this.z === L.Ocean) base = 4;
    else if (this.z === L.Moon || this.z === L.Mars) base = this.layers.hasGear("skafandr") ? 18 : -40;
    else if (this.z === L.Shadow) base = 2;
    else if (this.z === L.Dream) base = 20;
    else if (this.z === L.Chaos) base = 30;
    else {
      const tn = tempN(this.seed, ptx, pty);
      const seasonOff = [-1, 13, 3, -15][this.season()];
      const dayOff = this.isNight() ? -7 : 6;
      const weatherOff: Record<WeatherId, number> = { clear: 0, rain: -4, storm: -6, snow: -8, fog: -2 };
      const biome = biomeAt(this.seed, ptx, pty, 0);
      const desertHot = biome === Biome.Desert && !this.isNight() ? 13 : 0;
      base = tn * 26 - 4 + seasonOff + dayOff + weatherOff[this.weather] + desertHot;
    }
    let fire = 0;
    for (const b of this.buildings) {
      const def = BUILDINGS[b.def];
      if (b.done && def.warmth) {
        const d = this.distTo((b.tx + 0.5) * TILE, (b.ty + 0.5) * TILE);
        if (d < 7) fire = Math.max(fire, def.warmth * (1 - d / 7));
      }
    }
    this.player.temp = Math.round(base + fire + this.warmthSum());
  }

  // ---------- Спавн ----------
  private trySpawn() {
    if (!MODE_BY_ID[this.mode].monsters && this.z === 0) return;
    const ptx = Math.floor(this.player.x / TILE), pty = Math.floor(this.player.y / TILE);
    const zone = zoneAt(ptx, pty);
    const night = this.isNight();
    const layerTable = this.layers.spawnTable(this.z);
    // --- Состав таблицы спавна (этап 7): ночные — ночью, пещерные — в пещерах,
    // --- биомные — в своих биомах; древние слои получают добавки категорий.
    let table: [string, number][];
    if (layerTable) {
      const extra = MONSTER_LAYER_SPAWN[this.z];
      table = extra ? [...layerTable, ...extra] : layerTable;
    } else if (this.z === 1) {
      table = [...CAVE_SPAWN, ...MONSTER_CAVE_SPAWN];
    } else {
      const biomeMobs = monsterBiomeSpawn(biomeAt(this.seed, ptx, pty, 0), night);
      table = night
        ? [...NIGHT_SPAWN, ...MONSTER_NIGHT_SPAWN, ...biomeMobs]
        : [...DAY_SPAWN, ...biomeMobs];
    }
    const layerDef = LAYER_BY_ID[this.z];
    const eliteChance = Math.min(0.14, 0.035 + zone * 0.012 + (layerDef?.danger ?? 0) * 0.006);
    const cap = layerTable ? Math.min(9, 4 + Math.floor((layerDef?.danger ?? 3) / 2))
      : this.z === 1 ? 5 : night ? Math.min(11, 6 + zone) : 7;
    if (this.mobs.length >= cap) return;
    for (let tries = 0; tries < 10; tries++) {
      const ang = this.rng() * Math.PI * 2;
      const dist = 12 + this.rng() * 8;
      const tx = ptx + Math.round(Math.cos(ang) * dist), ty = pty + Math.round(Math.sin(ang) * dist);
      const t = this.tileOf(tx, ty);
      if (SOLID_GROUND.has(t.g) || SOLID_OBJ.has(t.o)) continue;
      if (this.buildingAt(tx, ty)) continue;
      // ночные не появляются в свете
      if (night && this.z === 0) {
        let lit = false;
        for (const b of this.buildings) {
          const def = BUILDINGS[b.def];
          if (b.done && def.light && (tx - b.tx) ** 2 + (ty - b.ty) ** 2 < (def.light + 2) ** 2) { lit = true; break; }
        }
        if (lit) continue;
        // дождь отпугивает часть мобов
        if ((this.weather === "rain" || this.weather === "storm") && this.rng() < 0.35) return;
      }
      let id = pickW(this.rng(), table);
      // элитный ролл: шанс встретить «Древнюю» версию монстра (другой цвет, больше силы)
      const anc = ANCIENT_ID[id];
      if (anc && this.rng() < eliteChance) id = anc;
      const def = this.mobDef(id);
      if (!def) continue;
      if (def.elite && id.endsWith("_drevn")) {
        this.toast(`${def.name} рыщет неподалёку…`, "warn");
        snd.monster();
      }
      const lvl = 1 + zone + Math.floor((LAYER_BY_ID[this.z]?.danger ?? 1) / 2);
      this.mobs.push({
        uid: this.uid++, def: id, x: tx * TILE + 20, y: ty * TILE + 20,
        hp: Math.round(def.hp * zoneHpMult(zone)), maxHp: Math.round(def.hp * zoneHpMult(zone)),
        state: "idle", t: this.rng() * 3, cd: 0, flash: 0, lvl,
        tx: tx + 2, ty: ty + 2, breathe: this.rng() * 6, hitT: 0,
      });
      return;
    }
  }

  private spawnDragonIfClose() {
    if (this.dragonDead || this.z === 1) return;
    if (this.mobs.some((m) => m.def === "drakon")) return;
    const a = arenaCenter(this.seed);
    const d = Math.hypot(this.player.x / TILE - a.x, this.player.y / TILE - a.y);
    if (d < 30) {
      const def = MOBS.drakon;
      this.mobs.push({
        uid: this.uid++, def: "drakon", x: a.x * TILE + 20, y: a.y * TILE + 20,
        hp: def.hp, maxHp: def.hp, state: "chase", t: 0, cd: 3, flash: 0, lvl: 1,
        tx: a.x, ty: a.y, breathe: 0, hitT: 0,
      });
      this.toast("Земля содрогается… ДРЕВНИЙ ДРАКОН проснулся!", "bad");
      snd.thunder();
      this.shake = 0.7;
    }
  }

  // ---------- Мобы ----------
  private updateMob(mob: Mob, dt: number) {
    const def = this.mobDef(mob.def);
    if (!def) { mob.hp = -1; return; }
    mob.breathe += dt;
    mob.flash = Math.max(0, mob.flash - dt);
    mob.hitT = Math.max(0, mob.hitT - dt);
    mob.cd = Math.max(0, mob.cd - dt);
    const dp = this.distTo(mob.x, mob.y);
    if (dp > 42) { mob.hp = -1; return; } // далеко — деспавн
    // сгорание днём: все ночные твари на поверхности
    if (this.z === 0 && !this.isNight() && def.night) {
      mob.hp -= 18 * dt;
      if (Math.random() < dt * 6) this.spawnHitParticles(mob.x, mob.y - 10, "#f2a24d", 2, "ember");
      if (mob.hp <= 0) this.spawnHitParticles(mob.x, mob.y, "#6b5c4d", 10, "puff");
      return;
    }
    const zone = zoneAt(Math.floor(mob.x / TILE), Math.floor(mob.y / TILE));
    const dmgMult = zoneDmgMult(zone) * (1 + (mob.lvl - 1) * 0.1);
    const speed = def.speed * (mob.state === "flee" ? 1.35 : 1);

    const chaseOrNot = () => {
      if (def.ai === "flee") {
        if (mob.hitT > 0 || dp < def.aggroR * 0.7) { mob.state = "flee"; mob.t = Math.max(mob.t, 1.5); }
        else if (mob.state === "flee" && mob.t <= 0) mob.state = "idle";
        return;
      }
      if (def.ai === "neutral") {
        if (mob.hitT > 0 && dp < 14) mob.state = "chase";
        else if (mob.state === "chase" && mob.hitT <= 0) mob.state = "idle";
        return;
      }
      // враждебные: ночные — ночью, пещерные/слоёвые — во тьме своих слоёв,
      // биомные (без флага night) — в любое время суток
      const canAggro = this.isNight() || this.z !== 0 || def.ai === "boss" || !def.night;
      if (canAggro && dp < def.aggroR && !this.player.dead) {
        if (mob.state === "idle" || mob.state === "wander") { mob.state = "chase"; if (def.night) snd.monster(); }
      } else if (mob.state === "chase" && dp > def.aggroR + 6) {
        mob.state = "idle";
      }
    };
    chaseOrNot();

    mob.t -= dt;
    let vx = 0, vy = 0;
    switch (mob.state) {
      case "idle":
        if (mob.t <= 0) {
          mob.state = "wander";
          mob.t = 2 + this.rng() * 4;
          mob.tx = Math.floor(mob.x / TILE) + (this.rng() - 0.5) * 8;
          mob.ty = Math.floor(mob.y / TILE) + (this.rng() - 0.5) * 8;
        }
        break;
      case "wander": {
        const dx = mob.tx * TILE + 20 - mob.x, dy = mob.ty * TILE + 20 - mob.y;
        const dd = Math.hypot(dx, dy);
        if (dd < 10 || mob.t <= 0) { mob.state = "idle"; mob.t = 1 + this.rng() * 3; }
        else { vx = (dx / dd) * speed * 0.5; vy = (dy / dd) * speed * 0.5; }
        break;
      }
      case "flee": {
        const dx = mob.x - this.player.x, dy = mob.y - this.player.y;
        const dd = Math.hypot(dx, dy) || 1;
        vx = (dx / dd) * speed; vy = (dy / dd) * speed;
        if (mob.t <= 0) mob.state = "idle";
        break;
      }
      case "chase": {
        const dx = this.player.x - mob.x, dy = this.player.y - mob.y;
        const dd = Math.hypot(dx, dy) || 1;
        if (def.ai === "ranged") {
          if (dd > def.atkR * TILE) { vx = (dx / dd) * speed; vy = (dy / dd) * speed; }
          else if (dd < 3.5 * TILE) { vx = -(dx / dd) * speed; vy = -(dy / dd) * speed; }
          if (dd < def.atkR * TILE * 1.15 && mob.cd <= 0) {
            mob.cd = def.atkCd;
            const sp = 340;
            this.projectiles.push({
              x: mob.x, y: mob.y - 10, vx: (dx / dd) * sp, vy: (dy / dd) * sp,
              dmg: def.dmg * dmgMult, t: 2.5,
              kind: "arrow", // or fire
            });
            snd.ui();
          }
        } else if (def.ai === "explode") {
          if (dd < def.atkR * TILE) { mob.state = "boom"; mob.fuse = 1.15; snd.monster(); }
          else { vx = (dx / dd) * speed; vy = (dy / dd) * speed; }
        } else if (def.ai === "boss") {
          if (dd > def.atkR * TILE) { vx = (dx / dd) * speed; vy = (dy / dd) * speed; }
          if (mob.cd <= 0 && dd < 8 * TILE) {
            mob.cd = 6.5;
            // огненный веер
            const baseAng = Math.atan2(dy, dx);
            for (let i = -2; i <= 2; i++) {
              const a = baseAng + i * 0.22;
              this.projectiles.push({
                x: mob.x, y: mob.y - 20, vx: Math.cos(a) * 300, vy: Math.sin(a) * 300,
                dmg: 16, t: 1.8, kind: "fire",
              });
            }
            snd.fireball();
          }
          if (dd < def.atkR * TILE && mob.cd <= 1.2) {
            mob.cd = def.atkCd;
            this.hurtPlayer(def.dmg * dmgMult, mob.x, mob.y);
          }
        } else {
          if (dd > def.atkR * TILE * 0.8) { vx = (dx / dd) * speed; vy = (dy / dd) * speed; }
          if (dd < def.atkR * TILE && mob.cd <= 0) {
            mob.cd = def.atkCd;
            this.hurtPlayer(def.dmg * dmgMult, mob.x, mob.y);
          }
        }
        break;
      }
      case "boom": {
        mob.fuse = (mob.fuse ?? 1) - dt;
        if (mob.fuse <= 0) {
          // ВЗРЫВ
          const dd = this.distTo(mob.x, mob.y);
          if (dd < 3.4) this.hurtPlayer(def.dmg * (1 - dd / 4), mob.x, mob.y);
          this.spawnHitParticles(mob.x, mob.y, "#f2a24d", 26, "ember");
          this.spawnHitParticles(mob.x, mob.y, "#57504a", 14, "puff");
          this.shake = 0.7;
          snd.explosion();
          mob.hp = -1;
          if (def.drops.length) {
            const r = this.rng();
            for (const d of def.drops) if (r < d.ch * 0.7) this.give(d.id, d.n);
          }
        }
        break;
      }
    }
    // движение с коллизиями
    if (vx !== 0 || vy !== 0) {
      const nx = mob.x + vx * TILE * dt, ny = mob.y + vy * TILE * dt;
      const flying = def.flying || def.ai === "ghost";
      const ntx = Math.floor(nx / TILE), nty = Math.floor(ny / TILE);
      if (!this.isBlocked(ntx, Math.floor(mob.y / TILE), true, flying)) mob.x = nx;
      if (!this.isBlocked(Math.floor(mob.x / TILE), nty, true, flying)) mob.y = ny;
    }
    // рассредоточение
    for (const o of this.mobs) {
      if (o === mob) continue;
      const dx = mob.x - o.x, dy = mob.y - o.y;
      const dd = dx * dx + dy * dy;
      if (dd < 28 * 28 && dd > 1) {
        const f = (1 - Math.sqrt(dd) / 28) * 18 * dt;
        const n = Math.sqrt(dd);
        mob.x += (dx / n) * f; mob.y += (dy / n) * f;
      }
    }
  }

  // ---------- Частицы / флоатеры ----------
  addFloater(text: string, color: string, x: number, y: number, big = false) {
    this.floaters.push({ x, y, text, color, age: 0, big });
    if (this.floaters.length > 40) this.floaters.shift();
  }
  spawnHitParticles(x: number, y: number, color: string, n: number, kind: Particle["kind"] = "chip") {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 30 + Math.random() * 90;
      this.particles.push({
        x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 40,
        age: 0, life: 0.5 + Math.random() * 0.5, color,
        size: kind === "spark" ? 2 : 2 + Math.random() * 3,
        grav: kind === "spark" || kind === "chip" || kind === "drop" ? 260 : 40,
        kind,
      });
    }
    if (this.particles.length > 240) this.particles.splice(0, this.particles.length - 240);
  }

  // ---------- Взаимодействие UI ----------
  subscribe(cb: () => void): () => void {
    this.uiListeners.add(cb);
    return () => this.uiListeners.delete(cb);
  }
  onToast(cb: (t: Toast) => void): () => void {
    this.toastListeners.add(cb);
    return () => this.toastListeners.delete(cb);
  }
  toast(text: string, kind: Toast["kind"]) {
    const t = { id: this.toastId++, text, kind };
    for (const cb of this.toastListeners) cb(t);
  }
  poke() {
    for (const cb of this.uiListeners) cb();
  }

  /** Смена суток: тик города, экономики, жителей и династии */
  onNewDay() {
    this.city.dayTick(this);
    this.economy.dayTick(this);
    this.npcs.dayTick(this);
    this.personae.dayTick(this);
    this.cine.dayTick(this);
    this.dynasty.dayTick(this);
    this.nations.dayTick(this);
    this.lore.dayTick(this);
    this.layers.dayTick(this);
    this.meta.dayTick(this);
    if (this.day % 3 === 0) this.economy.marketEvent(this, this.seed);
    this.uiTick++;
    this.poke();
  }

  /** Множитель скорости строительства (указы, чудеса, район науки) */
  buildSpeed(): number { return this.city.s.founded ? this.city.prodMul(this) : (1 + this.lore.techEffect("prod")); }

  /** Человеческое имя постройки по id */
  buildingName(id: string): string { return BUILDINGS[id]?.name ?? id; }

  /** Разрешены ли войны в текущем режиме */
  modeAllowsWar(): boolean { return MODE_BY_ID[this.mode].wars; }

  /** Столкновение с препятствием: «тап издалека» довёл до цели — действуем; в ствол — стоп, подсветка и «тук» */
  private bumpInto(tx: number, ty: number) {
    // шли по тапу к этой клетке (рубить/добывать/войти): цель достигнута у препятствия
    const pa = this.pending;
    if (pa && pa.tx === tx && pa.ty === ty && this.distTo(tx * TILE + TILE / 2, ty * TILE + TILE / 2) <= REACH) {
      this.moveTarget = null;
      this.pending = null;
      this.doAction(pa);
      return;
    }
    if (this.bumpCd > 0) return;
    const t = this.tileOf(tx, ty);
    const trunk = t.o === O.Oak || t.o === O.Pine || t.o === O.Birch || t.o === O.CloudTree || t.o === O.ShadowTree;
    if (!trunk) return;
    this.bumpCd = 0.3;
    this.bumpFx = { tx, ty, t: 0.28 };
    this.moveTarget = null;
    this.pending = null;
    this.shake = Math.max(this.shake, 0.045); // едва заметный толчок — «уперлись»
    snd.thud();
  }

  /** Описание моба: базовые + мобы слоёв */
  /** Описание моба: базовые + мобы слоёв + бестиарий (monster.ts) */
  mobDef(id: string) { return MOBS[id] ?? LAYER_MOBS[id] ?? MONSTER_MOBS[id] ?? BOSS_MOBS[id]; }

  distTo(x: number, y: number): number {
    return Math.hypot(x - this.player.x, y - this.player.y) / TILE;
  }
  enemiesNear(r = 12): number {
    return this.mobs.filter((m) => {
      const d = this.mobDef(m.def);
      if (!d) return false;
      return (d.night || d.ai === "boss" || (d.ai === "neutral" && m.state === "chase")) && this.distTo(m.x, m.y) < r;
    }).length;
  }
  nearWell(): boolean {
    return this.buildings.some((b) => b.done && BUILDINGS[b.def].well &&
      this.distTo((b.tx + 0.5) * TILE, (b.ty + 0.5) * TILE) < 2.5);
  }
  nearBed(): boolean {
    return this.buildings.some((b) => b.done && BUILDINGS[b.def].sleep &&
      this.distTo((b.tx + 0.5) * TILE, (b.ty + 0.5) * TILE) < 2.5);
  }
  arenaPos() { return arenaCenter(this.seed); }
  spawnPoint(): Vec { return this.findSpawn(); }

  ui(): UiSnapshot {
    const p = this.player;
    const ptx = Math.floor(p.x / TILE), pty = Math.floor(p.y / TILE);
    const hours = Math.floor(((6 + this.time * 24) % 24));
    const minutes = Math.floor((((6 + this.time * 24) % 24) % 1) * 60);
    const zone = zoneAt(ptx, pty);
    const biome = this.z === 1 ? Biome.Cave : biomeAt(this.seed, ptx, pty, 0);
    return {
      hp: Math.round(p.hp), maxHp: p.maxHp, food: Math.round(p.food), water: Math.round(p.water),
      stamina: Math.round(p.stamina), temp: p.temp,
      xp: Math.round(p.xp), xpNeed: xpNeed(p.level), level: p.level, gold: p.gold,
      inv: p.inv.map((s) => ({ ...s })), equip: { ...p.equip },
      hours, minutes, isNight: this.isNight(), day: this.day, season: this.season(), weather: this.weather,
      z: this.z, zone, zoneName: ZONE_NAMES[zone], biomeName: BIOME_NAMES[biome], tx: ptx, ty: pty,
      enemiesNear: this.enemiesNear(), nearFire: this.nearFire(), dmgFlash: this.dmgFlash, playerDead: p.dead,
      buildDef: this.buildDef, buildValid: this.buildGhost.valid, buildReason: this.buildGhost.reason,
      poisoned: p.poisonT > 0, tutorialDone: this.tutorialStep >= 10,
      stats: { ...this.stats },
      dragonAlive: !this.dragonDead, weatherT: this.weatherT,
      time: this.time,
      cityFounded: this.city.s.founded,
      cityName: this.city.s.name,
      cityPop: Math.floor(this.city.s.pop),
      cityCap: this.city.s.popCap,
      cityHappy: Math.round(this.city.s.happiness),
      cityTier: this.city.tierName(),
      cityRiot: Math.round(this.city.s.riot),
      cityRioting: this.city.s.rioting,
      cityIncome: Math.round(this.city.incomePerSec(this) * 60),
      canFoundCity: !this.city.s.founded && this.city.canFound(this).ok,
      foundHint: this.city.s.founded ? "" : this.city.canFound(this).reason,
      npcNear: this.npcs.npcs.length,
      govName: this.dynasty.govDef().name,
      support: this.dynasty.avgSupport(),
      routeCount: this.economy.routes.length,
      uiTick: this.uiTick,
      armyPower: this.army.power(),
      armyMen: this.army.totalMen(),
      armyCap: this.army.manpowerCap(this),
      squadCount: this.army.squads.length,
      generalCount: this.army.generals.filter((g) => g.alive).length,
      upkeepGold: this.army.upkeepGold(),
      warCount: this.nations.atWar().length,
      allyCount: this.nations.allies().length,
      vassalCount: this.nations.vassals().length,
      envoyCount: this.nations.envoys.length,
      battleActive: this.battle.s.active,
      battleTurn: this.battle.s.turn,
      battleSide: this.battle.s.side,
      battleOver: this.battle.s.over !== null,
      inviteBattle: this.battle.invitePrompt !== null,
      fame: Math.round(this.nations.fame),
      leagueMember: this.nations.league.member,
      incomingWar: this.nations.nations.some((n) => n.incoming),
      woundedCount: this.army.hospital.reduce((a, h) => a + h.n, 0),
      eraName: this.lore.eraDef().name,
      eraIcon: this.lore.eraDef().icon,
      eraColor: this.lore.eraDef().color,
      science: Math.floor(this.lore.science),
      sciTotal: Math.floor(this.lore.sciTotal),
      sciRate: Math.round(this.lore.sciRate(this) * 60 * 10) / 10,
      researching: this.lore.researching,
      researchName: this.lore.researching ? (TECH_BY_ID[this.lore.researching]?.name ?? "") : "",
      researchProgress: this.lore.researching
        ? clamp01(this.lore.science / Math.max(1, TECH_BY_ID[this.lore.researching]?.cost ?? 1)) * 100
        : 0,
      techCount: this.lore.techs.size,
      techTotal: TECHS.length,
      isMage: this.lore.magic.school !== null,
      magicUnlocked: this.lore.magic.unlocked,
      schoolName: this.lore.magic.school ? (SCHOOLS.find((s) => s.id === this.lore.magic.school)?.name ?? "") : "",
      magicLvl: this.lore.magic.lvl,
      mana: Math.floor(this.lore.magic.mana),
      manaMax: Math.floor(this.lore.magic.manaMax + this.lore.artEffect("mana")),
      spellCount: this.lore.magic.spells.length,
      artifactCount: this.lore.magic.artifacts.length,
      beastCount: this.lore.magic.beasts.length,
      ritualName: this.lore.magic.ritual ? (RITUALS.find((r) => r.id === this.lore.magic.ritual!.id)?.name ?? null) : null,
      ritualLeft: this.lore.magic.ritual?.left ?? 0,
      religionFounded: this.lore.religion.founded,
      religionName: this.lore.religion.name,
      religionSymbol: this.lore.religion.symbol,
      religionColor: this.lore.religion.color,
      followers: Math.round(this.lore.religion.followers * 10) / 10,
      doctrineCount: this.lore.religion.doctrines.length,
      inquisition: this.lore.religion.inquisition,
      culture: Math.floor(this.lore.culture.points),
      cultureTotal: Math.floor(this.lore.culture.total),
      greatsReady: this.lore.culture.greats.filter((g) => !g.used).length,
      borders: this.lore.borderRadius(),
      cultureVictory: Math.round(this.lore.culture.victoryProgress),
      layerName: this.layers.def(this.z).name,
      layerShort: this.layers.def(this.z).short,
      layerIcon: this.layers.def(this.z).icon,
      layerColor: this.layers.def(this.z).color,
      layerDanger: this.layers.def(this.z).danger,
      layerHazard: this.layers.def(this.z).hazardText,
      oxygen: Math.round(this.layers.oxygen),
      hasGearForLayer: !this.layers.def(this.z).needItem || this.layers.hasGear(this.layers.def(this.z).needItem!),
      unlockedLayers: this.layers.unlocked.size,
      gateBuilding: this.layers.building?.id ?? null,
      gateLeft: this.layers.building?.left ?? 0,
      spaceBuilds: this.layers.spaceBuilds.size,
      bossHere: this.layers.bossOf(this.z)?.name ?? null,
      bossAliveHere: this.layers.bossAlive(this.z),
      chaosRule: this.layers.chaosRule,
      mode: this.mode,
      modeName: MODE_BY_ID[this.mode].name,
      act: this.meta.act,
      questCount: this.meta.activeQuests().length,
      storyTitle: this.meta.storyQuest()?.title ?? null,
      questsDone: this.meta.questsDone.size,
      stars: this.meta.stars,
      prestige: this.meta.prestige,
      rating: Math.round(this.meta.rating),
      achCount: this.meta.achievements.size,
      collCount: this.meta.collection.size,
      dailyStreak: this.meta.daily.streak,
      dailyReady: !this.meta.daily.claimed,
      dailyTasksLeft: this.meta.daily.tasks.filter((t) => !t.done).length,
      pendingChoice: this.meta.pendingChoice !== null,
      hardcoreDeath: this.hardcoreDeath,
    };
  }

  // ---------- Сохранение ----------
  serialize(): SaveData {
    return {
      version: 1, seed: this.seed, slot: this.slot,
      time: this.time, day: this.day, season: this.season(), weather: this.weather,
      z: this.z,
      player: { ...this.player, inv: this.player.inv.map((s) => ({ ...s })), equip: { ...this.player.equip } },
      mods: [...this.mods.entries()],
      buildings: this.buildings.map((b) => ({ ...b })),
      dragonDead: this.dragonDead,
      stats: { ...this.stats },
      tutorial: this.tutorialStep,
      meta: { savedAt: Date.now(), name: `${this.worldName} · день ${this.day} · ур. ${this.player.level}` },
      cityData: {
        city: JSON.parse(JSON.stringify(this.city.s)),
        market: JSON.parse(JSON.stringify(this.economy.market)),
        bank: JSON.parse(JSON.stringify(this.economy.bank)),
        routes: this.economy.routes.map((r) => ({ ...r })),
        towns: this.economy.towns.map((t) => ({ ...t })),
        npcs: this.npcs.npcs.map((n) => ({ ...n, children: [...n.children] })),
        royals: this.dynasty.royals.map((r) => ({ ...r })),
        factions: this.dynasty.factions.map((f) => ({ ...f })),
        gov: this.dynasty.gov,
        npcUid: this.npcs.uid,
        eventLog: this.dynasty.log.map((l) => ({ ...l })),
      },
      warData: {
        squads: this.army.squads.map((s) => ({ ...s })),
        generals: this.army.generals.map((g) => ({ ...g })),
        nations: this.nations.nations.map((n) => ({ ...n, wars: [...n.wars], allies: [...n.allies] })),
        league: { ...this.nations.league },
        envoys: this.nations.envoys.map((x) => ({ ...x })),
        warLog: this.nations.warLog.map((l) => ({ ...l })),
        genUid: this.army.genUid,
        squadUid: this.army.squadUid,
        cb: { ...this.nations.cb },
        hospital: this.army.hospital.map((h) => ({ ...h })),
        guerrilla: this.nations.guerrilla,
        fame: this.nations.fame,
      },
      loreData: {
        techs: [...this.lore.techs],
        science: this.lore.science,
        sciTotal: this.lore.sciTotal,
        era: this.lore.era,
        researching: this.lore.researching,
        magic: JSON.parse(JSON.stringify(this.lore.magic)),
        religion: JSON.parse(JSON.stringify(this.lore.religion)),
        culture: JSON.parse(JSON.stringify(this.lore.culture)),
        worldReligions: this.lore.worldReligions.map((w) => ({ ...w })),
      },
      layerData: this.layers.serialize(),
      metaData: this.meta.serialize(),
      personaData: this.personae.serialize(),
      cinemaData: this.cine.serialize(),
      mode: this.mode,
    };
  }
  save(silent = false) {
    const ok = saveSlot(this.serialize());
    this.stats.saved = (this.stats.saved ?? 0) + 1;
    if (!silent) this.toast(ok ? "Игра сохранена" : "Не удалось сохранить", ok ? "good" : "bad");
    return ok;
  }
  load(slot: number): boolean {
    const d = loadSlotSync(slot);
    if (!d) return false;
    this.applySave(d);
    return true;
  }
  applySave(d: SaveData) {
    this.seed = d.seed; this.slot = d.slot; this.z = d.z;
    this.time = d.time; this.day = d.day; this.weather = d.weather;
    this.player = { ...d.player, swing: 0, swingDir: 1 };
    this.mods = new Map(d.mods);
    this.buildings = d.buildings.map((b) => ({ ...b }));
    this.bIndex.clear();
    for (const b of this.buildings) this.bIndex.set(`${b.tx},${b.ty}`, b);
    this.dragonDead = d.dragonDead;
    this.stats = { ...d.stats };
    this.tutorialStep = d.tutorial ?? 0;
    this.rng = mulberry32((d.seed ^ Date.now()) >>> 0);
    this.mobs = []; this.projectiles = []; this.particles = []; this.floaters = [];
    this.cam.x = this.player.x; this.cam.y = this.player.y;
    this.worldName = d.meta?.name?.split(" · ")[0] ?? "Старая земля";
    this.lastDay = d.day;
    // ---- восстановление города и державы (старые сейвы просто получают новое ядро) ----
    this.city = new CitySim();
    this.economy = new EconomySim();
    this.economy.init(d.seed);
    this.npcs = new NpcSim();
    this.dynasty = new DynastySim();
    this.dynasty.init(d.day);
    const cd = d.cityData as CitySave | undefined;
    if (cd) {
      this.city.s = { ...freshCity(), ...cd.city, districts: { ...freshCity().districts, ...cd.city?.districts } };
      if (cd.market) for (const k of Object.keys(cd.market)) if (this.economy.market[k]) this.economy.market[k] = cd.market[k];
      if (cd.bank) this.economy.bank = cd.bank;
      if (cd.routes) this.economy.routes = cd.routes.map((r: TradeRoute) => ({ ...r }));
      if (cd.towns?.length) this.economy.towns = cd.towns.map((t) => ({ ...t }));
      if (cd.npcs) { this.npcs.npcs = cd.npcs.map((n) => ({ ...n })); this.npcs.uid = cd.npcUid ?? this.npcs.npcs.length + 1; }
      if (cd.royals?.length) this.dynasty.royals = cd.royals.map((r) => ({ ...r }));
      if (cd.factions?.length) this.dynasty.factions = cd.factions.map((f) => ({ ...f }));
      if (cd.gov) this.dynasty.gov = cd.gov;
      if (cd.eventLog) this.dynasty.log = cd.eventLog.map((l) => ({ ...l }));
      this.dynasty.uid = Math.max(1, ...this.dynasty.royals.map((r) => r.uid + 1));
      this.city.recompute(this);
    }
    // ---- армия, нации, битвы ----
    this.army = new ArmySim();
    this.army.reset();
    this.nations = new NationSim();
    this.nations.init(d.seed);
    this.battle = new BattleSim();
    this.battle.reset();
    const wd = d.warData as WarSave | undefined;
    if (wd) {
      if (wd.squads) this.army.squads = wd.squads.map((s) => ({ ...s }));
      if (wd.generals) this.army.generals = wd.generals.map((g) => ({ ...g }));
      if (wd.hospital) this.army.hospital = wd.hospital.map((h) => ({ ...h }));
      this.army.genUid = Math.max(1, wd.genUid ?? 1);
      this.army.squadUid = Math.max(1, wd.squadUid ?? 1);
      if (wd.nations?.length) this.nations.nations = wd.nations.map((n) => ({ ...n, wars: [...(n.wars ?? [])], allies: [...(n.allies ?? [])] }));
      if (wd.league) this.nations.league = { ...wd.league };
      if (wd.envoys) this.nations.envoys = wd.envoys.map((x) => ({ ...x }));
      if (wd.warLog) this.nations.warLog = wd.warLog.map((l) => ({ ...l }));
      if (wd.cb) this.nations.cb = { ...wd.cb };
      this.nations.guerrilla = !!wd.guerrilla;
      this.nations.fame = wd.fame ?? 0;
    }
    // ---- знание, чары, вера, культура ----
    this.lore = new LoreSim();
    this.lore.init(d.seed);
    const ld = d.loreData as LoreSave | undefined;
    if (ld) {
      if (ld.techs) this.lore.techs = new Set(ld.techs);
      this.lore.science = ld.science ?? 0;
      this.lore.sciTotal = ld.sciTotal ?? 0;
      if (ld.era) this.lore.era = ld.era;
      this.lore.researching = ld.researching ?? null;
      if (ld.magic) this.lore.magic = { ...this.lore.magic, ...ld.magic, cds: { ...(ld.magic.cds ?? {}) } };
      if (ld.religion) this.lore.religion = { ...this.lore.religion, ...ld.religion };
      if (ld.culture) this.lore.culture = { ...this.lore.culture, ...ld.culture, greats: (ld.culture.greats ?? []).map((g) => ({ ...g })) };
      if (ld.worldReligions?.length) this.lore.worldReligions = ld.worldReligions.map((w) => ({ ...w }));
    }
    this.layers = new LayerSim();
    this.layers.reset();
    if (d.layerData) this.layers.load(d.layerData as LayerSave);
    this.meta = new MetaSim();
    this.meta.init((d.mode as GameMode) ?? "normal");
    if (d.metaData) this.meta.load(d.metaData as MetaSave);
    this.mode = this.meta.mode;
    // ---- именные жители и кинематографика (8-й этап) ----
    this.personae = new PersonaSim();
    this.personae.reset();
    this.personae.load(d.personaData as import("./personae").PersonaSave | undefined);
    this.cine = new CineSim();
    this.cine.reset();
    this.cine.load(d.cinemaData as import("./cutscenes").CineSave | undefined);
    this.timeScale = 1;
    this.poke();
  }

  // ---------- Главный цикл ----------
  update(dtReal: number) {
    if (this.paused) return;
    let dt = dtReal;
    if (this.freeze > 0) { this.freeze -= dtReal; dt = dtReal * 0.06; }
    else if (this.timeScale !== 1) dt = dtReal * this.timeScale; // кинематографическое слоумо
    const p = this.player;

    // время
    this.time += dt / DAY_LEN;
    if (this.time >= 1) { this.time -= 1; this.day += 1; this.toast(`День ${this.day}. ${["Весна", "Лето", "Осень", "Зима"][this.season()]} в этих землях`, "info"); }
    if (this.day !== this.lastDay) { this.lastDay = this.day; this.onNewDay(); }
    this.weatherT -= dt;
    if (this.weatherT <= 0) this.rollWeather();

    // выживание
    if (!p.dead) {
      const hot = p.temp > 36, cold = p.temp < 2;
      const hungerOn = MODE_BY_ID[this.mode].hunger;
      if (hungerOn) p.food = clamp(p.food - dt * (100 / 600), 0, 100);
      if (hungerOn) p.water = clamp(p.water - dt * (100 / 480) * (hot ? 1.7 : 1), 0, 100);
      if (p.food <= 0) { p.hp = clamp(p.hp - dt * 1.4, 0, p.maxHp); if (Math.random() < dt * 0.5) this.addFloater("Голод!", "#f2b45c", p.x, p.y - 34); }
      if (p.water <= 0) { p.hp = clamp(p.hp - dt * 1.8, 0, p.maxHp); if (Math.random() < dt * 0.5) this.addFloater("Жажда!", "#7fd4f2", p.x, p.y - 34); }
      if (cold) { p.hp = clamp(p.hp - dt * 1.1, 0, p.maxHp); if (Math.random() < dt * 0.4) this.addFloater("Обморожение", "#9fd4f2", p.x, p.y - 34); }
      if (p.poisonT > 0) { p.poisonT -= dt; p.hp = clamp(p.hp - dt * 0.9, 0, p.maxHp); }
      // реген
      if (p.food > 55 && p.water > 45 && p.hp < p.maxHp) p.hp = clamp(p.hp + dt * 1.6, 0, p.maxHp);
      if (p.hp <= 0) this.die();
      // стамина
      p.stamina = clamp(p.stamina + dt * (p.food > 15 ? 7 : 2.2), 0, 100);
    }

    // движение
    this.swingCd = Math.max(0, this.swingCd - dt);
    this.hammerCd = Math.max(0, this.hammerCd - dt);
    this.bumpCd = Math.max(0, this.bumpCd - dt);
    if (this.bumpFx.t > 0) this.bumpFx.t = Math.max(0, this.bumpFx.t - dt);
    p.swing = Math.max(0, p.swing - dt * 3.2);
    let mvx = 0, mvy = 0;
    if (this.keys.has("w") || this.keys.has("arrowup")) mvy -= 1;
    if (this.keys.has("s") || this.keys.has("arrowdown")) mvy += 1;
    if (this.keys.has("a") || this.keys.has("arrowleft")) mvx -= 1;
    if (this.keys.has("d") || this.keys.has("arrowright")) mvx += 1;
    if ((mvx !== 0 || mvy !== 0) && !p.dead) {
      const n = Math.hypot(mvx, mvy);
      mvx /= n; mvy /= n;
      this.moveTarget = null; this.pending = null;
      this.cam.follow = true;
    } else if (this.moveTarget && !p.dead) {
      const dx = this.moveTarget.x - p.x, dy = this.moveTarget.y - p.y;
      const dd = Math.hypot(dx, dy);
      if (dd < 6) {
        this.moveTarget = null;
        if (this.pending) {
          const pa = this.pending;
          // проверить дистанцию до цели действия
          const cDist = this.distTo(pa.tx * TILE + 20, pa.ty * TILE + 20);
          if (pa.kind === "attack") {
            const m = this.mobs.find((mm) => mm.uid === pa.mobUid);
            if (m && this.distTo(m.x, m.y) <= ATK_REACH) { this.doAction(pa); this.pending = null; }
            else if (m) { this.moveTarget = { x: m.x, y: m.y }; }
            else this.pending = null;
          } else if (cDist <= REACH) { this.doAction(pa); this.pending = null; }
          else this.pending = null;
        }
      } else { mvx = dx / dd; mvy = dy / dd; }
    }
    // цель атаки догоняет подвижного моба
    if (this.pending?.kind === "attack") {
      const m = this.mobs.find((mm) => mm.uid === this.pending!.mobUid);
      if (m) {
        if (this.distTo(m.x, m.y) <= ATK_REACH) { this.doAction(this.pending); this.pending = null; }
        else this.moveTarget = { x: m.x, y: m.y };
      } else this.pending = null;
    }

    if ((mvx !== 0 || mvy !== 0) && !p.dead) {
      const slow = p.stamina < 12 ? 0.65 : 1;
      const sp = PLAYER_SPEED * slow * (this.weather === "snow" && this.z === 0 ? 0.92 : 1);
      const nx = p.x + mvx * sp * TILE * dt;
      const ny = p.y + mvy * sp * TILE * dt;
      const r = 0.3;
      const bxT = Math.floor((nx + Math.sign(mvx) * r * TILE) / TILE);
      const byT = Math.floor((ny + Math.sign(mvy) * r * TILE) / TILE);
      if (!this.isBlocked(bxT, Math.floor(p.y / TILE))) p.x = nx;
      else this.bumpInto(bxT, Math.floor(p.y / TILE));
      if (!this.isBlocked(Math.floor(p.x / TILE), byT)) p.y = ny;
      else this.bumpInto(Math.floor(p.x / TILE), byT);
      p.dir = Math.atan2(mvy, mvx);
      p.moving = true;
      this.stats.moved = (this.stats.moved ?? 0) + dt * 0.25;
      snd.step();
      p.stamina = clamp(p.stamina - dt * 0.4, 0, 100);
    } else p.moving = false;

    this.updateTemperature();

    // здания
    for (const b of this.buildings) {
      const def = BUILDINGS[b.def];
      if (!b.done) {
        b.progress += dt * this.buildSpeed();
        if (b.progress >= def.buildTime) this.finishBuild(b);
      } else if (def.produce) {
        const rainBoost = this.weather === "rain" && b.def === "ferma" ? 1.5 : 1;
        if (b.store < def.produce.max) {
          b.prodT += dt * rainBoost;
          if (b.prodT >= def.produce.every) { b.prodT = 0; b.store++; this.poke(); }
        }
      }
    }

    // мобы и спавн
    this.spawnT -= dt;
    if (this.spawnT <= 0) { this.spawnT = 2.6 + this.rng() * 1.5; this.trySpawn(); }
    this.dragonCheckT -= dt;
    if (this.dragonCheckT <= 0) { this.dragonCheckT = 2; this.spawnDragonIfClose(); }
    for (const m of [...this.mobs]) {
      this.updateMob(m, dt);
    }
    this.mobs = this.mobs.filter((m) => m.hp > 0);

    // снаряды
    for (const pr of [...this.projectiles]) {
      pr.t -= dt;
      pr.x += pr.vx * dt; pr.y += pr.vy * dt;
      if (pr.kind === "fire" && Math.random() < dt * 20) {
        this.particles.push({ x: pr.x, y: pr.y, vx: (Math.random() - 0.5) * 40, vy: (Math.random() - 0.5) * 40, age: 0, life: 0.4, color: "#f2a24d", size: 3, grav: 0, kind: "ember" });
      }
      const dp = Math.hypot(pr.x - p.x, pr.y - (p.y - 10));
      if (dp < 18 && !p.dead) {
        this.hurtPlayer(pr.dmg, pr.x, pr.y);
        pr.t = 0;
      }
      if (pr.t <= 0) this.projectiles = this.projectiles.filter((x) => x !== pr);
    }

    // частицы и флоатеры
    for (const pt of this.particles) {
      pt.age += dt;
      pt.x += pt.vx * dt; pt.y += pt.vy * dt;
      pt.vy += pt.grav * dt;
    }
    this.particles = this.particles.filter((pt) => pt.age < pt.life);
    for (const f of this.floaters) f.age += dt;
    this.floaters = this.floaters.filter((f) => f.age < 1.3);

    // камера
    const targetX = p.x + this.cam.panX;
    const targetY = p.y + this.cam.panY;
    this.cam.x = lerp(this.cam.x, targetX, 1 - Math.pow(0.0018, dt));
    this.cam.y = lerp(this.cam.y, targetY, 1 - Math.pow(0.0018, dt));
    if (this.cam.follow) { this.cam.panX = lerp(this.cam.panX, 0, dt * 2); this.cam.panY = lerp(this.cam.panY, 0, dt * 2); }
    this.shake = Math.max(0, this.shake - dt * 2.4);
    this.dmgFlash = Math.max(0, this.dmgFlash - dt * 1.6);

    // звук окружения
    const mood = this.battle.s.active ? "war"
      : this.nations.atWar().length > 0 || this.nations.nations.some((n) => n.incoming) ? "war"
        : this.z === 2 || this.z === 1 ? "deep"
          : this.z === 5 || this.z === 6 ? "space"
            : this.city.s.paradeT > 0 ? "victory"
              : this.isNight() ? "night" : "calm";
    snd.update(dt, {
      mood,
      night: this.isNight(),
      rain: this.weather === "rain" || this.weather === "storm" ? 1 : 0,
      snow: this.weather === "snow",
      windAmt: this.z === 1 ? 0.2 : this.weather === "fog" || this.weather === "storm" ? 1 : 0.45,
      nearFire: this.nearFire(),
    });
    // гроза — вспышки и раскаты
    if (this.weather === "storm" && Math.random() < dt * 0.08) {
      snd.thunder();
    }

    // ---- системы города, экономики, жителей ----
    this.city.update(this, dt);
    this.economy.update(this, dt);
    this.npcs.update(this, dt);
    this.personae.update(this, dt);
    this.cine.update(this, dt);
    // ---- армия, нации, битвы ----
    this.army.update(this, dt);
    this.nations.update(this, dt);
    this.battle.update(this, dt);
    this.lore.update(this, dt);
    this.layers.update(this, dt);
    this.meta.update(this, dt);
    for (const b of this.buildings) if (b.smoke && b.smoke > 0) b.smoke -= dt;

    // автосейв
    this.autosaveT -= dt;
    if (this.autosaveT <= 0) {
      this.autosaveT = 30;
      if (!p.dead && MODE_BY_ID[this.mode].autosave) this.save(true);
    }

    // ui
    this.uiT -= dt;
    if (this.uiT <= 0) { this.uiT = 0.12; this.poke(); }
  }
}

function diggOk(g: number): boolean {
  return g === G.Sand || g === G.Desert || g === G.Snow || g === G.Dirt;
}

export function xpNeed(level: number): number {
  return Math.round(34 * Math.pow(level, 1.32));
}
