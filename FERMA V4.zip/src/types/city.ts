// ===== Типы города, экономики, жителей и династии =====

// ---- Районы ----
export type District = "res" | "ind" | "com" | "mil" | "sci" | "mag" | "rel";
export const DISTRICTS: { id: District; name: string; icon: string; desc: string }[] = [
  { id: "res", name: "Жилой", icon: "Home", desc: "Больше домов и прироста жителей" },
  { id: "ind", name: "Промышленный", icon: "Factory", desc: "Ускоряет производства, но коптит небо" },
  { id: "com", name: "Торговый", icon: "Coins", desc: "Рост налогов и прибыли караванов" },
  { id: "mil", name: "Военный", icon: "Swords", desc: "Порядок, гарнизон, подавление бунтов" },
  { id: "sci", name: "Научный", icon: "FlaskConical", desc: "Наука и скорость строительства" },
  { id: "mag", name: "Магический", icon: "Sparkles", desc: "Чары, редкие товары, странные ветра" },
  { id: "rel", name: "Религиозный", icon: "Church", desc: "Вера и спокойствие в сердцах" },
];

// ---- Эффекты здания на город ----
export interface CityEff {
  food?: number; water?: number; energy?: number; health?: number;
  crime?: number; pollution?: number; culture?: number; faith?: number;
  science?: number; gold?: number; order?: number; happy?: number;
}

export interface CityMetrics {
  food: number; water: number; energy: number; health: number;
  crime: number; pollution: number; culture: number; faith: number;
  science: number; order: number;
}

export interface CityState {
  founded: boolean;
  name: string;
  cx: number; cy: number;      // центр (ратуша), в тайлах
  foundedDay: number;
  pop: number;                  // текущее население (дробное для плавного роста)
  popCap: number;
  happiness: number;            // 0..100
  taxRate: number;              // 0..50 %
  jobs: number;
  employed: number;
  metrics: CityMetrics;
  districts: Record<District, number>;   // приоритет 0..2
  edicts: Record<string, number>;        // id -> день окончания
  stock: Record<string, number>;         // городской склад
  riot: number;                          // 0..100 напряжение
  rioting: boolean;
  tier: number;                          // ранг города 1..6
  monuments: string[];
  paradeT: number;                       // визуальный праздник
  lastGrowT: number;
  history: number[];                     // население по дням
  totalTax: number;
  unrestNote: string;
}

export const TIER_NAMES = ["Стоянка", "Деревня", "Село", "Городок", "Город", "Столица", "Великий Град"];

// ---- Указы ----
export interface EdictDef {
  id: string; name: string; desc: string; icon: string;
  cost: number; days: number;
  happy?: number; taxMul?: number; crime?: number; order?: number;
  growth?: number; science?: number; faith?: number; prod?: number;
}

// ---- Экономика ----
export interface GoodDef { id: string; name: string; base: number; cat: string }
export interface GoodMarket { price: number; trend: number; stock: number; demand: number; hist: number[] }

export interface Loan { id: number; amount: number; rate: number; left: number; dueDay: number }
export interface BankState {
  deposit: number; depRate: number;
  loans: Loan[]; loanRate: number;
  invested: number; investDay: number;
  credit: number; // кредитный рейтинг 0..100
}

export type RouteKind = "caravan" | "ship" | "train";
export interface TradeRoute {
  id: number; kind: RouteKind; town: string;
  good: string; n: number;
  progress: number; dur: number;
  profit: number; risk: number;
  state: "go" | "back" | "raided" | "done";
  x: number; y: number; ang: number;
}

export interface NeighborTown {
  id: string; name: string; dist: number; ang: number;
  wants: string; gives: string; relation: number; embargo: boolean;
}

// ---- NPC ----
export type NpcRole =
  | "krestyanin" | "kupec" | "remeslennik" | "strazhnik" | "mag" | "uchenyi"
  | "svyashennik" | "razbojnik" | "pirat" | "kochevnik" | "strannik" | "rebenok" | "starik";

export const NPC_ROLES: Record<NpcRole, { name: string; color: string; icon: string }> = {
  krestyanin: { name: "Крестьянин", color: "#8a7a52", icon: "Wheat" },
  kupec: { name: "Купец", color: "#c9a227", icon: "Coins" },
  remeslennik: { name: "Ремесленник", color: "#9a6a44", icon: "Hammer" },
  strazhnik: { name: "Стражник", color: "#7a8a9a", icon: "Shield" },
  mag: { name: "Маг", color: "#8a6ac9", icon: "Sparkles" },
  uchenyi: { name: "Учёный", color: "#5a9ac9", icon: "FlaskConical" },
  svyashennik: { name: "Священник", color: "#d8cbb0", icon: "Church" },
  razbojnik: { name: "Разбойник", color: "#6a4a4a", icon: "Skull" },
  pirat: { name: "Пират", color: "#4a5a6a", icon: "Anchor" },
  kochevnik: { name: "Кочевник", color: "#a07a4a", icon: "Tent" },
  strannik: { name: "Странник", color: "#7a9a7a", icon: "Footprints" },
  rebenok: { name: "Ребёнок", color: "#d9a88a", icon: "Baby" },
  starik: { name: "Старик", color: "#b0a898", icon: "PersonStanding" },
};

export type NpcState = "home" | "work" | "tavern" | "walk" | "talk" | "flee" | "riot";

export interface Npc {
  uid: number; name: string; role: NpcRole; sex: 0 | 1;
  age: number; x: number; y: number;
  tx: number; ty: number;                 // цель
  hx: number; hy: number;                 // дом
  wx: number; wy: number;                 // работа
  state: NpcState; t: number;
  mood: number;                           // -100..100 отношение к игроку
  spouse: number; children: number[];     // spouse = -1 → замужем/женат на игроке
  anim: number; talkT: number;
  quest: { item: string; n: number; reward: number } | null;
  bob: number;
  persona?: string;                       // id именного персонажа из data/npcs.ts (8-й этап)
}

// ---- Династия ----
export type RoyalRole = "ruler" | "consort" | "heir" | "child" | "relative";
export interface Royal {
  uid: number; name: string; sex: 0 | 1; age: number;
  role: RoyalRole; trait: string; ambition: string;
  loyalty: number; skill: number; alive: boolean;
  spouse: number; parent: number; born: number;
}

export const TRAITS = ["Мудрый", "Храбрый", "Скупой", "Щедрый", "Хитрый", "Набожный", "Гневливый", "Учёный", "Прекрасный", "Суровый"];
export const AMBITIONS = ["Слава рода", "Золото и торг", "Вера отцов", "Меч и щит", "Тайные знания", "Мир и покой"];

// ---- Парламент ----
export type FactionId = "znat" | "kupcy" | "cerkov" | "narod" | "armiya" | "magi";
export interface Faction { id: FactionId; name: string; icon: string; power: number; support: number; demand: string }

export const FACTION_BASE: { id: FactionId; name: string; icon: string; demands: string[] }[] = [
  { id: "znat", name: "Знать", icon: "Crown", demands: ["Снизить налоги для родов", "Построить дворец", "Дать земли наследнику"] },
  { id: "kupcy", name: "Купечество", icon: "Coins", demands: ["Открыть новый торговый путь", "Построить биржу", "Снизить пошлины"] },
  { id: "cerkov", name: "Церковь", icon: "Church", demands: ["Возвести храм", "Объявить день молитвы", "Больше веры в городе"] },
  { id: "narod", name: "Народ", icon: "Users", demands: ["Устроить праздник", "Снизить налоги", "Больше еды в амбарах"] },
  { id: "armiya", name: "Армия", icon: "Swords", demands: ["Построить казармы", "Укрепить стены", "Поднять порядок"] },
  { id: "magi", name: "Круг магов", icon: "Sparkles", demands: ["Возвести алтарь", "Открыть портал", "Основать академию"] },
];

// ---- Формы правления ----
export type GovForm = "monarchy" | "republic" | "theocracy" | "dictature" | "magocracy" | "technocracy";
export interface GovDef {
  id: GovForm; name: string; icon: string; desc: string;
  tax: number; happy: number; science: number; order: number; faith: number; trade: number;
  need: string;
}

export const GOVERNMENTS: GovDef[] = [
  { id: "monarchy", name: "Монархия", icon: "Crown", desc: "Власть по крови. Знать довольна, народ терпит.", tax: 1, happy: 0, science: 1, order: 1.15, faith: 1.1, trade: 1, need: "Начальная форма правления" },
  { id: "republic", name: "Республика", icon: "Scale", desc: "Голос купцов и народа. Торговля цветёт, армия ропщет.", tax: 1.15, happy: 1.1, science: 1.1, order: 0.9, faith: 0.9, trade: 1.25, need: "Парламент + поддержка купцов 60" },
  { id: "theocracy", name: "Теократия", icon: "Church", desc: "Слово веры — закон. Покой и вера, но наука спит.", tax: 0.95, happy: 1.1, science: 0.75, order: 1.2, faith: 1.6, trade: 0.9, need: "Собор + поддержка церкви 60" },
  { id: "dictature", name: "Диктатура", icon: "Swords", desc: "Железный кулак. Порядок любой ценой.", tax: 1.3, happy: 0.75, science: 0.9, order: 1.6, faith: 0.9, trade: 1, need: "Казармы + поддержка армии 60" },
  { id: "magocracy", name: "Магократия", icon: "Sparkles", desc: "Правят чародеи. Чудеса вместо законов.", tax: 1, happy: 1, science: 1.35, order: 1, faith: 0.7, trade: 1.1, need: "Обсидиановый трон + поддержка магов 60" },
  { id: "technocracy", name: "Технократия", icon: "FlaskConical", desc: "Правят учёные. Расчёт выше чувств.", tax: 1.1, happy: 0.95, science: 1.6, order: 1.05, faith: 0.6, trade: 1.15, need: "Университет + поддержка магов/купцов 55" },
];

// ---- Сохранение доп. блока ----
export interface CitySave {
  city: CityState;
  market: Record<string, GoodMarket>;
  bank: BankState;
  routes: TradeRoute[];
  towns: NeighborTown[];
  npcs: Npc[];
  royals: Royal[];
  factions: Faction[];
  gov: GovForm;
  npcUid: number;
  eventLog: { day: number; text: string; kind: string }[];
}
