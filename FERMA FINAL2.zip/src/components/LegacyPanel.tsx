import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { ACHIEVEMENTS, ACH_CATS, COLLECTION, COLLECT_CATS } from "../data/achievements";
import { STAR_UPGRADES, MODE_BY_ID } from "../types/meta";
import {
  Star, Trophy, Boxes, Gift, Infinity as Inf, Crown, Check, Lock,
  Flame, Bell, HelpCircle, ChevronRight,
} from "lucide-react";
import { ENCYCLOPEDIA } from "../data/encyclopedia";

const TABS = ["Награды", "Достижения", "Коллекция", "Звёзды", "Рейтинг", "Помощь"];

export function LegacyPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const m = engine.meta;
  const [tab, setTab] = useState("Награды");
  const [achCat, setAchCat] = useState<string>("survive");
  const [colCat, setColCat] = useState<string>("flora");
  const [encOpen, setEncOpen] = useState<string | null>(null);

  return (
    <Sheet
      title="Наследие"
      sub={`★ ${snap.stars} · достижений ${snap.achCount}/${ACHIEVEMENTS.length} · коллекция ${snap.collCount}/${COLLECTION.length} · рейтинг ${snap.rating}`}
      onClose={onClose}
    >
      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "60vh" }}>

        {tab === "Награды" && (
          <div className="space-y-2">
            <div className="rounded-xl border border-amber-400/30 bg-amber-400/8 p-3 text-center">
              <Gift size={26} className="mx-auto text-amber-300" />
              <div className="mt-1 font-display text-[16px] font-bold text-amber-100">Ежедневная награда</div>
              <div className="text-[11.5px] text-white/50">Серия: {snap.dailyStreak} дн. подряд</div>
              <div className="mt-2 flex justify-center gap-1">
                {[...Array(7)].map((_, i) => (
                  <div key={i} className={`h-2.5 w-2.5 rounded-full ${i < (snap.dailyStreak % 7 || (snap.dailyStreak > 0 ? 7 : 0)) ? "bg-amber-400" : "bg-white/15"}`} />
                ))}
              </div>
              <button className="btn mt-2.5 w-full py-2.5!" disabled={!snap.dailyReady} onClick={() => m.claimDaily(engine)}>
                {snap.dailyReady ? `Получить (+${300 + Math.max(1, snap.dailyStreak) * 150} зол., +${2 + Math.floor(Math.max(1, snap.dailyStreak) / 3)} ★)` : "Сегодня уже получено"}
              </button>
              <div className="mt-1 text-[10px] text-white/35">Каждый 7-й день — сундук с чешуёй дракона</div>
            </div>

            <div className="text-[11px] font-bold uppercase tracking-wide text-white/40">Задания дня</div>
            {m.daily.tasks.map((t) => (
              <div key={t.id} className={`rounded-xl border p-2 ${t.done ? "border-emerald-400/30 bg-emerald-400/6" : "border-white/8 bg-black/25"}`}>
                <div className="flex items-center gap-2">
                  {t.done ? <Check size={14} className="shrink-0 text-emerald-400" /> : <Flame size={14} className="shrink-0 text-amber-300/70" />}
                  <span className="flex-1 truncate text-[12.5px] text-amber-50">{t.text}</span>
                  <span className="text-[11px] font-bold text-white/45">{t.have}/{t.target}</span>
                  <span className="text-[11px] font-bold text-amber-300">+{t.reward} ★</span>
                </div>
                <div className="bar-track mt-1 h-1!">
                  <div className="bar-fill" style={{ width: `${Math.min(100, (t.have / t.target) * 100)}%`, background: t.done ? "#7ae68a" : "#f2c14e" }} />
                </div>
              </div>
            ))}

            <button className="btn-ghost w-full py-2! text-[12px]!" onClick={() => void m.askNotifications(engine)}>
              <Bell size={14} /> {m.notifications ? "Уведомления включены" : "Включить уведомления"}
            </button>
          </div>
        )}

        {tab === "Достижения" && (
          <div className="space-y-1.5">
            <div className="flex gap-1 overflow-x-auto pb-1" style={{ touchAction: "pan-x" }}>
              {ACH_CATS.map((c) => (
                <button key={c.id} onClick={() => setAchCat(c.id)}
                  className={`flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${achCat === c.id ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-white/50"}`}>
                  <ItemIcon icon={c.icon} size={11} /> {c.name}
                </button>
              ))}
            </div>
            {ACHIEVEMENTS.filter((a) => a.cat === achCat).map((a) => {
              const got = m.achievements.has(a.id);
              return (
                <div key={a.id} className={`flex items-center gap-2 rounded-xl border p-2 ${got ? "border-amber-400/35 bg-amber-400/8" : "border-white/8 bg-black/20 opacity-70"}`}>
                  <div className="item-cell h-9! w-9! shrink-0">
                    {got ? <ItemIcon icon={a.icon} size={16} className="text-amber-300" /> : <Lock size={13} className="text-white/25" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12.5px] font-bold text-amber-50">{a.name}</div>
                    <div className="truncate text-[10.5px] text-white/45">{a.desc}</div>
                  </div>
                  <span className={`shrink-0 text-[11px] font-bold ${got ? "text-amber-300" : "text-white/30"}`}>{a.stars} ★</span>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Коллекция" && (
          <div className="space-y-1.5">
            <div className="flex gap-1 overflow-x-auto pb-1" style={{ touchAction: "pan-x" }}>
              {COLLECT_CATS.map((c) => {
                const total = COLLECTION.filter((x) => x.cat === c.id).length;
                const got = COLLECTION.filter((x) => x.cat === c.id && m.collection.has(x.id)).length;
                return (
                  <button key={c.id} onClick={() => setColCat(c.id)}
                    className={`flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${colCat === c.id ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-white/50"}`}>
                    <ItemIcon icon={c.icon} size={11} /> {c.name} {got}/{total}
                  </button>
                );
              })}
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {COLLECTION.filter((c) => c.cat === colCat).map((c) => {
                const got = m.collection.has(c.id);
                return (
                  <div key={c.id} className={`rounded-xl border p-2 ${got ? "border-emerald-400/30 bg-emerald-400/6" : "border-white/8 bg-black/18 opacity-65"}`}>
                    <div className="flex items-center gap-1.5">
                      {got ? <ItemIcon icon={c.icon} size={15} className="text-emerald-300" /> : <Lock size={12} className="text-white/25" />}
                      <span className="truncate text-[12px] font-bold text-amber-50">{got ? c.name : "???"}</span>
                    </div>
                    <div className="mt-0.5 text-[10px] leading-snug text-white/45">{got ? c.desc : "Ещё не встречено"}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {tab === "Звёзды" && (
          <div className="space-y-1.5">
            <div className="rounded-xl border border-amber-400/30 bg-amber-400/8 p-2.5 text-center">
              <Star size={22} className="mx-auto text-amber-300" fill="currentColor" />
              <div className="font-display text-[20px] font-bold text-amber-100">{snap.stars} ★</div>
              <div className="text-[11px] text-white/45">Звёзды остаются с вами навсегда, даже после перерождения</div>
            </div>
            {STAR_UPGRADES.map((u) => {
              const lvl = m.upg(u.id);
              const cost = u.cost * (lvl + 1);
              const maxed = lvl >= u.max;
              return (
                <div key={u.id} className={`rounded-xl border p-2 ${maxed ? "border-emerald-400/30 bg-emerald-400/6" : "border-white/8 bg-black/25"}`}>
                  <div className="flex items-start gap-2">
                    <div className="item-cell h-9! w-9! shrink-0"><ItemIcon icon={u.icon} size={16} className="text-amber-200" /></div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[12.5px] font-bold text-amber-50">{u.name}</span>
                        <span className="text-[10px] font-bold text-amber-300">{lvl}/{u.max}</span>
                      </div>
                      <div className="text-[10.5px] leading-snug text-white/45">{u.desc}</div>
                    </div>
                    <button className="btn px-2.5! py-1.5! text-[11px]!" disabled={maxed || m.stars < cost}
                      onClick={() => m.buyUpgrade(engine, u.id)}>
                      {maxed ? "макс" : `${cost} ★`}
                    </button>
                  </div>
                </div>
              );
            })}

            <div className="mt-2 rounded-xl border border-purple-400/30 bg-purple-500/8 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[13px] font-bold text-purple-200">
                <Inf size={15} /> Перерождение
              </div>
              <p className="text-[11.5px] leading-snug text-white/55">
                Начать мир заново, обратив всё величие в звёзды. Достижения, коллекция и улучшения остаются.
              </p>
              <Row k="Перерождений" v={snap.prestige} color="#c98ae0" />
              <Row k="Получите звёзд" v={`${m.prestigeGain(engine)} ★`} color="#ffd97a" />
              <button className="btn mt-2 w-full py-2.5! text-[12.5px]!" disabled={!m.canPrestige(engine)}
                onClick={() => { if (confirm(`Переродиться? Мир начнётся заново, вы получите ${m.prestigeGain(engine)} ★`)) { m.doPrestige(engine); onClose(); } }}>
                <Inf size={14} /> Переродиться
              </button>
            </div>
          </div>
        )}

        {tab === "Рейтинг" && (
          <div className="space-y-1.5">
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <Row k="Ваш рейтинг" v={snap.rating} color="#ffd97a" />
              <Row k="Лучший результат" v={m.bestRating()} color="#7ae68a" />
              <Row k="Режим" v={`${snap.modeName} (×${MODE_BY_ID[m.mode].ratingMul})`} />
              <Row k="Перерождений" v={snap.prestige} />
            </div>
            <div className="text-[11px] font-bold uppercase tracking-wide text-white/40">Таблица славы</div>
            {m.leaderboard(engine).map((r, i) => (
              <div key={i} className={`flex items-center gap-2 rounded-xl border p-2 ${r.you ? "border-amber-400/50 bg-amber-400/10" : "border-white/8 bg-black/22"}`}>
                <span className={`w-6 shrink-0 text-center font-display text-[13px] font-bold ${i === 0 ? "text-amber-300" : i === 1 ? "text-white/70" : i === 2 ? "text-orange-300" : "text-white/35"}`}>
                  {i + 1}
                </span>
                {i === 0 ? <Crown size={14} className="shrink-0 text-amber-300" /> : <Trophy size={13} className="shrink-0 text-white/25" />}
                <span className={`flex-1 truncate text-[12.5px] ${r.you ? "font-bold text-amber-100" : "text-white/70"}`}>{r.name}</span>
                <span className="shrink-0 font-display text-[13px] font-bold text-amber-200">{r.score}</span>
              </div>
            ))}
            <p className="px-1 text-[10.5px] leading-snug text-white/35">
              Рейтинг растёт от уровня, богатства, города, знаний, миров, коллекции и перерождений.
            </p>
          </div>
        )}

        {tab === "Помощь" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11px] leading-snug text-white/45">
              Энциклопедия по всем механикам игры. Нажмите на раздел, чтобы раскрыть.
            </p>
            {ENCYCLOPEDIA.map((sec) => {
              const open = encOpen === sec.id;
              return (
                <div key={sec.id} className="overflow-hidden rounded-xl border border-white/8 bg-black/25">
                  <button className="flex w-full items-center gap-2 p-2.5 text-left" onClick={() => setEncOpen(open ? null : sec.id)}>
                    <ItemIcon icon={sec.icon} size={16} className="shrink-0 text-amber-200" />
                    <span className="flex-1 truncate text-[12.5px] font-bold text-amber-50">{sec.title}</span>
                    <ChevronRight size={14} className={`shrink-0 text-white/35 transition-transform ${open ? "rotate-90" : ""}`} />
                  </button>
                  {open && (
                    <div className="space-y-1.5 border-t border-white/8 px-2.5 py-2">
                      {sec.items.map((it, i) => (
                        <div key={i}>
                          <div className="text-[11.5px] font-bold text-amber-200/90">{it.q}</div>
                          <div className="text-[11.5px] leading-snug text-white/60">{it.a}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5 text-[11px] leading-snug text-white/45">
              <HelpCircle size={12} className="mr-1 inline" />
              Подсказка: удерживайте палец на любом месте мира — появится меню действий.
            </div>
          </div>
        )}
      </div>

      <div className="mt-2 flex items-center justify-between rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5 text-[11px]">
        <span className="flex items-center gap-1 text-amber-200"><Star size={11} fill="currentColor" /> {snap.stars}</span>
        <span className="flex items-center gap-1 text-white/45"><Trophy size={11} /> {snap.achCount}</span>
        <span className="flex items-center gap-1 text-white/45"><Boxes size={11} /> {snap.collCount}</span>
        <span className="flex items-center gap-1 text-white/45"><Inf size={11} /> {snap.prestige}</span>
      </div>
    </Sheet>
  );
}
