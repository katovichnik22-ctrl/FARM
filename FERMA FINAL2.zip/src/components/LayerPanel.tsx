import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { LAYERS, GATES, SPACE_BUILDS, ALIENS, LAYER_GEAR } from "../data/layers";
import { ITEMS } from "../data/items";
import {
  Lock, Check, ArrowRight, Hourglass, Skull, ShieldAlert,
  Rocket, Hammer, Gift, Handshake, Swords, Sparkle,
} from "lucide-react";

const TABS = ["Слои", "Переходы", "Снаряжение", "Космос"];

export function LayerPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const ly = engine.layers;
  const [tab, setTab] = useState("Слои");

  return (
    <Sheet
      title="Врата миров"
      sub={`Ныне: ${snap.layerName} · открыто слоёв ${snap.unlockedLayers}/${LAYERS.length} · опасность ${snap.layerDanger}/10`}
      onClose={onClose}
    >
      {/* Текущий слой */}
      <div className="mb-2 rounded-xl border p-2.5" style={{ borderColor: `${snap.layerColor}44`, background: "rgba(0,0,0,0.3)" }}>
        <div className="flex items-center gap-2">
          <ItemIcon icon={snap.layerIcon} size={20} style={{ color: snap.layerColor }} />
          <div className="min-w-0 flex-1">
            <div className="font-display text-[14px] font-bold text-amber-50">{snap.layerName}</div>
            {snap.layerHazard && (
              <div className={`text-[10.5px] ${snap.hasGearForLayer ? "text-white/45" : "text-rose-300"}`}>
                {snap.hasGearForLayer ? "Снаряжение защищает" : snap.layerHazard}
              </div>
            )}
          </div>
          {snap.bossHere && (
            <span className={`rounded-full px-2 py-0.5 text-[9.5px] font-bold ${snap.bossAliveHere ? "bg-rose-500/20 text-rose-200" : "bg-emerald-500/15 text-emerald-300"}`}>
              {snap.bossAliveHere ? `${snap.bossHere} жив` : "усмирён"}
            </span>
          )}
        </div>
        {snap.oxygen < 100 && (
          <>
            <div className="mt-1.5 flex justify-between text-[9.5px] uppercase tracking-wide text-white/40">
              <span>Воздух</span><span>{snap.oxygen}%</span>
            </div>
            <div className="bar-track h-1.5!">
              <div className="bar-fill" style={{ width: `${snap.oxygen}%`, background: snap.oxygen > 30 ? "#5cb8e0" : "#e05a5a" }} />
            </div>
          </>
        )}
        {snap.chaosRule && engine.z === 9 && (
          <div className="mt-1.5 rounded-lg bg-fuchsia-500/12 px-2 py-1 text-[10.5px] font-semibold text-fuchsia-200">
            Правило хаоса: {snap.chaosRule}
          </div>
        )}
      </div>

      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "52vh" }}>

        {tab === "Слои" && (
          <div className="space-y-1.5">
            {LAYERS.map((d) => {
              const unlocked = ly.isUnlocked(d.id);
              const here = engine.z === d.id;
              const can = ly.canTravel(engine, d.id);
              const boss = ly.bossOf(d.id);
              return (
                <div key={d.id}
                  className={`rounded-xl border p-2 ${here ? "border-amber-400/60 bg-amber-400/10" : unlocked ? "border-white/10 bg-black/28" : "border-white/8 bg-black/15 opacity-60"}`}>
                  <div className="flex items-start gap-2">
                    <div className="item-cell h-10! w-10! shrink-0" style={{ borderColor: `${d.color}55` }}>
                      {unlocked ? <ItemIcon icon={d.icon} size={18} style={{ color: d.color }} /> : <Lock size={15} className="text-white/30" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[13px] font-bold text-amber-50">{d.name}</span>
                        {here && <span className="rounded-full bg-amber-400/20 px-1.5 text-[9px] font-bold text-amber-200">вы здесь</span>}
                      </div>
                      <div className="text-[10.5px] italic leading-snug text-white/45">{d.desc}</div>
                      <div className="mt-0.5 flex flex-wrap gap-1 text-[9.5px] font-semibold">
                        <span className="rounded bg-rose-400/12 px-1.5 py-0.5 text-rose-200">опасность {d.danger}/10</span>
                        {d.needItemName && (
                          <span className={`rounded px-1.5 py-0.5 ${ly.hasGear(d.needItem!) ? "bg-emerald-400/12 text-emerald-300" : "bg-amber-400/12 text-amber-200"}`}>
                            {d.needItemName}
                          </span>
                        )}
                        {boss && (
                          <span className={`rounded px-1.5 py-0.5 ${ly.bossesKilled.has(boss.id) ? "bg-emerald-400/12 text-emerald-300" : "bg-purple-400/12 text-purple-200"}`}>
                            {ly.bossesKilled.has(boss.id) ? "✓ " : "босс: "}{boss.name}
                          </span>
                        )}
                        {!unlocked && <span className="rounded bg-white/8 px-1.5 py-0.5 text-white/45">{d.gate}</span>}
                      </div>
                    </div>
                    {!here && (
                      <button className="btn px-2.5! py-2! text-[11px]!" disabled={!can.ok}
                        onClick={() => { ly.travel(engine, d.id); onClose(); }}>
                        <ArrowRight size={13} />
                      </button>
                    )}
                  </div>
                  {!here && !can.ok && can.reason !== "Вы уже здесь" && (
                    <div className="mt-1 text-[10px] text-amber-300/70">{can.reason}</div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {tab === "Переходы" && (
          <div className="space-y-1.5">
            {ly.building && (
              <div className="rounded-xl border border-sky-400/30 bg-sky-400/8 p-2.5">
                <div className="flex items-center gap-1.5 text-[12.5px] font-bold text-sky-200">
                  <Hourglass size={13} /> Идёт стройка: {GATES.find((g) => g.id === ly.building!.id)?.name}
                </div>
                <div className="mt-0.5 text-[11px] text-white/50">Осталось {ly.building.left} дн.</div>
              </div>
            )}
            {GATES.map((g) => {
              const built = ly.hasGate(g.id);
              const c = ly.canBuildGate(engine, g.id);
              const to = ly.def(g.to);
              return (
                <div key={g.id} className={`rounded-xl border p-2 ${built ? "border-emerald-400/30 bg-emerald-400/6" : c.ok ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-70"}`}>
                  <div className="flex items-start gap-2">
                    <div className="item-cell h-10! w-10! shrink-0"><ItemIcon icon={g.icon} size={18} className={built ? "text-emerald-300" : "text-amber-200"} /></div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[13px] font-bold text-amber-50">{g.name}</span>
                        {built && <Check size={12} className="text-emerald-400" />}
                      </div>
                      <div className="text-[10.5px] italic leading-snug text-white/45">{g.desc}</div>
                      <div className="mt-0.5 text-[10px] font-semibold" style={{ color: to.color }}>
                        {ly.def(g.from).short} → {to.name}
                      </div>
                      {!built && (
                        <div className="mt-0.5 flex flex-wrap gap-x-2 text-[10px]">
                          <span className={engine.player.gold >= g.cost.gold ? "text-emerald-300" : "text-rose-300"}>{g.cost.gold} зол.</span>
                          {g.cost.res.map(([id, n]) => {
                            const have = engine.count(id) + engine.city.stockOf(id);
                            return <span key={id} className={have >= n ? "text-emerald-300" : "text-rose-300"}>{ITEMS[id]?.name ?? id} {have}/{n}</span>;
                          })}
                        </div>
                      )}
                    </div>
                    {!built && (
                      <button className="btn px-2.5! py-2! text-[11px]!" disabled={!c.ok} onClick={() => ly.buildGate(engine, g.id)}>
                        <Hammer size={13} />
                      </button>
                    )}
                  </div>
                  {!built && !c.ok && <div className="mt-1 text-[10px] text-amber-300/70">{c.reason}</div>}
                </div>
              );
            })}
          </div>
        )}

        {tab === "Снаряжение" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11px] leading-snug text-white/45">
              Без снаряжения иные слои убивают за считаные вздохи: жар, вакуум, вода.
            </p>
            {LAYER_GEAR.map((gr) => {
              const has = ly.hasGear(gr.id);
              const c = ly.canBuyGear(engine, gr.id);
              return (
                <div key={gr.id} className={`rounded-xl border p-2 ${has ? "border-emerald-400/30 bg-emerald-400/6" : c.ok ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-70"}`}>
                  <div className="flex items-start gap-2">
                    <div className="item-cell h-10! w-10! shrink-0"><ItemIcon icon={gr.icon} size={18} className={has ? "text-emerald-300" : "text-amber-200"} /></div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[13px] font-bold text-amber-50">{gr.name}</span>
                        {has && <Check size={12} className="text-emerald-400" />}
                      </div>
                      <div className="text-[10.5px] italic leading-snug text-white/45">{gr.desc}</div>
                      {!has && (
                        <div className="mt-0.5 flex flex-wrap gap-x-2 text-[10px]">
                          <span className={engine.player.gold >= gr.cost.gold ? "text-emerald-300" : "text-rose-300"}>{gr.cost.gold} зол.</span>
                          {gr.cost.res.map(([id, n]) => {
                            const have = engine.count(id) + engine.city.stockOf(id);
                            return <span key={id} className={have >= n ? "text-emerald-300" : "text-rose-300"}>{ITEMS[id]?.name ?? id} {have}/{n}</span>;
                          })}
                        </div>
                      )}
                    </div>
                    {!has && (
                      <button className="btn px-2.5! py-2! text-[11px]!" disabled={!c.ok} onClick={() => ly.buyGear(engine, gr.id)}>
                        Собрать
                      </button>
                    )}
                  </div>
                  {!has && !c.ok && <div className="mt-1 text-[10px] text-amber-300/70">{c.reason}</div>}
                </div>
              );
            })}
          </div>
        )}

        {tab === "Космос" && (
          <div className="space-y-1.5">
            <div className="rounded-xl border border-indigo-400/25 bg-indigo-500/8 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[12.5px] font-bold text-indigo-200">
                <Rocket size={14} /> Космическая программа
              </div>
              <Row k="Построек" v={`${ly.spaceBuilds.size}/${SPACE_BUILDS.length}`} color="#8fa2f2" />
              <Row k="Доход" v={`+${ly.spaceEffect("gold")} зол./день`} color="#f2c14e" />
              <Row k="Наука" v={`+${ly.spaceEffect("sci")}`} color="#5a9ac9" />
              {ly.spaceEffect("def") > 0 && <Row k="Орбитальный удар" v={`+${Math.round(ly.spaceEffect("def") * 100)}% войску`} color="#e05a5a" />}
            </div>
            {SPACE_BUILDS.map((b) => {
              const built = ly.spaceBuilds.has(b.id);
              const c = ly.canBuildSpace(engine, b.id);
              return (
                <div key={b.id} className={`rounded-xl border p-2 ${built ? "border-emerald-400/30 bg-emerald-400/6" : c.ok ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-70"}`}>
                  <div className="flex items-start gap-2">
                    <div className="item-cell h-10! w-10! shrink-0"><ItemIcon icon={b.icon} size={18} className={built ? "text-emerald-300" : "text-indigo-200"} /></div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[13px] font-bold text-amber-50">{b.name}</span>
                        {built && <Check size={12} className="text-emerald-400" />}
                      </div>
                      <div className="text-[10.5px] italic leading-snug text-white/45">{b.desc}</div>
                      <div className="text-[10.5px] font-semibold text-amber-200/85">{b.bonusText}</div>
                      {!built && (
                        <div className="mt-0.5 flex flex-wrap gap-x-2 text-[10px]">
                          <span className={engine.player.gold >= b.cost.gold ? "text-emerald-300" : "text-rose-300"}>{b.cost.gold} зол.</span>
                          {b.cost.res.map(([id, n]) => {
                            const have = engine.count(id) + engine.city.stockOf(id);
                            return <span key={id} className={have >= n ? "text-emerald-300" : "text-rose-300"}>{ITEMS[id]?.name ?? id} {have}/{n}</span>;
                          })}
                        </div>
                      )}
                    </div>
                    {!built && (
                      <button className="btn px-2.5! py-2! text-[11px]!" disabled={!c.ok} onClick={() => ly.buildSpace(engine, b.id)}>
                        <Hammer size={13} />
                      </button>
                    )}
                  </div>
                  {!built && !c.ok && <div className="mt-1 text-[10px] text-amber-300/70">{c.reason}</div>}
                </div>
              );
            })}

            <div className="mt-2 text-[11px] font-bold uppercase tracking-wide text-white/40">Иные расы</div>
            {ALIENS.map((a) => {
              const rel = Math.round(ly.aliens[a.id] ?? 0);
              const relColor = rel > 30 ? "#7ae68a" : rel > -20 ? "#f2b45c" : "#e05a5a";
              return (
                <div key={a.id} className="rounded-xl border border-white/8 bg-black/25 p-2">
                  <div className="flex items-start gap-2">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full" style={{ background: `${a.color}22`, color: a.color }}>
                      <ItemIcon icon={a.icon} size={18} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[13px] font-bold text-amber-50">{a.name}</span>
                        <span className="text-[10.5px] font-bold" style={{ color: relColor }}>{rel}</span>
                      </div>
                      <div className="text-[10.5px] italic leading-snug text-white/45">{a.desc}</div>
                      <div className="text-[10.5px] text-amber-200/80">{a.offer}</div>
                    </div>
                  </div>
                  <div className="mt-1.5 flex gap-1">
                    <button className="btn-ghost flex-1 py-1.5! text-[10.5px]!" onClick={() => ly.alienAct(engine, a.id, "gift")}>
                      <Gift size={11} /> Дары 800
                    </button>
                    <button className="btn-ghost flex-1 py-1.5! text-[10.5px]!" onClick={() => ly.alienAct(engine, a.id, "trade")}>
                      <Handshake size={11} /> Обмен 500
                    </button>
                    <button className="btn-ghost flex-1 py-1.5! text-[10.5px]! text-rose-200!" onClick={() => ly.alienAct(engine, a.id, "attack")}>
                      <Swords size={11} /> Война
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="mt-2 flex items-center justify-between rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5 text-[11px]">
        <span className="flex items-center gap-1 text-white/45">
          <Skull size={11} /> Боссов повержено: {ly.bossesKilled.size}
        </span>
        <span className="flex items-center gap-1 text-white/45">
          <Sparkle size={11} /> Слоёв открыто: {snap.unlockedLayers}
        </span>
        <span className="font-display text-[14px] font-bold text-amber-200">{engine.player.gold} зол.</span>
      </div>
      <div className="hidden"><ShieldAlert size={1} /></div>
    </Sheet>
  );
}
