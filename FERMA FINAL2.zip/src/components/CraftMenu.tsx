import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { RECIPES, RECIPE_CATS } from "../data/recipes";
import { ITEMS } from "../data/items";
import { ItemIcon } from "./ItemIcon";
import { X, Flame, Hammer } from "lucide-react";

export function CraftMenu({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const [cat, setCat] = useState("Всё");
  const list = RECIPES.filter((r) => cat === "Всё" || r.cat === cat);

  return (
    <div className="absolute inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px]" />
      <div
        className="glass relative flex max-h-[80vh] w-full max-w-md flex-col rounded-b-none p-3 safe-bottom"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-amber-100">Ремесло</h2>
          <div className="flex items-center gap-2">
            <span className={`flex items-center gap-1 rounded-full border px-2 py-1 text-[10px] font-bold ${snap.nearFire ? "border-orange-400/40 text-orange-300" : "border-white/10 text-white/35"}`}>
              <Flame size={11} /> {snap.nearFire ? "Костёр рядом" : "Нет костра"}
            </span>
            <button className="btn-ghost p-2!" onClick={onClose}><X size={17} /></button>
          </div>
        </div>

        <div className="mb-2 flex gap-1 overflow-x-auto pb-1" style={{ touchAction: "pan-x" }}>
          {RECIPE_CATS.map((c) => (
            <button
              key={c}
              className={`shrink-0 rounded-full border px-3 py-1.5 text-[12px] font-semibold transition ${cat === c ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 bg-white/5 text-white/55"}`}
              onClick={() => setCat(c)}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="scroll-area flex-1 space-y-1.5 pr-0.5">
          {list.map((r) => {
            const check = engine.canCraft(r.id);
            return (
              <div key={r.id} className={`flex items-center gap-2.5 rounded-xl border p-2 ${check.ok ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-70"}`}>
                <div className="item-cell h-11! w-11! shrink-0">
                  <ItemIcon icon={r.icon} size={22} className={check.ok ? "text-amber-200" : "text-white/40"} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-display text-[14px] font-bold text-amber-50">{r.name}</span>
                    {r.outN > 1 && <span className="text-[11px] font-bold text-white/40">×{r.outN}</span>}
                    {r.fire && <Flame size={12} className={snap.nearFire ? "text-orange-400" : "text-white/25"} />}
                  </div>
                  <div className="mt-0.5 flex flex-wrap gap-x-2 gap-y-0.5">
                    {r.needs.map(([id, n]) => {
                      const have = engine.count(id);
                      const ok = have >= n;
                      return (
                        <span key={id} className={`text-[11px] font-semibold ${ok ? "text-emerald-300/90" : "text-rose-300/90"}`}>
                          {ITEMS[id]?.name} {have}/{n}
                        </span>
                      );
                    })}
                  </div>
                  {!check.ok && check.reason && r.fire && (
                    <div className="text-[10px] text-orange-300/80">{check.reason}</div>
                  )}
                </div>
                <button
                  className="btn px-3! py-2! text-[12px]"
                  disabled={!check.ok}
                  onClick={() => engine.craft(r.id)}
                >
                  <Hammer size={14} />
                </button>
              </div>
            );
          })}
          {list.length === 0 && <div className="py-8 text-center text-sm text-white/35">Пусто</div>}
        </div>
      </div>
    </div>
  );
}
