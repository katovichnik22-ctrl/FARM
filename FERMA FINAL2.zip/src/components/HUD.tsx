import { useLayoutEffect, useRef } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import {
  Heart, Drumstick, Droplets, Zap, Thermometer, Sun, Moon, Coins,
  CloudRain, CloudSnow, CloudFog, CloudLightning, LocateFixed,
  Skull, Flame, Snowflake, Plus, Minus, Landmark, Users, Smile, Swords, Sparkles,
} from "lucide-react";
import { SEASON_NAMES } from "../types";
import { ItemIcon } from "./ItemIcon";
import { snd } from "../lib/sound";

function Bar({ value, max, color, icon: I, warn }: { value: number; max: number; color: string; icon: typeof Heart; warn?: boolean }) {
  const frac = Math.max(0, Math.min(1, value / max));
  return (
    <div className={`flex items-center gap-1 ${warn ? "pulse-soft" : ""}`}>
      <I size={12} style={{ color }} className="shrink-0 drop-shadow" />
      <div className="bar-track w-full">
        <div className="bar-fill" style={{ width: `${frac * 100}%`, background: `linear-gradient(90deg, ${color}cc, ${color})` }} />
      </div>
    </div>
  );
}

const WEATHER_ICON = { clear: Sun, rain: CloudRain, storm: CloudLightning, snow: CloudSnow, fog: CloudFog };

function sndUi() { snd.ensure(); snd.ui(); }

export function HUD({ engine, snap }: { engine: Engine; snap: UiSnapshot }) {
  const W = WEATHER_ICON[snap.weather];
  const cold = snap.temp < 2;
  const hot = snap.temp > 36;
  const timeStr = `${String(snap.hours).padStart(2, "0")}:${String(snap.minutes).padStart(2, "0")}`;

  // Реальная высота HUD → CSS-переменная: тосты и миникарта встают строго ниже
  const rootRef = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const el = rootRef.current;
    if (!el) return;
    const apply = () =>
      document.documentElement.style.setProperty("--hud-h", `${Math.round(el.getBoundingClientRect().height)}px`);
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  return (
    <div ref={rootRef} className="safe-top pointer-events-none absolute left-0 right-0 top-0 z-30 px-1.5">
      {/*
        Адаптивная сетка: на узких телефонах (до ~640px) центральный блок
        переносится на вторую строку (order-3 + wrap), три колонки не наезжают.
        Все надписи truncate — ничего не вылезает за экран.
      */}
      <div className="flex flex-wrap items-start justify-between gap-x-1.5 gap-y-1">
        {/* Левый блок: уровень + шкалы */}
        <div className="glass pointer-events-auto flex shrink-0 items-center gap-1.5 px-1.5 py-1.5">
          <div className="relative flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded-full border border-amber-400/40 bg-black/40">
            <span className="font-display text-base font-bold leading-none text-amber-300">{snap.level}</span>
            <div className="mt-0.5 h-1 w-6 overflow-hidden rounded-full bg-black/60">
              <div className="h-full rounded-full bg-amber-400 transition-all duration-300" style={{ width: `${(snap.xp / snap.xpNeed) * 100}%` }} />
            </div>
          </div>
          <div className="flex w-[clamp(76px,23vw,110px)] flex-col gap-[3px]">
            <Bar value={snap.hp} max={snap.maxHp} color="#e05a5a" icon={Heart} warn={snap.hp < snap.maxHp * 0.25} />
            <Bar value={snap.food} max={100} color="#f2a24d" icon={Drumstick} warn={snap.food < 28} />
            <Bar value={snap.water} max={100} color="#5cb8e0" icon={Droplets} warn={snap.water < 28} />
            <Bar value={snap.stamina} max={100} color="#a8e68a" icon={Zap} warn={snap.stamina < 20} />
          </div>
        </div>

        {/* Центр: время и мир (на телефоне — отдельной строкой ниже) */}
        <div className="glass pointer-events-auto order-3 mx-auto flex min-w-0 max-w-full flex-1 basis-[170px] flex-col items-center px-2.5 py-1 text-center sm:order-none">
          <div className="flex max-w-full items-center gap-1.5 whitespace-nowrap">
            {snap.isNight ? <Moon size={14} className="shrink-0 text-indigo-300" /> : <Sun size={14} className="shrink-0 text-amber-300" />}
            <span className="font-display text-[15px] font-bold tracking-wider">{timeStr}</span>
            <W size={14} className="shrink-0 text-sky-200/90" />
            <span className="ml-0.5 truncate text-[10px] font-semibold tracking-wide text-amber-100/80">
              День {snap.day} · {SEASON_NAMES[snap.season]} · {snap.biomeName}
            </span>
          </div>
          <div className="max-w-full truncate text-[10px] text-white/50">{snap.zoneName} ({snap.tx}, {snap.ty})</div>
          {snap.z !== 0 && (
            <div className="mt-0.5 flex max-w-full items-center gap-1 truncate rounded-full px-2 py-0.5 text-[9.5px] font-bold"
              style={{ background: `${snap.layerColor}1f`, color: snap.layerColor }}>
              <ItemIcon icon={snap.layerIcon} size={9} />
              <span className="truncate">{snap.layerName}</span>
              {snap.oxygen < 100 && (
                <span className={snap.oxygen > 30 ? "text-sky-300" : "text-rose-300"}>O₂ {snap.oxygen}%</span>
              )}
              {!snap.hasGearForLayer && <span className="pulse-soft text-rose-300">БЕЗ ЗАЩИТЫ</span>}
            </div>
          )}
          <div className="mt-0.5 flex max-w-full flex-wrap items-center justify-center gap-x-1.5 text-[9.5px] font-bold">
            <span className="flex items-center gap-0.5 whitespace-nowrap" style={{ color: snap.eraColor }}>
              <ItemIcon icon={snap.eraIcon} size={9} /> {snap.eraName}
            </span>
            {snap.isMage && (
              <span className="flex items-center gap-0.5 whitespace-nowrap text-purple-300">
                <Sparkles size={9} /> {snap.mana}
              </span>
            )}
            {snap.religionFounded && (
              <span className="whitespace-nowrap" style={{ color: snap.religionColor }}>{snap.religionSymbol} {snap.followers}%</span>
            )}
            <span className="whitespace-nowrap text-amber-300">★{snap.stars}</span>
            {snap.mode !== "normal" && <span className="whitespace-nowrap text-white/45">{snap.modeName}</span>}
          </div>
          {snap.cityFounded && (
            <div className="mt-0.5 flex max-w-full items-center gap-1 rounded-full bg-amber-400/10 px-2 py-0.5 text-[9.5px] font-bold">
              <Landmark size={9} className="shrink-0 text-amber-300" />
              <span className="max-w-[96px] truncate text-amber-100">{snap.cityName}</span>
              <span className="text-white/40">·</span>
              <Users size={9} className="shrink-0 text-sky-300" />
              <span className="whitespace-nowrap text-sky-200">{snap.cityPop}</span>
              <Smile size={9} className={`shrink-0 ${snap.cityHappy > 50 ? "text-emerald-300" : "text-rose-300"}`} />
              <span className={`whitespace-nowrap ${snap.cityHappy > 50 ? "text-emerald-200" : "text-rose-200"}`}>{snap.cityHappy}%</span>
              {snap.cityRioting && <span className="pulse-soft whitespace-nowrap text-rose-300">БУНТ</span>}
            </div>
          )}
        </div>

        {/* Правый блок: золото, температура, камера */}
        <div className="flex shrink-0 flex-col items-end gap-1">
          <div className="glass pointer-events-auto flex items-center gap-1.5 px-2 py-1.5">
            <Coins size={14} className="shrink-0 text-amber-300" />
            <span className="font-display max-w-[64px] truncate text-[14px] font-bold text-amber-100">{snap.gold}</span>
            <span className="mx-0.5 h-3 w-px shrink-0 bg-white/15" />
            <Thermometer size={14} className={`shrink-0 ${cold ? "text-sky-300" : hot ? "text-rose-300" : "text-emerald-200"}`} />
            <span className={`whitespace-nowrap text-[13px] font-bold ${cold ? "text-sky-200" : hot ? "text-rose-200" : "text-emerald-100"}`}>{snap.temp}°</span>
          </div>
          <div className="pointer-events-auto flex max-w-[132px] flex-wrap justify-end gap-1">
            {snap.poisoned && (
              <div className="glass-soft flex items-center gap-1 px-2 py-1 text-[10px] font-bold text-lime-300"><Skull size={11} /> Яд</div>
            )}
            {cold && (
              <div className="glass-soft flex items-center gap-1 px-2 py-1 text-[10px] font-bold text-sky-300"><Snowflake size={11} /> Холод</div>
            )}
            {hot && (
              <div className="glass-soft flex items-center gap-1 px-2 py-1 text-[10px] font-bold text-rose-300"><Flame size={11} /> Жара</div>
            )}
            {snap.enemiesNear > 0 && (
              <div className="glass-soft pulse-soft flex items-center gap-1 border-rose-400/30 px-2 py-1 text-[10px] font-bold text-rose-300">
                <Skull size={11} /> {snap.enemiesNear}
              </div>
            )}
            {snap.warCount > 0 && (
              <div className={`glass-soft flex items-center gap-1 px-2 py-1 text-[10px] font-bold ${snap.incomingWar ? "pulse-soft border-rose-400/50 text-rose-200" : "text-amber-200"}`}>
                <Swords size={11} /> {snap.warCount}
                {snap.armyMen > 0 && <span className="text-white/45">· {snap.armyMen}</span>}
              </div>
            )}
          </div>
          <div className="pointer-events-auto flex gap-1">
            <button className="btn-icon min-w-0! p-2!" aria-label="Центр" onClick={() => { engine.cam.follow = true; engine.cam.panX = 0; engine.cam.panY = 0; sndUi(); }}>
              <LocateFixed size={16} />
            </button>
            <button className="btn-icon min-w-0! p-2!" aria-label="Приблизить" onClick={() => { engine.cam.zoom = Math.min(2.3, engine.cam.zoom * 1.18); sndUi(); }}>
              <Plus size={16} />
            </button>
            <button className="btn-icon min-w-0! p-2!" aria-label="Отдалить" onClick={() => { engine.cam.zoom = Math.max(0.55, engine.cam.zoom * 0.85); sndUi(); }}>
              <Minus size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
