import { useEffect, useRef } from "react";
import type { Engine } from "../game/engine";
import { renderGame } from "../game/render";
import { TILE } from "../types";
import { snd } from "../lib/sound";

interface Props {
  engine: Engine;
  onContext: (opts: { label: string; act: string }[]) => void;
}

export function GameCanvas({ engine, onContext }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext("2d", { alpha: false })!;
    let W = 0, H = 0, dpr = 1;
    let raf = 0;
    let last = performance.now();

    // ---- Адаптивное качество для слабых телефонов ----
    // Автоматически подбирает внутреннее разрешение канваса и плотность эффектов:
    // лагает → снижаем чёткость/частицы (картинка остаётся той же по размеру),
    // есть запас → возвращаем качество. Ничего из игры не выключается навсегда.
    let quality = 2; // 2 — высокое, 1 — среднее, 0 — экономное
    const Q_SCALE = [0.58, 0.78, 1];    // доля от базового dpr
    const Q_FX = [0.45, 0.72, 1];       // плотность дождя/снега/частиц
    let emaMs = 16;                     // сглаженное время кадра
    let frames = 0;
    let cool = 0;                       // пауза между переключениями качества

    const effDpr = () => Math.min(2, window.devicePixelRatio || 1) * Q_SCALE[quality];
    const applyQuality = () => {
      engine.fx = Q_FX[quality];
      dpr = effDpr();
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
    };

    const resize = () => {
      W = window.innerWidth;
      H = window.innerHeight;
      dpr = effDpr();
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
    };
    resize();
    window.addEventListener("resize", resize);

    const frame = (t: number) => {
      const rawMs = Math.max(1, t - last);
      const dt = Math.min(0.06, Math.max(0.001, rawMs / 1000));
      last = t;
      engine.update(dt);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      renderGame(engine, ctx, W, H, t / 1000);

      // регулятор качества: смотрим на среднее время кадра
      emaMs = emaMs * 0.92 + rawMs * 0.08;
      if (cool > 0) cool--;
      else if (frames > 120) {
        if (emaMs > 33 && quality > 0) { quality--; applyQuality(); cool = 300; }
        else if (emaMs < 19 && quality < 2) { quality++; applyQuality(); cool = 900; }
      }
      frames++;
      raf = requestAnimationFrame(frame);
    };
    engine.fx = Q_FX[quality];
    raf = requestAnimationFrame(frame);

    // ---- Ввод ----
    const pointers = new Map<number, { x: number; y: number }>();
    let downX = 0, downY = 0, downT = 0, moved = false, panning = false;
    let longTimer: ReturnType<typeof setTimeout> | null = null;
    let pinchDist = 0;
    let lastTapT = 0;

    const toWorld = (sx: number, sy: number) => ({
      x: engine.cam.x + (sx - W / 2) / engine.cam.zoom,
      y: engine.cam.y + (sy - H / 2) / engine.cam.zoom,
    });

    const clearLong = () => { if (longTimer) { clearTimeout(longTimer); longTimer = null; } };

    const onDown = (ev: PointerEvent) => {
      snd.ensure();
      canvas.setPointerCapture(ev.pointerId);
      pointers.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
      if (pointers.size === 2) {
        const [p1, p2] = [...pointers.values()];
        pinchDist = Math.hypot(p1.x - p2.x, p1.y - p2.y);
        clearLong();
        moved = true;
        return;
      }
      downX = ev.clientX; downY = ev.clientY; downT = performance.now();
      moved = false; panning = false;
      clearLong();
      longTimer = setTimeout(() => {
        if (!moved && pointers.size === 1) {
          const w = toWorld(downX, downY);
          const opts = engine.longPress(w.x, w.y);
          onContext(opts);
          moved = true;
        }
      }, 480);
    };

    const onMove = (ev: PointerEvent) => {
      const prev = pointers.get(ev.pointerId);
      if (!prev) { 
        // ховер для призрака постройки (мышь)
        if (engine.buildDef) {
          const w = toWorld(ev.clientX, ev.clientY);
          engine.buildGhost.tx = Math.floor(w.x / TILE);
          engine.buildGhost.ty = Math.floor(w.y / TILE);
          engine.validateBuild();
        }
        return;
      }
      const dx = ev.clientX - prev.x, dy = ev.clientY - prev.y;
      pointers.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });

      if (pointers.size === 2) {
        const [p1, p2] = [...pointers.values()];
        const nd = Math.hypot(p1.x - p2.x, p1.y - p2.y);
        if (pinchDist > 0) {
          const next = engine.cam.zoom * (nd / pinchDist);
          engine.cam.zoom = Math.min(2.3, Math.max(0.55, next));
        }
        pinchDist = nd;
        return;
      }
      if (!moved && Math.hypot(ev.clientX - downX, ev.clientY - downY) > 13) {
        moved = true;
        clearLong();
        if (!engine.buildDef) panning = true;
      }
      if (moved) {
        if (panning) {
          engine.cam.panX -= dx / engine.cam.zoom;
          engine.cam.panY -= dy / engine.cam.zoom;
          engine.cam.follow = false;
          const lim = 14 * TILE;
          engine.cam.panX = Math.max(-lim, Math.min(lim, engine.cam.panX));
          engine.cam.panY = Math.max(-lim, Math.min(lim, engine.cam.panY));
        } else if (engine.buildDef) {
          const w = toWorld(ev.clientX, ev.clientY);
          engine.buildGhost.tx = Math.floor(w.x / TILE);
          engine.buildGhost.ty = Math.floor(w.y / TILE);
          engine.validateBuild();
          engine.poke();
        }
      }
    };

    const onUp = (ev: PointerEvent) => {
      pointers.delete(ev.pointerId);
      clearLong();
      if (pointers.size < 2) pinchDist = 0;
      if (pointers.size === 0) {
        const quick = performance.now() - downT < 420;
        if (!moved && quick) {
          const now = performance.now();
          if (now - lastTapT < 320) {
            // двойной тап — центр камеры
            engine.cam.follow = true;
            engine.cam.panX = 0; engine.cam.panY = 0;
          } else {
            const w = toWorld(ev.clientX, ev.clientY);
            engine.tap(w.x, w.y);
          }
          lastTapT = now;
        }
        moved = false; panning = false;
      }
    };

    const onWheel = (ev: WheelEvent) => {
      ev.preventDefault();
      const next = engine.cam.zoom * (ev.deltaY > 0 ? 0.9 : 1.1);
      engine.cam.zoom = Math.min(2.3, Math.max(0.55, next));
    };

    const onKey = (ev: KeyboardEvent) => {
      const k = ev.key.toLowerCase();
      if (["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(k)) {
        engine.keys.add(k);
        ev.preventDefault();
      }
    };
    const onKeyUp = (ev: KeyboardEvent) => {
      engine.keys.delete(ev.key.toLowerCase());
    };

    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerup", onUp);
    canvas.addEventListener("pointercancel", onUp);
    canvas.addEventListener("wheel", onWheel, { passive: false });
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKeyUp);
    // блок контекстного меню браузера
    const onCtx = (ev: Event) => ev.preventDefault();
    canvas.addEventListener("contextmenu", onCtx);

    return () => {
      cancelAnimationFrame(raf);
      clearLong();
      window.removeEventListener("resize", resize);
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("pointercancel", onUp);
      canvas.removeEventListener("wheel", onWheel);
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onKeyUp);
      canvas.removeEventListener("contextmenu", onCtx);
    };
  }, [engine, onContext]);

  return <canvas ref={ref} className="absolute inset-0 touch-none" style={{ touchAction: "none" }} />;
}
