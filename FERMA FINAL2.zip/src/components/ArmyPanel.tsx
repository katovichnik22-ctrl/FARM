import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { UNITS, UNIT_ORDER } from "../data/army";
import { GEN_TRAITS } from "../types/war";
import type { UnitKind } from "../types/war";
import { ITEMS } from "../data/items";
import {
  Swords, UserPlus, Split, Merge, Trash2, Star, HeartPulse,
  Shield, Zap, Flame, Coins, Wheat,
} from "lucide-react";

const TABS = ["Войско", "Найм", "Воеводы", "Госпиталь"];

export function ArmyPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const [tab, setTab] = useState("Войско");
  const [mergeFrom, setMergeFrom] = useState<number | null>(null);
  const [pickGenFor, setPickGenFor] = useState<number | null>(null);
  const [amount, setAmount] = useState(3);
  const a = engine.army;

  return (
    <Sheet
      title="Войско державы"
      sub={`Сила ${snap.armyPower} · бойцов ${snap.armyMen}/${snap.armyCap} · содержание ${snap.upkeepGold} зол./мин`}
      onClose={onClose}
    >
      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "60vh" }}>

        {tab === "Войско" && (
          <div className="space-y-1.5">
            <div className="grid grid-cols-3 gap-1.5">
              <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
                <Swords size={14} className="mx-auto text-rose-300" />
                <div className="font-display text-[16px] font-bold text-amber-100">{snap.armyPower}</div>
                <div className="text-[9.5px] text-white/40">сила</div>
              </div>
              <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
                <Coins size={14} className="mx-auto text-amber-300" />
                <div className="font-display text-[16px] font-bold text-amber-100">{snap.upkeepGold}</div>
                <div className="text-[9.5px] text-white/40">зол./мин</div>
              </div>
              <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
                <Wheat size={14} className="mx-auto text-lime-300" />
                <div className="font-display text-[16px] font-bold text-amber-100">{a.upkeepFood()}</div>
                <div className="text-[9.5px] text-white/40">еды/мин</div>
              </div>
            </div>
            {a.squads.length === 0 && (
              <div className="py-6 text-center text-[12.5px] text-white/40">
                Войска нет. Наберите бойцов во вкладке «Найм».
              </div>
            )}
            {a.squads.map((s) => {
              const d = UNITS[s.kind];
              const g = a.genOf(s.general);
              return (
                <div key={s.uid} className={`rounded-xl border p-2 ${mergeFrom === s.uid ? "border-amber-400/70 bg-amber-400/10" : "border-white/8 bg-black/25"}`}>
                  <div className="flex items-center gap-2">
                    <div className="item-cell h-10! w-10! shrink-0"><ItemIcon icon={d.icon} size={19} className="text-amber-200" /></div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1">
                        <span className="truncate text-[13px] font-bold text-amber-50">{s.name}</span>
                        <span className="flex items-center gap-0.5 text-[10px] font-bold text-amber-300"><Star size={8} fill="currentColor" />{s.lvl}</span>
                      </div>
                      <div className="text-[10.5px] text-white/45">
                        {d.name} ×{s.n} · атака {d.atk} · защита {d.def}
                        {g && <span className="text-amber-300/80"> · {g.name}</span>}
                      </div>
                      <div className="mt-1 flex gap-1.5">
                        <MiniBar label="мораль" v={s.morale} color="#7ae68a" />
                        <MiniBar label="усталость" v={s.fatigue} color="#e08a5a" />
                      </div>
                    </div>
                  </div>
                  <div className="mt-1.5 flex gap-1">
                    <button className="btn-ghost flex-1 py-1.5! text-[10.5px]!" onClick={() => setPickGenFor(pickGenFor === s.uid ? null : s.uid)}>
                      <UserPlus size={12} /> Воевода
                    </button>
                    <button className="btn-ghost flex-1 py-1.5! text-[10.5px]!" onClick={() => a.split(engine, s.uid)}>
                      <Split size={12} /> Делить
                    </button>
                    <button
                      className="btn-ghost flex-1 py-1.5! text-[10.5px]!"
                      onClick={() => {
                        if (mergeFrom === null) setMergeFrom(s.uid);
                        else if (mergeFrom === s.uid) setMergeFrom(null);
                        else { a.merge(engine, mergeFrom, s.uid); setMergeFrom(null); }
                      }}
                    >
                      <Merge size={12} /> {mergeFrom === s.uid ? "отмена" : "Слить"}
                    </button>
                    <button className="btn-ghost px-2! py-1.5!" onClick={() => a.disband(engine, s.uid)}>
                      <Trash2 size={12} />
                    </button>
                  </div>
                  {pickGenFor === s.uid && (
                    <div className="mt-1.5 space-y-1 rounded-lg border border-amber-400/20 bg-black/40 p-1.5">
                      {a.generals.filter((x) => x.alive).length === 0 && <div className="text-[11px] text-white/40">Воевод нет — наймите во вкладке «Воеводы»</div>}
                      {a.generals.filter((x) => x.alive).map((gg) => (
                        <button key={gg.uid} className="flex w-full items-center gap-1.5 rounded px-1.5 py-1 text-left text-[11.5px] hover:bg-white/5"
                          onClick={() => { a.assignGeneral(engine, s.uid, gg.uid); setPickGenFor(null); }}>
                          <Shield size={11} className="text-amber-300" />
                          <span className="flex-1 truncate text-amber-50">{gg.name} «{gg.title}»</span>
                          <span className="text-[10px] text-white/40">{GEN_TRAITS[gg.trait].name}</span>
                          {s.general === gg.uid && <span className="text-[10px] text-emerald-300">снять</span>}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {tab === "Найм" && (
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 rounded-xl border border-white/8 bg-black/25 px-2 py-1.5">
              <span className="text-[11px] font-bold uppercase text-white/45">Число</span>
              {[1, 3, 5, 10].map((n) => (
                <button key={n} onClick={() => setAmount(n)}
                  className={`flex-1 rounded-lg border py-1 text-[12px] font-bold ${amount === n ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : "border-white/10 text-white/50"}`}>
                  {n}
                </button>
              ))}
            </div>
            {UNIT_ORDER.map((k) => {
              const d = UNITS[k as UnitKind];
              const check = a.canRecruit(engine, k as UnitKind, amount);
              return (
                <div key={k} className={`rounded-xl border p-2 ${check.ok ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-70"}`}>
                  <div className="flex items-center gap-2">
                    <div className="item-cell h-10! w-10! shrink-0"><ItemIcon icon={d.icon} size={19} className={check.ok ? "text-amber-200" : "text-white/35"} /></div>
                    <div className="min-w-0 flex-1">
                      <div className="text-[13px] font-bold text-amber-50">{d.name}</div>
                      <div className="text-[10.5px] leading-snug text-white/45">{d.desc}</div>
                      <div className="mt-0.5 flex flex-wrap gap-x-2 text-[10px] font-semibold">
                        <span className="text-rose-300">атака {d.atk}</span>
                        <span className="text-sky-300">защита {d.def}</span>
                        <span className="text-emerald-300">ход {d.move}</span>
                        <span className="text-amber-300">даль {d.rng}</span>
                        {d.siege ? <span className="text-orange-300">осада {d.siege}</span> : null}
                      </div>
                      <div className="mt-0.5 flex flex-wrap gap-x-2 text-[10px]">
                        <span className={engine.player.gold >= d.cost.gold * amount ? "text-emerald-300" : "text-rose-300"}>
                          {d.cost.gold * amount} зол.
                        </span>
                        {d.cost.res.map(([id, c]) => {
                          const have = engine.count(id) + engine.city.stockOf(id);
                          return <span key={id} className={have >= c * amount ? "text-emerald-300" : "text-rose-300"}>{ITEMS[id]?.name ?? id} {have}/{c * amount}</span>;
                        })}
                      </div>
                    </div>
                    <button className="btn px-2.5! py-2! text-[11px]" disabled={!check.ok} onClick={() => a.recruit(engine, k as UnitKind, amount)}>
                      Нанять
                    </button>
                  </div>
                  {!check.ok && <div className="mt-1 text-[10px] text-amber-300/70">{check.reason}</div>}
                </div>
              );
            })}
          </div>
        )}

        {tab === "Воеводы" && (
          <div className="space-y-1.5">
            <button className="btn w-full py-2.5! text-[12.5px]" onClick={() => a.hireGeneral(engine)}>
              <UserPlus size={15} /> Нанять воеводу ({a.hireCost()} зол.)
            </button>
            {a.generals.filter((g) => g.alive).map((g) => {
              const t = GEN_TRAITS[g.trait];
              const squad = a.squads.find((s) => s.general === g.uid);
              return (
                <div key={g.uid} className="rounded-xl border border-white/8 bg-black/25 p-2.5">
                  <div className="flex items-start gap-2">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-400/15 text-amber-300">
                      <Shield size={18} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-baseline gap-x-1.5">
                        <span className="font-display text-[14px] font-bold text-amber-50">{g.name}</span>
                        <span className="text-[10.5px] font-bold uppercase tracking-wide text-amber-300/70">«{g.title}»</span>
                        <span className="text-[11px] text-white/40">ур. {g.lvl}</span>
                      </div>
                      <div className="text-[11px] italic leading-snug text-white/45">{g.bio}</div>
                      <div className="mt-1 flex flex-wrap gap-1 text-[10px] font-semibold">
                        <span className="rounded bg-amber-400/12 px-1.5 py-0.5 text-amber-200">{t.name}: {t.desc}</span>
                        <span className="rounded bg-white/8 px-1.5 py-0.5 text-white/55">битв {g.battles} / побед {g.wins}</span>
                        <span className="rounded bg-rose-400/10 px-1.5 py-0.5 text-rose-200">жалованье {g.wage}</span>
                      </div>
                      <div className="mt-0.5 text-[10.5px] text-white/40">
                        {squad ? `Ведёт: ${squad.name}` : "Без отряда"}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            {a.generals.filter((g) => g.alive).length === 0 && (
              <div className="py-4 text-center text-[12px] text-white/40">Воевод нет. Без них войско слепо.</div>
            )}
          </div>
        )}

        {tab === "Госпиталь" && (
          <div className="space-y-1.5">
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <Row k="Раненых" v={snap.woundedCount} color="#e08a5a" />
              <Row k="Скорость лечения" v={a.hospitalCapacity(engine) >= 1 ? "быстрая (есть храм)" : "медленная"} />
              <p className="mt-1 text-[10.5px] leading-snug text-white/35">
                Храм, собор, монастырь или общая кухня ускоряют выздоровление. Возвращается около двух третей раненых.
              </p>
            </div>
            {a.hospital.map((h, i) => (
              <div key={i} className="flex items-center gap-2 rounded-xl border border-white/8 bg-black/25 p-2">
                <HeartPulse size={16} className="shrink-0 text-rose-300" />
                <span className="flex-1 text-[12.5px] text-amber-50">{UNITS[h.kind].name} ×{h.n}</span>
                <span className="text-[11px] font-bold text-white/45">{Math.ceil(h.t)}с</span>
              </div>
            ))}
            {a.hospital.length === 0 && <div className="py-4 text-center text-[12px] text-white/40">Раненых нет. Хороший знак.</div>}
          </div>
        )}
      </div>
      <div className="mt-2 flex items-center justify-between rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5 text-[11.5px]">
        <span className="flex items-center gap-1 text-white/45"><Zap size={12} /> Слава: {snap.fame}</span>
        <span className="flex items-center gap-1 text-white/45"><Flame size={12} /> Войн: {snap.warCount}</span>
        <span className="font-display text-[15px] font-bold text-amber-200">{engine.player.gold} зол.</span>
      </div>
    </Sheet>
  );
}

function MiniBar({ label, v, color }: { label: string; v: number; color: string }) {
  return (
    <div className="flex-1">
      <div className="flex justify-between text-[8.5px] uppercase tracking-wide text-white/35">
        <span>{label}</span><span>{Math.round(v)}</span>
      </div>
      <div className="bar-track h-1!"><div className="bar-fill" style={{ width: `${v}%`, background: color }} /></div>
    </div>
  );
}
