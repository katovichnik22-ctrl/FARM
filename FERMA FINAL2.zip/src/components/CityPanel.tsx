import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Stat, Row, Slider, Spark, happyColor } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { DISTRICTS, type District } from "../types/city";
import { EDICTS } from "../data/citydata";
import { BUILDINGS } from "../data/buildings";
import { ITEMS } from "../data/items";
import {
  Landmark, Users, Sparkle, Flag, Coins, ShieldAlert, ArrowUpCircle,
  PartyPopper, Pencil, Package, ArrowDownToLine, ArrowUpFromLine, Star,
} from "lucide-react";
import { snd } from "../lib/sound";

const TABS = ["Обзор", "Районы", "Здания", "Указы", "Склад", "Хроника"];

export function CityPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const [tab, setTab] = useState("Обзор");
  const [rename, setRename] = useState("");
  const [founding, setFounding] = useState(false);
  const c = engine.city;
  const s = c.s;

  // ---------- Основание ----------
  if (!s.founded) {
    const check = c.canFound(engine);
    return (
      <Sheet title="Основание города" sub="Ратуша и четыре здания рядом — и поселение оживёт" onClose={onClose}>
        <div className="scroll-area space-y-3 pb-1">
          <div className="flex items-center gap-3 rounded-xl border border-amber-400/20 bg-black/30 p-3">
            <Landmark size={34} className="shrink-0 text-amber-300" />
            <div className="text-[12.5px] leading-snug text-white/65">
              Город даёт жителей, налоги, ремёсла, биржу и державную политику. Постройте <b className="text-amber-200">Ратушу</b> (Стройка → Город) и ещё 4 здания вокруг неё.
            </div>
          </div>
          <div className={`rounded-xl border p-3 text-[13px] font-semibold ${check.ok ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-200" : "border-amber-400/25 bg-amber-400/5 text-amber-200/80"}`}>
            {check.ok ? "Всё готово — можно основывать!" : check.reason}
            {!check.ok && check.need > 0 && <div className="mt-1 text-[11px] text-white/45">Зданий рядом: {check.have}/{check.need}</div>}
          </div>
          {founding ? (
            <div className="rounded-xl border border-white/10 bg-black/30 p-3">
              <label className="text-[11px] font-bold uppercase tracking-wide text-white/45">Имя города</label>
              <input
                autoFocus value={rename} onChange={(e) => setRename(e.target.value)}
                placeholder="Тихий Град"
                className="mt-1 w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-[15px] text-amber-50 outline-none focus:border-amber-400/50"
              />
              <button className="btn mt-2 w-full py-2.5!" onClick={() => { if (c.found(engine, rename)) { setFounding(false); setTab("Обзор"); } }}>
                <Flag size={16} /> Основать город
              </button>
            </div>
          ) : (
            <button className="btn w-full py-3!" disabled={!check.ok} onClick={() => { snd.uiOpen(); setFounding(true); }}>
              <Flag size={17} /> Основать город
            </button>
          )}
        </div>
      </Sheet>
    );
  }

  const m = s.metrics;
  const unemp = c.unemployment();
  const cityBuildings = engine.buildings.filter((b) => b.done && BUILDINGS[b.def] && !BUILDINGS[b.def].road);

  return (
    <Sheet
      title={s.name}
      sub={`${c.tierName()} · жителей ${Math.floor(s.pop)}/${s.popCap} · ${snap.govName} · основан на ${s.foundedDay}-й день`}
      onClose={onClose}
    >
      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "58vh" }}>

        {tab === "Обзор" && (
          <div className="space-y-2">
            {s.rioting && (
              <div className="rounded-xl border border-rose-400/40 bg-rose-500/12 p-2.5">
                <div className="flex items-center gap-2 text-[13px] font-bold text-rose-200">
                  <ShieldAlert size={16} /> БУНТ! {s.unrestNote}
                </div>
                <div className="mt-2 flex gap-1.5">
                  <button className="btn flex-1 py-2! text-[12px]" onClick={() => c.suppress(engine, "army")}>Подавить армией</button>
                  <button className="btn-ghost flex-1 py-2! text-[12px]" onClick={() => c.suppress(engine, "concede")}>Пойти на уступки</button>
                </div>
              </div>
            )}
            {!s.rioting && s.riot > 20 && (
              <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 px-2.5 py-2 text-[12px] font-semibold text-amber-200">
                Напряжение {Math.round(s.riot)}% — {s.unrestNote || "народ ропщет"}
              </div>
            )}

            <div className="grid grid-cols-3 gap-1.5">
              <Stat label="Счастье" value={s.happiness} color={happyColor(s.happiness)} suffix="%" />
              <Stat label="Еда" value={m.food} color="#f2a24d" suffix="%" />
              <Stat label="Вода" value={m.water} color="#5cb8e0" suffix="%" />
              <Stat label="Энергия" value={m.energy} color="#d9c25c" suffix="%" />
              <Stat label="Здоровье" value={m.health} color="#7ae68a" suffix="%" />
              <Stat label="Преступность" value={m.crime} color="#e05a5a" suffix="%" />
              <Stat label="Грязь" value={m.pollution} color="#9a8a72" suffix="%" />
              <Stat label="Безработица" value={unemp} color="#c9a227" suffix="%" />
              <Stat label="Порядок" value={m.order} max={120} color="#8fa2b8" />
              <Stat label="Культура" value={m.culture} max={120} color="#c98ae0" />
              <Stat label="Вера" value={m.faith} max={120} color="#e8d9a0" />
              <Stat label="Наука" value={m.science} max={140} color="#5a9ac9" />
            </div>

            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <Slider label="Налоговая ставка" value={s.taxRate} min={0} max={50} suffix="%" onChange={(v) => { c.setTax(v); engine.poke(); }} />
              <Row k="Доход казны" v={`${snap.cityIncome > 0 ? "+" : ""}${snap.cityIncome} зол./мин`} color={snap.cityIncome >= 0 ? "#7ae68a" : "#e05a5a"} />
              <Row k="Собрано всего" v={`${Math.floor(s.totalTax)} зол.`} color="#f2c14e" />
              <Row k="Рабочих мест" v={`${s.employed}/${s.jobs}`} />
              <Row k="Чудес света" v={`${c.wonderCount()}/12`} color="#ffd97a" />
            </div>

            <div className="flex gap-1.5">
              <button className="btn flex-1 py-2.5! text-[12.5px]" onClick={() => c.parade(engine)}>
                <PartyPopper size={15} /> Парад ({60 + Math.floor(s.pop * 4)} зол.)
              </button>
              <div className="flex flex-1 gap-1">
                <input
                  value={rename} onChange={(e) => setRename(e.target.value)} placeholder="Новое имя"
                  className="w-full rounded-xl border border-white/10 bg-black/40 px-2.5 text-[12.5px] text-amber-50 outline-none focus:border-amber-400/50"
                />
                <button className="btn-ghost px-2.5!" onClick={() => { c.rename(rename); setRename(""); snd.ui(); engine.poke(); }}>
                  <Pencil size={14} />
                </button>
              </div>
            </div>
          </div>
        )}

        {tab === "Районы" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11.5px] leading-snug text-white/45">
              Приоритет района усиливает соответствующие здания. Ставьте туда, где хотите роста.
            </p>
            {DISTRICTS.map((d) => (
              <div key={d.id} className="rounded-xl border border-white/8 bg-black/25 p-2.5">
                <div className="flex items-center gap-2">
                  <ItemIcon icon={d.icon} size={17} className="text-amber-200" />
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] font-bold text-amber-50">{d.name}</div>
                    <div className="truncate text-[10.5px] text-white/40">{d.desc}</div>
                  </div>
                  <div className="flex gap-1">
                    {[0, 1, 2].map((v) => (
                      <button
                        key={v}
                        className={`h-7 w-7 rounded-lg border text-[11px] font-bold transition ${s.districts[d.id as District] === v ? "border-amber-400/70 bg-amber-400/20 text-amber-200" : "border-white/10 bg-white/5 text-white/40"}`}
                        onClick={() => { c.setDistrict(d.id as District, v); snd.ui(); c.recompute(engine); engine.poke(); }}
                      >
                        {v === 0 ? "—" : v === 1 ? "I" : "II"}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "Здания" && (
          <div className="space-y-1.5">
            {cityBuildings.length === 0 && <div className="py-6 text-center text-[12px] text-white/35">Пока ничего не построено</div>}
            {cityBuildings.map((b) => {
              const def = BUILDINGS[b.def];
              const u = c.upgradeCost(b);
              const afford = u.can && u.cost.every(([id, n]) => engine.count(id) >= n) && engine.player.gold >= u.gold;
              return (
                <div key={b.uid} className="flex items-center gap-2 rounded-xl border border-white/8 bg-black/25 p-2">
                  <div className="item-cell h-10! w-10! shrink-0"><ItemIcon icon={def.icon} size={19} className="text-amber-200" /></div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1">
                      <span className="truncate text-[13px] font-bold text-amber-50">{def.name}</span>
                      <span className="flex items-center gap-0.5 text-[10px] font-bold text-amber-300">
                        <Star size={9} fill="currentColor" />{b.lvl ?? 1}
                      </span>
                    </div>
                    <div className="truncate text-[10.5px] text-white/40">
                      {def.jobs ? `${def.jobs * (b.lvl ?? 1)} мест · ` : ""}{def.housing ? `${def.housing * (b.lvl ?? 1)} жителей · ` : ""}
                      {def.chain ? `${ITEMS[def.chain.out[0]]?.name}` : def.cat}
                    </div>
                  </div>
                  {u.can ? (
                    <button
                      className={`btn px-2.5! py-2! text-[11px] ${afford ? "" : "opacity-50"}`}
                      onClick={() => c.upgrade(engine, b)}
                      title={`${u.cost.map(([id, n]) => `${ITEMS[id]?.name} ${n}`).join(", ")} + ${u.gold} зол.`}
                    >
                      <ArrowUpCircle size={14} /> {u.gold}
                    </button>
                  ) : (
                    <span className="px-2 text-[10px] font-bold text-white/30">макс.</span>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {tab === "Указы" && (
          <div className="space-y-1.5">
            {EDICTS.map((ed) => {
              const active = c.hasEdict(ed.id);
              return (
                <div key={ed.id} className={`rounded-xl border p-2.5 ${active ? "border-emerald-400/40 bg-emerald-400/8" : "border-white/8 bg-black/25"}`}>
                  <div className="flex items-start gap-2">
                    <ItemIcon icon={ed.icon} size={18} className={active ? "text-emerald-300" : "text-amber-200"} />
                    <div className="min-w-0 flex-1">
                      <div className="text-[13px] font-bold text-amber-50">{ed.name}</div>
                      <div className="text-[11px] leading-snug text-white/45">{ed.desc}</div>
                      <div className="mt-0.5 flex flex-wrap gap-1 text-[10px] font-semibold">
                        {ed.happy ? <span className={ed.happy > 0 ? "text-emerald-300" : "text-rose-300"}>счастье {ed.happy > 0 ? "+" : ""}{ed.happy}</span> : null}
                        {ed.taxMul ? <span className="text-amber-300">налоги ×{ed.taxMul}</span> : null}
                        {ed.order ? <span className="text-sky-300">порядок +{ed.order}</span> : null}
                        {ed.crime ? <span className="text-emerald-300">преступность {ed.crime}</span> : null}
                        {ed.prod ? <span className="text-amber-200">работа ×{ed.prod}</span> : null}
                        <span className="text-white/40">{ed.days} дн.</span>
                      </div>
                    </div>
                    <button className="btn px-2.5! py-2! text-[11px]" disabled={active} onClick={() => c.issueEdict(engine, ed.id)}>
                      {active ? "идёт" : ed.cost > 0 ? `${ed.cost}` : "Издать"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Склад" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11.5px] leading-snug text-white/45">
              Мастерские берут сырьё со склада и кладут туда готовый товар. Сдавайте ресурсы — цепочки заработают сами.
            </p>
            {Object.keys(s.stock).length === 0 && (
              <div className="py-4 text-center text-[12px] text-white/35">Склад пуст. Сдайте сырьё из сумки ↓</div>
            )}
            {Object.entries(s.stock).filter(([, n]) => n >= 1).map(([id, n]) => (
              <div key={id} className="flex items-center gap-2 rounded-xl border border-white/8 bg-black/25 p-1.5">
                <ItemIcon icon={ITEMS[id]?.icon ?? "Package"} size={17} className="text-amber-200" />
                <span className="flex-1 truncate text-[12.5px] text-amber-50">{ITEMS[id]?.name ?? id}</span>
                <span className="text-[13px] font-bold text-amber-200">{Math.floor(n)}</span>
                <button className="btn-ghost px-2! py-1.5!" onClick={() => c.withdrawFromCity(engine, id, 10)}>
                  <ArrowUpFromLine size={13} />
                </button>
              </div>
            ))}
            <div className="mt-2 text-[11px] font-bold uppercase tracking-wide text-white/40">Сдать со своей сумки</div>
            <div className="grid grid-cols-4 gap-1.5">
              {snap.inv.filter((x) => ITEMS[x.id]?.type === "res" || ["zerno", "muka", "tkan", "hleb"].includes(x.id)).slice(0, 16).map((x, i) => (
                <button key={`${x.id}${i}`} className="item-cell aspect-auto! py-1.5" onClick={() => c.depositToCity(engine, x.id, x.n)}>
                  <ItemIcon icon={ITEMS[x.id].icon} size={16} className="text-amber-100/80" />
                  <span className="text-[9px] font-bold text-white/60">{x.n}</span>
                  <ArrowDownToLine size={9} className="absolute right-1 top-1 text-emerald-300/70" />
                </button>
              ))}
            </div>
          </div>
        )}

        {tab === "Хроника" && (
          <div className="space-y-2">
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                <Users size={12} /> Население по дням
              </div>
              <Spark data={s.history.length > 1 ? s.history : [s.pop, s.pop]} />
              <Row k="Сейчас" v={`${Math.floor(s.pop)} чел.`} color="#fbbf24" />
              <Row k="Вместимость" v={`${s.popCap} чел.`} />
              <Row k="Жителей на улицах" v={snap.npcNear} />
            </div>
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                <Coins size={12} /> Держава
              </div>
              <Row k="Форма правления" v={snap.govName} color="#f2c14e" />
              <Row k="Поддержка фракций" v={`${snap.support}%`} color={happyColor(snap.support)} />
              <Row k="Торговых путей в дороге" v={snap.routeCount} />
              <Row k="Памятников и чудес" v={`${c.wonderCount()}`} />
            </div>
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                <Sparkle size={12} /> Летопись рода
              </div>
              {engine.dynasty.log.slice(0, 8).map((l, i) => (
                <div key={i} className="border-b border-white/5 py-1 text-[11.5px] last:border-0">
                  <span className="text-white/35">День {l.day}: </span>
                  <span className={l.kind === "bad" ? "text-rose-300" : l.kind === "good" ? "text-emerald-300" : "text-white/70"}>{l.text}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="mt-2 flex items-center justify-between rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5 text-[11.5px]">
        <span className="flex items-center gap-1 text-white/45"><Package size={12} /> Казна</span>
        <span className="font-display text-[15px] font-bold text-amber-200">{engine.player.gold} зол.</span>
      </div>
    </Sheet>
  );
}
