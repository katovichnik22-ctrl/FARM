import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row, happyColor } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { GOVERNMENTS } from "../types/city";
import { TRAIT_HINTS as TH } from "../data/citydata";
import type { GovForm, Royal } from "../types";
import { Crown, Heart, Baby, Check, X as XIcon, Scale, ShieldQuestion } from "lucide-react";

const TABS = ["Род", "Парламент", "Правление"];

const ROLE_RU: Record<Royal["role"], string> = {
  ruler: "Правитель", consort: "Супруг(а)", heir: "Наследник", child: "Дитя рода", relative: "Родич",
};

export function RealmPanel({ engine, snap, onClose, startTab }: {
  engine: Engine; snap: UiSnapshot; onClose: () => void; startTab?: string;
}) {
  const [tab, setTab] = useState(startTab ?? "Род");
  const d = engine.dynasty;
  const ruler = d.ruler();
  const alive = d.royals.filter((r) => r.alive);
  const gov = d.govDef();

  return (
    <Sheet
      title={`Род ${d.house}`}
      sub={`${gov.name} · поддержка ${snap.support}% · ${ruler ? `правит ${ruler.name}, ${ruler.age} лет` : "трон пуст"}`}
      onClose={onClose}
    >
      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "62vh" }}>

        {tab === "Род" && (
          <div className="space-y-1.5">
            {alive.map((r) => (
              <div key={r.uid} className={`rounded-xl border p-2.5 ${r.role === "ruler" ? "border-amber-400/45 bg-amber-400/8" : "border-white/8 bg-black/25"}`}>
                <div className="flex items-start gap-2">
                  <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${r.role === "ruler" ? "bg-amber-400/20 text-amber-300" : "bg-white/8 text-white/60"}`}>
                    {r.role === "ruler" ? <Crown size={19} /> : r.age < 16 ? <Baby size={18} /> : <ItemIcon icon="PersonStanding" size={18} />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-baseline gap-x-1.5">
                      <span className="font-display text-[14px] font-bold text-amber-50">{r.name}</span>
                      <span className="text-[10.5px] font-bold uppercase tracking-wide text-amber-300/70">{ROLE_RU[r.role]}</span>
                      <span className="text-[11px] text-white/40">{r.age} лет</span>
                    </div>
                    <div className="mt-0.5 flex flex-wrap gap-1 text-[10px] font-semibold">
                      <span className="rounded bg-white/8 px-1.5 py-0.5 text-amber-100/80" title={TH[r.trait] ?? ""}>{r.trait}</span>
                      <span className="rounded bg-white/8 px-1.5 py-0.5 text-white/55">{r.ambition}</span>
                      <span className={`rounded px-1.5 py-0.5 ${r.loyalty > 60 ? "bg-emerald-400/15 text-emerald-300" : r.loyalty > 30 ? "bg-amber-400/15 text-amber-300" : "bg-rose-400/15 text-rose-300"}`}>
                        верность {Math.round(r.loyalty)}
                      </span>
                      <span className="rounded bg-sky-400/10 px-1.5 py-0.5 text-sky-300">умения {r.skill}</span>
                    </div>
                    <div className="mt-1.5 flex gap-1.5">
                      {!r.spouse && r.age >= 16 && (
                        <button className="btn-ghost px-2.5! py-1.5! text-[11px]" onClick={() => d.arrangeMarriage(engine, r.uid)}>
                          <Heart size={12} /> Сосватать (260)
                        </button>
                      )}
                      {r.spouse > 0 && (
                        <span className="rounded-lg bg-rose-400/10 px-2 py-1 text-[10.5px] font-semibold text-rose-200/80">
                          в браке с {d.royals.find((x) => x.uid === r.spouse)?.name ?? "?"}
                        </span>
                      )}
                      {r.role !== "ruler" && r.role !== "heir" && r.role !== "consort" && (
                        <button className="btn-ghost px-2.5! py-1.5! text-[11px]" onClick={() => d.designateHeir(engine, r.uid)}>
                          <Crown size={12} /> В наследники
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 text-[11px] font-bold uppercase tracking-wide text-white/45">Летопись</div>
              {d.log.slice(0, 10).map((l, i) => (
                <div key={i} className="border-b border-white/5 py-1 text-[11.5px] last:border-0">
                  <span className="text-white/35">День {l.day}: </span>
                  <span className={l.kind === "bad" ? "text-rose-300" : l.kind === "good" ? "text-emerald-300" : "text-white/70"}>{l.text}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "Парламент" && (
          <div className="space-y-1.5">
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <Row k="Средняя поддержка" v={`${snap.support}%`} color={happyColor(snap.support)} />
              <Row k="Форма правления" v={gov.name} color="#f2c14e" />
              {d.coupWarn > 0 && <Row k="Угроза переворота" v={`${d.coupWarn}/3`} color="#e05a5a" />}
            </div>
            {d.factions.map((f) => {
              const cost = d.demandCost(engine, f);
              const done = d.demandHint(engine, f);
              return (
                <div key={f.id} className="rounded-xl border border-white/8 bg-black/25 p-2.5">
                  <div className="flex items-center gap-2">
                    <ItemIcon icon={f.icon} size={17} className="text-amber-200" />
                    <span className="flex-1 truncate text-[13px] font-bold text-amber-50">{f.name}</span>
                    <span className="text-[11px] font-bold text-white/40">вес {f.power}</span>
                    <span className="font-display text-[15px] font-bold" style={{ color: happyColor(f.support) }}>
                      {Math.round(f.support)}%
                    </span>
                  </div>
                  <div className="bar-track mt-1 h-1.5!">
                    <div className="bar-fill" style={{ width: `${f.support}%`, background: happyColor(f.support) }} />
                  </div>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <ShieldQuestion size={13} className="shrink-0 text-amber-300/70" />
                    <span className="flex-1 text-[11.5px] leading-snug text-white/60">
                      «{f.demand}» {done && <span className="text-emerald-300">— уже исполнено</span>}
                    </span>
                  </div>
                  <div className="mt-1.5 flex gap-1.5">
                    <button className="btn flex-1 py-1.5! text-[11.5px]" onClick={() => d.acceptDemand(engine, f.id)}>
                      <Check size={13} /> Уступить ({cost})
                    </button>
                    <button className="btn-ghost flex-1 py-1.5! text-[11.5px]" onClick={() => d.refuseDemand(engine, f.id)}>
                      <XIcon size={13} /> Отказать
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Правление" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11.5px] leading-snug text-white/45">
              Форма правления меняет налоги, счастье, науку и порядок. Реформа стоит 420 золота и требует поддержки.
            </p>
            {GOVERNMENTS.map((g) => {
              const cur = d.gov === g.id;
              const can = d.canReform(engine, g.id as GovForm);
              return (
                <div key={g.id} className={`rounded-xl border p-2.5 ${cur ? "border-amber-400/50 bg-amber-400/10" : can.ok ? "border-emerald-400/25 bg-black/25" : "border-white/8 bg-black/15 opacity-75"}`}>
                  <div className="flex items-center gap-2">
                    <ItemIcon icon={g.icon} size={18} className={cur ? "text-amber-300" : "text-white/55"} />
                    <span className="flex-1 text-[13.5px] font-bold text-amber-50">{g.name}</span>
                    {cur && <span className="rounded-full bg-amber-400/20 px-2 py-0.5 text-[10px] font-bold text-amber-200">сейчас</span>}
                  </div>
                  <div className="mt-0.5 text-[11.5px] leading-snug text-white/50">{g.desc}</div>
                  <div className="mt-1 flex flex-wrap gap-1 text-[10px] font-semibold">
                    <Tag v={g.tax} label="налоги" /><Tag v={g.happy || 1} label="счастье" />
                    <Tag v={g.science} label="наука" /><Tag v={g.order} label="порядок" />
                    <Tag v={g.faith} label="вера" /><Tag v={g.trade} label="торг" />
                  </div>
                  {!cur && (
                    <div className="mt-1.5 flex items-center gap-2">
                      <span className={`flex-1 text-[10.5px] ${can.ok ? "text-emerald-300" : "text-white/40"}`}>
                        {can.ok ? "Условия выполнены" : can.reason || g.need}
                      </span>
                      <button className="btn px-3! py-1.5! text-[11.5px]" disabled={!can.ok} onClick={() => d.reform(engine, g.id as GovForm)}>
                        <Scale size={13} /> Реформа
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Sheet>
  );
}

function Tag({ v, label }: { v: number; label: string }) {
  const good = v > 1;
  const neutral = Math.abs(v - 1) < 0.02;
  return (
    <span className={`rounded px-1.5 py-0.5 ${neutral ? "bg-white/8 text-white/45" : good ? "bg-emerald-400/12 text-emerald-300" : "bg-rose-400/12 text-rose-300"}`}>
      {label} ×{v.toFixed(2).replace(/0$/, "")}
    </span>
  );
}


