import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { TECHS } from "../data/tech";
import { ERAS, TECH_BRANCHES } from "../types/lore";
import type { TechBranch, EraId } from "../types/lore";
import { Check, Lock, FlaskConical, Hourglass, Sparkle, ChevronRight } from "lucide-react";

export function TechPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const l = engine.lore;
  const [branch, setBranch] = useState<"all" | TechBranch>("all");
  const [era, setEra] = useState<EraId | "all">(l.era);

  const branches: ("all" | TechBranch)[] = ["all", "mil", "eco", "sci", "mag", "cul", "soc", "space"];
  const eraIdx = l.eraIndex();
  const nextEra = l.nextEra();

  const list = TECHS.filter((t) =>
    (branch === "all" || t.branch === branch) && (era === "all" || t.era === era)
  );

  return (
    <Sheet
      title="Палата знаний"
      sub={`${snap.eraName} · открыто ${snap.techCount}/${snap.techTotal} · наука ${snap.sciRate}/мин`}
      onClose={onClose}
    >
      {/* Текущее исследование */}
      <div className="mb-2 rounded-xl border border-sky-400/25 bg-black/30 p-2.5">
        {snap.researching ? (
          <>
            <div className="flex items-center gap-1.5">
              <Hourglass size={13} className="text-sky-300" />
              <span className="flex-1 truncate text-[12.5px] font-bold text-amber-50">{snap.researchName}</span>
              <span className="text-[11px] font-bold text-sky-300">{Math.round(snap.researchProgress)}%</span>
            </div>
            <div className="bar-track mt-1 h-1.5!">
              <div className="bar-fill" style={{ width: `${snap.researchProgress}%`, background: "#5a9ac9" }} />
            </div>
          </>
        ) : (
          <div className="text-center text-[12px] text-white/45">Учёные без дела — выберите, что изучать</div>
        )}
        <div className="mt-1.5 flex items-center justify-between text-[10.5px] text-white/40">
          <span>Накоплено: {snap.science}</span>
          <span>Всего за эпохи: {snap.sciTotal}</span>
        </div>
      </div>

      {/* Полоса эпох */}
      <div className="mb-2 flex gap-1 overflow-x-auto pb-1" style={{ touchAction: "pan-x" }}>
        {ERAS.map((er, i) => {
          const reached = i <= eraIdx;
          return (
            <button key={er.id} onClick={() => setEra(era === er.id ? "all" : er.id)}
              className={`flex shrink-0 items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-semibold transition ${era === er.id ? "border-amber-400/60 bg-amber-400/15 text-amber-200" : reached ? "border-white/15 bg-white/5 text-white/65" : "border-white/8 bg-black/20 text-white/30"}`}>
              <span style={{ color: reached ? er.color : undefined }}>●</span>
              {er.name}
            </button>
          );
        })}
      </div>
      {nextEra && (
        <div className="mb-2 flex items-center gap-2 rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5">
          <ChevronRight size={13} className="shrink-0 text-amber-300" />
          <span className="flex-1 text-[11px] text-white/55">До эпохи «{nextEra.name}»</span>
          <div className="w-20">
            <div className="bar-track h-1.5!">
              <div className="bar-fill" style={{
                width: `${Math.min(100, (snap.sciTotal / nextEra.sciNeed) * 100)}%`,
                background: nextEra.color,
              }} />
            </div>
          </div>
          <span className="text-[10px] text-white/40">{snap.sciTotal}/{nextEra.sciNeed}</span>
        </div>
      )}

      <Tabs
        tabs={branches.map((b) => (b === "all" ? "Всё" : TECH_BRANCHES[b].name))}
        active={branch === "all" ? "Всё" : TECH_BRANCHES[branch].name}
        onPick={(name) => {
          const found = branches.find((b) => (b === "all" ? "Всё" : TECH_BRANCHES[b].name) === name);
          if (found) setBranch(found);
        }}
      />

      <div className="scroll-area flex-1 space-y-1.5 pr-0.5" style={{ maxHeight: "48vh" }}>
        {list.map((t) => {
          const known = l.has(t.id);
          const check = l.canResearch(t.id);
          const active = l.researching === t.id;
          const br = TECH_BRANCHES[t.branch];
          return (
            <div key={t.id}
              className={`rounded-xl border p-2 ${known ? "border-emerald-400/30 bg-emerald-400/6" : active ? "border-sky-400/45 bg-sky-400/8" : check.ok ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-65"}`}>
              <div className="flex items-start gap-2">
                <div className="item-cell h-10! w-10! shrink-0" style={{ borderColor: `${br.color}55` }}>
                  <ItemIcon icon={t.icon} size={18} style={{ color: known ? "#7ae68a" : br.color }} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="truncate text-[13px] font-bold text-amber-50">{t.name}</span>
                    {known && <Check size={12} className="shrink-0 text-emerald-400" />}
                    {!known && !check.ok && <Lock size={11} className="shrink-0 text-white/35" />}
                  </div>
                  <div className="text-[10.5px] italic leading-snug text-white/45">{t.desc}</div>
                  <div className="mt-0.5 flex flex-wrap items-center gap-1 text-[10px] font-semibold">
                    <span className="rounded px-1.5 py-0.5" style={{ background: `${br.color}22`, color: br.color }}>{br.name}</span>
                    <span className="rounded bg-white/8 px-1.5 py-0.5 text-white/55">{ERAS.find((x) => x.id === t.era)?.name}</span>
                    <span className="rounded bg-sky-400/12 px-1.5 py-0.5 text-sky-300">{t.cost} науки</span>
                  </div>
                  <div className="mt-0.5 flex items-start gap-1 text-[10.5px] text-amber-200/80">
                    <Sparkle size={9} className="mt-0.5 shrink-0" /> {t.bonusText}
                  </div>
                  {!known && !check.ok && <div className="mt-0.5 text-[10px] text-white/35">{check.reason}</div>}
                </div>
                {!known && (
                  <button className="btn px-2.5! py-2! text-[11px]!" disabled={!check.ok || active}
                    onClick={() => l.setResearch(engine, t.id)}>
                    {active ? "идёт" : <FlaskConical size={13} />}
                  </button>
                )}
              </div>
            </div>
          );
        })}
        {list.length === 0 && <div className="py-8 text-center text-[12px] text-white/35">В этой ветви пока пусто</div>}
      </div>

      <div className="mt-2 rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5">
        <Row k="Эпоха" v={snap.eraName} color={snap.eraColor} />
        <Row k="Прирост науки" v={`${snap.sciRate}/мин`} color="#5a9ac9" />
      </div>
    </Sheet>
  );
}
