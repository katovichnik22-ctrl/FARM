import { useEffect, useRef } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { miniColor } from "../world/worldgen";

const RANGE = 50; // 100×100 тайлов

const off = typeof document !== "undefined" ? document.createElement("canvas") : null;
const OFF = 75;

export function Minimap({ engine, snap }: { engine: Engine; snap: UiSnapshot }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const lastDraw = useRef({ tx: -999, ty: -999, t: 0 });

  useEffect(() => {
    const c = ref.current;
    if (!c || !off) return;
    const ctx = c.getContext("2d")!;
    const size = 150;
    const now = performance.now();
    const moved = Math.abs(snap.tx - lastDraw.current.tx) + Math.abs(snap.ty - lastDraw.current.ty);
    if (moved < 3 && now - lastDraw.current.t < 900) return;
    lastDraw.current = { tx: snap.tx, ty: snap.ty, t: now };

    // Сэмплируем в 75×75 и растягиваем — в 4 раза меньше работы
    off.width = OFF; off.height = OFF;
    const octx = off.getContext("2d")!;
    const img = octx.createImageData(OFF, OFF);
    const x0 = snap.tx - RANGE, y0 = snap.ty - RANGE;
    const step = (RANGE * 2) / OFF;
    for (let py = 0; py < OFF; py++) {
      for (let px = 0; px < OFF; px++) {
        const tx = Math.floor(x0 + px * step), ty = Math.floor(y0 + py * step);
        const col = miniColor(engine.seed, tx, ty, snap.z);
        const n = parseInt(col.slice(1), 16);
        const i = (py * OFF + px) * 4;
        img.data[i] = (n >> 16) & 255; img.data[i + 1] = (n >> 8) & 255; img.data[i + 2] = n & 255; img.data[i + 3] = 255;
      }
    }
    octx.putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(off, 0, 0, size, size);

    const scale = size / (RANGE * 2);

    // здания
    for (const b of engine.buildings) {
      const bx = (b.tx - x0) * scale, by = (b.ty - y0) * scale;
      if (bx < -6 || by < -6 || bx > size + 6 || by > size + 6) continue;
      ctx.fillStyle = b.done ? "#f5c542" : "#e08a4d";
      ctx.fillRect(bx - 2, by - 2, 5, 5);
    }
    // точка дома (спавн)
    const sp = engine.spawnPoint();
    const sx = (sp.x - x0) * scale, sy = (sp.y - y0) * scale;
    if (sx > 0 && sx < size && sy > 0 && sy < size) {
      ctx.fillStyle = "#7ae68a";
      ctx.beginPath();
      ctx.moveTo(sx, sy - 4); ctx.lineTo(sx + 4, sy); ctx.lineTo(sx, sy + 4); ctx.lineTo(sx - 4, sy);
      ctx.closePath(); ctx.fill();
    }
    // арена дракона
    const ar = engine.arenaPos();
    const ax = (ar.x - x0) * scale, ay = (ar.y - y0) * scale;
    if (ax > -10 && ax < size + 10 && ay > -10 && ay < size + 10 && snap.dragonAlive) {
      ctx.fillStyle = "#e05a4d";
      ctx.beginPath(); ctx.arc(Math.max(6, Math.min(size - 6, ax)), Math.max(6, Math.min(size - 6, ay)), 4, 0, 7); ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.beginPath(); ctx.arc(Math.max(6, Math.min(size - 6, ax)), Math.max(6, Math.min(size - 6, ay)), 1.4, 0, 7); ctx.fill();
    }
    // враги
    for (const m of engine.mobs) {
      const mx = (m.x / 40 - x0) * scale, my = (m.y / 40 - y0) * scale;
      if (mx < 0 || my < 0 || mx > size || my > size) continue;
      ctx.fillStyle = "#ff5a4d";
      ctx.fillRect(mx - 1, my - 1, 2.6, 2.6);
    }
    // вражеские войска на подходе
    for (const nn of engine.nations.nations) {
      if (!nn.incoming) continue;
      const ang = Math.atan2(nn.y, nn.x);
      const bx = size / 2 + Math.cos(ang) * (size * 0.38);
      const by = size / 2 + Math.sin(ang) * (size * 0.38);
      ctx.fillStyle = nn.flag.bg;
      ctx.beginPath();
      ctx.moveTo(bx, by - 5); ctx.lineTo(bx + 5, by + 4); ctx.lineTo(bx - 5, by + 4);
      ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#ff6a5a"; ctx.lineWidth = 1.2; ctx.stroke();
    }
    // игрок
    ctx.fillStyle = "#fff";
    ctx.strokeStyle = "rgba(0,0,0,0.7)";
    ctx.lineWidth = 1.6;
    ctx.beginPath(); ctx.arc(size / 2, size / 2, 4.4, 0, 7); ctx.fill(); ctx.stroke();
    const p = engine.player;
    ctx.strokeStyle = "#fff";
    ctx.beginPath();
    ctx.moveTo(size / 2, size / 2);
    ctx.lineTo(size / 2 + Math.cos(p.dir) * 9, size / 2 + Math.sin(p.dir) * 9);
    ctx.stroke();
    // рамка взгляда северной метки
    ctx.fillStyle = "rgba(255,255,255,0.55)";
    ctx.font = "700 9px system-ui";
    ctx.textAlign = "center";
    ctx.fillText("N", size / 2, 10);
  }, [engine, snap]);

  return (
    <div
      className="pointer-events-none absolute right-2 z-20 origin-top-right scale-[0.72] min-[420px]:scale-[0.85] sm:scale-100"
      style={{ top: "calc(var(--hud-h, 128px) + 6px)" }}
    >
      <div className="glass p-1.5">
        <canvas ref={ref} width={150} height={150} className="rounded-xl" style={{ imageRendering: "pixelated" }} />
        <div className="mt-1 text-center text-[10px] font-semibold text-white/55">
          {snap.tx}, {snap.ty} · {snap.biomeName}
        </div>
      </div>
    </div>
  );
}
