import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row, Spark } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { DOCTRINES, GREAT_KINDS } from "../types/lore";
import type { DoctrineId } from "../types/lore";
import {
  Church, Flame, Users, Send, Gavel, Sparkle, Trophy, Landmark, Scroll,
} from "lucide-react";
import { snd } from "../lib/sound";

const TABS = ["Вера", "Догматы", "Мир", "Культура"];

export function FaithPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const l = engine.lore;
  const r = l.religion;
  const [tab, setTab] = useState(r.founded ? "Вера" : "Вера");
  const [name, setName] = useState("");
  const [doc, setDoc] = useState<DoctrineId>("faithDoc");

  // --- Основание религии ---
  if (!r.founded) {
    const c = l.canFoundReligion(engine);
    return (
      <Sheet title="Основание веры" sub="Слово, сказанное однажды, переживёт державы" onClose={onClose}>
        <div className="scroll-area space-y-2" style={{ maxHeight: "62vh" }}>
          <div className="flex items-start gap-3 rounded-xl border border-amber-400/25 bg-amber-400/6 p-3">
            <Church size={30} className="shrink-0 text-amber-300" />
            <p className="text-[12.5px] leading-snug text-white/65">
              Своя религия даёт догматы с бонусами всей державе, расходится по миру, меняет отношения стран
              и открывает священные походы. Нужен храм и вера в городе.
            </p>
          </div>
          <div className={`rounded-xl border p-2.5 text-[12.5px] font-semibold ${c.ok ? "border-emerald-400/30 bg-emerald-400/8 text-emerald-200" : "border-amber-400/25 bg-amber-400/6 text-amber-200/80"}`}>
            {c.ok ? "Всё готово — наречём веру" : c.reason}
          </div>
          {c.ok && (
            <>
              <div className="rounded-xl border border-white/10 bg-black/30 p-2.5">
                <label className="text-[11px] font-bold uppercase tracking-wide text-white/45">Имя веры</label>
                <div className="mt-1 flex gap-1.5">
                  <input value={name} onChange={(e) => setName(e.target.value)} placeholder={l.suggestReligionName()}
                    className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 text-[14px] text-amber-50 outline-none focus:border-amber-400/50" />
                  <button className="btn-ghost px-3!" onClick={() => { setName(l.suggestReligionName()); snd.ui(); }}>
                    <Sparkle size={15} />
                  </button>
                </div>
              </div>
              <div className="text-[11px] font-bold uppercase tracking-wide text-white/40">Первый догмат</div>
              <div className="space-y-1">
                {DOCTRINES.map((d) => (
                  <button key={d.id}
                    className={`flex w-full items-start gap-2 rounded-xl border p-2 text-left transition ${doc === d.id ? "border-amber-400/60 bg-amber-400/10" : "border-white/8 bg-black/25"}`}
                    onClick={() => { setDoc(d.id); snd.ui(); }}>
                    <ItemIcon icon={d.icon} size={17} className="mt-0.5 shrink-0 text-amber-200" />
                    <div className="min-w-0 flex-1">
                      <div className="text-[12.5px] font-bold text-amber-50">{d.name}</div>
                      <div className="text-[10.5px] leading-snug text-white/45">{d.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
              <button className="btn w-full py-3!" onClick={() => l.foundReligion(engine, name, doc)}>
                <Church size={16} /> Основать веру
              </button>
            </>
          )}
        </div>
      </Sheet>
    );
  }

  return (
    <Sheet
      title={`${r.symbol} ${r.name}`}
      sub={`Последователей ${snap.followers}% · догматов ${r.doctrines.length}/4 · священный град ${r.holyCity}`}
      onClose={onClose}
    >
      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "58vh" }}>

        {tab === "Вера" && (
          <div className="space-y-2">
            <div className="rounded-xl border p-2.5" style={{ borderColor: `${r.color}44`, background: "rgba(0,0,0,0.3)" }}>
              <div className="flex items-center gap-2">
                <div className="flex h-11 w-11 items-center justify-center rounded-full text-[22px]" style={{ background: `${r.color}22`, color: r.color }}>
                  {r.symbol}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-display text-[15px] font-bold text-amber-50">{r.name}</div>
                  <div className="text-[11px] text-white/45">основана на {r.founderDay}-й день · паломников {r.pilgrims}</div>
                </div>
              </div>
              <div className="bar-track mt-2 h-2!">
                <div className="bar-fill" style={{ width: `${r.followers}%`, background: r.color }} />
              </div>
              <div className="mt-0.5 text-right text-[10px] text-white/40">доля мира: {snap.followers}%</div>
            </div>

            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <Row k="Вера в городе" v={engine.city.s.founded ? engine.city.s.metrics.faith : "—"} color="#ffd97a" />
              <Row k="Прирост последователей" v={`+${(0.25 * l.religionEffect("spread")).toFixed(2)}%/день`} color="#7ae68a" />
              <Row k="Милостыня паломников" v={`+${Math.floor(r.pilgrims * 0.6)} зол./день`} color="#f2c14e" />
              <Row k="Инквизиция" v={r.inquisition ? "объявлена" : "нет"} color={r.inquisition ? "#e05a5a" : undefined} />
            </div>

            <div className="flex gap-1.5">
              <button className="btn flex-1 py-2.5! text-[12px]!" onClick={() => l.sendMissionaries(engine)}>
                <Send size={14} /> Проповедники (220)
              </button>
              <button className={`flex-1 py-2.5! text-[12px]! ${r.inquisition ? "btn" : "btn-ghost"}`} onClick={() => l.toggleInquisition(engine)}>
                <Gavel size={14} /> {r.inquisition ? "Распустить" : "Инквизиция"}
              </button>
            </div>

            {engine.nations.atWar().length > 0 && (
              <>
                <div className="text-[11px] font-bold uppercase tracking-wide text-white/40">Священный поход (800 зол.)</div>
                {engine.nations.nations.filter((n) => n.state !== "ally" && n.state !== "vassal").slice(0, 6).map((n) => (
                  <div key={n.id} className="flex items-center gap-2 rounded-xl border border-white/8 bg-black/25 p-2">
                    <div className="flex h-6 w-8 items-center justify-center rounded border border-white/20 text-[11px] font-bold"
                      style={{ background: n.flag.bg, color: n.flag.fg }}>{n.flag.sym}</div>
                    <span className="flex-1 truncate text-[12.5px] text-amber-50">{n.name}</span>
                    <button className="btn px-2.5! py-1.5! text-[11px]!" onClick={() => l.callCrusade(engine, n.id)}>
                      <Flame size={12} /> Поход
                    </button>
                  </div>
                ))}
              </>
            )}

            {r.prophets.length > 0 && (
              <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
                <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                  <Scroll size={12} /> Пророки
                </div>
                {r.prophets.slice(-5).map((p, i) => (
                  <Row key={i} k={`${p.name} «${p.trait}»`} v={`день ${p.day}`} />
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "Догматы" && (
          <div className="space-y-1.5">
            <p className="px-1 text-[11px] leading-snug text-white/45">
              Каждый догмат меняет лицо веры. Больше последователей — больше догматов (до четырёх).
            </p>
            {DOCTRINES.map((d) => {
              const taken = r.doctrines.includes(d.id);
              const need = 25 * r.doctrines.length;
              const can = !taken && r.doctrines.length < 4 && r.followers >= need;
              return (
                <div key={d.id} className={`rounded-xl border p-2 ${taken ? "border-emerald-400/35 bg-emerald-400/8" : can ? "border-amber-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-65"}`}>
                  <div className="flex items-start gap-2">
                    <ItemIcon icon={d.icon} size={17} className="mt-0.5 shrink-0" style={{ color: taken ? "#7ae68a" : "#f2c14e" }} />
                    <div className="min-w-0 flex-1">
                      <div className="text-[12.5px] font-bold text-amber-50">{d.name}</div>
                      <div className="text-[10.5px] leading-snug text-white/45">{d.desc}</div>
                      <div className="mt-0.5 flex flex-wrap gap-1 text-[10px] font-semibold">
                        {Object.entries(d.effect).map(([k, v]) => (
                          <span key={k} className="rounded bg-white/8 px-1.5 py-0.5 text-amber-200/80">
                            {({ faith: "вера", happy: "счастье", armyAtk: "атака", gold: "золото", food: "еда", sci: "наука", culture: "культура", spread: "распространение" } as Record<string, string>)[k] ?? k}
                            {" "}{typeof v === "number" && v < 1 && v > 0 && k !== "spread" ? `+${v}` : k === "spread" || k === "armyAtk" ? `×${v}` : `+${v}`}
                          </span>
                        ))}
                      </div>
                      {!taken && !can && <div className="mt-0.5 text-[10px] text-white/35">Нужно {need}% последователей</div>}
                    </div>
                    {!taken && (
                      <button className="btn px-2.5! py-2! text-[11px]!" disabled={!can} onClick={() => l.addDoctrine(engine, d.id)}>
                        {l.addDoctrineCost()}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Мир" && (
          <div className="space-y-1.5">
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                <Landmark size={12} /> Веры мира
              </div>
              <div className="mb-1.5 flex items-center gap-2">
                <span className="text-[16px]" style={{ color: r.color }}>{r.symbol}</span>
                <span className="flex-1 truncate text-[12.5px] font-bold text-amber-50">{r.name} (ваша)</span>
                <span className="text-[12px] font-bold" style={{ color: r.color }}>{snap.followers}%</span>
              </div>
              <div className="bar-track mb-2 h-1.5!"><div className="bar-fill" style={{ width: `${r.followers}%`, background: r.color }} /></div>
              {l.worldReligions.map((w, i) => (
                <div key={i} className="mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[14px]" style={{ color: w.color }}>{w.symbol}</span>
                    <span className="flex-1 truncate text-[12px] text-white/65">{w.name}</span>
                    <span className="text-[11px] font-bold text-white/45">{w.share.toFixed(1)}%</span>
                  </div>
                  <div className="bar-track h-1!"><div className="bar-fill" style={{ width: `${w.share}%`, background: w.color }} /></div>
                </div>
              ))}
            </div>
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5 text-[11px] leading-snug text-white/45">
              Религиозные державы теплеют к вам, когда ваша вера крепнет, и злятся на инквизицию.
              Священный поход объявляет войну, но даёт войску рвение на шесть дней.
            </div>
          </div>
        )}

        {tab === "Культура" && (
          <CultureTab engine={engine} snap={snap} />
        )}
      </div>
    </Sheet>
  );
}

// ---------- Вкладка культуры ----------
function CultureTab({ engine, snap }: { engine: Engine; snap: UiSnapshot }) {
  const l = engine.lore;
  const cu = l.culture;
  const ready = cu.greats.filter((g) => !g.used);
  const used = cu.greats.filter((g) => g.used);
  return (
    <div className="space-y-2">
      <div className="grid grid-cols-3 gap-1.5">
        <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
          <Sparkle size={14} className="mx-auto text-pink-300" />
          <div className="font-display text-[16px] font-bold text-amber-100">{snap.cultureTotal}</div>
          <div className="text-[9.5px] text-white/40">культуры</div>
        </div>
        <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
          <Landmark size={14} className="mx-auto text-amber-300" />
          <div className="font-display text-[16px] font-bold text-amber-100">{snap.borders}</div>
          <div className="text-[9.5px] text-white/40">границы</div>
        </div>
        <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
          <Trophy size={14} className="mx-auto text-emerald-300" />
          <div className="font-display text-[16px] font-bold text-amber-100">{cu.masterpieces}</div>
          <div className="text-[9.5px] text-white/40">шедевров</div>
        </div>
      </div>

      <div className="rounded-xl border border-pink-400/25 bg-pink-400/6 p-2.5">
        <div className="flex items-center gap-1.5">
          <Trophy size={13} className="text-pink-300" />
          <span className="flex-1 text-[11px] font-bold uppercase tracking-wide text-white/50">Культурная победа</span>
          <span className="text-[13px] font-bold text-pink-200">{snap.cultureVictory}%</span>
        </div>
        <div className="bar-track mt-1 h-2!">
          <div className="bar-fill" style={{ width: `${snap.cultureVictory}%`, background: "#e08ac9" }} />
        </div>
        <div className="mt-1 text-[10.5px] text-white/40">
          Накопите 45 000 культуры — и мир покорится вам без единого меча.
        </div>
      </div>

      <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
        <div className="mb-1 flex items-center justify-between text-[11px] font-bold uppercase tracking-wide text-white/45">
          <span>До великого человека</span>
          <span>{Math.floor(cu.greatProgress)}/{l.greatCost()}</span>
        </div>
        <div className="bar-track h-1.5!">
          <div className="bar-fill" style={{ width: `${(cu.greatProgress / l.greatCost()) * 100}%`, background: "#f2c14e" }} />
        </div>
        <Spark data={[0, cu.greatProgress, l.greatCost()]} color="#e08ac9" h={0} />
      </div>

      {ready.length > 0 && <div className="text-[11px] font-bold uppercase tracking-wide text-white/40">Ждут вашего слова</div>}
      {ready.map((g) => {
        const meta = GREAT_KINDS[g.kind];
        return (
          <div key={g.uid} className="rounded-xl border border-amber-400/30 bg-amber-400/6 p-2.5">
            <div className="flex items-start gap-2">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full" style={{ background: `${meta.color}22`, color: meta.color }}>
                <ItemIcon icon={meta.icon} size={18} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-x-1.5">
                  <span className="font-display text-[13.5px] font-bold text-amber-50">{g.name}</span>
                  <span className="text-[10.5px] font-bold uppercase" style={{ color: meta.color }}>{meta.name}</span>
                </div>
                <div className="text-[10.5px] italic leading-snug text-white/45">{g.bio}</div>
                <div className="text-[10.5px] text-amber-200/80">{meta.desc}</div>
              </div>
            </div>
            <button className="btn mt-1.5 w-full py-2! text-[12px]!" onClick={() => l.useGreat(engine, g.uid)}>
              {meta.act}
            </button>
          </div>
        );
      })}

      {used.length > 0 && (
        <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
          <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
            <Users size={12} /> Зал славы
          </div>
          {used.slice(-8).reverse().map((g) => (
            <Row key={g.uid} k={`${g.name}`} v={`${GREAT_KINDS[g.kind].name}, день ${g.day}`} />
          ))}
        </div>
      )}
      {ready.length === 0 && used.length === 0 && (
        <div className="py-4 text-center text-[12px] text-white/40">
          Великие люди приходят к тем, кто строит театры, храмы и парки.
        </div>
      )}
    </div>
  );
}
