import { useState } from "react";
import type { Engine } from "../game/engine";
import { Sheet, Row } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { NPC_ROLES } from "../types/city";
import { BUILDINGS } from "../data/buildings";
import { ITEMS } from "../data/items";
import { Heart, HandCoins, Gift, ArrowUpCircle, Star, Hammer, Coins, Users, MessageCircle, HeartHandshake, MapPin, BookOpen, UserX, UserCheck } from "lucide-react";
import { snd } from "../lib/sound";
import { PERSONA_BY_ID, CHARACTER_RU, TIER_RU, PLACE_RU, ROMANCE_TIER_RU } from "../data/npcs";
import { personaSub } from "../game/personae";

// ---------- Диалог с именным персонажем ----------
function PersonaDialog({ engine, n, onClose }: { engine: Engine; n: NonNullable<Engine["activeNpc"]>; onClose: () => void }) {
  const [giftOpen, setGiftOpen] = useState(false);
  const [reply, setReply] = useState<string | null>(null);
  const d = engine.personae.dialog(engine, n);
  const { def, bond, tier } = d;
  const ch = CHARACTER_RU[def.character];
  const meta = NPC_ROLES[n.role];
  const fCol = bond.f >= 42 ? "#7ae68a" : bond.f >= 12 ? "#a8d8a0" : bond.f > -20 ? "#f2b45c" : "#e05a5a";
  const hour = (6 + engine.time * 24) % 24;
  const openInfo = tier === "known" || tier === "pal" || tier === "friend";
  const deepInfo = tier === "pal" || tier === "friend";
  const inv = engine.player.inv.filter((s) => s.n >= 1 && ITEMS[s.id]).slice(0, 14);

  return (
    <Sheet title={def.name} sub={personaSub(def, tier)} onClose={onClose}>
      <div className="scroll-area space-y-2" style={{ maxHeight: "58vh" }}>
        {/* Реплики */}
        <div className="flex items-start gap-3 rounded-xl border border-white/8 bg-black/25 p-2.5">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full" style={{ background: `${meta.color}33`, color: meta.color }}>
            <ItemIcon icon={meta.icon} size={21} />
          </div>
          <div className="min-w-0 flex-1 space-y-1">
            {(reply ? [reply, ...d.lines.slice(0, 1)] : d.lines).map((l, i) => (
              <p key={i} className="font-display text-[13px] leading-snug text-amber-50/85">«{l}»</p>
            ))}
          </div>
        </div>

        {/* Узы */}
        <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
          <div className="mb-1 flex items-center justify-between text-[11px] text-white/50">
            <span>Дружба · {TIER_RU[tier]}</span>
            <b style={{ color: fCol }}>{Math.round(bond.f)}</b>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/8">
            <div className="h-full rounded-full transition-all" style={{ width: `${Math.max(2, (bond.f + 100) / 2)}%`, background: fCol }} />
          </div>
          {def.romance && (
            <>
              <div className="mb-1 mt-2 flex items-center justify-between text-[11px] text-white/50">
                <span className="flex items-center gap-1"><Heart size={11} className="text-rose-300" /> {ROMANCE_TIER_RU(bond.h)}</span>
                <b className="text-rose-300">{Math.round(bond.h)}</b>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-white/8">
                <div className="h-full rounded-full bg-gradient-to-r from-rose-400 to-pink-300 transition-all" style={{ width: `${Math.max(2, bond.h)}%` }} />
              </div>
            </>
          )}
          <div className="mt-2 flex flex-wrap gap-1.5">
            <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10.5px]" style={{ color: ch.color }}>{ch.name}</span>
            <span className="flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10.5px] text-white/60">
              <MapPin size={10} /> сейчас: {PLACE_RU[engine.personae.placeFor(def, hour)].toLowerCase()}
            </span>
            {engine.personae.playerSpouse === def.id && (
              <span className="rounded-full border border-rose-300/30 bg-rose-400/10 px-2 py-0.5 text-[10.5px] text-rose-200">ваш супруг(а)</span>
            )}
          </div>
        </div>

        {/* Проблема и история (открываются по мере уз) */}
        {openInfo ? (
          <div className="rounded-xl border border-amber-400/25 bg-amber-400/6 p-2.5">
            <div className="mb-0.5 text-[11px] font-bold uppercase tracking-wider text-amber-200/80">Забота</div>
            <p className="text-[12.5px] leading-snug text-amber-50/75">{def.problem}</p>
          </div>
        ) : (
          <div className="rounded-xl border border-white/8 bg-black/20 p-2.5 text-[12px] italic text-white/35">
            Пока вы чужие люди. Поговорите поближе — и {def.sex === 0 ? "он" : "она"} расскажет о своём.
          </div>
        )}
        {deepInfo && (
          <>
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-0.5 flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-sky-200/80"><BookOpen size={11} /> Судьба</div>
              <p className="text-[12.5px] leading-snug text-white/65">{def.story}</p>
            </div>
            {Object.keys(def.relations).length > 0 && (
              <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
                <div className="mb-1 text-[11px] font-bold uppercase tracking-wider text-white/50">Связи</div>
                {Object.entries(def.relations).filter(([id, v]) => v !== 0 && PERSONA_BY_ID[id]).map(([id, v]) => (
                  <div key={id} className="flex items-center gap-1.5 py-0.5 text-[12px] text-white/60">
                    {v > 0 ? <UserCheck size={12} className="text-emerald-300" /> : <UserX size={12} className="text-rose-300" />}
                    {PERSONA_BY_ID[id].name.split(" ")[0]} — {v > 0 ? "дружба" : "вражда"}
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Выбор подарка */}
        {giftOpen && (
          <div className="rounded-xl border border-rose-300/25 bg-rose-400/6 p-2.5">
            <div className="mb-1.5 text-[11px] font-bold uppercase tracking-wider text-rose-200/80">Подарок из сумки (раз в день)</div>
            {!d.canGift && <div className="mb-1 text-[11px] text-white/45">Сегодня уже получал(а) подарок.</div>}
            <div className="grid grid-cols-2 gap-1">
              {inv.map((s) => (
                <button key={s.id} disabled={!d.canGift}
                  className="btn-ghost flex items-center gap-1.5 justify-start! py-1.5! text-left text-[11.5px] disabled:opacity-40"
                  onClick={() => {
                    const r = engine.personae.gift(engine, n, s.id);
                    setReply(r.text);
                    setGiftOpen(false);
                  }}>
                  <ItemIcon icon={ITEMS[s.id].icon} size={15} />
                  <span className="min-w-0 flex-1 truncate">{ITEMS[s.id].name} ×{s.n}</span>
                  {def.likedGifts.includes(s.id) && <Heart size={11} className="shrink-0 text-rose-300" />}
                </button>
              ))}
              {!inv.length && <div className="col-span-2 text-[11.5px] text-white/40">Сумка пуста.</div>}
            </div>
          </div>
        )}

        {/* Действия */}
        <div className="flex gap-1.5">
          <button className="btn flex-1 py-2! text-[12px]" disabled={!d.canChat}
            onClick={() => setReply(engine.personae.chat(engine, n))}>
            <MessageCircle size={13} /> {d.canChat ? "Поговорить" : "Уже говорили"}
          </button>
          <button className={`btn-ghost flex-1 py-2! text-[12px] ${giftOpen ? "bg-white/15!" : ""}`}
            onClick={() => { setGiftOpen((v) => !v); snd.ui(); }}>
            <Gift size={13} /> Подарок
          </button>
        </div>
        {d.canPropose && (
          <button className="btn w-full py-2.5! text-[12.5px] bg-gradient-to-r! !from-rose-500/90 !to-pink-500/90"
            onClick={() => setReply(engine.personae.propose(engine, n))}>
            <HeartHandshake size={14} /> Предложить руку и сердце
          </button>
        )}
        <button className="btn-ghost w-full py-2! text-[12px]" onClick={() => { snd.ui(); onClose(); }}>Попрощаться</button>
      </div>
    </Sheet>
  );
}

// ---------- Диалог с жителем ----------
export function NpcDialog({ engine, onClose }: { engine: Engine; onClose: () => void }) {
  const n = engine.activeNpc;
  if (!n) return null;
  if (n.persona && PERSONA_BY_ID[n.persona]) return <PersonaDialog engine={engine} n={n} onClose={onClose} />;
  const g = engine.npcs.greet(engine, n);
  const meta = NPC_ROLES[n.role];
  const moodLabel = n.mood > 60 ? "обожает вас" : n.mood > 25 ? "уважает" : n.mood > -10 ? "равнодушен" : n.mood > -45 ? "недоволен" : "ненавидит";
  const moodColor = n.mood > 25 ? "#7ae68a" : n.mood > -10 ? "#f2b45c" : "#e05a5a";

  return (
    <Sheet title={n.name} sub={`${meta.name}, ${n.age} лет · ${moodLabel}`} onClose={onClose}>
      <div className="scroll-area space-y-2" style={{ maxHeight: "56vh" }}>
        <div className="flex items-start gap-3 rounded-xl border border-white/8 bg-black/25 p-2.5">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full" style={{ background: `${meta.color}33`, color: meta.color }}>
            <ItemIcon icon={meta.icon} size={21} />
          </div>
          <div className="min-w-0 flex-1 space-y-1">
            {g.lines.map((l, i) => (
              <p key={i} className="font-display text-[13px] leading-snug text-amber-50/85">«{l}»</p>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
          <Row k="Отношение" v={`${Math.round(n.mood)} (${moodLabel})`} color={moodColor} />
          <Row k="Занятие" v={n.state === "work" ? "на работе" : n.state === "home" ? "дома" : n.state === "tavern" ? "в таверне" : n.state === "riot" ? "на площади, бунтует" : "гуляет"} />
          <Row k="Семья" v={n.spouse ? `в браке · детей ${n.children.length}` : "одинок"} />
        </div>

        {n.quest && (
          <div className="rounded-xl border border-amber-400/30 bg-amber-400/8 p-2.5">
            <div className="mb-1 flex items-center gap-1.5 text-[12px] font-bold text-amber-200">
              <Gift size={14} /> Просьба
            </div>
            <p className="text-[12px] leading-snug text-white/65">{engine.npcs.questText(n)}</p>
            <div className="mt-1 text-[11px] text-white/45">
              У вас: {engine.count(n.quest.item)}/{n.quest.n} {ITEMS[n.quest.item]?.name}
            </div>
            <button className="btn mt-2 w-full py-2! text-[12.5px]" disabled={!g.canGive} onClick={() => { engine.npcs.completeQuest(engine, n); onClose(); }}>
              <HandCoins size={14} /> Помочь ({n.quest.reward} зол.)
            </button>
          </div>
        )}

        <div className="flex gap-1.5">
          <button
            className="btn-ghost flex-1 py-2! text-[12px]"
            onClick={() => {
              const cost = 25;
              if (engine.player.gold < cost) { engine.toast("Нет золота на подарок", "warn"); return; }
              engine.player.gold -= cost;
              n.mood = Math.min(100, n.mood + 18);
              engine.toast(`${n.name} тронут вашей щедростью`, "good");
              snd.pickup();
              engine.dynasty.support("narod", 1);
              engine.poke();
            }}
          >
            <Heart size={13} /> Подарить 25 зол.
          </button>
          <button className="btn-ghost flex-1 py-2! text-[12px]" onClick={() => { snd.ui(); onClose(); }}>Попрощаться</button>
        </div>
      </div>
    </Sheet>
  );
}

// ---------- Карточка постройки ----------
export function BuildingInfo({ engine, onClose }: { engine: Engine; onClose: () => void }) {
  const b = engine.activeBuilding;
  if (!b) return null;
  const def = BUILDINGS[b.def];
  if (!def) return null;
  const lvl = b.lvl ?? 1;
  const u = engine.city.upgradeCost(b);
  const eff = def.eff ?? {};
  const effList: [string, number][] = Object.entries(eff).filter(([, v]) => v) as [string, number][];
  const EFF_RU: Record<string, string> = {
    food: "еда", water: "вода", energy: "энергия", health: "здоровье", crime: "преступность",
    pollution: "грязь", culture: "культура", faith: "вера", science: "наука", gold: "доход", order: "порядок", happy: "счастье",
  };

  return (
    <Sheet title={def.name} sub={`${def.cat} · уровень ${lvl}/${def.maxLvl ?? 3} · ${def.w}×${def.h}`} onClose={onClose}>
      <div className="scroll-area space-y-2" style={{ maxHeight: "56vh" }}>
        <div className="flex items-start gap-3 rounded-xl border border-white/8 bg-black/25 p-2.5">
          <div className="item-cell h-12! w-12! shrink-0"><ItemIcon icon={def.icon} size={24} className="text-amber-200" /></div>
          <div className="min-w-0 flex-1">
            <p className="text-[12.5px] leading-snug text-white/60">{def.desc}</p>
            {def.bonus && <p className="mt-1 text-[11.5px] font-semibold text-amber-300">★ {def.bonus}</p>}
          </div>
        </div>

        <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
          {def.jobs ? <Row k="Рабочих мест" v={def.jobs * lvl} color="#8fa2b8" /> : null}
          {def.housing ? <Row k="Вмещает жителей" v={def.housing * lvl} color="#7ae68a" /> : null}
          {def.upkeep ? <Row k="Содержание" v={`${def.upkeep * lvl} зол./день`} color="#e05a5a" /> : null}
          {effList.map(([k, v]) => (
            <Row key={k} k={EFF_RU[k] ?? k} v={`${v > 0 ? "+" : ""}${(v * lvl).toFixed(0)}`} color={v > 0 ? "#7ae68a" : "#e05a5a"} />
          ))}
          {def.chain && (
            <Row
              k="Цепочка"
              v={`${def.chain.in.map(([id, n]) => `${ITEMS[id]?.name} ×${n}`).join(" + ")} → ${ITEMS[def.chain.out[0]]?.name} ×${def.chain.out[1] * lvl}`}
              color="#f2c14e"
            />
          )}
          {def.produce && <Row k="Накопилось" v={`${b.store} × ${ITEMS[def.produce.id]?.name}`} color="#f2c14e" />}
        </div>

        {def.produce && b.store > 0 && (
          <button className="btn w-full py-2.5! text-[12.5px]" onClick={() => { engine.doAction({ kind: "collect", tx: b.tx, ty: b.ty, bUid: b.uid }); onClose(); }}>
            <Coins size={15} /> Забрать {b.store} × {ITEMS[def.produce.id]?.name}
          </button>
        )}

        {u.can ? (
          <div className="rounded-xl border border-amber-400/25 bg-amber-400/6 p-2.5">
            <div className="mb-1 flex items-center gap-1.5 text-[12px] font-bold text-amber-200">
              <ArrowUpCircle size={14} /> Улучшение до уровня {lvl + 1}
            </div>
            <div className="flex flex-wrap gap-x-2 text-[11.5px]">
              {u.cost.map(([id, n]) => (
                <span key={id} className={engine.count(id) >= n ? "text-emerald-300" : "text-rose-300"}>
                  {ITEMS[id]?.name ?? id} {engine.count(id)}/{n}
                </span>
              ))}
              <span className={engine.player.gold >= u.gold ? "text-emerald-300" : "text-rose-300"}>золото {engine.player.gold}/{u.gold}</span>
            </div>
            <button className="btn mt-2 w-full py-2! text-[12.5px]" onClick={() => engine.city.upgrade(engine, b)}>
              <Star size={14} /> Улучшить
            </button>
          </div>
        ) : (
          <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center text-[12px] text-white/45">
            Высший уровень достигнут
          </div>
        )}

        {!b.done && (
          <button className="btn w-full py-2.5! text-[12.5px]" onClick={() => engine.doAction({ kind: "hammer", tx: b.tx, ty: b.ty, bUid: b.uid })}>
            <Hammer size={15} /> Ускорить стройку (стучать)
          </button>
        )}

        {engine.city.s.founded && (
          <div className="rounded-xl border border-white/8 bg-black/25 px-2.5 py-1.5 text-[11px] text-white/45">
            <Users size={11} className="mr-1 inline" />
            Работники приходят сами, когда в городе есть свободные жители.
          </div>
        )}
      </div>
    </Sheet>
  );
}
