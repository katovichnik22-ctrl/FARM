import { useEffect, useRef, useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { HEX_W, HEX_H, hexDist } from "../game/battle";
import { UNITS } from "../data/army";
import { SPELL_BY_ID } from "../data/magic";
import { SCHOOLS } from "../types/lore";
import { ItemIcon } from "./ItemIcon";
import { GEN_TRAITS } from "../types/war";
import type { BattleUnit, HexTerrain } from "../types/war";
import {
  Swords, Zap, Flag, ScrollText, X, Sparkles, Shovel, Hammer,
  Coins, Moon, CloudRain, ChevronRight, Trophy, Skull,
} from "lucide-react";
import { snd } from "../lib/sound";

const HEXR = 26;
const HEXW = Math.sqrt(3) * HEXR;
const HEXH = 2 * HEXR * 0.75;

const TCOL: Record<HexTerrain, [string, string]> = {
  grass: ["#5f8248", "#527040"],
  forest: ["#3d5f38", "#33502f"],
  hill: ["#7d7a52", "#6b6845"],
  water: ["#3d6b96", "#35608a"],
  wall: ["#8e8a86", "#736f6a"],
  gate: ["#8a6a44", "#71563a"],
  tower: ["#9a9490", "#7d7873"],
  road: ["#96876d", "#87795f"],
  rubble: ["#6b645c", "#57524b"],
};

function hexCenter(q: number, r: number): [number, number] {
  const x = HEXW * (q + (r & 1) * 0.5) + HEXW / 2 + 6;
  const y = HEXH * r + HEXR + 6;
  return [x, y];
}

export function BattleView({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [showLog, setShowLog] = useState(false);
  const [spellMode, setSpellMode] = useState(false);
  const [spellPick, setSpellPick] = useState<string | null>(null);
  const [spellList, setSpellList] = useState(false);
  const b = engine.battle;
  const s = b.s;

  // ---- отрисовка ----
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    let raf = 0;
    const W = HEXW * (HEX_W + 0.5) + 12;
    const H = HEXH * HEX_H + HEXR * 0.6 + 12;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = W * dpr; cv.height = H * dpr;
    cv.style.width = `${W}px`; cv.style.height = `${H}px`;

    const sel = b.selected();
    const reach = sel && !sel.moved && s.side === 0 && !s.over ? b.reachable(sel) : [];
    const reachSet = new Set(reach.map((c) => `${c.q},${c.r}`));
    const tgts = sel && !sel.acted && s.side === 0 && !s.over ? b.targets(sel) : [];
    const tgtSet = new Set(tgts.map((t) => `${t.q},${t.r}`));
    const sieges = sel && !sel.acted && s.side === 0 && !s.over ? b.siegeTargets(sel) : [];
    const siegeSet = new Set(sieges.map((c) => `${c.q},${c.r}`));

    const draw = (t: number) => {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = s.night ? "#171a26" : "#1e1f1a";
      ctx.fillRect(0, 0, W, H);

      // гексы
      for (const c of s.cells) {
        const [cx, cy] = hexCenter(c.q, c.r);
        const [fill, edge] = TCOL[c.t];
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (Math.PI / 180) * (60 * i - 90);
          const px = cx + HEXR * 0.94 * Math.cos(a);
          const py = cy + HEXR * 0.94 * Math.sin(a);
          i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
        }
        ctx.closePath();
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.strokeStyle = edge;
        ctx.lineWidth = 1.2;
        ctx.stroke();

        // фактура
        if (c.t === "forest") {
          ctx.fillStyle = "#2c4a2a";
          for (let i = 0; i < 3; i++) {
            const tx = cx - 8 + i * 8, ty = cy + 4 - (i % 2) * 5;
            ctx.beginPath(); ctx.moveTo(tx, ty - 9); ctx.lineTo(tx - 5, ty + 2); ctx.lineTo(tx + 5, ty + 2); ctx.closePath(); ctx.fill();
          }
        } else if (c.t === "hill") {
          ctx.fillStyle = "#94906a";
          ctx.beginPath(); ctx.moveTo(cx - 11, cy + 5); ctx.quadraticCurveTo(cx, cy - 10, cx + 11, cy + 5); ctx.closePath(); ctx.fill();
        } else if (c.t === "water") {
          ctx.strokeStyle = "rgba(220,240,255,0.35)";
          ctx.lineWidth = 1.4;
          for (let i = 0; i < 2; i++) {
            const wy = cy - 4 + i * 9 + Math.sin(t / 420 + c.q) * 1.6;
            ctx.beginPath(); ctx.moveTo(cx - 10, wy); ctx.quadraticCurveTo(cx, wy - 3, cx + 10, wy); ctx.stroke();
          }
        } else if (c.t === "wall" || c.t === "tower") {
          ctx.fillStyle = "#6f6b66";
          ctx.fillRect(cx - 13, cy - 9, 26, 18);
          ctx.fillStyle = "#a8a29a";
          for (let i = 0; i < 3; i++) ctx.fillRect(cx - 13 + i * 9, cy - 13, 6, 5);
          if (c.t === "tower") {
            ctx.fillStyle = "#c9c2b2";
            ctx.beginPath(); ctx.moveTo(cx, cy - 20); ctx.lineTo(cx - 8, cy - 11); ctx.lineTo(cx + 8, cy - 11); ctx.closePath(); ctx.fill();
          }
        } else if (c.t === "gate") {
          ctx.fillStyle = "#5d452e";
          ctx.fillRect(cx - 11, cy - 10, 22, 20);
          ctx.strokeStyle = "#c9a227"; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(cx, cy - 10); ctx.lineTo(cx, cy + 10); ctx.stroke();
        } else if (c.t === "rubble") {
          ctx.fillStyle = "#4e4a44";
          for (let i = 0; i < 4; i++) {
            ctx.beginPath();
            ctx.arc(cx - 9 + i * 6, cy + 2 + ((i % 2) * 5 - 2), 3.4, 0, 7);
            ctx.fill();
          }
        }

        // подсветки
        if (reachSet.has(`${c.q},${c.r}`)) {
          ctx.fillStyle = `rgba(120,220,150,${0.16 + Math.sin(t / 320) * 0.05})`;
          ctx.fill();
        }
        if (tgtSet.has(`${c.q},${c.r}`) || siegeSet.has(`${c.q},${c.r}`)) {
          ctx.strokeStyle = "#ff6a5a";
          ctx.lineWidth = 2.4;
          ctx.stroke();
        }
      }

      // юниты
      for (const u of s.units) {
        if (u.n <= 0) continue;
        const [cx0, cy0] = hexCenter(u.q, u.r);
        const shake = u.shake > 0 ? (Math.random() - 0.5) * 6 * u.shake : 0;
        const cx = cx0 + shake, cy = cy0 + shake * 0.5;
        const d = UNITS[u.kind];
        const isSel = u.uid === s.sel;
        // тень
        ctx.fillStyle = "rgba(0,0,0,0.35)";
        ctx.beginPath(); ctx.ellipse(cx, cy + 12, 13, 5, 0, 0, 7); ctx.fill();
        // жетон
        ctx.beginPath(); ctx.arc(cx, cy, 15, 0, 7);
        ctx.fillStyle = u.side === 0 ? "#2f5a8a" : "#8a2f2f";
        ctx.fill();
        ctx.lineWidth = isSel ? 3.4 : 2;
        ctx.strokeStyle = isSel ? "#ffd97a" : u.side === 0 ? "#8fc2f2" : "#f29a8a";
        ctx.stroke();
        // силуэт рода войск
        ctx.fillStyle = "#efe6d5";
        ctx.font = "bold 13px Georgia";
        ctx.textAlign = "center"; ctx.textBaseline = "middle";
        const glyph = u.kind === "infantry" ? "⚔" : u.kind === "archer" ? "➶" : u.kind === "cavalry" ? "⇶"
          : u.kind === "catapult" ? "◎" : u.kind === "mage" ? "✦" : u.kind === "dragon" ? "🜂"
            : u.kind === "siege" ? "⛏" : "⛵";
        ctx.fillText(glyph, cx, cy - 1);
        // численность
        ctx.fillStyle = "rgba(10,8,6,0.85)";
        ctx.fillRect(cx - 12, cy + 13, 24, 11);
        ctx.fillStyle = "#f2e8d5";
        ctx.font = "bold 10px system-ui";
        ctx.fillText(`${u.n}`, cx, cy + 19);
        // мораль
        const mw = 24;
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.fillRect(cx - mw / 2, cy - 23, mw, 3.5);
        ctx.fillStyle = u.morale > 60 ? "#7ae68a" : u.morale > 30 ? "#f2b45c" : "#e05a5a";
        ctx.fillRect(cx - mw / 2, cy - 23, mw * (u.morale / 100), 3.5);
        // генерал
        if (u.general) {
          ctx.fillStyle = "#ffd97a";
          ctx.beginPath(); ctx.arc(cx + 12, cy - 12, 4, 0, 7); ctx.fill();
        }
        // ходил?
        if ((u.moved && u.acted) && u.side === 0) {
          ctx.fillStyle = "rgba(0,0,0,0.42)";
          ctx.beginPath(); ctx.arc(cx, cy, 15, 0, 7); ctx.fill();
        }
        // вспышка
        if (u.flash > 0) {
          ctx.globalAlpha = Math.min(1, u.flash * 3);
          ctx.fillStyle = "#fff";
          ctx.beginPath(); ctx.arc(cx, cy, 17, 0, 7); ctx.fill();
          ctx.globalAlpha = 1;
        }
        void d;
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [b, s, snap.uiTick, snap.battleTurn, snap.battleSide, spellMode]);

  // ---- ввод ----
  const onTap = (ev: React.MouseEvent<HTMLCanvasElement>) => {
    if (s.over || s.side !== 0) return;
    const rect = ev.currentTarget.getBoundingClientRect();
    const px = (ev.clientX - rect.left) * (ev.currentTarget.width / (window.devicePixelRatio || 1) / rect.width);
    const py = (ev.clientY - rect.top) * (ev.currentTarget.height / (window.devicePixelRatio || 1) / rect.height);
    // ближайший гекс
    let best: { q: number; r: number; d: number } | null = null;
    for (const c of s.cells) {
      const [cx, cy] = hexCenter(c.q, c.r);
      const d = Math.hypot(cx - px, cy - py);
      if (!best || d < best.d) best = { q: c.q, r: c.r, d };
    }
    if (!best || best.d > HEXR * 1.2) return;
    const { q, r } = best;

    if (spellMode) {
      engine.battle.castSpell(engine, q, r, spellPick ?? undefined);
      setSpellMode(false); setSpellPick(null);
      return;
    }

    const clicked = b.unitAt(q, r);
    const sel = b.selected();
    if (clicked && clicked.side === 0) { s.sel = clicked.uid; snd.ui(); engine.poke(); return; }
    if (!sel) return;
    if (clicked && clicked.side === 1) {
      if (!sel.acted && hexDist(sel.q, sel.r, clicked.q, clicked.r) <= UNITS[sel.kind].rng + (sel.general && sel.kind === "archer" ? 1 : 0)) {
        b.attack(engine, sel, clicked);
      } else engine.toast("Слишком далеко для удара", "warn");
      return;
    }
    const cell = b.cellAt(q, r);
    if (cell && (cell.t === "wall" || cell.t === "gate") && !sel.acted && UNITS[sel.kind].siege) {
      b.siegeAttack(engine, sel, cell);
      return;
    }
    b.move(engine, sel, q, r);
  };

  const sel = b.selected();
  const n = engine.nations.get(s.nationId);
  const myUnits = s.units.filter((u) => u.side === 0 && u.n > 0);
  const foeUnits = s.units.filter((u) => u.side === 1 && u.n > 0);

  return (
    <div className="absolute inset-0 z-[60] flex flex-col bg-[#12131a]">
      {/* Шапка */}
      <div className="safe-top glass flex items-center gap-2 rounded-none border-x-0 border-t-0 px-3 py-2">
        <Swords size={18} className="shrink-0 text-rose-300" />
        <div className="min-w-0 flex-1">
          <div className="truncate font-display text-[14px] font-bold text-amber-100">
            {s.kind === "siege" ? "Осада" : s.kind === "defense" ? "Оборона" : "Битва"} · {n?.name ?? "враг"}
          </div>
          <div className="flex items-center gap-2 text-[10.5px] text-white/50">
            <span>Ход {s.turn}</span>
            <span className={s.side === 0 ? "font-bold text-emerald-300" : "font-bold text-rose-300"}>
              {s.side === 0 ? "ваш приказ" : "ход врага…"}
            </span>
            {s.night && <span className="flex items-center gap-0.5"><Moon size={9} /> ночь</span>}
            {(s.weather === "rain" || s.weather === "storm") && <span className="flex items-center gap-0.5"><CloudRain size={9} /> дождь</span>}
            <span>нас {myUnits.reduce((a, u) => a + u.n, 0)} · их {foeUnits.reduce((a, u) => a + u.n, 0)}</span>
          </div>
        </div>
        <button className="btn-ghost p-2!" onClick={() => setShowLog(!showLog)}><ScrollText size={16} /></button>
        <button className="btn-ghost p-2!" onClick={onClose}><X size={16} /></button>
      </div>

      {/* Стены при осаде */}
      {(s.wallMax > 0 || s.gateMax > 0) && (
        <div className="flex gap-2 px-3 py-1.5">
          {s.wallMax > 0 && (
            <div className="flex-1">
              <div className="flex justify-between text-[9.5px] uppercase tracking-wide text-white/40">
                <span>Стены</span><span>{Math.round(s.wallHp)}/{s.wallMax}</span>
              </div>
              <div className="bar-track h-1.5!"><div className="bar-fill" style={{ width: `${(s.wallHp / s.wallMax) * 100}%`, background: "#a8a29a" }} /></div>
            </div>
          )}
          {s.gateMax > 0 && (
            <div className="flex-1">
              <div className="flex justify-between text-[9.5px] uppercase tracking-wide text-white/40">
                <span>Ворота</span><span>{Math.round(s.gateHp)}/{s.gateMax}</span>
              </div>
              <div className="bar-track h-1.5!"><div className="bar-fill" style={{ width: `${(s.gateHp / s.gateMax) * 100}%`, background: "#c9a227" }} /></div>
            </div>
          )}
          {s.sapper > 0 && (
            <div className="flex-1">
              <div className="flex justify-between text-[9.5px] uppercase tracking-wide text-white/40">
                <span>Подкоп</span><span>{Math.min(100, Math.round(s.sapper))}%</span>
              </div>
              <div className="bar-track h-1.5!"><div className="bar-fill" style={{ width: `${Math.min(100, s.sapper)}%`, background: "#8a6a44" }} /></div>
            </div>
          )}
        </div>
      )}

      {/* Поле */}
      <div className="scroll-area flex-1 overflow-auto p-2" style={{ touchAction: "pan-x pan-y" }}>
        <canvas ref={ref} onClick={onTap} className="mx-auto rounded-xl" />
      </div>

      {/* Лог */}
      {showLog && (
        <div className="glass mx-2 mb-1 max-h-[26vh] overflow-y-auto rounded-xl p-2 scroll-area">
          {s.log.map((l, i) => (
            <div key={i} className="border-b border-white/5 py-0.5 text-[11.5px] last:border-0">
              <span className="text-white/30">[{l.t}] </span>
              <span className={
                l.kind === "kill" ? "text-rose-300" : l.kind === "siege" ? "text-amber-300"
                  : l.kind === "spell" ? "text-purple-300" : l.kind === "info" ? "text-white/55" : "text-white/75"
              }>{l.text}</span>
            </div>
          ))}
        </div>
      )}

      {/* Панель выбранного отряда */}
      {sel && !s.over && (
        <div className="glass mx-2 mb-1 flex items-center gap-2 rounded-xl px-2.5 py-1.5">
          <div className="min-w-0 flex-1">
            <div className="truncate text-[12.5px] font-bold text-amber-50">
              {UNITS[sel.kind].name} ×{sel.n}
              {sel.general ? <span className="ml-1 text-[10.5px] text-amber-300">
                {engine.army.genOf(sel.general)?.name} ({GEN_TRAITS[engine.army.genOf(sel.general)!.trait].name})
              </span> : null}
            </div>
            <div className="text-[10px] text-white/45">
              мораль {Math.round(sel.morale)} · усталость {Math.round(sel.fatigue)} · ход {UNITS[sel.kind].move} · даль {UNITS[sel.kind].rng}
              {sel.moved && sel.acted ? " · отходил" : sel.moved ? " · уже двигался" : ""}
            </div>
          </div>
          <div className="flex shrink-0 gap-1">
            {myUnits.length > 1 && (
              <button className="btn-ghost px-2! py-1.5!" onClick={() => {
                const i = myUnits.findIndex((u) => u.uid === s.sel);
                s.sel = myUnits[(i + 1) % myUnits.length].uid;
                snd.ui(); engine.poke();
              }}>
                <ChevronRight size={14} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Кнопки действий */}
      {!s.over && (
        <div className="safe-bottom flex flex-wrap gap-1.5 px-2 pb-2">
          <button
            className={`btn-icon min-w-0! flex-1! flex-row! gap-1.5! py-2! text-[11px]! ${spellMode ? "active" : ""}`}
            onClick={() => {
              snd.ui();
              if (spellMode) { setSpellMode(false); setSpellPick(null); return; }
              const mySpells = engine.lore.magic.spells.filter((id) => SPELL_BY_ID[id]?.battle);
              if (engine.lore.magic.school && mySpells.length) setSpellList(true);
              else setSpellMode(true);
            }}
          >
            <Sparkles size={15} /> {spellMode ? (spellPick ? `${SPELL_BY_ID[spellPick].name}: цель` : "Выбери цель") : "Чары"}
          </button>
          {(s.kind === "siege") && (
            <>
              <button className="btn-icon min-w-0! flex-1! flex-row! gap-1.5! py-2! text-[11px]!" onClick={() => b.sap(engine)}>
                <Shovel size={15} /> Подкоп
              </button>
              <button className="btn-icon min-w-0! flex-1! flex-row! gap-1.5! py-2! text-[11px]!" onClick={() => b.starveOut(engine)}>
                <Hammer size={15} /> Измор
              </button>
              <button className="btn-icon min-w-0! flex-1! flex-row! gap-1.5! py-2! text-[11px]!" onClick={() => b.bribeGarrison(engine)}>
                <Coins size={15} /> Подкуп
              </button>
            </>
          )}
          <button className="btn-icon min-w-0! flex-1! flex-row! gap-1.5! py-2! text-[11px]!" onClick={() => b.autoBattle(engine)}>
            <Zap size={15} /> Авто-бой
          </button>
          <button
            className="btn min-w-0! flex-1 py-2.5! text-[12px]!"
            disabled={s.side !== 0}
            onClick={() => { b.endTurn(engine); snd.ui(); }}
          >
            <Flag size={15} /> Конец хода
          </button>
        </div>
      )}

      {/* Выбор заклинания */}
      {spellList && (
        <div className="absolute inset-0 z-20 flex items-end justify-center bg-black/60 p-3" onClick={() => setSpellList(false)}>
          <div className="glass w-full max-w-sm p-3" onClick={(ev) => ev.stopPropagation()}>
            <div className="mb-2 flex items-center justify-between">
              <span className="font-display text-[15px] font-bold text-amber-100">Какие чары творить?</span>
              <span className="text-[12px] font-bold text-purple-300">мана {Math.floor(engine.lore.magic.mana)}</span>
            </div>
            <div className="scroll-area max-h-[44vh] space-y-1">
              {engine.lore.magic.spells.filter((id) => SPELL_BY_ID[id]?.battle).map((id) => {
                const sp = SPELL_BY_ID[id];
                const sd = SCHOOLS.find((x) => x.id === sp.school)!;
                const ready = engine.lore.spellReady(id) && engine.lore.magic.mana >= sp.mana;
                return (
                  <button key={id} disabled={!ready}
                    className={`flex w-full items-center gap-2 rounded-xl border p-2 text-left ${ready ? "border-purple-400/30 bg-black/30" : "border-white/8 bg-black/15 opacity-60"}`}
                    onClick={() => { setSpellPick(id); setSpellMode(true); setSpellList(false); snd.ui(); }}>
                    <ItemIconInline icon={sp.icon} color={sd.color} />
                    <div className="min-w-0 flex-1">
                      <div className="text-[12.5px] font-bold text-amber-50">{sp.name}</div>
                      <div className="truncate text-[10.5px] text-white/45">{sp.desc}</div>
                    </div>
                    <span className="shrink-0 text-[11px] font-bold text-purple-300">{sp.mana}</span>
                  </button>
                );
              })}
              <button className="btn-ghost w-full py-2! text-[12px]!"
                onClick={() => { setSpellPick(null); setSpellMode(true); setSpellList(false); }}>
                Огненный вихрь отряда чародеев
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Итог */}
      {s.over && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/72 p-5">
          <div className="glass w-full max-w-sm p-5 text-center">
            <div className={`mx-auto mb-2 flex h-14 w-14 items-center justify-center rounded-full ${s.over.win ? "bg-amber-400/20" : "bg-rose-500/15"}`}>
              {s.over.win ? <Trophy size={30} className="text-amber-300" /> : <Skull size={30} className="text-rose-300" />}
            </div>
            <h2 className={`font-display text-2xl font-bold ${s.over.win ? "text-amber-100" : "text-rose-100"}`}>
              {s.over.win ? "Победа!" : "Поражение"}
            </h2>
            <p className="mt-2 text-[13px] leading-relaxed text-white/60">{s.over.text}</p>
            <div className="mt-3 max-h-[22vh] overflow-y-auto rounded-xl border border-white/8 bg-black/30 p-2 text-left scroll-area">
              {s.log.slice(0, 12).map((l, i) => (
                <div key={i} className="py-0.5 text-[11px] text-white/55">{l.text}</div>
              ))}
            </div>
            <button className="btn mt-3 w-full py-3!" onClick={() => { b.close(engine); onClose(); }}>
              Вернуться в мир
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ---- Предложение боя при вторжении ----
export function BattlePrompt({ engine, onClose }: { engine: Engine; onClose: () => void }) {
  const p = engine.battle.invitePrompt;
  if (!p) return null;
  const n = engine.nations.get(p.nation);
  if (!n) return null;
  const cost = Math.floor(250 + n.army * 45);
  const myPow = engine.army.power();
  const theirPow = engine.nations.strength(n);
  return (
    <div className="absolute inset-0 z-[60] flex items-center justify-center bg-black/70 p-4">
      <div className="glass w-full max-w-sm p-4">
        <div className="mb-2 flex items-center gap-2">
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-rose-500/15">
            <Swords size={22} className="text-rose-300" />
          </div>
          <div className="min-w-0">
            <h2 className="font-display text-lg font-bold text-rose-100">Вторжение!</h2>
            <p className="truncate text-[11.5px] text-white/50">{n.name} перешли границу</p>
          </div>
        </div>
        <p className="text-[12.5px] leading-snug text-white/65">
          Войско {n.adj} земель встало у ваших полей. Их сила — {engine.nations.visibleStrength(n)}, ваша — {myPow}.
          Решайте: принять бой, откупиться или уклониться и потерять добро.
        </p>
        <div className="mt-2 rounded-xl border border-white/8 bg-black/25 p-2 text-[11.5px]">
          <div className="flex justify-between"><span className="text-white/45">Ваша сила</span><span className="font-bold text-amber-200">{myPow}</span></div>
          <div className="flex justify-between"><span className="text-white/45">Их сила (оценка)</span><span className="font-bold text-rose-300">{theirPow}</span></div>
        </div>
        <div className="mt-3 space-y-1.5">
          <button className="btn w-full py-2.5! text-[12.5px]!" onClick={() => { engine.battle.begin(engine, n.id, engine.city.s.founded ? "defense" : "field"); }}>
            <Swords size={15} /> Принять бой
          </button>
          <button className="btn-ghost w-full py-2! text-[12px]!" onClick={() => { engine.battle.autoBattle(engine, n.id, engine.city.s.founded ? "defense" : "field"); }}>
            <Zap size={14} /> Авто-бой
          </button>
          <button className="btn-ghost w-full py-2! text-[12px]!" disabled={engine.player.gold < cost} onClick={() => { engine.battle.buyOff(engine); onClose(); }}>
            <Coins size={14} /> Откупиться ({cost} зол.)
          </button>
          <button className="btn-ghost w-full py-2! text-[12px]! text-rose-200!" onClick={() => { engine.battle.declineBattle(engine); onClose(); }}>
            Уклониться (разорят округу)
          </button>
        </div>
      </div>
    </div>
  );
}

function ItemIconInline({ icon, color }: { icon: string; color: string }) {
  return (
    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border" style={{ borderColor: `${color}55`, background: "rgba(0,0,0,0.3)" }}>
      <ItemIcon icon={icon} size={17} style={{ color }} />
    </div>
  );
}

export type { BattleUnit };
