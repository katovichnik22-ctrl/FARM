import { useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { Sheet, Tabs, Row } from "./ui";
import { ItemIcon } from "./ItemIcon";
import { DIPLO_ACTS, SPY_ACTS, NATION_CHARS } from "../types/war";
import type { Nation } from "../types/war";
import {
  Swords, Globe2, ScrollText, Crown, Handshake, Skull, ShieldAlert,
  Check, X as XIcon, Flame, Gavel, Eye, ChevronLeft,
} from "lucide-react";

const TABS = ["Страны", "Послы", "Лига", "Хроника"];

function Flag({ n, size = 28 }: { n: Nation; size?: number }) {
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded border border-white/20 font-bold"
      style={{ width: size, height: size * 0.72, background: n.flag.bg, color: n.flag.fg, fontSize: size * 0.5 }}
    >
      {n.flag.sym}
    </div>
  );
}

const STATE_META: Record<string, { label: string; color: string }> = {
  peace: { label: "мир", color: "#a8b2bd" },
  war: { label: "ВОЙНА", color: "#e05a5a" },
  ally: { label: "союзник", color: "#7ae68a" },
  vassal: { label: "ваш вассал", color: "#f2c14e" },
  overlord: { label: "ваш сюзерен", color: "#c98ae0" },
  truce: { label: "перемирие", color: "#8fa2b8" },
};

export function DiplomacyPanel({ engine, snap, onClose }: { engine: Engine; snap: UiSnapshot; onClose: () => void }) {
  const [tab, setTab] = useState("Страны");
  const [sel, setSel] = useState<string | null>(engine.activeNation);
  const ns = engine.nations;
  const nation = sel ? ns.get(sel) : null;
  if (!engine.stats.diplo) { engine.stats.diplo = 1; }

  // ---------- Карточка страны ----------
  if (nation) {
    const st = STATE_META[nation.state] ?? STATE_META.peace;
    const relColor = nation.rel > 40 ? "#7ae68a" : nation.rel > 0 ? "#a8e68a" : nation.rel > -40 ? "#f2b45c" : "#e05a5a";
    const hasCB = ns.hasCB(nation.id, engine.day);
    const canBattle = engine.battle.canAttack(engine, nation);
    return (
      <Sheet
        title={nation.name}
        sub={`${nation.gov} · ${nation.ruler} · ${NATION_CHARS[nation.char].name}`}
        onClose={onClose}
      >
        <button className="btn-ghost mb-2 w-fit! px-2.5! py-1.5! text-[11.5px]!" onClick={() => { setSel(null); engine.activeNation = null; }}>
          <ChevronLeft size={13} /> Ко всем странам
        </button>
        <div className="scroll-area space-y-2" style={{ maxHeight: "58vh" }}>
          <div className="flex items-start gap-3 rounded-xl border border-white/8 bg-black/25 p-2.5">
            <Flag n={nation} size={44} />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-baseline gap-x-2">
                <span className="font-display text-[15px] font-bold text-amber-50">{nation.capital}</span>
                <span className="text-[11px] font-bold uppercase" style={{ color: st.color }}>{st.label}</span>
              </div>
              <div className="text-[11px] leading-snug text-white/50">
                {nation.religion} · {nation.culture} · {NATION_CHARS[nation.char].desc}
              </div>
              <div className="mt-0.5 text-[11px] text-white/40">Ныне: {nation.lastAction}</div>
            </div>
          </div>

          <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
            <Row k="Отношение" v={`${Math.round(nation.rel)} (${ns.relLabel(nation.rel)})`} color={relColor} />
            <Row k="Сила войска" v={ns.visibleStrength(nation)} color="#e08a5a" />
            <Row k="Городов" v={nation.spyKnown >= 1 ? nation.cities : "?"} />
            <Row k="Население" v={nation.spyKnown >= 2 ? nation.pop : "?"} />
            <Row k="Казна" v={nation.spyKnown >= 2 ? `${nation.gold} зол.` : "?"} />
            <Row k="Технологии / магия" v={nation.spyKnown >= 1 ? `${nation.tech} / ${nation.magic}` : "?"} />
            {nation.tribute > 0 && <Row k="Платят дань" v={`${nation.tribute} зол./день`} color="#7ae68a" />}
            {nation.state === "war" && <Row k="Счёт войны" v={`${Math.round(nation.warScore)}`} color={nation.warScore > 0 ? "#7ae68a" : "#e05a5a"} />}
            {hasCB && <Row k="Casus belli" v="есть повод к войне" color="#f2c14e" />}
            {nation.wars.length > 0 && <Row k="Воюют с" v={nation.wars.map((w) => ns.get(w)?.name ?? "?").slice(0, 2).join(", ")} />}
            {nation.allies.length > 0 && <Row k="В союзе с" v={nation.allies.map((w) => ns.get(w)?.name ?? "?").slice(0, 2).join(", ")} />}
          </div>

          {nation.state === "war" && (
            <div className="rounded-xl border border-rose-400/35 bg-rose-500/10 p-2.5">
              <div className="mb-1.5 flex items-center gap-1.5 text-[12.5px] font-bold text-rose-200">
                <Swords size={14} /> Война с {nation.name}
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button className="btn flex-1 py-2! text-[11.5px]!" disabled={!canBattle.ok}
                  onClick={() => { engine.battle.begin(engine, nation.id, "field"); onClose(); }}>
                  Полевая битва
                </button>
                <button className="btn flex-1 py-2! text-[11.5px]!" disabled={!canBattle.ok}
                  onClick={() => { engine.battle.begin(engine, nation.id, "siege"); onClose(); }}>
                  Осада города
                </button>
                <button className="btn-ghost flex-1 py-2! text-[11.5px]!" disabled={!canBattle.ok}
                  onClick={() => { engine.battle.autoBattle(engine, nation.id, "field"); onClose(); }}>
                  Авто-бой
                </button>
              </div>
              {!canBattle.ok && <div className="mt-1 text-[10.5px] text-amber-300/70">{canBattle.reason}</div>}
            </div>
          )}

          <div className="text-[11px] font-bold uppercase tracking-wide text-white/40">Дипломатия</div>
          <div className="space-y-1">
            {DIPLO_ACTS.filter((act) => (act.needWar ? nation.state === "war" : true) && (act.needPeace ? nation.state !== "war" : true)).map((act) => {
              const affordable = engine.player.gold >= act.gold;
              const relOk = nation.rel >= act.minRel;
              const dim = !affordable || !relOk;
              return (
                <button key={act.id} disabled={!affordable}
                  className={`flex w-full items-start gap-2 rounded-xl border p-2 text-left transition active:scale-[0.98] ${dim ? "border-white/8 bg-black/15 opacity-70" : "border-amber-400/25 bg-black/30"}`}
                  onClick={() => ns.act(engine, nation.id, act.id)}>
                  <ItemIcon icon={act.icon} size={16} className="mt-0.5 shrink-0 text-amber-200" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-[12.5px] font-bold text-amber-50">{act.name}</span>
                      {act.gold > 0 && <span className={`text-[10.5px] font-bold ${affordable ? "text-amber-300" : "text-rose-300"}`}>{act.gold} зол.</span>}
                      {!relOk && act.minRel > -100 && <span className="text-[10px] text-rose-300/80">нужно +{act.minRel}</span>}
                    </div>
                    <div className="text-[10.5px] leading-snug text-white/45">{act.desc}</div>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="text-[11px] font-bold uppercase tracking-wide text-white/40">Тайные дела</div>
          <div className="space-y-1">
            {SPY_ACTS.map((act) => (
              <button key={act.id} disabled={engine.player.gold < act.gold}
                className={`flex w-full items-start gap-2 rounded-xl border p-2 text-left transition active:scale-[0.98] ${engine.player.gold >= act.gold ? "border-indigo-400/25 bg-black/30" : "border-white/8 bg-black/15 opacity-70"}`}
                onClick={() => ns.spy(engine, nation.id, act.id)}>
                <ItemIcon icon={act.icon} size={16} className="mt-0.5 shrink-0 text-indigo-300" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-[12.5px] font-bold text-amber-50">{act.name}</span>
                    <span className="text-[10.5px] font-bold text-amber-300">{act.gold} зол.</span>
                  </div>
                  <div className="text-[10.5px] leading-snug text-white/45">{act.desc}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </Sheet>
    );
  }

  // ---------- Список ----------
  const sorted = [...ns.nations].sort((a, b) => {
    const order = (n: Nation) => n.state === "war" ? 0 : n.state === "ally" ? 1 : n.state === "vassal" ? 2 : 3;
    return order(a) - order(b) || b.rel - a.rel;
  });

  return (
    <Sheet
      title="Посольский приказ"
      sub={`Держав ${ns.nations.length} · войн ${snap.warCount} · союзов ${snap.allyCount} · вассалов ${snap.vassalCount} · слава ${snap.fame}`}
      onClose={onClose}
    >
      <Tabs tabs={TABS} active={tab} onPick={setTab} />
      <div className="scroll-area flex-1 pr-0.5" style={{ maxHeight: "62vh" }}>

        {tab === "Страны" && (
          <div className="space-y-1.5">
            {sorted.map((n) => {
              const st = STATE_META[n.state] ?? STATE_META.peace;
              return (
                <button key={n.id} className="flex w-full items-center gap-2 rounded-xl border border-white/8 bg-black/25 p-2 text-left transition active:scale-[0.98]"
                  onClick={() => { setSel(n.id); engine.activeNation = n.id; }}>
                  <Flag n={n} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="truncate text-[13px] font-bold text-amber-50">{n.name}</span>
                      {n.incoming && <span className="pulse-soft text-[9.5px] font-bold text-rose-300">ИДУТ НА ВАС</span>}
                    </div>
                    <div className="text-[10.5px] text-white/45">{n.capital} · {ns.visibleStrength(n)} · {n.lastAction}</div>
                    <div className="bar-track mt-1 h-1!">
                      <div className="bar-fill" style={{
                        width: `${(n.rel + 100) / 2}%`,
                        background: n.rel > 20 ? "#7ae68a" : n.rel > -20 ? "#f2b45c" : "#e05a5a",
                      }} />
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="text-[11px] font-bold" style={{ color: st.color }}>{st.label}</div>
                    <div className="text-[10px] text-white/40">{Math.round(n.rel)}</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {tab === "Послы" && (
          <div className="space-y-1.5">
            {ns.envoys.length === 0 && <div className="py-8 text-center text-[12.5px] text-white/40">Послов нет. В мире тихо… пока.</div>}
            {ns.envoys.map((en) => {
              const n = ns.get(en.nation);
              if (!n) return null;
              const bad = en.kind === "demand";
              return (
                <div key={en.id} className={`rounded-xl border p-2.5 ${bad ? "border-rose-400/35 bg-rose-500/8" : "border-emerald-400/25 bg-emerald-400/6"}`}>
                  <div className="flex items-start gap-2">
                    <Flag n={n} size={34} />
                    <div className="min-w-0 flex-1">
                      <div className="text-[12.5px] font-bold text-amber-50">{n.name}</div>
                      <p className="font-display text-[12px] leading-snug text-white/70">«{en.text}»</p>
                    </div>
                  </div>
                  <div className="mt-1.5 flex gap-1.5">
                    <button className="btn flex-1 py-2! text-[11.5px]!" onClick={() => ns.answerEnvoy(engine, en.id, true)}>
                      <Check size={13} /> Принять
                    </button>
                    <button className="btn-ghost flex-1 py-2! text-[11.5px]!" onClick={() => ns.answerEnvoy(engine, en.id, false)}>
                      <XIcon size={13} /> Отказать
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "Лига" && (
          <div className="space-y-2">
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[13px] font-bold text-amber-100">
                <Globe2 size={15} /> Лига Наций
              </div>
              <p className="text-[11.5px] leading-snug text-white/50">
                Совет держав, где спорят о войне и мире. Члены Лиги благоволят друг другу, а голос влиятельных решает судьбы.
              </p>
              <Row k="Вы в Лиге" v={ns.league.member ? "да" : "нет"} color={ns.league.member ? "#7ae68a" : "#e05a5a"} />
              <Row k="Влияние" v={`${Math.round(ns.league.influence)}/100`} color="#f2c14e" />
              <Row k="Держав в Лиге" v={ns.nations.filter((n) => n.league).length} />
              {!ns.league.member ? (
                <button className="btn mt-2 w-full py-2.5! text-[12.5px]!" onClick={() => ns.joinLeague(engine)}>
                  <Gavel size={14} /> Вступить (900 зол.)
                </button>
              ) : (
                <button className="btn-ghost mt-2 w-full py-2! text-[12px]!" onClick={() => ns.leaveLeague(engine)}>
                  Покинуть Лигу
                </button>
              )}
            </div>
            {ns.league.member && (
              <>
                <div className="text-[11px] font-bold uppercase tracking-wide text-white/40">Внести резолюцию (10 влияния + 200 зол.)</div>
                {ns.nations.filter((n) => n.league).map((n) => (
                  <div key={n.id} className="flex items-center gap-2 rounded-xl border border-white/8 bg-black/25 p-2">
                    <Flag n={n} size={26} />
                    <span className="flex-1 truncate text-[12.5px] text-amber-50">{n.name}</span>
                    <button className="btn px-2.5! py-1.5! text-[11px]!" onClick={() => ns.leaguePush(engine, n.id)}>
                      {n.state === "war" ? "Осудить" : "Санкции"}
                    </button>
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        {tab === "Хроника" && (
          <div className="space-y-2">
            <div className="grid grid-cols-3 gap-1.5">
              <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
                <Swords size={14} className="mx-auto text-rose-300" />
                <div className="font-display text-[16px] font-bold text-amber-100">{snap.warCount}</div>
                <div className="text-[9.5px] text-white/40">войн</div>
              </div>
              <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
                <Handshake size={14} className="mx-auto text-emerald-300" />
                <div className="font-display text-[16px] font-bold text-amber-100">{snap.allyCount}</div>
                <div className="text-[9.5px] text-white/40">союзов</div>
              </div>
              <div className="rounded-xl border border-white/8 bg-black/25 p-2 text-center">
                <Crown size={14} className="mx-auto text-amber-300" />
                <div className="font-display text-[16px] font-bold text-amber-100">{snap.vassalCount}</div>
                <div className="text-[9.5px] text-white/40">вассалов</div>
              </div>
            </div>
            {ns.guerrilla && (
              <div className="rounded-xl border border-amber-400/35 bg-amber-400/10 p-2.5 text-[12px] font-semibold text-amber-200">
                <Flame size={13} className="mr-1 inline" />
                Идёт партизанская война: народ уходит в леса и точит врага исподволь.
              </div>
            )}
            {ns.overlord() && (
              <div className="rounded-xl border border-purple-400/35 bg-purple-400/10 p-2.5 text-[12px] font-semibold text-purple-200">
                <ShieldAlert size={13} className="mr-1 inline" />
                Вы под рукой {ns.overlord()!.name}. Дань уходит каждую минуту.
              </div>
            )}
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                <ScrollText size={12} /> Летопись войн и союзов
              </div>
              {ns.warLog.length === 0 && <div className="py-2 text-center text-[11.5px] text-white/35">Пока тихо</div>}
              {ns.warLog.slice(0, 14).map((l, i) => (
                <div key={i} className="border-b border-white/5 py-1 text-[11.5px] last:border-0">
                  <span className="text-white/35">День {l.day}: </span>
                  <span className={l.kind === "bad" ? "text-rose-300" : l.kind === "good" ? "text-emerald-300" : "text-white/70"}>{l.text}</span>
                </div>
              ))}
            </div>
            <div className="rounded-xl border border-white/8 bg-black/25 p-2.5">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-white/45">
                <Eye size={12} /> Разведка
              </div>
              <p className="text-[11px] leading-snug text-white/45">
                Пока лазутчики не посланы, сила чужих войск видна лишь на глаз: «малая», «средняя», «грозная».
              </p>
            </div>
            <div className="flex items-center justify-center gap-1.5 rounded-xl border border-white/8 bg-black/25 p-2 text-[11.5px] text-white/45">
              <Skull size={12} /> Слава полководца: <span className="font-bold text-amber-200">{snap.fame}</span>
            </div>
          </div>
        )}
      </div>
    </Sheet>
  );
}
