import { useRef, useState } from "react";
import type { Engine, UiSnapshot } from "../game/engine";
import { exportSave, importSave, loadSlotAsync, getMuted, setMutedFlag } from "../lib/save";
import { X, Save, FolderDown, FolderUp, Volume2, VolumeX, RotateCcw, Home, GraduationCap } from "lucide-react";
import { snd } from "../lib/sound";

interface Props {
  engine: Engine;
  snap: UiSnapshot;
  onClose: () => void;
  onExit: () => void;
}

export function GameMenu({ engine, snap, onClose, onExit }: Props) {
  const [muted, setMuted] = useState(getMuted());
  const [busy, setBusy] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const slotBtn = (n: number) => (
    <div key={n} className="flex gap-1">
      <button
        className="btn-ghost flex-1 py-2! text-[12px]"
        onClick={() => { engine.slot = n; engine.save(); setBusy(`Сохранено в слот ${n}`); setTimeout(() => setBusy(""), 1800); }}
      >
        <Save size={13} /> В слот {n}
      </button>
      <button
        className="btn-ghost flex-1 py-2! text-[12px]"
        onClick={async () => {
          const d = await loadSlotAsync(n);
          if (!d) { engine.toast(`Слот ${n} пуст`, "warn"); return; }
          if (confirm(`Загрузить слот ${n}? Текущий прогресс без сохранения пропадёт.`)) {
            engine.applySave(d);
            engine.toast("Мир загружен", "good");
            onClose();
          }
        }}
      >
        <FolderUp size={13} /> Из слота {n}
      </button>
    </div>
  );

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[3px]" />
      <div className="glass scroll-area relative max-h-[84vh] w-full max-w-sm p-4" onClick={(e) => e.stopPropagation()}>
        <div className="mb-1 flex items-center justify-between">
          <h2 className="font-display text-xl font-bold text-amber-100">Привал</h2>
          <button className="btn-ghost p-2!" onClick={onClose}><X size={17} /></button>
        </div>
        <p className="mb-3 text-[12px] text-white/45">
          {new Date().toLocaleDateString("ru-RU")} · день {snap.day} · ур. {snap.level} · {snap.zoneName}
        </p>

        <div className="space-y-1.5">
          <div className="text-[11px] font-bold uppercase tracking-wider text-white/40">Сохранить / загрузить</div>
          {[1, 2, 3].map(slotBtn)}
        </div>

        <div className="mt-3 space-y-1.5">
          <div className="text-[11px] font-bold uppercase tracking-wider text-white/40">Файл</div>
          <div className="flex gap-1.5">
            <button className="btn-ghost flex-1 py-2! text-[12px]" onClick={() => { exportSave(engine.serialize()); engine.toast("Сохранение выгружено в JSON", "good"); }}>
              <FolderDown size={13} /> Экспорт
            </button>
            <button className="btn-ghost flex-1 py-2! text-[12px]" onClick={() => fileRef.current?.click()}>
              <FolderUp size={13} /> Импорт
            </button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept=".json"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                const d = await importSave(f);
                engine.applySave(d);
                engine.toast("Мир загружен из файла", "good");
                onClose();
              } catch { engine.toast("Файл не читается", "bad"); }
              e.target.value = "";
            }}
          />
        </div>

        <div className="mt-3 space-y-1.5">
          <div className="text-[11px] font-bold uppercase tracking-wider text-white/40">Прочее</div>
          <button
            className="btn-ghost w-full justify-start! py-2! text-[12px]"
            onClick={() => { const m = !muted; setMuted(m); setMutedFlag(m); snd.setMuted(m); }}
          >
            {muted ? <VolumeX size={14} /> : <Volume2 size={14} />} Звук: {muted ? "выкл" : "вкл"}
          </button>
          <button
            className="btn-ghost w-full justify-start! py-2! text-[12px]"
            onClick={() => { engine.tutorialStep = 0; engine.toast("Наставник вернулся", "info"); onClose(); }}
          >
            <GraduationCap size={14} /> Пройти обучение заново
          </button>
          <button
            className="btn-ghost w-full justify-start! py-2! text-[12px] text-rose-200!"
            onClick={() => {
              if (!engine.player.dead && confirm("Сохранить и выйти в главное меню?")) engine.save(true);
              else if (engine.player.dead) { /* просто выход */ }
              else return;
              onExit();
            }}
          >
            <Home size={14} /> В главное меню
          </button>
          <button
            className="btn-ghost w-full justify-start! py-2! text-[12px]"
            onClick={() => { if (confirm("Начать мир заново в этом слоте?")) { engine.newGame((Math.random() * 1e9) | 0, engine.slot, engine.worldName); onClose(); } }}
          >
            <RotateCcw size={14} /> Пересоздать мир
          </button>
        </div>
        {busy && <div className="mt-2 text-center text-[12px] font-semibold text-emerald-300">{busy}</div>}
      </div>
    </div>
  );
}
