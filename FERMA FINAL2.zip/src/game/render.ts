import { G, O, TILE } from "../types";
import type { Engine } from "./engine";
import type { Mob } from "../types";
import { MOBS } from "../data/mobs";
import { BUILDINGS } from "../data/buildings";
import { groundSprite, objSprite, objSpriteTreeParts, getShadowSprite } from "./sprites";
import { hash2, clamp, clamp01 } from "../lib/noise";
import { genericBuilding, drawRoad, drawBuildingLife, drawNpc, drawCaravan, drawParade, BS } from "./render_city";
import { SCHOOLS } from "../types/lore";
import { LAYER_BY_ID, LAYER_MOBS } from "../data/layers";
import { MONSTER_MOBS } from "../data/monsters";
import { BOSS_MOBS } from "../data/bosses";
import { drawMobBody, drawBossBody, bossAura, BOSS_IDS, type MobDrawCtx } from "./sprites_mobs";

const SCHOOL_COLOR: Record<string, string> = Object.fromEntries(SCHOOLS.map((s) => [s.id, s.color]));

/** Объекты, что светятся собственным цветом */
const GLOW_OBJ: Record<number, string> = {
  [O.GlowShroom]: "rgba(111,214,232,0.5)",
  [O.Chest]: "rgba(242,193,78,0.34)",
  [O.RuinChest]: "rgba(255,214,110,0.42)",
  [O.Gold]: "rgba(242,193,78,0.3)",
  [O.Mithril]: "rgba(127,212,232,0.38)",
  [O.Adamant]: "rgba(138,106,216,0.4)",
  [O.Crystal]: "rgba(143,216,240,0.36)",
  [O.SkyCrystal]: "rgba(201,168,242,0.36)",
  [O.LavaVent]: "rgba(255,140,50,0.45)",
  [O.MoonOre]: "rgba(223,226,234,0.34)",
  [O.MarsOre]: "rgba(224,112,60,0.34)",
  [O.AlienRelic]: "rgba(95,232,192,0.38)",
  [O.ChaosOrb]: "rgba(224,90,201,0.42)",
  [O.DreamFlower]: "rgba(230,150,230,0.3)",
  [O.ShadowTree]: "rgba(140,100,220,0.26)",
  [O.Pearl]: "rgba(240,230,242,0.3)",
};

// ===== Рендер мира =====

const bCache = new Map<string, HTMLCanvasElement>();
const B_LIMIT = 160;
function cv(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  return [c, c.getContext("2d")!];
}

// свечение для сундуков/руд
const glowCache = new Map<string, HTMLCanvasElement>();
function glowSprite(color: string): HTMLCanvasElement {
  const hit = glowCache.get(color);
  if (hit) return hit;
  const [c, ctx] = cv(80, 80);
  const g = ctx.createRadialGradient(40, 40, 4, 40, 40, 40);
  g.addColorStop(0, color);
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 80, 80);
  glowCache.set(color, c);
  return c;
}

// ---- Спрайты зданий ----
function buildingSprite(defId: string, done: boolean, store: number, lvl = 1): HTMLCanvasElement {
  const key = `b_${defId}_${done}_${store > 0 ? 1 : 0}_${lvl}`;
  const hit = bCache.get(key);
  if (hit) return hit;
  const def = BUILDINGS[defId];
  const W = def.w * TILE, H = def.h * TILE + (defId === "vyshka" ? 40 : def.wonder ? 74 : def.h >= 3 ? 52 : 30);
  const [c, ctx] = cv(W * BS, H * BS);
  ctx.scale(BS, BS);
  ctx.lineJoin = "round";
  const cx = W / 2, base = H - 14;

  const alpha = done ? 1 : 0.55;
  ctx.globalAlpha = alpha;

  switch (defId) {
    case "koster": {
      // круг камней с объёмом
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        const sx = cx + Math.cos(a) * TILE * 0.32;
        const sy = base - 7 + Math.sin(a) * TILE * 0.18;
        const g = ctx.createLinearGradient(sx - 5, sy - 5, sx + 5, sy + 5);
        g.addColorStop(0, "#a49c92");
        g.addColorStop(0.5, "#7d766c");
        g.addColorStop(1, "#4e4942");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(sx, sy, 5.2, 4, a, 0, 7);
        ctx.fill();
        ctx.strokeStyle = "rgba(26,22,18,0.8)";
        ctx.lineWidth = 0.9;
        ctx.stroke();
        ctx.fillStyle = "rgba(255,250,235,0.22)";
        ctx.beginPath();
        ctx.ellipse(sx - 1.4, sy - 1.6, 2.2, 1.3, a, 0, 7);
        ctx.fill();
      }
      // зола
      ctx.fillStyle = "rgba(60,52,46,0.6)";
      ctx.beginPath(); ctx.ellipse(cx, base - 6, TILE * 0.26, TILE * 0.13, 0, 0, 7); ctx.fill();
      // брёвна крест-накрест
      for (const [x1, y1, x2, y2] of [[-13, -3, 13, -13], [13, -3, -13, -13]] as [number, number, number, number][]) {
        const g = ctx.createLinearGradient(cx + x1, base + y1, cx + x2, base + y2);
        g.addColorStop(0, "#8a6440");
        g.addColorStop(0.5, "#6b4a2e");
        g.addColorStop(1, "#43301c");
        ctx.strokeStyle = g;
        ctx.lineWidth = 5.4;
        ctx.lineCap = "round";
        ctx.beginPath(); ctx.moveTo(cx + x1, base + y1); ctx.lineTo(cx + x2, base + y2); ctx.stroke();
        ctx.strokeStyle = "rgba(30,20,10,0.45)";
        ctx.lineWidth = 0.9;
        ctx.beginPath(); ctx.moveTo(cx + x1, base + y1 + 1.4); ctx.lineTo(cx + x2, base + y2 + 1.4); ctx.stroke();
      }
      // тлеющие угли
      for (let i = 0; i < 4; i++) {
        ctx.fillStyle = i % 2 ? "rgba(255,150,60,0.75)" : "rgba(255,90,40,0.6)";
        ctx.beginPath();
        ctx.arc(cx - 7 + i * 4.6, base - 7 + (i % 2) * 2, 1.8, 0, 7);
        ctx.fill();
      }
      break;
    }
    case "shalash": {
      // фундамент-камни
      ctx.fillStyle = "#6e675e";
      ctx.beginPath(); ctx.roundRect(cx - W * 0.46, base - 4, W * 0.92, 5, 2); ctx.fill();
      // соломенный конус
      ctx.beginPath();
      ctx.moveTo(cx, base - TILE * 1.42);
      ctx.lineTo(cx - W * 0.46, base - 2);
      ctx.quadraticCurveTo(cx, base + 3, cx + W * 0.46, base - 2);
      ctx.closePath();
      const rg = ctx.createLinearGradient(cx - W * 0.4, base - TILE, cx + W * 0.4, base);
      rg.addColorStop(0, "#9a7c46");
      rg.addColorStop(0.42, "#755c30");
      rg.addColorStop(1, "#46371c");
      ctx.fillStyle = rg;
      ctx.fill();
      ctx.strokeStyle = "rgba(24,16,8,0.8)"; ctx.lineWidth = 1; ctx.stroke();
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, base - TILE * 1.42);
      ctx.lineTo(cx - W * 0.46, base - 2);
      ctx.quadraticCurveTo(cx, base + 3, cx + W * 0.46, base - 2);
      ctx.closePath();
      ctx.clip();
      // пряди соломы
      for (let i = 0; i < 20; i++) {
        const t2 = i / 19;
        const sx = cx - W * 0.46 + t2 * W * 0.92;
        ctx.strokeStyle = i % 3 === 0 ? "rgba(255,238,190,0.22)" : "rgba(36,24,10,0.3)";
        ctx.lineWidth = i % 3 === 0 ? 1 : 0.8;
        ctx.beginPath();
        ctx.moveTo(sx, base);
        ctx.quadraticCurveTo(cx + (sx - cx) * 0.55, base - TILE * 0.7, cx + (sx - cx) * 0.06, base - TILE * 1.36);
        ctx.stroke();
      }
      // перевязи
      ctx.strokeStyle = "rgba(70,48,24,0.55)"; ctx.lineWidth = 1.6;
      for (let i = 1; i <= 2; i++) {
        const yy = base - TILE * 0.36 * i;
        const ww = W * 0.44 * (1 - i * 0.26);
        ctx.beginPath(); ctx.moveTo(cx - ww, yy); ctx.quadraticCurveTo(cx, yy + 2.4, cx + ww, yy); ctx.stroke();
      }
      ctx.fillStyle = "rgba(16,10,6,0.26)";
      ctx.beginPath();
      ctx.moveTo(cx, base - TILE * 1.42); ctx.lineTo(cx + W * 0.46, base - 2); ctx.lineTo(cx, base + 1);
      ctx.closePath(); ctx.fill();
      ctx.restore();
      // тёмный вход
      const eg = ctx.createRadialGradient(cx, base - TILE * 0.2, 1, cx, base - TILE * 0.2, TILE * 0.38);
      eg.addColorStop(0, "#0d0906");
      eg.addColorStop(1, "#2a1e12");
      ctx.fillStyle = eg;
      ctx.beginPath();
      ctx.moveTo(cx, base - TILE * 0.72);
      ctx.quadraticCurveTo(cx - W * 0.18, base - TILE * 0.3, cx - W * 0.15, base - 2);
      ctx.lineTo(cx + W * 0.15, base - 2);
      ctx.quadraticCurveTo(cx + W * 0.18, base - TILE * 0.3, cx, base - TILE * 0.72);
      ctx.closePath();
      ctx.fill();
      // жерди по краям входа
      ctx.strokeStyle = "#5d452e"; ctx.lineWidth = 2.6; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(cx - W * 0.15, base - 2); ctx.lineTo(cx - W * 0.03, base - TILE * 1.44); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx + W * 0.15, base - 2); ctx.lineTo(cx + W * 0.03, base - TILE * 1.44); ctx.stroke();
      break;
    }
    case "dom": {
      const bw = W * 0.84;
      // фундамент
      ctx.fillStyle = "#6e675e";
      ctx.beginPath(); ctx.roundRect(cx - bw / 2 - 3, base - 7, bw + 6, 9, 2); ctx.fill();
      ctx.strokeStyle = "rgba(24,20,17,0.8)"; ctx.lineWidth = 1; ctx.stroke();
      for (let i = 0; i < 5; i++) {
        ctx.fillStyle = i % 2 ? "#867e73" : "#5d564e";
        ctx.beginPath(); ctx.roundRect(cx - bw / 2 - 2 + (i / 5) * (bw + 4), base - 6, (bw + 4) / 5 - 1.6, 7, 1.4); ctx.fill();
      }
      // сруб
      const wallTop = base - 6 - TILE * 1.34;
      const wg = ctx.createLinearGradient(cx - bw / 2, 0, cx + bw / 2, 0);
      wg.addColorStop(0, "#a8845c");
      wg.addColorStop(0.4, "#8a6a44");
      wg.addColorStop(1, "#5a4128");
      ctx.fillStyle = wg;
      ctx.fillRect(cx - bw / 2, wallTop, bw, TILE * 1.34);
      ctx.strokeStyle = "rgba(28,18,10,0.75)"; ctx.lineWidth = 1;
      ctx.strokeRect(cx - bw / 2 + 0.5, wallTop + 0.5, bw - 1, TILE * 1.34 - 1);
      ctx.save();
      ctx.beginPath(); ctx.rect(cx - bw / 2, wallTop, bw, TILE * 1.34); ctx.clip();
      const logs = 7;
      for (let i = 0; i < logs; i++) {
        const ly = wallTop + (i / logs) * TILE * 1.34;
        const lh = (TILE * 1.34) / logs;
        ctx.fillStyle = i % 2 ? "rgba(255,244,220,0.08)" : "rgba(20,12,6,0.13)";
        ctx.fillRect(cx - bw / 2, ly, bw, lh);
        ctx.strokeStyle = "rgba(26,16,8,0.35)"; ctx.lineWidth = 0.8;
        ctx.beginPath(); ctx.moveTo(cx - bw / 2, ly + lh); ctx.lineTo(cx + bw / 2, ly + lh); ctx.stroke();
      }
      // торцы брёвен
      for (const dx of [-1, 1]) {
        for (let i = 0; i < logs; i++) {
          const ly = wallTop + (i / logs) * TILE * 1.34 + (TILE * 1.34) / logs / 2;
          ctx.fillStyle = i % 2 ? "#9a7550" : "#7d5e3c";
          ctx.beginPath(); ctx.ellipse(cx + dx * (bw / 2 - 1), ly, 2.4, (TILE * 1.34) / logs / 2, 0, 0, 7); ctx.fill();
        }
      }
      const shg = ctx.createLinearGradient(0, wallTop + TILE * 0.7, 0, base);
      shg.addColorStop(0, "rgba(16,10,6,0)");
      shg.addColorStop(1, "rgba(16,10,6,0.3)");
      ctx.fillStyle = shg;
      ctx.fillRect(cx - bw / 2, wallTop, bw, TILE * 1.34);
      ctx.restore();
      // крыша с черепицей
      const roofTop = wallTop - TILE * 0.86;
      ctx.beginPath();
      ctx.moveTo(cx - W * 0.52, wallTop + 2);
      ctx.lineTo(cx, roofTop);
      ctx.lineTo(cx + W * 0.52, wallTop + 2);
      ctx.closePath();
      const rg2 = ctx.createLinearGradient(cx - W * 0.4, roofTop, cx + W * 0.4, wallTop);
      rg2.addColorStop(0, "#96574a");
      rg2.addColorStop(0.45, "#7a4a3a");
      rg2.addColorStop(1, "#4a2a20");
      ctx.fillStyle = rg2;
      ctx.fill();
      ctx.strokeStyle = "rgba(20,10,6,0.8)"; ctx.lineWidth = 1; ctx.stroke();
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx - W * 0.52, wallTop + 2); ctx.lineTo(cx, roofTop); ctx.lineTo(cx + W * 0.52, wallTop + 2);
      ctx.closePath(); ctx.clip();
      for (let r = 0; r < 5; r++) {
        const ry = wallTop + 2 - (r / 5) * TILE * 0.86;
        const rw = W * 1.04 * (1 - r / 5);
        for (let k = 0; k < 9; k++) {
          const txp = cx - rw / 2 + (k / 9) * rw;
          ctx.fillStyle = (k + r) % 2 ? "#6d4034" : "#8a5040";
          ctx.beginPath(); ctx.roundRect(txp, ry - TILE * 0.18, rw / 9 - 0.8, TILE * 0.18, 1.2); ctx.fill();
        }
      }
      ctx.fillStyle = "rgba(16,8,4,0.26)";
      ctx.beginPath(); ctx.moveTo(cx, roofTop); ctx.lineTo(cx + W * 0.52, wallTop + 2); ctx.lineTo(cx, wallTop + 2); ctx.closePath(); ctx.fill();
      ctx.restore();
      // труба
      ctx.fillStyle = "#6b645c";
      ctx.fillRect(cx + W * 0.2, roofTop + TILE * 0.1, 8, TILE * 0.5);
      ctx.fillStyle = "#4a443e";
      ctx.fillRect(cx + W * 0.2 - 1.6, roofTop + TILE * 0.08, 11.2, 3.6);
      // окна со ставнями
      for (const dx of [-1, 1]) {
        const wx = cx + dx * bw * 0.27 - 5;
        const wy = wallTop + TILE * 0.3;
        ctx.fillStyle = "#4a3826";
        ctx.fillRect(wx - 1.6, wy - 1.6, 13.2, 13.2);
        ctx.fillStyle = "rgba(38,30,24,0.95)";
        ctx.fillRect(wx, wy, 10, 10);
        ctx.strokeStyle = "rgba(255,248,224,0.25)"; ctx.lineWidth = 0.9;
        ctx.beginPath(); ctx.moveTo(wx + 5, wy); ctx.lineTo(wx + 5, wy + 10); ctx.moveTo(wx, wy + 5); ctx.lineTo(wx + 10, wy + 5); ctx.stroke();
        ctx.fillStyle = "rgba(180,210,235,0.16)";
        ctx.beginPath(); ctx.moveTo(wx, wy + 8); ctx.lineTo(wx + 8, wy); ctx.lineTo(wx + 10, wy); ctx.lineTo(wx, wy + 10); ctx.closePath(); ctx.fill();
      }
      // дверь
      const dw2 = 16, dh2 = TILE * 0.78;
      const dxp = cx - dw2 / 2, dyp = base - 6 - dh2;
      ctx.fillStyle = "#3a2a18";
      ctx.fillRect(dxp - 1.6, dyp - 1.6, dw2 + 3.2, dh2 + 2);
      const dgr = ctx.createLinearGradient(dxp, 0, dxp + dw2, 0);
      dgr.addColorStop(0, "#5c4227"); dgr.addColorStop(0.45, "#43301c"); dgr.addColorStop(1, "#2c1f12");
      ctx.fillStyle = dgr;
      ctx.fillRect(dxp, dyp, dw2, dh2);
      ctx.strokeStyle = "rgba(94,72,44,0.7)"; ctx.lineWidth = 0.8;
      for (let i = 1; i < 3; i++) { ctx.beginPath(); ctx.moveTo(dxp + (i / 3) * dw2, dyp); ctx.lineTo(dxp + (i / 3) * dw2, dyp + dh2); ctx.stroke(); }
      ctx.fillStyle = "#6f665c";
      ctx.fillRect(dxp + 0.8, dyp + dh2 * 0.18, 3.8, 2.4);
      ctx.fillRect(dxp + 0.8, dyp + dh2 * 0.7, 3.8, 2.4);
      ctx.fillStyle = "#d9b45c";
      ctx.beginPath(); ctx.arc(dxp + dw2 - 3.6, dyp + dh2 * 0.5, 1.6, 0, 7); ctx.fill();
      ctx.fillStyle = "#7d766c";
      ctx.beginPath(); ctx.roundRect(cx - dw2 * 0.72, base - 6, dw2 * 1.44, 3.2, 1); ctx.fill();
      break;
    }
    case "fakel_st": {
      ctx.strokeStyle = "#6d4c33";
      ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(cx, base); ctx.lineTo(cx, base - TILE * 0.8); ctx.stroke();
      break;
    }
    case "lesopilka": {
      ctx.fillStyle = "#7a5f3d";
      ctx.fillRect(cx - W * 0.44, base - TILE * 0.8, W * 0.88, TILE * 0.8);
      ctx.fillStyle = "#5d492e";
      ctx.beginPath();
      ctx.moveTo(cx - W * 0.5, base - TILE * 0.8);
      ctx.lineTo(cx, base - TILE * 1.5);
      ctx.lineTo(cx + W * 0.5, base - TILE * 0.8);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "#c9c2b2";
      ctx.lineWidth = 3.4;
      ctx.beginPath(); ctx.moveTo(cx - 14, base - TILE * 0.7); ctx.lineTo(cx + 14, base - TILE * 0.3); ctx.stroke();
      ctx.fillStyle = "#a8845c";
      ctx.fillRect(cx - W * 0.3, base - TILE * 0.28, W * 0.24, TILE * 0.24);
      break;
    }
    case "kamenolom": {
      ctx.fillStyle = "#8a857c";
      ctx.beginPath(); ctx.arc(cx - W * 0.2, base - TILE * 0.3, TILE * 0.32, 0, 7); ctx.fill();
      ctx.fillStyle = "#7a756c";
      ctx.beginPath(); ctx.arc(cx + W * 0.18, base - TILE * 0.35, TILE * 0.42, 0, 7); ctx.fill();
      ctx.strokeStyle = "#6d4c33";
      ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(cx - W * 0.35, base); ctx.lineTo(cx + W * 0.3, base - TILE * 1.1); ctx.stroke();
      break;
    }
    case "ferma": {
      ctx.fillStyle = "#6e5238";
      ctx.fillRect(4, H - TILE - 10, W - 8, TILE);
      ctx.strokeStyle = "#5d452e";
      ctx.lineWidth = 2.5;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath(); ctx.moveTo(8, H - TILE + i * 10 - 4); ctx.lineTo(W - 8, H - TILE + i * 10 - 4); ctx.stroke();
      }
      if (done) {
        const grown = clamp(store / 4, 0.35, 1);
        for (let i = 0; i < 6; i++) {
          const x = 14 + (i % 3) * (W / 3.2), y = H - TILE + 6 + Math.floor(i / 3) * 16;
          ctx.fillStyle = "#6e9a52";
          ctx.beginPath(); ctx.arc(x, y, 8 * grown, 0, 7); ctx.fill();
          ctx.fillStyle = "#c94f5d";
          ctx.beginPath(); ctx.arc(x - 3, y - 2, 2.2, 0, 7); ctx.fill();
          ctx.beginPath(); ctx.arc(x + 3, y + 1, 2.2, 0, 7); ctx.fill();
        }
      }
      break;
    }
    case "kolodec": {
      ctx.fillStyle = "#8a857c";
      ctx.beginPath(); ctx.ellipse(cx, base - TILE * 0.3, TILE * 0.34, TILE * 0.2, 0, 0, 7); ctx.fill();
      ctx.fillStyle = "#2c3e50";
      ctx.beginPath(); ctx.ellipse(cx, base - TILE * 0.32, TILE * 0.26, TILE * 0.14, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = "#6d4c33";
      ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(cx - TILE * 0.3, base - TILE * 0.3); ctx.lineTo(cx - TILE * 0.3, base - TILE * 1.1); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx + TILE * 0.3, base - TILE * 0.3); ctx.lineTo(cx + TILE * 0.3, base - TILE * 1.1); ctx.stroke();
      ctx.fillStyle = "#7a4a3a";
      ctx.beginPath();
      ctx.moveTo(cx - TILE * 0.42, base - TILE * 1.1);
      ctx.lineTo(cx, base - TILE * 1.45);
      ctx.lineTo(cx + TILE * 0.42, base - TILE * 1.1);
      ctx.closePath(); ctx.fill();
      break;
    }
    case "chastokol": {
      ctx.fillStyle = "#7a5a38";
      for (let i = 0; i < 4; i++) {
        const x = cx - TILE * 0.36 + i * TILE * 0.24;
        ctx.beginPath();
        ctx.moveTo(x, base);
        ctx.lineTo(x, base - TILE * 0.85);
        ctx.lineTo(x + TILE * 0.09, base - TILE * 1.05);
        ctx.lineTo(x + TILE * 0.18, base - TILE * 0.85);
        ctx.lineTo(x + TILE * 0.18, base);
        ctx.closePath();
        ctx.fill();
      }
      ctx.strokeStyle = "#5d452e";
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(4, base - TILE * 0.5); ctx.lineTo(W - 4, base - TILE * 0.55); ctx.stroke();
      break;
    }
    case "stena": {
      ctx.fillStyle = "#8a857c";
      ctx.fillRect(3, H - TILE * 0.9 - 8, W - 6, TILE * 0.9);
      ctx.strokeStyle = "#6d675f";
      ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath(); ctx.moveTo(5, H - 10 - i * TILE * 0.3 - TILE * 0.05); ctx.lineTo(W - 5, H - 10 - i * TILE * 0.3 - TILE * 0.05); ctx.stroke();
      }
      ctx.fillStyle = "#9a958c";
      ctx.fillRect(3, H - TILE * 0.9 - 8, W - 6, 6);
      break;
    }
    case "dver": {
      ctx.fillStyle = "#7a5f3d";
      ctx.fillRect(6, H - TILE - 8, W - 12, TILE);
      ctx.strokeStyle = "#5d492e";
      ctx.lineWidth = 3;
      ctx.strokeRect(6, H - TILE - 8, W - 12, TILE);
      ctx.beginPath(); ctx.moveTo(10, H - 10 - TILE * 0.5); ctx.lineTo(W - 10, H - 10 - TILE * 0.5); ctx.stroke();
      ctx.fillStyle = "#3a3122";
      ctx.beginPath(); ctx.arc(W - 14, H - 8 - TILE * 0.45, 3, 0, 7); ctx.fill();
      break;
    }
    case "vyshka": {
      ctx.strokeStyle = "#6d4c33";
      ctx.lineWidth = 5;
      ctx.beginPath(); ctx.moveTo(cx - TILE * 0.28, base); ctx.lineTo(cx - TILE * 0.18, base - TILE * 1.7 - 24); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx + TILE * 0.28, base); ctx.lineTo(cx + TILE * 0.18, base - TILE * 1.7 - 24); ctx.stroke();
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(cx - TILE * 0.26, base - TILE * 0.7); ctx.lineTo(cx + TILE * 0.22, base - TILE * 0.9); ctx.stroke();
      ctx.fillStyle = "#8a6a44";
      ctx.fillRect(cx - TILE * 0.34, base - TILE * 2.2 - 24, TILE * 0.68, TILE * 0.44);
      ctx.fillStyle = "#5d452e";
      ctx.beginPath();
      ctx.moveTo(cx - TILE * 0.42, base - TILE * 1.76 - 24);
      ctx.lineTo(cx, base - TILE * 2.3 - 24);
      ctx.lineTo(cx + TILE * 0.42, base - TILE * 1.76 - 24);
      ctx.closePath(); ctx.fill();
      break;
    }
    default:
      genericBuilding(ctx, def, W, H, lvl);
      break;
  }
  ctx.globalAlpha = 1;
  // значок "можно собрать"
  if (done && store > 0) {
    ctx.fillStyle = "rgba(245,197,66,0.9)";
    ctx.beginPath(); ctx.arc(W - 12, 12, 9, 0, 7); ctx.fill();
    ctx.fillStyle = "#4a3010";
    ctx.font = "bold 12px Georgia";
    ctx.textAlign = "center";
    ctx.fillText("!", W - 12, 16);
  }
  if (bCache.size >= B_LIMIT) {
    const first = bCache.keys().next().value;
    if (first !== undefined) bCache.delete(first);
  }
  bCache.set(key, c);
  return c;
}

// ---- Погодные частицы (экранные) ----
interface WDrop { x: number; y: number; v: number; l: number }
const rainArr: WDrop[] = [];
const snowArr: WDrop[] = [];
for (let i = 0; i < 110; i++) rainArr.push({ x: Math.random(), y: Math.random(), v: 0.5 + Math.random() * 0.5, l: 10 + Math.random() * 14 });
for (let i = 0; i < 80; i++) snowArr.push({ x: Math.random(), y: Math.random(), v: 0.25 + Math.random() * 0.4, l: 1 + Math.random() * 2.4 });
let lightning = 0;
let birdFly = { t: -6, y: 0, dir: 1 };
let fishT = 0;

// ============ Главная функция рендера ============

let prevNow = 0; // метка прошлого кадра — для плавного затухания кроны

/**
 * Стоит ли герой под кроной дерева, чей ствол на тайле (tx,ty)?
 * Крона — эллипс над основанием ствола; прямо перед стволом (южнее) не считается.
 */
function underTreeCrown(px: number, py: number, tx: number, ty: number): boolean {
  const cxT = tx * TILE + TILE / 2, baseY = ty * TILE + TILE;
  const crownCy = baseY - TILE * 1.42; // центр листвы над основанием ствола
  const ex = (px - cxT) / (TILE * 1.04);
  const ey = (py - crownCy) / (TILE * 1.02);
  return ex * ex + ey * ey < 1 && py < baseY - 2;
}

export function renderGame(e: Engine, ctx: CanvasRenderingContext2D, W: number, H: number, now: number) {
  const cam = e.cam;
  const zoom = cam.zoom;
  const shakeAmp = e.shake * 14;
  const shX = (Math.random() - 0.5) * shakeAmp;
  const shY = (Math.random() - 0.5) * shakeAmp;
  const fx = e.fx ?? 1; // плотность эффектов от адаптивного регулятора качества

  const layerDef = LAYER_BY_ID[e.z];
  if (layerDef && e.z !== 0) {
    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, layerDef.bgTop);
    bg.addColorStop(1, layerDef.bgBot);
    ctx.fillStyle = bg;
  } else ctx.fillStyle = "#1a1620";
  ctx.fillRect(0, 0, W, H);

  ctx.save();
  ctx.translate(W / 2 + shX, H / 2 + shY);
  ctx.scale(zoom, zoom);
  ctx.translate(-cam.x, -cam.y);

  const season = e.season();
  const viewL = cam.x - W / 2 / zoom - TILE;
  const viewT = cam.y - H / 2 / zoom - TILE * 2;
  const viewR = cam.x + W / 2 / zoom + TILE;
  const viewB = cam.y + H / 2 / zoom + TILE * 2;
  const tx0 = Math.floor(viewL / TILE), ty0 = Math.floor(viewT / TILE);
  const tx1 = Math.ceil(viewR / TILE), ty1 = Math.ceil(viewB / TILE);

  // --- Грунт ---
  const df = e.daylight();
  const night = 1 - df;
  for (let ty = ty0; ty <= ty1; ty++) {
    for (let tx = tx0; tx <= tx1; tx++) {
      const v = Math.floor(hash2(e.seed ^ 0x77, tx, ty) * 4);
      const t = e.tileOf(tx, ty);
      ctx.drawImage(groundSprite(t.g, v, season), tx * TILE, ty * TILE);
    }
  }

  // --- Вода: мерцание + рыба ---
  fishT = now;
  for (let ty = ty0; ty <= ty1; ty++) {
    for (let tx = tx0; tx <= tx1; tx++) {
      const t = e.tileOf(tx, ty);
      if (t.g === G.Water || t.g === G.DeepWater) {
        const ph = now * 1.6 + hash2(e.seed, tx, ty) * 20;
        const a = 0.14 + Math.sin(ph) * 0.12;
        if (a > 0.1) {
          ctx.strokeStyle = `rgba(230,244,252,${a.toFixed(3)})`;
          ctx.lineWidth = 1.6;
          const off = (Math.sin(ph * 0.7) + 1) * 6;
          ctx.beginPath();
          ctx.moveTo(tx * TILE + 6 + off, ty * TILE + 12 + (tx % 3) * 8);
          ctx.lineTo(tx * TILE + 18 + off, ty * TILE + 12 + (tx % 3) * 8);
          ctx.stroke();
        }
        // рыба (на экономном качестве не рисуем — вода и блики остаются)
        if (fx > 0.5 && t.g === G.Water && hash2(e.seed ^ 0xf1, tx, ty) < 0.16) {
          const fph = now * 0.7 + hash2(e.seed, tx + 5, ty) * 10;
          const fx = tx * TILE + 20 + Math.sin(fph) * 10;
          const fy = ty * TILE + 22 + Math.cos(fph * 1.3) * 6;
          ctx.fillStyle = "rgba(20,40,60,0.4)";
          ctx.beginPath();
          ctx.ellipse(fx, fy, 6, 2.6, Math.sin(fph) > 0 ? 0.2 : Math.PI - 0.2, 0, 7);
          ctx.fill();
        }
      }
    }
  }

  // --- День/ночь свет собираем заранее ---
  interface Light { x: number; y: number; r: number; warm: string }
  const lights: Light[] = [];
  for (const b of e.buildings) {
    const def = BUILDINGS[b.def];
    if (b.done && def.light) {
      const bx = (b.tx + def.w / 2) * TILE, by = (b.ty + def.h / 2) * TILE;
      if (bx > viewL - 300 && bx < viewR + 300 && by > viewT - 300 && by < viewB + 300) {
        lights.push({ x: bx, y: by, r: def.light * TILE, warm: "rgba(255,176,84,0.5)" });
      }
    }
    if (b.done && b.def === "koster" && Math.random() < 0.3) {
      // искры над костром — создаются в update? рисуем тут напрямую
    }
  }

  // --- Дороги: плоский слой поверх земли ---
  for (const b of e.buildings) {
    if (!BUILDINGS[b.def]?.road) continue;
    const bx = b.tx * TILE, by = b.ty * TILE;
    if (bx < viewL - TILE || bx > viewR || by < viewT - TILE || by > viewB) continue;
    drawRoad(ctx, b, now);
  }

  // --- Строки объектов + зданий + сущностей (painter) ---
  type Ent = { y: number; m: Mob | null; n?: import("../types").Npc };
  const entities: Ent[] = [
    ...e.mobs
      .filter((m) => m.x > viewL - 90 && m.x < viewR + 90 && m.y > viewT - 120 && m.y < viewB + 90)
      .map((m) => ({ y: m.y, m })),
    ...e.npcs.npcs
      .filter((n) => n.x > viewL - 60 && n.x < viewR + 60 && n.y > viewT - 60 && n.y < viewB + 60)
      .map((n) => ({ y: n.y, m: null, n })),
    { y: e.player.y, m: null as Mob | null },
  ];
  entities.sort((a, b2) => a.y - b2.y);
  let ei = 0;

  const shadow = getShadowSprite();

  // --- Плавная растворённость кроны, когда герой стоит под листвой ---
  {
    const dtR = clamp(now - prevNow, 0, 0.06); prevNow = now;
    let under = false;
    const px = e.player.x, py = e.player.y;
    const ptxC = Math.floor(px / TILE), ptyC = Math.floor(py / TILE);
    // крона накрывает до ~2.4 тайлов над стволом и ~1 тайл по сторонам
    outer: for (let cty = ptyC; cty <= ptyC + 3; cty++) {
      for (let ctx2 = ptxC - 1; ctx2 <= ptxC + 1; ctx2++) {
        const t = e.tileOf(ctx2, cty);
        if ((t.o === O.Oak || t.o === O.Pine || t.o === O.Birch) && underTreeCrown(px, py, ctx2, cty)) { under = true; break outer; }
      }
    }
    e.crownFade = clamp01(e.crownFade + (under ? dtR * 7 : -dtR * 4.5));
  }

  for (let ty = ty0; ty <= ty1; ty++) {
    const rowY = ty * TILE + TILE;
    // объекты мира
    for (let tx = tx0; tx <= tx1; tx++) {
      const t = e.tileOf(tx, ty);
      if (t.o === O.None) continue;
      const chestTier = t.o === O.Chest ? (e.z >= 5 ? 2 : e.z > 0 ? 1 : 0) : 0;
      const spr = objSprite(t.o, season, chestTier);
      const bigTree = t.o === O.Oak || t.o === O.Pine || t.o === O.Birch;
      const px = tx * TILE, py = ty * TILE;
      if (bigTree) {
        // тень
        ctx.drawImage(shadow, px - TILE * 0.55, py + TILE * 0.42, TILE * 2.1, TILE * 0.55);
        // покачивание
        const sway = Math.sin(now * 1.25 + tx * 0.9 + ty * 0.6) * 0.023;
        const cxT = px + TILE / 2, baseY = py + TILE;
        // два слоя: ствол всегда сплошной; крона плавно полупрозрачна, когда герой под ней
        const parts = objSpriteTreeParts(t.o, season);
        const underCrown = underTreeCrown(e.player.x, e.player.y, tx, ty);
        const drX = -TILE, drY = -TILE * 2.4 + TILE * 0.1, drW = TILE * 2, drH = TILE * 2.4;
        ctx.save();
        ctx.translate(cxT, baseY);
        ctx.rotate(sway);
        ctx.drawImage(parts.trunk, drX, drY, drW, drH);
        if (underCrown && e.crownFade > 0.001) {
          ctx.globalAlpha = 1 - e.crownFade * 0.52; // слегка прозрачная листва — героя видно
        }
        ctx.drawImage(parts.crown, drX, drY, drW, drH);
        ctx.restore();
      } else {
        const isFlora = t.o === O.Bush || t.o === O.GrassTuft || t.o === O.FlowerR || t.o === O.FlowerY || t.o === O.Reeds || t.o === O.DeadBush || t.o === O.Mushroom;
        // мягкое пульсирующее свечение ценных объектов
        const gl = GLOW_OBJ[t.o];
        if (gl) {
          const pulse = 0.78 + Math.sin(now * 2 + tx * 0.7 + ty * 0.5) * 0.22;
          const gr = 30 * pulse;
          ctx.globalAlpha = pulse;
          ctx.drawImage(glowSprite(gl), px + TILE / 2 - gr, py + TILE / 2 - gr, gr * 2, gr * 2);
          ctx.globalAlpha = 1;
        }
        if (isFlora) {
          const sway = Math.sin(now * 1.7 + tx * 1.4 + ty) * 0.05;
          ctx.save();
          ctx.translate(px + TILE / 2, py + TILE);
          ctx.rotate(sway);
          ctx.drawImage(spr, -TILE / 2, -TILE, TILE, TILE);
          ctx.restore();
        } else if (t.o === O.RuinChest || (t.o === O.Chest && chestTier === 2)) {
          // легендарный сундук слегка покачивается
          const rock = Math.sin(now * 1.6 + tx) * 0.035;
          ctx.save();
          ctx.translate(px + TILE / 2, py + TILE);
          ctx.rotate(rock);
          ctx.drawImage(spr, -TILE / 2, -TILE, TILE, TILE);
          ctx.restore();
        } else {
          ctx.drawImage(spr, px, py, TILE, TILE);
        }
        // остаток хп объекта — трещина-индикатор
        const maxHp = 40;
        if (t.hp < maxHp && t.hp > 0 && (t.o === O.Oak || t.o === O.Pine || t.o === O.Birch || t.o === O.Rock || t.o === O.Coal || t.o === O.Copper || t.o === O.Iron || t.o === O.Gold)) {
          const fullMax = t.o === O.Oak ? 40 : t.o === O.Birch ? 30 : t.o === O.Pine ? 34 : 66;
          const frac = t.hp / fullMax;
          if (frac < 1) {
            ctx.fillStyle = "rgba(0,0,0,0.5)";
            ctx.fillRect(px + 4, py - 6, TILE - 8, 4);
            ctx.fillStyle = frac > 0.5 ? "#a8e68a" : "#f2b45c";
            ctx.fillRect(px + 4, py - 6, (TILE - 8) * frac, 4);
          }
        }
      }
    }
    // здания этой строки
    for (const b of e.buildings) {
      const def = BUILDINGS[b.def];
      if (def.road) continue;
      if (b.tx * TILE > viewR + TILE * 4 || (b.tx + def.w) * TILE < viewL - TILE * 4) continue;
      if (b.ty + def.h - 1 !== ty && !(def.w === 1 && def.h === 1 && b.ty === ty)) continue;
      if (b.ty + def.h - 1 !== ty) continue;
      const spr = buildingSprite(b.def, b.done, b.store, b.lvl ?? 1);
      const bx = b.tx * TILE, by = (b.ty + def.h) * TILE;
      ctx.drawImage(shadow, bx + def.w * TILE * 0.08, by - TILE * 0.36, def.w * TILE * 0.9, TILE * 0.4);
      // ореол чуда света
      if (def.wonder && b.done) {
        ctx.drawImage(glowSprite("rgba(255,214,120,0.28)"), bx - 30, by - spr.height / BS - 20, def.w * TILE + 60, spr.height / BS + 50);
      }
      ctx.drawImage(spr, bx, by - spr.height / BS, spr.width / BS, spr.height / BS);
      if (b.done) drawBuildingLife(ctx, b, def, night, now, e.particles as unknown as { push: (p: unknown) => void });
      // огонёк факела
      if (b.done && b.def === "fakel_st") {
        const fl = 0.8 + Math.sin(now * 9 + b.uid) * 0.2;
        drawFlame(ctx, bx + TILE / 2, by - TILE * 0.86, 5 * fl, now + b.uid);
      }
      // пламя костра
      if (b.done && b.def === "koster") {
        drawFlame(ctx, bx + TILE / 2, by - TILE * 0.42, 11, now * 2 + b.uid);
        if (Math.random() < 0.06 * fx) {
          e.particles.push({
            x: bx + TILE / 2, y: by - TILE * 0.5, vx: (Math.random() - 0.5) * 24, vy: -46 - Math.random() * 30,
            age: 0, life: 0.9, color: "#f2a24d", size: 2.2, grav: -30, kind: "ember",
          });
        }
      }
      // прогресс стройки
      if (!b.done) {
        const frac = clamp01(b.progress / BUILDINGS[b.def].buildTime);
        ctx.fillStyle = "rgba(0,0,0,0.55)";
        ctx.fillRect(bx + 2, by - BUILDINGS[b.def].h * TILE - 12, def.w * TILE - 4, 7);
        ctx.fillStyle = "#f2b45c";
        ctx.fillRect(bx + 2, by - BUILDINGS[b.def].h * TILE - 12, (def.w * TILE - 4) * frac, 7);
        ctx.fillStyle = "#efe6d5";
        ctx.font = "600 11px system-ui";
        ctx.textAlign = "center";
        ctx.fillText("стройка — стучите", bx + (def.w * TILE) / 2, by - BUILDINGS[b.def].h * TILE - 17);
      }
    }
    // сущности до конца строки
    while (ei < entities.length && entities[ei].y <= rowY) {
      const ent = entities[ei];
      if (ent.m) drawMob(ctx, ent.m, now, e);
      else if (ent.n) drawNpc(ctx, ent.n, now);
      else drawPlayer(ctx, e, now);
      ei++;
    }
  }
  while (ei < entities.length) {
    const ent = entities[ei];
    if (ent.m) drawMob(ctx, ent.m, now, e);
    else if (ent.n) drawNpc(ctx, ent.n, now);
    else drawPlayer(ctx, e, now);
    ei++;
  }

  // --- Караваны: свои и чужие ---
  for (const r of e.economy.routes) if (r.x) drawCaravan(ctx, r, now, false);
  for (const r of e.economy.foreign) drawCaravan(ctx, r, now, true);

  // --- Культурные границы города ---
  if (e.city.s.founded) {
    const rad = e.lore.borderRadius() * TILE;
    const cx = e.city.s.cx * TILE, cy = e.city.s.cy * TILE;
    const pulse = 1 + Math.sin(now * 0.8) * 0.012;
    ctx.save();
    ctx.setLineDash([14, 10]);
    ctx.lineDashOffset = -now * 12;
    ctx.strokeStyle = e.lore.religion.founded
      ? `${e.lore.religion.color}66`
      : "rgba(242,193,78,0.34)";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.arc(cx, cy, rad * pulse, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = 0.05;
    ctx.fillStyle = e.lore.religion.founded ? e.lore.religion.color : "#f2c14e";
    ctx.beginPath();
    ctx.arc(cx, cy, rad * pulse, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  // --- Магическая аура героя ---
  if (e.lore.magic.school) {
    const sc = SCHOOL_COLOR[e.lore.magic.school] ?? "#a26af2";
    const aura = e.lore.magic.auraT > 0 ? Math.min(1, e.lore.magic.auraT / 3) : 0;
    const manaFrac = clamp01(e.lore.magic.mana / Math.max(1, e.lore.magic.manaMax));
    const baseR = 26 + manaFrac * 10;
    // кольцо рун
    ctx.save();
    ctx.globalAlpha = 0.22 + aura * 0.5;
    ctx.strokeStyle = sc;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.ellipse(e.player.x, e.player.y + 6, baseR + aura * 24, (baseR + aura * 24) * 0.42, 0, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 6; i++) {
      const a = now * (0.7 + aura) + (i / 6) * Math.PI * 2;
      const rr = baseR + aura * 24;
      const rx = e.player.x + Math.cos(a) * rr;
      const ry = e.player.y + 6 + Math.sin(a) * rr * 0.42;
      ctx.globalAlpha = 0.35 + aura * 0.5;
      ctx.fillStyle = sc;
      ctx.beginPath();
      ctx.arc(rx, ry, 2 + aura * 2.4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
    // всплеск при творении чар
    if (aura > 0.02 && Math.random() < 0.4 * fx) {
      e.particles.push({
        x: e.player.x + (Math.random() - 0.5) * 30, y: e.player.y - 6,
        vx: (Math.random() - 0.5) * 30, vy: -35 - Math.random() * 30,
        age: 0, life: 0.9, color: sc, size: 2.4, grav: -18, kind: "star",
      });
    }
  }

  // --- Ореол веры над храмами ---
  if (e.lore.religion.founded) {
    for (const b of e.buildings) {
      if (!b.done || !["hram", "sobor", "monastyr", "altar"].includes(b.def)) continue;
      const def = BUILDINGS[b.def];
      const bx = (b.tx + def.w / 2) * TILE, by = (b.ty + def.h / 2) * TILE;
      if (bx < viewL - 120 || bx > viewR + 120 || by < viewT - 120 || by > viewB + 120) continue;
      const fl = 0.5 + Math.sin(now * 1.6 + b.uid) * 0.2;
      ctx.save();
      ctx.globalAlpha = 0.25 * fl + night * 0.25;
      ctx.fillStyle = e.lore.religion.color;
      ctx.font = "bold 17px Georgia";
      ctx.textAlign = "center";
      ctx.fillText(e.lore.religion.symbol, bx, by - def.h * TILE - 16 + Math.sin(now * 1.1 + b.uid) * 3);
      ctx.restore();
      if (night > 0.3) {
        ctx.drawImage(glowSprite(`${e.lore.religion.color}55`), bx - 40, by - def.h * TILE - 50, 80, 80);
      }
    }
  }

  // --- Знамёна вражеских войск на подходе ---
  {
    const incoming = e.nations.nations.filter((nn) => nn.incoming);
    for (const nn of incoming) {
      const ang = Math.atan2(nn.y, nn.x);
      const base = e.city.s.founded
        ? { x: e.city.s.cx * TILE, y: e.city.s.cy * TILE }
        : { x: e.player.x, y: e.player.y };
      const dist = 16 * TILE;
      const bx = base.x + Math.cos(ang) * dist;
      const by = base.y + Math.sin(ang) * dist;
      if (bx < viewL - 200 || bx > viewR + 200 || by < viewT - 200 || by > viewB + 200) continue;
      for (let i = 0; i < 4; i++) {
        const ox = bx + (i - 1.5) * 34;
        const oy = by + Math.sin(now * 1.4 + i) * 3;
        ctx.drawImage(shadow, ox - 14, oy + 6, 28, 10);
        // древко и полотнище
        ctx.strokeStyle = "#5d452e"; ctx.lineWidth = 2.6;
        ctx.beginPath(); ctx.moveTo(ox, oy + 8); ctx.lineTo(ox, oy - 26); ctx.stroke();
        const wave = Math.sin(now * 3 + i * 0.7) * 3;
        ctx.fillStyle = nn.flag.bg;
        ctx.beginPath();
        ctx.moveTo(ox, oy - 26);
        ctx.quadraticCurveTo(ox + 11, oy - 22 + wave, ox + 20, oy - 25);
        ctx.lineTo(ox + 20, oy - 12);
        ctx.quadraticCurveTo(ox + 11, oy - 9 + wave, ox, oy - 13);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = nn.flag.fg;
        ctx.font = "bold 10px Georgia"; ctx.textAlign = "center";
        ctx.fillText(nn.flag.sym, ox + 10, oy - 16);
        // силуэт воина
        ctx.fillStyle = "#3a3038";
        ctx.beginPath(); ctx.ellipse(ox - 6, oy, 5, 7, 0, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.arc(ox - 6, oy - 9, 3.4, 0, 7); ctx.fill();
      }
      ctx.font = "800 13px Georgia";
      ctx.textAlign = "center";
      ctx.lineWidth = 3.4; ctx.strokeStyle = "rgba(0,0,0,0.8)";
      ctx.strokeText(`${nn.name} идут войной`, bx, by - 42);
      ctx.fillStyle = "#f2766a";
      ctx.fillText(`${nn.name} идут войной`, bx, by - 42);
    }
  }

  // --- Городской праздник ---
  if (e.city.s.founded && e.city.s.paradeT > 0) {
    drawParade(ctx, e.city.s.cx * TILE, e.city.s.cy * TILE, now, e.particles as unknown as { push: (p: unknown) => void });
  }

  // --- Снаряды ---
  for (const pr of e.projectiles) {
    if (pr.kind === "arrow") {
      const ang = Math.atan2(pr.vy, pr.vx);
      ctx.save();
      ctx.translate(pr.x, pr.y);
      ctx.rotate(ang);
      ctx.strokeStyle = "#d8cbb0";
      ctx.lineWidth = 2.4;
      ctx.beginPath(); ctx.moveTo(-9, 0); ctx.lineTo(7, 0); ctx.stroke();
      ctx.fillStyle = "#8a4a4a";
      ctx.beginPath(); ctx.moveTo(-9, 0); ctx.lineTo(-5, -3); ctx.lineTo(-5, 3); ctx.closePath(); ctx.fill();
      ctx.restore();
    } else {
      ctx.drawImage(glowSprite("rgba(242,140,60,0.7)"), pr.x - 22, pr.y - 22, 44, 44);
      ctx.fillStyle = "#ffd97a";
      ctx.beginPath(); ctx.arc(pr.x, pr.y, 5, 0, 7); ctx.fill();
    }
  }

  // --- Частицы ---
  for (const pt of e.particles) {
    const a = 1 - pt.age / pt.life;
    ctx.globalAlpha = a;
    ctx.fillStyle = pt.color;
    if (pt.kind === "spark" || pt.kind === "star" || pt.kind === "ember") {
      ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.size * a + 0.5, 0, 7); ctx.fill();
    } else if (pt.kind === "leaf" || pt.kind === "chip") {
      ctx.fillRect(pt.x - pt.size / 2, pt.y - pt.size / 2, pt.size, pt.size * 0.7);
    } else {
      ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.size * 0.7, 0, 7); ctx.fill();
    }
  }
  ctx.globalAlpha = 1;

  // --- Цель движения ---
  if (e.moveTarget) {
    const rad = 6 + Math.sin(now * 6) * 2;
    ctx.strokeStyle = "rgba(245,197,66,0.75)";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(e.moveTarget.x, e.moveTarget.y, rad, 0, 7); ctx.stroke();
    ctx.beginPath(); ctx.arc(e.moveTarget.x, e.moveTarget.y, 2.4, 0, 7); ctx.fill();
  }

  // --- Упор в ствол: тёплое свечение, рамка тайла и расходящееся кольцо «тук» ---
  if (e.bumpFx.t > 0) {
    const k = clamp01(e.bumpFx.t / 0.28);
    const hx = e.bumpFx.tx * TILE, hy = e.bumpFx.ty * TILE;
    const cxT = hx + TILE / 2, cyT = hy + TILE / 2;
    ctx.save();
    // мягкое свечение по центру ствола
    const gr = TILE * (0.85 + (1 - k) * 0.35);
    ctx.globalAlpha = k * 0.8;
    ctx.drawImage(glowSprite("rgba(242,162,77,0.5)"), cxT - gr, cyT - gr, gr * 2, gr * 2);
    // рамка тайла ствола
    ctx.globalAlpha = k;
    ctx.strokeStyle = "#f2a24d";
    ctx.lineWidth = 3;
    ctx.strokeRect(hx + 1.5, hy + 1.5, TILE - 3, TILE - 3);
    ctx.strokeStyle = "rgba(242,162,77,0.45)";
    ctx.lineWidth = 6;
    ctx.strokeRect(hx + 3, hy + 3, TILE - 6, TILE - 6);
    // кольцо удара со стороны героя
    const ang = Math.atan2(e.player.y - cyT, e.player.x - cxT);
    const ringX = cxT + Math.cos(ang) * TILE * 0.5, ringY = cyT + Math.sin(ang) * TILE * 0.5;
    ctx.strokeStyle = `rgba(255,222,156,${(0.9 * k).toFixed(3)})`;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(ringX, ringY, TILE * (0.14 + (1 - k) * 0.5), 0, 7);
    ctx.stroke();
    ctx.restore();
  }

  // --- Призрак постройки ---
  if (e.buildDef) {
    const def = BUILDINGS[e.buildDef];
    const g = e.buildGhost;
    const spr = buildingSprite(e.buildDef, true, 0);
    ctx.globalAlpha = 0.62;
    ctx.drawImage(spr, g.tx * TILE, (g.ty + def.h) * TILE - spr.height / BS, spr.width / BS, spr.height / BS);
    ctx.globalAlpha = 1;
    ctx.fillStyle = g.valid ? "rgba(120,230,130,0.22)" : "rgba(240,90,80,0.22)";
    ctx.strokeStyle = g.valid ? "#7ae68a" : "#f06a5a";
    ctx.lineWidth = 2 / zoom + 1;
    ctx.fillRect(g.tx * TILE, g.ty * TILE, def.w * TILE, def.h * TILE);
    ctx.strokeRect(g.tx * TILE, g.ty * TILE, def.w * TILE, def.h * TILE);
  }

  // ==== Ночное освещение ====
  if (night > 0.03) {
    const layerDark = e.z === 0 ? 0 : (1 - (LAYER_BY_ID[e.z]?.light ?? 1)) * 0.55;
    const darkA = clamp((night * 0.68 + layerDark) * 0.94, 0, 0.9);
    const vx0 = cam.x - W / 2 / zoom, vy0 = cam.y - H / 2 / zoom;
    ctx.fillStyle = `rgba(13,18,44,${darkA.toFixed(3)})`;
    ctx.fillRect(vx0 - 80, vy0 - 80, W / zoom + 160, H / zoom + 160);
    ctx.globalCompositeOperation = "lighter";
    // тёплый ореол вокруг героя
    const pr = (e.z === 0 ? 3.4 : 4.6) * TILE;
    const pg = ctx.createRadialGradient(e.player.x, e.player.y, 8, e.player.x, e.player.y, pr);
    pg.addColorStop(0, `rgba(90,110,170,${(0.35 * night).toFixed(2)})`);
    pg.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = pg;
    ctx.fillRect(e.player.x - pr, e.player.y - pr, pr * 2, pr * 2);
    for (const l of lights) {
      const flick = 1 + Math.sin(now * 8 + l.x) * 0.06;
      const r = l.r * flick * (night * 0.75 + 0.35);
      const g2 = ctx.createRadialGradient(l.x, l.y, 6, l.x, l.y, r);
      g2.addColorStop(0, l.warm.replace(/[\d.]+\)$/, `${(0.55 * night + 0.08).toFixed(2)})`));
      g2.addColorStop(0.6, "rgba(255,150,60,0.12)");
      g2.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g2;
      ctx.fillRect(l.x - r, l.y - r, r * 2, r * 2);
    }
    ctx.globalCompositeOperation = "source-over";
    // тёплый полутон на краях (чтобы ночь не была чёрной)
    ctx.fillStyle = `rgba(90,60,30,${(night * 0.05).toFixed(3)})`;
    ctx.fillRect(vx0 - 80, vy0 - 80, W / zoom + 160, H / zoom + 160);
  }

  // --- Письма-флоатеры ---
  for (const f of e.floaters) {
    const a = f.age < 0.85 ? 1 : 1 - (f.age - 0.85) / 0.45;
    const rise = 46 * (1 - Math.pow(1 - Math.min(f.age * 1.6, 1), 3));
    const pop = f.age < 0.14 ? 1 + (0.14 - f.age) * 3.2 : 1;
    ctx.globalAlpha = clamp01(a);
    ctx.font = `800 ${Math.round((f.big ? 21 : 15) * pop)}px Georgia, serif`;
    ctx.textAlign = "center";
    ctx.lineWidth = 4;
    ctx.strokeStyle = "rgba(10,6,4,0.85)";
    ctx.strokeText(f.text, f.x, f.y - rise);
    ctx.fillStyle = f.color;
    ctx.fillText(f.text, f.x, f.y - rise);
  }
  ctx.globalAlpha = 1;

  ctx.restore();

  // ===== Экранные слои =====
  const dl = e.daylight();

  // птицы днём
  if (fx > 0.5 && e.z === 0 && dl > 0.5 && e.weather === "clear") {
    birdFly.t += 1 / 60;
    if (birdFly.t > 14) {
      birdFly = { t: 0, y: 0.15 + Math.random() * 0.4, dir: Math.random() > 0.5 ? 1 : -1 };
    }
    if (birdFly.t > 0 && birdFly.t < 8) {
      const bx = birdFly.dir > 0 ? (birdFly.t / 8) * (W + 200) - 100 : W + 100 - (birdFly.t / 8) * (W + 200);
      const by = birdFly.y * H + Math.sin(birdFly.t * 2) * 20;
      const flap = Math.sin(now * 9) * 5;
      ctx.strokeStyle = "rgba(40,35,40,0.7)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(bx + i * 26 - 8, by + i * 12);
        ctx.quadraticCurveTo(bx + i * 26, by + i * 12 - 6 - flap, bx + i * 26 + 8, by + i * 12);
        ctx.stroke();
      }
    }
  }

  // дождь
  if (e.weather === "rain" || e.weather === "storm") {
    const inten = (e.weather === "storm" ? 1 : 0.65) * fx;
    ctx.strokeStyle = `rgba(170,200,230,${(0.4 * (e.weather === "storm" ? 1 : 0.65)).toFixed(2)})`;
    ctx.lineWidth = 1.2;
    const rainN = Math.floor(rainArr.length * inten);
    for (let i = 0; i < rainN; i++) {
      const d = rainArr[i];
      d.y += d.v * 0.024;
      if (d.y > 1.05) { d.y = -0.05; d.x = Math.random(); }
      const x = d.x * W + d.y * 30;
      const y = d.y * H;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x - 2, y + d.l);
      ctx.stroke();
    }
    // молнии
    if (e.weather === "storm") {
      lightning -= 1 / 60;
      if (Math.random() < 0.006) lightning = 0.16;
      if (lightning > 0) {
        ctx.fillStyle = `rgba(220,230,255,${(lightning * 1.8).toFixed(2)})`;
        ctx.fillRect(0, 0, W, H);
      }
    }
  }
  // снег
  if (e.weather === "snow") {
    ctx.fillStyle = "rgba(240,246,252,0.75)";
    const snowN = Math.floor(snowArr.length * fx);
    for (let i = 0; i < snowN; i++) {
      const d = snowArr[i];
      d.y += d.v * 0.006;
      d.x += Math.sin(now + d.v * 9) * 0.0007;
      if (d.y > 1.05) { d.y = -0.05; d.x = Math.random(); }
      ctx.beginPath();
      ctx.arc(d.x * W, d.y * H, d.l, 0, 7);
      ctx.fill();
    }
  }
  // туман
  if (e.weather === "fog") {
    ctx.fillStyle = "rgba(190,195,205,0.16)";
    ctx.fillRect(0, 0, W, H);
    const fogN = Math.max(1, Math.round(4 * fx));
    for (let i = 0; i < fogN; i++) {
      const fx = ((now * 12 * (i % 2 ? 1 : -1) + i * 420) % (W + 700)) - 350;
      const g = ctx.createRadialGradient(fx, H * (0.25 + i * 0.2), 10, fx, H * (0.25 + i * 0.2), 260);
      g.addColorStop(0, "rgba(200,205,215,0.14)");
      g.addColorStop(1, "rgba(200,205,215,0)");
      ctx.fillStyle = g;
      ctx.fillRect(fx - 260, 0, 520, H);
    }
  }

  // ===== Атмосфера слоёв =====
  if (e.z !== 0) {
    const zl = e.z;
    if (zl === 2) {
      // Глубины: искры и жаркое марево
      ctx.fillStyle = "rgba(224,102,46,0.06)";
      ctx.fillRect(0, 0, W, H);
      const sparkN = Math.round(26 * fx);
      for (let i = 0; i < sparkN; i++) {
        const t2 = (now * 0.35 + i * 0.37) % 1;
        const x = ((i * 137.5) % 100) / 100 * W;
        const y = H - t2 * H;
        ctx.fillStyle = `rgba(255,${160 + ((i * 37) % 70)},80,${(0.6 * (1 - t2)).toFixed(2)})`;
        ctx.beginPath(); ctx.arc(x + Math.sin(now * 2 + i) * 8, y, 1.6 + (i % 3) * 0.6, 0, 7); ctx.fill();
      }
    } else if (zl === 3) {
      // Небо: облачная дымка и парящие пушинки
      const cloudN = Math.max(1, Math.round(4 * fx));
      for (let i = 0; i < cloudN; i++) {
        const cx2 = ((now * 14 * (i % 2 ? 1 : -1) + i * 420) % (W + 700)) - 350;
        const g2 = ctx.createRadialGradient(cx2, H * (0.2 + i * 0.22), 10, cx2, H * (0.2 + i * 0.22), 240);
        g2.addColorStop(0, "rgba(235,245,255,0.16)");
        g2.addColorStop(1, "rgba(235,245,255,0)");
        ctx.fillStyle = g2;
        ctx.fillRect(cx2 - 240, 0, 480, H);
      }
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      const puffN = Math.round(20 * fx);
      for (let i = 0; i < puffN; i++) {
        const x = ((i * 91.7 + now * 12) % (W + 40)) - 20;
        const y = ((i * 57.3 + Math.sin(now * 0.5 + i) * 30) % H + H) % H;
        ctx.beginPath(); ctx.arc(x, y, 1.4, 0, 7); ctx.fill();
      }
    } else if (zl === 4) {
      // Океан: толща воды, пузыри, лучи
      ctx.fillStyle = "rgba(20,90,140,0.2)";
      ctx.fillRect(0, 0, W, H);
      const beamN = Math.max(1, Math.round(4 * fx));
      for (let i = 0; i < beamN; i++) {
        const bx2 = (i / beamN) * W + Math.sin(now * 0.3 + i) * 40;
        const gr = ctx.createLinearGradient(bx2, 0, bx2 + 90, H);
        gr.addColorStop(0, "rgba(190,235,255,0.09)");
        gr.addColorStop(1, "rgba(190,235,255,0)");
        ctx.fillStyle = gr;
        ctx.fillRect(bx2, 0, 90, H);
      }
      ctx.strokeStyle = "rgba(220,245,255,0.4)";
      ctx.lineWidth = 1.2;
      const bubN = Math.round(24 * fx);
      for (let i = 0; i < bubN; i++) {
        const t2 = (now * 0.22 + i * 0.41) % 1;
        const x = ((i * 163.4) % 100) / 100 * W + Math.sin(now * 2 + i) * 10;
        const y = H - t2 * H;
        ctx.beginPath(); ctx.arc(x, y, 1.6 + (i % 4) * 0.9, 0, 7); ctx.stroke();
      }
    } else if (zl === 5 || zl === 6) {
      // Космос: звёзды и далёкое светило
      const starN = Math.round(70 * fx);
      for (let i = 0; i < starN; i++) {
        const x = ((i * 137.9) % 100) / 100 * W;
        const y = ((i * 79.3) % 100) / 100 * H * 0.75;
        const tw = 0.4 + Math.sin(now * 1.6 + i) * 0.35;
        ctx.fillStyle = `rgba(255,255,240,${Math.max(0.08, tw).toFixed(2)})`;
        ctx.beginPath(); ctx.arc(x, y, i % 11 === 0 ? 1.9 : 1, 0, 7); ctx.fill();
      }
      const planet = zl === 5 ? "#3d6ba8" : "#a8763d";
      ctx.globalAlpha = 0.5;
      ctx.fillStyle = planet;
      ctx.beginPath(); ctx.arc(W * 0.82, H * 0.16, 46, 0, 7); ctx.fill();
      ctx.globalAlpha = 0.18;
      ctx.fillStyle = "#000";
      ctx.beginPath(); ctx.arc(W * 0.86, H * 0.14, 42, 0, 7); ctx.fill();
      ctx.globalAlpha = 1;
    } else if (zl === 7) {
      // Тени: тянущиеся щупальца тьмы
      ctx.fillStyle = "rgba(20,10,35,0.22)";
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = "rgba(140,100,200,0.14)";
      ctx.lineWidth = 3;
      for (let i = 0; i < 6; i++) {
        const x = (i / 6) * W + Math.sin(now * 0.4 + i) * 50;
        ctx.beginPath();
        ctx.moveTo(x, H);
        ctx.quadraticCurveTo(x + Math.sin(now + i) * 70, H * 0.5, x + Math.cos(now * 0.7 + i) * 40, 0);
        ctx.stroke();
      }
    } else if (zl === 8) {
      // Сны: радужная дымка и парящие искры
      const g3 = ctx.createLinearGradient(0, 0, W, H);
      g3.addColorStop(0, `rgba(230,150,220,${(0.06 + Math.sin(now * 0.5) * 0.02).toFixed(3)})`);
      g3.addColorStop(1, "rgba(150,190,255,0.05)");
      ctx.fillStyle = g3;
      ctx.fillRect(0, 0, W, H);
      for (let i = 0; i < 26; i++) {
        const x = ((i * 113.7 + now * 9) % (W + 30)) - 15;
        const y = H * 0.5 + Math.sin(now * 0.8 + i * 0.9) * H * 0.4;
        ctx.fillStyle = i % 2 ? "rgba(255,190,240,0.6)" : "rgba(190,225,255,0.6)";
        ctx.beginPath(); ctx.arc(x, y, 1.8, 0, 7); ctx.fill();
      }
    } else if (zl === 9) {
      // Хаос: рваные вспышки цвета
      const hue = Math.floor((now * 40) % 360);
      ctx.fillStyle = `hsla(${hue},70%,50%,0.05)`;
      ctx.fillRect(0, 0, W, H);
      if (Math.random() < 0.05) {
        ctx.fillStyle = `hsla(${(hue + 120) % 360},80%,60%,0.1)`;
        ctx.fillRect(0, 0, W, H);
      }
      for (let i = 0; i < 12; i++) {
        const x = ((i * 191.3 + now * 30) % (W + 60)) - 30;
        const y = ((i * 71.7 + now * 18) % (H + 60)) - 30;
        ctx.fillStyle = `hsla(${(hue + i * 30) % 360},80%,65%,0.5)`;
        ctx.fillRect(x, y, 3 + (i % 3) * 2, 3 + (i % 4) * 2);
      }
    }
  }

  // виньетка тёплая
  const vg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.42, W / 2, H / 2, Math.max(W, H) * 0.72);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, `rgba(20,10,16,${0.34 + night * 0.1})`);
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);

  // урон по игроку — красная рамка
  if (e.dmgFlash > 0.02) {
    const dg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.7);
    dg.addColorStop(0, "rgba(200,40,30,0)");
    dg.addColorStop(1, `rgba(200,40,30,${(e.dmgFlash * 0.45).toFixed(2)})`);
    ctx.fillStyle = dg;
    ctx.fillRect(0, 0, W, H);
  }
}

// ---- Пламя (костёр/факел) ----
function drawFlame(ctx: CanvasRenderingContext2D, x: number, y: number, size: number, t: number) {
  ctx.save();
  ctx.translate(x, y);
  // тёплый свет вокруг
  const g = ctx.createRadialGradient(0, -size * 0.6, 1, 0, -size * 0.6, size * 3.2);
  g.addColorStop(0, "rgba(255,190,90,0.42)");
  g.addColorStop(0.45, "rgba(255,140,50,0.16)");
  g.addColorStop(1, "rgba(255,120,40,0)");
  ctx.fillStyle = g;
  ctx.fillRect(-size * 3.2, -size * 4.4, size * 6.4, size * 6.4);

  // три языка пламени со своей фазой
  const tongues: [number, number, string, number][] = [
    [-0.42, 0.72, "#d8461e", 7.3],
    [0.38, 0.8, "#f2762e", 9.1],
    [0, 1, "#ff9a3c", 6.2],
  ];
  for (const [off, sc, col, sp] of tongues) {
    const w1 = Math.sin(t * sp) * 0.3;
    const w2 = Math.sin(t * (sp * 1.4) + 2) * 0.24;
    const h = size * 2.3 * sc * (1 + Math.sin(t * sp * 0.7) * 0.12);
    ctx.beginPath();
    ctx.moveTo(off * size - size * 0.72 * sc, 0);
    ctx.quadraticCurveTo(off * size - size * (0.86 + w1) * sc, -h * 0.5, off * size + w2 * size * 0.6, -h);
    ctx.quadraticCurveTo(off * size + size * (0.86 - w1) * sc, -h * 0.5, off * size + size * 0.72 * sc, 0);
    ctx.closePath();
    const fg = ctx.createLinearGradient(0, 0, 0, -h);
    fg.addColorStop(0, "rgba(190,50,20,0.9)");
    fg.addColorStop(0.45, col);
    fg.addColorStop(1, "rgba(255,225,150,0.95)");
    ctx.fillStyle = fg;
    ctx.fill();
  }
  // раскалённое ядро
  const cw = Math.sin(t * 11) * 0.2;
  ctx.fillStyle = "#fff3c9";
  ctx.beginPath();
  ctx.ellipse(cw * size * 0.3, -size * 0.55, size * 0.3, size * 0.62, cw, 0, 7);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.75)";
  ctx.beginPath();
  ctx.ellipse(cw * size * 0.2, -size * 0.4, size * 0.13, size * 0.28, cw, 0, 7);
  ctx.fill();
  ctx.restore();
}

// ---- Игрок ----
function drawPlayer(ctx: CanvasRenderingContext2D, e: Engine, now: number) {
  const p = e.player;
  const x = p.x, y = p.y;
  const shadow = getShadowSprite();
  ctx.drawImage(shadow, x - 22, y - 4, 44, 16);
  const bob = p.moving ? Math.sin(now * 10) * 1.6 : Math.sin(now * 2.2) * 0.8;
  const py = y - 14 + bob;
  const flip = Math.cos(p.dir) < 0 ? -1 : 1;

  ctx.save();
  ctx.translate(x, py);
  ctx.scale(flip, 1);

  // тело
  const bc = p.equip.body ?? "";
  const bodyCol = bc.includes("zhel") ? "#9aa2ad" : bc.includes("med") ? "#b8816a" : bc === "shuba" ? "#8a7a6a" : bc ? "#7a5f45" : "#5d6e4a";
  ctx.fillStyle = bodyCol;
  ctx.beginPath();
  ctx.ellipse(0, 0, 8.5, 10.5, 0, 0, 7);
  ctx.fill();
  // ремень
  ctx.fillStyle = "#3a3122";
  ctx.fillRect(-8, 2, 16, 2.4);
  // голова
  ctx.fillStyle = "#e8b68a";
  ctx.beginPath();
  ctx.arc(0, -13, 6.8, 0, 7);
  ctx.fill();
  // голова: шлем/капюшон
  if (p.equip.head) {
    ctx.fillStyle = p.equip.head.includes("zhel") ? "#aab2bd" : p.equip.head.includes("med") ? "#c08a6a" : "#6d5540";
    ctx.beginPath();
    ctx.arc(0, -14.5, 7.2, Math.PI * 0.95, Math.PI * 2.05);
    ctx.fill();
  } else {
    ctx.fillStyle = "#4a3826";
    ctx.beginPath();
    ctx.arc(0, -15.5, 6.9, Math.PI, Math.PI * 2);
    ctx.fill();
  }
  // глаза
  ctx.fillStyle = "#2c2420";
  ctx.beginPath(); ctx.arc(2.6, -12.6, 1, 0, 7); ctx.fill();
  ctx.beginPath(); ctx.arc(5.4, -12.6, 1, 0, 7); ctx.fill();

  // руки + взмах оружия
  ctx.strokeStyle = "#e8b68a";
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(-7, -2); ctx.lineTo(-9.5, 4); ctx.stroke();
  const sw = p.swing > 0 ? Math.sin((0.3 - p.swing) * Math.PI / 0.3) : 0;
  ctx.beginPath(); ctx.moveTo(7, -2); ctx.lineTo(9.5 + sw * 6, 4 - sw * 9); ctx.stroke();
  if (sw > 0) {
    // дуга взмаха
    ctx.strokeStyle = `rgba(240,230,210,${(sw * 0.9).toFixed(2)})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(6, -2, 15, -0.7, 0.9);
    ctx.stroke();
  }
  // оружие в руке
  const wId = p.equip.weapon;
  if (wId) {
    const metal = wId.includes("zhel") ? "#c8ced6" : wId.includes("med") ? "#d89a72" : "#9a938a";
    ctx.strokeStyle = "#6d4c33";
    ctx.lineWidth = 2.6;
    const hx = 9.5 + sw * 6, hy = 4 - sw * 9;
    ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(hx + 3, hy - 9); ctx.stroke();
    ctx.strokeStyle = metal;
    ctx.lineWidth = 3.4;
    ctx.beginPath(); ctx.moveTo(hx + 3, hy - 9); ctx.lineTo(hx + 5, hy - 17); ctx.stroke();
  }
  ctx.restore();

  // яд — зелёные пузыри
  if (p.poisonT > 0 && Math.random() < 0.1) {
    e.particles.push({ x: x + (Math.random() - 0.5) * 16, y: y - 16, vx: 0, vy: -22, age: 0, life: 0.7, color: "#8ae68a", size: 2, grav: -10, kind: "puff" });
  }
}

// ---- Мобы ----
/** Все описания мобов: базовые + обитатели иных слоёв + бестиарий монстров */
const ALL_MOBS: Record<string, import("../types").MobDef> = { ...MOBS, ...LAYER_MOBS, ...MONSTER_MOBS, ...BOSS_MOBS };

// --- Перекраска спрайтов монстров: базовое тело рисуется в офскрин,
// --- затем поверх накладывается цвет (source-atop, сохраняет тени и объём).
let tintCanvas: HTMLCanvasElement | null = null;
const TINT_SZ = 128;
function drawTintedBody(
  ctx: CanvasRenderingContext2D, baseId: string, tint: string, c: MobDrawCtx,
): boolean {
  if (!tintCanvas) {
    tintCanvas = document.createElement("canvas");
    tintCanvas.width = tintCanvas.height = TINT_SZ;
  }
  const tc = tintCanvas.getContext("2d")!;
  tc.setTransform(1, 0, 0, 1, 0, 0);
  tc.globalCompositeOperation = "source-over";
  tc.globalAlpha = 1;
  tc.clearRect(0, 0, TINT_SZ, TINT_SZ);
  // тело в точке (TINT_SZ/2, TINT_SZ*0.55) — как локальная (0,0) у обычной отрисовки
  tc.save();
  tc.translate(TINT_SZ / 2, TINT_SZ * 0.55);
  // перекраска умеет и босс-базы (владыки 8-го этапа используют их как основу)
  const ok = drawMobBody(tc, baseId, c) || drawBossBody(tc, baseId, c);
  tc.restore();
  if (!ok) return false;
  // окраска: цвет смешивается с пикселями спрайта, альфа и шейдинг сохраняются
  tc.globalCompositeOperation = "source-atop";
  tc.globalAlpha = 0.55;
  tc.fillStyle = tint;
  tc.fillRect(0, 0, TINT_SZ, TINT_SZ);
  // лёгкий тёплый блик сверху, чтобы силуэт не «плоскел»
  const hi = tc.createLinearGradient(0, 0, 0, TINT_SZ);
  hi.addColorStop(0, "rgba(255,255,255,0.16)");
  hi.addColorStop(0.45, "rgba(255,255,255,0)");
  tc.globalAlpha = 1;
  tc.fillStyle = hi;
  tc.fillRect(0, 0, TINT_SZ, TINT_SZ);
  tc.globalCompositeOperation = "source-over";
  ctx.drawImage(tintCanvas, -TINT_SZ / 2, -TINT_SZ * 0.55);
  return true;
}

/** Аура элитного («древнего») существа — между тенью и телом */
function eliteAura(ctx: CanvasRenderingContext2D, x: number, y: number, now: number, s: number, tint: string) {
  const pulse = 1 + Math.sin(now * 3.1) * 0.14;
  const r = 30 * s * pulse;
  const g = ctx.createRadialGradient(x, y - 10 * s, 2, x, y - 10 * s, r);
  g.addColorStop(0, tint + "3d");
  g.addColorStop(0.7, tint + "14");
  g.addColorStop(1, tint + "00");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y - 10 * s, r, 0, 7);
  ctx.fill();
  // пульсирующее кольцо у ног
  ctx.strokeStyle = tint + "55";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.ellipse(x, y - 2, 20 * s * pulse, 7 * s * pulse, 0, 0, 7);
  ctx.stroke();
}

function drawMob(ctx: CanvasRenderingContext2D, m: Mob, now: number, e: Engine) {
  const def = ALL_MOBS[m.def];
  if (!def) return;
  const isBoss = BOSS_IDS.has(m.def) || def.ai === "boss";
  const s = def.scale;
  const x = m.x, y = m.y;
  // «дыхание»: масштаб + лёгкое покачивание по вертикали
  const breathe = 1 + Math.sin(m.breathe * 2.6) * 0.035;
  const bob = Math.sin(m.breathe * 2.6) * 1.2;

  // аура боссов — под телом (для владык берём ауру спрайта-основы, иначе фирменное кольцо)
  if (isBoss) {
    const auraOk = bossAura(ctx, def.spriteBase ?? m.def, x, y, now, s);
    if (!auraOk) eliteAura(ctx, x, y, now, s, def.tint ?? "#f2a24d");
  }
  // аура элитных («древних») существ
  if (!isBoss && def.elite) eliteAura(ctx, x, y, now, s, def.tint ?? "#e88ad8");

  // мягкая тень со смещением вниз-вправо
  const shadow = getShadowSprite();
  ctx.drawImage(shadow, x - 23 * s + 2.5 * s, y - 7, 46 * s, 16 * s);

  ctx.save();
  ctx.translate(x, y - 10 * s + bob);
  const face = e.player.x < x ? -1 : 1;
  ctx.scale(face * s * breathe, s * breathe);

  const dctx: MobDrawCtx = {
    now, breathe: m.breathe,
    moving: m.state === "chase" || m.state === "wander" || m.state === "flee",
    state: m.state, fuse: m.fuse ?? 0,
  };
  // базовый спрайт и перекраска (бестиарий и владыки используют спрайты-основы с тонировкой)
  const baseId = def.spriteBase ?? m.def;
  let drawn = isBoss && !def.spriteBase ? drawBossBody(ctx, m.def, dctx) : false;
  if (!drawn) drawn = def.tint ? drawTintedBody(ctx, baseId, def.tint, dctx)
    : drawMobBody(ctx, baseId, dctx) || drawBossBody(ctx, baseId, dctx);
  if (!drawn) {
    // запасной силуэт для неизвестных существ
    ctx.beginPath();
    ctx.ellipse(0, 0, 9, 8, 0, 0, 7);
    const g = ctx.createRadialGradient(-3, -4, 1, 0, 1, 11);
    g.addColorStop(0, "#9a8f86");
    g.addColorStop(1, "#4a423c");
    ctx.fillStyle = g;
    ctx.fill();
    ctx.strokeStyle = "rgba(14,10,12,0.8)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = "#e0483c";
    ctx.beginPath(); ctx.arc(-2.4, -2, 1.1, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(2.4, -2, 1.1, 0, 7); ctx.fill();
  }

  // белая вспышка при ударе
  if (m.flash > 0) {
    ctx.globalAlpha = Math.min(1, m.flash * 9);
    ctx.globalCompositeOperation = "lighter";
    const fg = ctx.createRadialGradient(0, -4, 1, 0, -4, 16 * (isBoss ? 1.8 : 1));
    fg.addColorStop(0, "rgba(255,255,255,0.9)");
    fg.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = fg;
    ctx.beginPath();
    ctx.arc(0, -4, 16 * (isBoss ? 1.8 : 1), 0, 7);
    ctx.fill();
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;
  }
  ctx.restore();

  // HP-бар сегментный
  if (m.hp < m.maxHp || def.night || isBoss) {
    const w = isBoss ? 74 : 38;
    const segs = isBoss ? 12 : Math.min(8, Math.max(3, Math.round(m.maxHp / 14)));
    const frac = clamp01(m.hp / m.maxHp);
    const hue = frac > 0.5 ? 105 : frac > 0.25 ? 45 : 12;
    const bx = x - w / 2, by = y - (isBoss ? 30 * s + 14 : 30 * s + 8);
    ctx.fillStyle = "rgba(10,6,4,0.72)";
    ctx.fillRect(bx - 1, by - 1, w + 2, 6);
    for (let i = 0; i < segs; i++) {
      const segW = w / segs;
      const on = i / segs < frac;
      ctx.fillStyle = on ? `hsl(${hue},72%,52%)` : "rgba(60,40,36,0.8)";
      ctx.fillRect(bx + i * segW + 0.6, by, segW - 1.2, 4);
    }
    // блик на полосе
    ctx.fillStyle = "rgba(255,255,255,0.18)";
    ctx.fillRect(bx, by, w, 1.6);
  }
  // имя босса
  if (isBoss) {
    const by = y - (30 * s + 22);
    ctx.font = "800 13px Georgia";
    ctx.textAlign = "center";
    ctx.lineWidth = 3.4;
    ctx.strokeStyle = "rgba(0,0,0,0.85)";
    ctx.strokeText(def.name.toUpperCase(), x, by);
    ctx.fillStyle = "#f2a24d";
    ctx.fillText(def.name.toUpperCase(), x, by);
  } else if (def.elite) {
    // имя элитного («древнего») существа
    const by = y - (30 * s + 18);
    ctx.font = "700 10px Georgia";
    ctx.textAlign = "center";
    ctx.lineWidth = 2.8;
    ctx.strokeStyle = "rgba(0,0,0,0.85)";
    ctx.strokeText(def.name.toUpperCase(), x, by);
    ctx.fillStyle = def.tint ?? "#e88ad8";
    ctx.fillText(def.name.toUpperCase(), x, by);
  }
  // шкала взрыва
  if (m.state === "boom") {
    const frac = 1 - (m.fuse ?? 0) / 1.15;
    ctx.strokeStyle = "#f2762e";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(m.x, m.y - 12, 18, -Math.PI / 2, -Math.PI / 2 + frac * Math.PI * 2);
    ctx.stroke();
  }
  void fishT; void birdFly;
}
