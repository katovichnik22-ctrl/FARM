import { G, O, CHUNK, Biome, type ObjId } from "../types";
import { fbm, hash2, clamp, clamp01 } from "../lib/noise";
import { layerTile, layerMiniColor } from "./layergen";
import { applyAnomaly } from "./anomalies";

// ===== Генерация мира. Всё детерминировано сидом. =====

export function heightN(seed: number, x: number, y: number): number {
  return fbm((seed ^ 0x1a2b3c) | 0, x / 420, y / 420, 4);
}
export function tempN(seed: number, x: number, y: number): number {
  return fbm((seed ^ 0x4d5e6f) | 0, x / 560 + 31, y / 560 + 17, 3);
}
export function moistN(seed: number, x: number, y: number): number {
  return fbm((seed ^ 0x7a8b9c) | 0, x / 360 + 91, y / 360 + 47, 3);
}

export function biomeAt(seed: number, tx: number, ty: number, z: number = 0): Biome {
  if (z !== 0) return Biome.Cave;
  const h = heightN(seed, tx, ty);
  if (h < 0.3) return Biome.Ocean;
  if (h < 0.348) return Biome.Beach;
  const t = tempN(seed, tx, ty);
  const m = moistN(seed, tx, ty);
  if (h > 0.74) return Biome.SnowMount;
  if (t < 0.3) return Biome.Tundra;
  if (t > 0.63 && m < 0.42) return Biome.Desert;
  if (m > 0.71 && h < 0.55) return Biome.Swamp;
  if (m > 0.44) return Biome.Forest;
  return Biome.Meadow;
}

// ---- Зоны риска: 8 колец по 224 тайла ----
export const ZONE_STEP = 224;
export function zoneAt(tx: number, ty: number): number {
  const d = Math.max(Math.abs(tx), Math.abs(ty));
  return Math.min(7, Math.floor(d / ZONE_STEP));
}
export const ZONE_NAMES = [
  "Зелёный Порог", "Тихие Поля", "Ветровой Край", "Волчьи Тропы",
  "Старые Рудники", "Пепел и Кость", "Владения Морока", "Край Дракона",
];
export const zoneHpMult = (z: number) => 1 + z * 0.22;
export const zoneDmgMult = (z: number) => 1 + z * 0.16;

// ---- Арена Древнего Дракона ----
export function arenaCenter(seed: number): { x: number; y: number } {
  const ang = hash2(seed, 777, 13) * Math.PI * 2;
  const dist = 3.4 * ZONE_STEP;
  return { x: Math.round(Math.cos(ang) * dist), y: Math.round(Math.sin(ang) * dist) };
}
const ARENA_R = 13;
export function inArena(seed: number, tx: number, ty: number): boolean {
  const a = arenaCenter(seed);
  const dx = tx - a.x, dy = ty - a.y;
  return dx * dx + dy * dy < ARENA_R * ARENA_R;
}

// ---- Здоровье объектов ----
export function objMaxHp(o: ObjId): number {
  switch (o) {
    case O.Oak: return 40; case O.Pine: return 34; case O.Birch: return 30;
    case O.Bush: return 14; case O.Rock: return 46; case O.Coal: return 40;
    case O.Copper: return 52; case O.Iron: return 66; case O.Gold: return 60;
    case O.Mushroom: return 8; case O.Clay: return 22; case O.GlowShroom: return 8;
    case O.Chest: return 30; case O.Cactus: return 16;
    case O.Mithril: return 90; case O.Adamant: return 130; case O.Crystal: return 50;
    case O.LavaVent: return 70; case O.SkyCrystal: return 70; case O.CloudTree: return 40;
    case O.Pearl: return 26; case O.CoralObj: return 30; case O.Seaweed: return 12;
    case O.Wreck: return 80; case O.MoonOre: return 95; case O.MarsOre: return 110;
    case O.AlienRelic: return 120; case O.ShadowTree: return 60; case O.DreamFlower: return 18;
    case O.ChaosOrb: return 100; case O.Mechanism: return 85; case O.RuinChest: return 40;
    case O.Trap: return 20;
    // лежачие находки — подбираются с одного касания
    case O.Pebble: case O.Stick: case O.FlintShard: case O.ClayLump:
    case O.CoalBit: case O.OldCoin: case O.FeatherG: return 3;
    case O.FallenLog: return 5;
    default: return 12;
  }
}

// ---- Лут детерминированный от координат (для сундуков) ----
export function chestLoot(seed: number, tx: number, ty: number): { id: string; n: number }[] {
  const zone = zoneAt(tx, ty);
  const r = (k: number) => hash2(seed ^ 0xc1e5, tx * 7 + k, ty * 13 + k);
  const loot: { id: string; n: number }[] = [];
  loot.push({ id: "zoloto", n: 3 + Math.floor(r(1) * (6 + zone * 5)) });
  if (r(2) < 0.6) loot.push({ id: "ugol", n: 1 + Math.floor(r(3) * 3) });
  if (r(4) < 0.45) loot.push({ id: "med_ruda", n: 1 + Math.floor(r(5) * (2 + zone)) });
  if (zone >= 2 && r(6) < 0.4) loot.push({ id: "zhel_ruda", n: 1 + Math.floor(r(7) * (1 + zone)) });
  if (r(8) < 0.35) loot.push({ id: "bint", n: 1 + Math.floor(r(9) * 2) });
  if (zone >= 3 && r(10) < 0.18) loot.push({ id: "cheshuya", n: 1 });
  if (r(11) < 0.3) loot.push({ id: "zharkoe", n: 1 + Math.floor(r(12) * 2) });
  return loot;
}

export interface TileInfo { g: number; o: number; hp: number }

// ---- Объекты поверхности: ствол/камень/руда/куст НИКОГДА не стоят вплотную ----
// Правило леса (как в Minecraft/Terraria): дерево занимает ровно один тайл со стволом
// (крона — только графика и прохода не держит), а между любыми двумя объектами
// всегда есть свободный тайл: любые два «крупных» объекта разнесены минимум на
// 2 тайла по Чебышёву — и стволы, и валуны, и жилы, и ягодные кусты.
// Куст остаётся проходимым («мягким», hard=false), но в споре за место участвует
// наравне с твёрдыми, поэтому нигде не лепится вплотную к деревьям и камням.

interface SurfCand { o: number; v: number; hard: boolean }

/** Кандидат на крупный объект поверхности — чистая функция от сида и координат */
function surfaceCand(seed: number, tx: number, ty: number): SurfCand | null {
  const b = biomeAt(seed, tx, ty);
  const r1 = hash2(seed ^ 0x0b1, tx, ty);
  const r2 = hash2(seed ^ 0x0b2, tx, ty);
  const r3 = hash2(seed ^ 0x0b3, tx, ty);
  const v = hash2(seed ^ 0x5ace, tx, ty); // жребий в споре соседей
  const T = true, F = false;
  switch (b) {
    case Biome.Meadow:
      if (r1 >= 0.275 && r1 < 0.3) return { o: O.Oak, v, hard: T };
      if (r1 >= 0.3 && r1 < 0.315) return { o: O.Rock, v, hard: T };
      if (r1 >= 0.24 && r1 < 0.275) return { o: O.Bush, v, hard: F };
      return null;
    case Biome.Forest: {
      const density = fbm(seed ^ 0xf0e, tx / 90, ty / 90, 2);
      if (r2 < density * 0.42) return { o: r3 < 0.55 ? O.Oak : r3 < 0.8 ? O.Birch : O.Pine, v, hard: T };
      if (r1 >= 0.1 && r1 < 0.115) return { o: O.Rock, v, hard: T };
      if (r1 >= 0.03 && r1 < 0.14) return { o: O.Bush, v, hard: F };
      return null;
    }
    case Biome.Desert:
      if (r1 < 0.03) return { o: O.Cactus, v, hard: T };
      if (r1 >= 0.07 && r1 < 0.085) return { o: O.Rock, v, hard: T };
      return null;
    case Biome.Tundra:
      if (r1 < 0.06) return { o: O.Pine, v, hard: T };
      if (r1 >= 0.06 && r1 < 0.1) return { o: O.Bush, v, hard: F };
      if (r1 >= 0.1 && r1 < 0.13) return { o: O.Rock, v, hard: T };
      return null;
    case Biome.SnowMount: {
      const slope = clamp01((heightN(seed, tx, ty) - 0.72) / 0.2);
      if (r2 < slope * 0.3) {
        const ore = hash2(seed ^ 0x0e8, tx, ty);
        return { o: ore < 0.34 ? O.Coal : ore < 0.55 ? O.Copper : ore < 0.82 ? O.Iron : ore < 0.9 ? O.Gold : O.Rock, v, hard: T };
      }
      if (r1 < 0.05) return { o: O.Pine, v, hard: T };
      if (r1 >= 0.05 && r1 < 0.09) return { o: O.Rock, v, hard: T };
      return null;
    }
    case Biome.Swamp:
      if (r1 >= 0.13 && r1 < 0.135) return { o: O.Oak, v, hard: T };
      return null;
    default:
      return null;
  }
}

/** Мелкий мягкий декор поверхности (трава, цветы, грибы — всегда проходим) */
function decorObject(seed: number, tx: number, ty: number): number {
  const b = biomeAt(seed, tx, ty);
  const r1 = hash2(seed ^ 0x0b1, tx, ty);
  switch (b) {
    case Biome.Meadow:
      return r1 < 0.05 ? O.FlowerR : r1 < 0.1 ? O.FlowerY : r1 < 0.24 ? O.GrassTuft : O.None;
    case Biome.Forest:
      return r1 < 0.03 ? O.Mushroom : r1 < 0.09 ? O.GrassTuft : O.None;
    case Biome.Desert:
      return r1 >= 0.03 && r1 < 0.07 ? O.DeadBush : r1 >= 0.085 && r1 < 0.095 ? O.Bones : O.None;
    case Biome.Tundra:
      return r1 >= 0.13 && r1 < 0.16 ? O.Mushroom : r1 >= 0.06 && r1 < 0.1 ? O.GrassTuft : r1 >= 0.16 && r1 < 0.24 ? O.GrassTuft : O.None;
    case Biome.Swamp:
      return r1 < 0.05 ? O.Reeds : r1 < 0.09 ? O.Mushroom : r1 < 0.12 ? O.Clay : r1 < 0.16 ? O.GrassTuft : O.None;
    default:
      return O.None;
  }
}

/**
 * «Лежачие» находки (9-й этап): камешки, хворост, поваленные стволы, осколки кремня,
 * комья глины, угольки, монеты и пёрышки, рассыпанные по земле.
 * Подбираются голыми руками с одного касания. Раздаётся отдельным жребием
 * (свои соли), поэтому старые миры сохраняют прежнюю расстановку объектов,
 * а находки появляются лишь на тайлах, где раньше ничего не было.
 */
function groundItem(seed: number, tx: number, ty: number, table: [number, number][]): number {
  const g = hash2(seed ^ 0x6e1d, tx, ty);
  for (const [obj, chance] of table) if (g < chance) return obj;
  return O.None;
}

/** Таблицы находок по биомам: [объект, накопительный шанс] — чем раньше в списке, тем реже */
const GROUND_MEADOW: [number, number][] = [
  [O.OldCoin, 0.0006], [O.FeatherG, 0.004], [O.Stick, 0.02], [O.Pebble, 0.046],
];
const GROUND_FOREST: [number, number][] = [
  [O.OldCoin, 0.0007], [O.FeatherG, 0.006], [O.FallenLog, 0.02], [O.Pebble, 0.036], [O.Stick, 0.07],
];
const GROUND_DESERT: [number, number][] = [
  [O.OldCoin, 0.0009], [O.FlintShard, 0.007], [O.Pebble, 0.026],
];
const GROUND_TUNDRA: [number, number][] = [
  [O.OldCoin, 0.0005], [O.CoalBit, 0.004], [O.FlintShard, 0.009], [O.Stick, 0.021], [O.Pebble, 0.04],
];
const GROUND_SNOWMOUNT: [number, number][] = [
  [O.OldCoin, 0.0008], [O.CoalBit, 0.006], [O.FlintShard, 0.016], [O.Pebble, 0.042],
];
const GROUND_SWAMP: [number, number][] = [
  [O.OldCoin, 0.0005], [O.ClayLump, 0.013], [O.Pebble, 0.021], [O.Stick, 0.034],
];
const GROUND_BEACH: [number, number][] = [
  [O.OldCoin, 0.0012], [O.FlintShard, 0.008], [O.ClayLump, 0.02], [O.Pebble, 0.056],
];
const GROUND_CAVE: [number, number][] = [
  [O.OldCoin, 0.0012], [O.FlintShard, 0.006], [O.CoalBit, 0.014], [O.Pebble, 0.038],
];

function groundTableFor(b: Biome): [number, number][] | null {
  switch (b) {
    case Biome.Meadow: return GROUND_MEADOW;
    case Biome.Forest: return GROUND_FOREST;
    case Biome.Desert: return GROUND_DESERT;
    case Biome.Tundra: return GROUND_TUNDRA;
    case Biome.SnowMount: return GROUND_SNOWMOUNT;
    case Biome.Swamp: return GROUND_SWAMP;
    default: return null;
  }
}

/** «Сырой» кандидат на провал в пещеру (без учёта соседей) */
function caveCandAt(seed: number, tx: number, ty: number): { g: number; o: number; v: number } | null {
  const b = biomeAt(seed, tx, ty);
  const r1 = hash2(seed ^ 0x0b1, tx, ty);
  const v = hash2(seed ^ 0x5ace, tx, ty);
  if (b === Biome.Forest && r1 > 0.997) return { g: G.Dirt, o: O.CaveIn, v };
  if (b === Biome.SnowMount && r1 > 0.996) return { g: G.Stone, o: O.CaveIn, v };
  return null;
}

/** Провал в пещеру: имеет приоритет над объектами, держит простор вокруг себя
 *  и никогда не сливается с соседним провалом (тот же спор жребиев). */
function caveInAt(seed: number, tx: number, ty: number): { g: number; o: number } | null {
  const c = caveCandAt(seed, tx, ty);
  if (!c) return null;
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dy === 0) continue;
      const nc = caveCandAt(seed, tx + dx, ty + dy);
      if (nc && nc.v < c.v) return null;
    }
  }
  return c;
}

/** Выживает ли кандидат: рядом (Чебышёв 1) нет ни входа в пещеру, ни более важного
 *  соседа-кандидата (дерева, камня, жилы или куста) — итог: минимум один свободный
 *  тайл между любыми двумя крупными объектами. */
function candSurvives(seed: number, tx: number, ty: number, cand: SurfCand): boolean {
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dy === 0) continue;
      if (caveInAt(seed, tx + dx, ty + dy)) return false;
      const nc = surfaceCand(seed, tx + dx, ty + dy);
      if (nc && nc.v < cand.v) return false;
    }
  }
  return true;
}

// ---- Чистая функция тайла: поверхность ----
function surfaceTile(seed: number, tx: number, ty: number): TileInfo {
  if (inArena(seed, tx, ty)) {
    const r = hash2(seed ^ 0xa5ea, tx, ty);
    return { g: G.Ash, o: r < 0.02 ? O.Bones : O.None, hp: 0 };
  }
  const h = heightN(seed, tx, ty);
  const biome = biomeAt(seed, tx, ty);
  const r1 = hash2(seed ^ 0x0b1, tx, ty);
  const d: TileInfo = { g: G.Grass, o: O.None, hp: 0 };

  // вода, пляж и болотные лужи — как раньше (твёрдых объектов там не бывает)
  if (biome === Biome.Ocean) {
    d.g = h < 0.2 ? G.DeepWater : G.Water;
    return d;
  }
  if (biome === Biome.Beach) {
    d.g = G.Sand;
    d.o = r1 < 0.05 ? O.Clay : r1 < 0.075 ? O.Reeds : O.None;
    if (d.o === O.None) d.o = groundItem(seed, tx, ty, GROUND_BEACH);
    d.hp = objMaxHp(d.o as ObjId);
    return d;
  }
  if (biome === Biome.Swamp && fbm(seed ^ 0x5a9, tx / 46, ty / 46, 2) > 0.62) {
    d.g = G.Water;
    return d;
  }

  // грунт биома
  d.g = biome === Biome.Meadow ? G.Grass
    : biome === Biome.Forest ? G.Meadow
    : biome === Biome.Desert ? G.Desert
    : biome === Biome.Tundra ? G.Snow
    : biome === Biome.SnowMount ? (clamp01((h - 0.72) / 0.2) > 0.45 ? G.SnowRock : G.Snow)
    : biome === Biome.Swamp ? G.Swamp
    : G.Grass;

  // вход в пещеру — приоритетный
  const cave = caveInAt(seed, tx, ty);
  if (cave) {
    d.g = cave.g; d.o = cave.o; d.hp = objMaxHp(O.CaveIn);
    return d;
  }

  // крупный объект: уступил соседу — на тайле остаётся только мелкий декор
  const cand = surfaceCand(seed, tx, ty);
  let o = cand && candSurvives(seed, tx, ty, cand) ? cand.o : decorObject(seed, tx, ty);
  // пустая земля — вдруг на ней что-то лежит?
  if (o === O.None) {
    const table = groundTableFor(biome);
    if (table) o = groundItem(seed, tx, ty, table);
  }
  d.o = o;
  d.hp = objMaxHp(o as ObjId);
  return d;
}

// ---- Чистая функция тайла: пещера ----
function caveTile(seed: number, tx: number, ty: number): TileInfo {
  const base = fbm(seed ^ 0xca7e, tx / 30, ty / 30, 4);
  const zone = zoneAt(tx, ty);
  const d: { g: number; o: number; hp: number } = { g: G.CaveWall, o: O.None, hp: 0 };
  const set = (g: number, o: number) => { d.g = g; d.o = o; d.hp = objMaxHp(o as ObjId); };

  if (base > 0.46) {
    // пол пещеры
    const r = hash2(seed ^ 0xc2, tx, ty);
    let o: number = r < 0.006 + zone * 0.0012 ? O.Chest : r < 0.02 ? O.GlowShroom : O.None;
    if (o === O.None) o = groundItem(seed, tx, ty, GROUND_CAVE);
    set(G.CaveFloor, o);
    return d;
  }
  // стены с рудами: смотрим соседний пол
  const n1 = fbm(seed ^ 0xca7e, (tx + 1) / 30, ty / 30, 4) > 0.46;
  const n2 = fbm(seed ^ 0xca7e, (tx - 1) / 30, ty / 30, 4) > 0.46;
  const n3 = fbm(seed ^ 0xca7e, tx / 30, (ty + 1) / 30, 4) > 0.46;
  const n4 = fbm(seed ^ 0xca7e, tx / 30, (ty - 1) / 30, 4) > 0.46;
  if (n1 || n2 || n3 || n4) {
    const r = hash2(seed ^ 0xc3, tx, ty);
    if (r < 0.34) {
      const ore = hash2(seed ^ 0xc4, tx, ty);
      set(G.CaveWall, ore < 0.3 ? O.Coal : ore < 0.52 ? O.Copper : ore < 0.72 - zone * 0.02 ? O.Iron : ore < 0.72 - zone * 0.02 + 0.035 * (1 + zone * 0.35) ? O.Gold : O.None);
    }
  }
  return d;
}

export function tileAt(seed: number, tx: number, ty: number, z: number): TileInfo {
  let base: TileInfo;
  if (z === 0) base = surfaceTile(seed, tx, ty);
  else if (z === 1) base = caveTile(seed, tx, ty);
  else base = layerTile(seed, tx, ty, z) ?? caveTile(seed, tx, ty);
  // аномальные зоны (8-й этап): поверх всех слоёв, чистой функцией от сида
  return applyAnomaly(seed, tx, ty, z, base);
}

// ---- Чанки с кэшем ----
export interface Chunk {
  g: Uint8Array; o: Uint8Array; hp: Uint8Array;
  key: string; t: number; // метка времени для LRU
}

const cache = new Map<string, Chunk>();
const MAX_CHUNKS = 220;
let clock = 0;

export function getChunk(seed: number, cx: number, cy: number, z: number, mods: Map<string, { o?: number; g?: number; hp?: number }>): Chunk {
  const key = `${seed}_${z}_${cx}_${cy}`;
  const hit = cache.get(key);
  if (hit) { hit.t = ++clock; return hit; }
  const g = new Uint8Array(CHUNK * CHUNK);
  const o = new Uint8Array(CHUNK * CHUNK);
  const hp = new Uint8Array(CHUNK * CHUNK);
  const x0 = cx * CHUNK, y0 = cy * CHUNK;
  for (let y = 0; y < CHUNK; y++) {
    for (let x = 0; x < CHUNK; x++) {
      const i = y * CHUNK + x;
      const tx = x0 + x, ty = y0 + y;
      const mod = mods.get(`${tx},${ty},${z}`);
      if (mod) {
        const base = tileAt(seed, tx, ty, z);
        g[i] = mod.g ?? base.g;
        o[i] = mod.o ?? base.o;
        hp[i] = mod.hp ?? objMaxHp(o[i] as ObjId);
      } else {
        const t = tileAt(seed, tx, ty, z);
        g[i] = t.g; o[i] = t.o; hp[i] = clamp(t.hp, 0, 255);
      }
    }
  }
  const chunk: Chunk = { g, o, hp, key, t: ++clock };
  cache.set(key, chunk);
  if (cache.size > MAX_CHUNKS) {
    let oldestKey = ""; let oldest = Infinity;
    for (const [k, c] of cache) { if (c.t < oldest) { oldest = c.t; oldestKey = k; } }
    if (oldestKey) cache.delete(oldestKey);
  }
  return chunk;
}

export function touchChunk(c: Chunk) { c.t = ++clock; }

// ---- Цвета для миникарты ----
export function miniColor(seed: number, tx: number, ty: number, z: number): string {
  if (z > 1) return layerMiniColor(seed, tx, ty, z) ?? "#444";
  if (z === 1) {
    const base = fbm(seed ^ 0xca7e, tx / 30, ty / 30, 3);
    return base > 0.46 ? "#3d3344" : "#171119";
  }
  const b = biomeAt(seed, tx, ty);
  switch (b) {
    case Biome.Ocean: return "#2c4f75";
    case Biome.Beach: return "#d8c290";
    case Biome.Meadow: return "#7fa55c";
    case Biome.Forest: return "#4d7a44";
    case Biome.Desert: return "#d9b568";
    case Biome.Tundra: return "#c9d3cf";
    case Biome.SnowMount: return "#e8edf2";
    case Biome.Swamp: return "#5c6e47";
    default: return "#7fa55c";
  }
}
