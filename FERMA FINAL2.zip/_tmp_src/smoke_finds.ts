// Безголовый прогон: находки, добыча голыми руками, целостность квестовой цепи
import { Engine } from "./src/game/engine";
import { O, TILE } from "./src/types";
import { STORY_QUESTS, QUEST_BY_ID } from "./src/data/story";
import { RECIPES } from "./src/data/recipes";
import { ITEMS } from "./src/data/items";

const ok: string[] = [];
const err: string[] = [];

// ---------- 1. Находки спавнятся рядом со спавном ----------
{
  const e = new Engine();
  e.newGame(12345, 1, "Тест");
  const counts: Record<number, number> = {};
  const R = 60;
  const ptx = Math.floor(e.player.x / TILE), pty = Math.floor(e.player.y / TILE);
  for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) {
    const t = e.tileOf(ptx + dx, pty + dy);
    if (t.o === O.Pebble || t.o === O.Stick || t.o === O.FallenLog || t.o === O.FlintShard ||
      t.o === O.ClayLump || t.o === O.CoalBit || t.o === O.OldCoin || t.o === O.FeatherG)
      counts[t.o] = (counts[t.o] ?? 0) + 1;
  }
  const names: Record<number, string> = {
    [O.Pebble]: "камешки", [O.Stick]: "хворост", [O.FallenLog]: "стволы", [O.FlintShard]: "кремень",
    [O.ClayLump]: "глина", [O.CoalBit]: "угольки", [O.OldCoin]: "монеты", [O.FeatherG]: "пёрышки",
  };
  const found = Object.entries(counts).map(([o, n]) => `${names[+o]}:${n}`).join(" ");
  if ((counts[O.Pebble] ?? 0) > 0) ok.push(`Находки в радиусе ${R} тайлов: ${found}`);
  else err.push("Камешков нет в радиусе 60 тайлов!");
}

// ---------- 2. Валун голыми руками: за N ударов даёт камень, кирка не нужна ----------
{
  const e = new Engine();
  e.newGame(777, 1, "Тест-руки");
  // убедимся, что кирки нет
  if (e.bestTool("pick").id) err.push("Стартовая кирка найдена — тест нечист");
  // найдём валун в радиусе 200
  const ptx = Math.floor(e.player.x / TILE), pty = Math.floor(e.player.y / TILE);
  let rx = -1, ry = -1;
  outer: for (let r = 1; r < 200; r++)
    for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
      const t = e.tileOf(ptx + dx, pty + dy);
      if (t.o === O.Rock) { rx = ptx + dx; ry = pty + dy; break outer; }
    }
  if (rx < 0) err.push("Не нашли валун в 200 тайлах");
  else {
    // передвинем игрока к валуну и бьём, пока не упадёт камень
    e.player.x = rx * TILE + TILE / 2 + 10; e.player.y = ry * TILE + TILE / 2 + 10;
    e.player.stamina = 100;
    const before = e.count("kamen");
    let hits = 0;
    for (let i = 0; i < 40 && e.count("kamen") === before; i++) {
      e.player.stamina = 100;
      e.doAction({ kind: "harvest", tx: rx, ty: ry });
      e.swingCd = 0;
      hits++;
    }
    if (e.count("kamen") > before) ok.push(`Валун разбит голыми руками за ${hits} ударов → камень получен`);
    else err.push("Валун голыми руками не разбивается!");
  }
}

// ---------- 3. Камешки подбираются с одного касания ----------
{
  const e = new Engine();
  e.newGame(999, 1, "Тест-подбор");
  const ptx = Math.floor(e.player.x / TILE), pty = Math.floor(e.player.y / TILE);
  let gx = -1, gy = -1;
  outer: for (let r = 1; r < 300; r++)
    for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
      const t = e.tileOf(ptx + dx, pty + dy);
      if (t.o === O.Pebble) { gx = ptx + dx; gy = pty + dy; break outer; }
    }
  if (gx < 0) err.push("Камешков нет в 300 тайлах");
  else {
    e.player.x = gx * TILE + TILE / 2; e.player.y = gy * TILE + TILE / 2;
    e.player.stamina = 100;
    const before = e.count("kamen");
    e.doAction({ kind: "harvest", tx: gx, ty: gy });
    if (e.count("kamen") > before && e.tileOf(gx, gy).o === O.None)
      ok.push(`Камешки подобраны с 1 касания → +${e.count("kamen") - before} камня`);
    else err.push("Камешки не подбираются с одного касания!");
  }
}

// ---------- 4. Сюжетная цепь непрерывна: q1_1 → ... → q5_5 ----------
{
  const missing = STORY_QUESTS.find((q) => q.next && !QUEST_BY_ID[q.next]);
  if (missing) err.push(`Квест ${missing.id} ведёт на несуществующий ${missing.next}`);
  const seen = new Set<string>();
  let cur: string | undefined = "q1_1";
  let steps = 0;
  while (cur) {
    if (seen.has(cur)) { err.push(`Петля в цепи квестов на ${cur}`); break; }
    seen.add(cur);
    cur = QUEST_BY_ID[cur]?.next;
    steps++;
    if (steps > 60) { err.push("Цепь длиннее 60 звеньев — похоже на цикл"); break; }
  }
  if (seen.has("q5_5") && seen.size === STORY_QUESTS.length)
    ok.push(`Сюжетная цепь непрерывна: ${seen.size}/${STORY_QUESTS.length} квестов от q1_1 до финала`);
  else if (!err.some((x) => x.includes("цеп")))
    err.push(`Цепь обрывается: достигнуто ${seen.size}/${STORY_QUESTS.length}, q5_5: ${seen.has("q5_5")}`);
}

// ---------- 5. Все цели квестов существуют (предметы/здания) ----------
{
  for (const q of STORY_QUESTS) {
    for (const g of q.goals) {
      if ((g.kind === "gather" || g.kind === "craft") && !ITEMS[g.target])
        err.push(`${q.id}: нет предмета ${g.target}`);
    }
  }
  if (!err.some((x) => x.includes("нет предмета"))) ok.push("Все предметные цели квестов существуют");
}

// ---------- 6. Стартовый замкнутый круг разомкнут: рецепт кирки досягаем ----------
{
  const kirka = RECIPES.find((r) => r.out === "kirka_k")!;
  const needs = kirka.needs.map(([id, n]) => `${id}×${n}`).join(" + ");
  ok.push(`Кирка требует ${needs} — камень теперь доступен с камешков и руками`);
}

console.log("\n=== OK ===");
for (const s of ok) console.log(" ✓", s);
if (err.length) {
  console.log("\n=== ОШИБКИ ===");
  for (const s of err) console.log(" ✗", s);
  process.exit(1);
}
console.log("\nВсе проверки пройдены.");
