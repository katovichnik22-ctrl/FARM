import { G, TILE } from "../types";
import { hash2 } from "../lib/noise";
import { drawObject, objSpriteBig, S } from "./sprites_objects";

// ===== Кэшированные процедурные спрайты. Рисуем один раз, используем всегда. =====

const cache = new Map<string, HTMLCanvasElement>();
const CACHE_LIMIT = 360;
/** FIFO-ограничение кэша: детальные спрайты весят память */
function cachePut(key: string, c: HTMLCanvasElement) {
  if (cache.size >= CACHE_LIMIT) {
    const first = cache.keys().next().value;
    if (first !== undefined) cache.delete(first);
  }
  cache.set(key, c);
}

function cv(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  return [c, c.getContext("2d")!];
}

// Палитры грунтов: [база, тень, свет, крап]
const GROUND_COLORS: Record<number, [string, string, string, string]> = {
  [G.DeepWater]: ["#274a6e", "#1e3c5c", "#35608c", "#4a79a8"],
  [G.Water]: ["#3d6b96", "#31608a", "#4a7ca9", "#7fa8c8"],
  [G.Sand]: ["#e0cd9b", "#d3be86", "#ecdcae", "#c4ae77"],
  [G.Grass]: ["#7fa95e", "#6f9750", "#92ba70", "#5e8548"],
  [G.Meadow]: ["#6e9a52", "#5d8745", "#83ad65", "#4e7440"],
  [G.Dirt]: ["#96704c", "#83603f", "#a97f58", "#6f5236"],
  [G.Desert]: ["#dfbe7c", "#d1ab67", "#edcd8c", "#bf9857"],
  [G.Snow]: ["#e9edf1", "#d9e0e7", "#f6f9fb", "#c3ced8"],
  [G.Stone]: ["#8e8a86", "#7c7873", "#a09c95", "#6a655f"],
  [G.Swamp]: ["#66734a", "#57633d", "#778556", "#4a5534"],
  [G.SnowRock]: ["#9ba0a4", "#878c92", "#dde3e8", "#6e7478"],
  [G.Ash]: ["#575049", "#463f3a", "#6a6158", "#39332e"],
  [G.CaveFloor]: ["#453c4d", "#383040", "#514859", "#2b2433"],
  [G.CaveWall]: ["#251f2c", "#1d1823", "#2f2738", "#14100f".slice(0, 7)],
  [G.FarmSoil]: ["#6e5238", "#5d452e", "#7d6043", "#4e3a26"],
  // --- слои 5-го этапа ---
  [G.Lava]: ["#e0662e", "#b8431c", "#ffb055", "#8a2c10"],
  [G.Obsidian]: ["#2e2635", "#241d2a", "#3d3347", "#171219"],
  [G.HellRock]: ["#4a2820", "#3a1e18", "#5f362a", "#2a1410"],
  [G.Cloud]: ["#1d2b3d", "#16212f", "#2a3d52", "#101823"],
  [G.SkyGrass]: ["#8fd0a0", "#76b788", "#a8e2b8", "#5f9a70"],
  [G.SeaFloor]: ["#2f6a86", "#265a73", "#3d7f9c", "#1c4658"],
  [G.CoralBed]: ["#c9756a", "#ad5f56", "#e8938a", "#8a4a44"],
  [G.DeepWaterCol]: ["#12405e", "#0d334c", "#1c5473", "#08283c"],
  [G.MoonDust]: ["#b8b2a4", "#a29c8f", "#d0cabc", "#8a857a"],
  [G.MarsSand]: ["#b0563a", "#96462e", "#c96f50", "#7a3724"],
  [G.VoidFloor]: ["#14121c", "#0e0c14", "#1f1c2a", "#08070c"],
  [G.ShadowGround]: ["#3a3048", "#2e263a", "#4a3f5c", "#221c2c"],
  [G.DreamGround]: ["#a874c9", "#8e5cae", "#c294e0", "#71458f"],
  [G.ChaosGround]: ["#8a3a7a", "#6f2c62", "#ab5098", "#54204a"],
  [G.MetalFloor]: ["#7d8893", "#69737d", "#96a1ac", "#555d66"],
};

const SEASON_TINT: [string, number][] = [
  ["#8fbf6a", 0.16], // весна — свежесть
  ["#ffd97a", 0.07], // лето — тепло
  ["#d98f3e", 0.22], // осень — рыжина
  ["#aec5d8", 0.16], // зима — холод
];
const isGreen = (g: number) => g === G.Grass || g === G.Meadow || g === G.Swamp;

export function groundSprite(g: number, variant: number, season: number): HTMLCanvasElement {
  const key = `g${g}_${variant}_${season}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const [c, ctx] = cv(TILE, TILE);
  const [base, dark, light, speck] = GROUND_COLORS[g] ?? GROUND_COLORS[G.Grass];
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, TILE, TILE);

  // крупные мягкие пятна
  for (let i = 0; i < 5; i++) {
    const r = hash2(g * 91 + variant * 17, i, 3);
    ctx.fillStyle = r > 0.5 ? dark : light;
    ctx.globalAlpha = 0.3;
    ctx.beginPath();
    ctx.arc(hash2(g, i, variant) * TILE, hash2(g + 3, variant, i) * TILE, 4 + r * 9, 0, 7);
    ctx.fill();
  }
  // крап
  for (let i = 0; i < 26; i++) {
    ctx.fillStyle = hash2(g, i, variant + 5) > 0.5 ? speck : dark;
    ctx.globalAlpha = 0.35 + hash2(g, variant, i) * 0.3;
    ctx.fillRect(
      Math.floor(hash2(g + 7, i, variant) * TILE),
      Math.floor(hash2(g + 13, variant, i) * TILE),
      hash2(g, i, variant * 3) > 0.7 ? 3 : 2, 2
    );
  }
  ctx.globalAlpha = 1;

  // вода — блики
  if (g === G.Water || g === G.DeepWater) {
    ctx.strokeStyle = "rgba(255,255,255,0.28)";
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 3; i++) {
      const y = 6 + i * 13 + hash2(g, variant, i) * 6;
      ctx.beginPath();
      ctx.moveTo(3 + hash2(g, i, variant) * 10, y);
      ctx.quadraticCurveTo(14, y - 3, 24, y);
      ctx.quadraticCurveTo(30, y + 2, 37, y);
      ctx.stroke();
    }
  }
  // лава: раскалённые прожилки
  if (g === G.Lava) {
    ctx.strokeStyle = "rgba(255,220,120,0.6)";
    ctx.lineWidth = 2;
    for (let i = 0; i < 3; i++) {
      const y = 8 + i * 12 + hash2(g, variant, i) * 6;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.quadraticCurveTo(TILE * 0.5, y + (hash2(g, i, variant) - 0.5) * 12, TILE, y);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(255,180,80,0.35)";
    ctx.beginPath(); ctx.arc(TILE * 0.5, TILE * 0.5, 9, 0, 7); ctx.fill();
  }
  // облака: клубы
  if (g === G.Cloud) {
    ctx.fillStyle = "rgba(160,190,220,0.14)";
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.arc(hash2(g, i, variant) * TILE, hash2(g + 2, variant, i) * TILE, 6 + hash2(g, variant, i) * 7, 0, 7);
      ctx.fill();
    }
  }
  // вода океана: колонна света
  if (g === G.DeepWaterCol || g === G.SeaFloor || g === G.CoralBed) {
    ctx.strokeStyle = "rgba(190,230,255,0.16)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(TILE * 0.3 + variant * 3, 0);
    ctx.lineTo(TILE * 0.45 + variant * 3, TILE);
    ctx.stroke();
  }
  // кратеры Луны
  if (g === G.MoonDust) {
    for (let i = 0; i < 2; i++) {
      const cx = hash2(g, i, variant) * TILE, cy = hash2(g + 1, variant, i) * TILE;
      const rr = 4 + hash2(g, variant, i + 3) * 6;
      ctx.strokeStyle = "rgba(120,114,104,0.5)";
      ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.arc(cx, cy, rr, 0, 7); ctx.stroke();
      ctx.fillStyle = "rgba(150,144,134,0.3)";
      ctx.beginPath(); ctx.arc(cx, cy, rr * 0.6, 0, 7); ctx.fill();
    }
  }
  // мир снов: мерцающие узоры
  if (g === G.DreamGround || g === G.ChaosGround) {
    ctx.strokeStyle = g === G.DreamGround ? "rgba(240,200,255,0.3)" : "rgba(255,160,230,0.32)";
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(hash2(g, i, variant) * TILE, hash2(g + 5, variant, i) * TILE, 3 + hash2(g, variant, i) * 5, 0, 4.5);
      ctx.stroke();
    }
  }
  // металлический пол баз
  if (g === G.MetalFloor) {
    ctx.strokeStyle = "rgba(40,46,52,0.6)";
    ctx.lineWidth = 1.6;
    ctx.strokeRect(3, 3, TILE - 6, TILE - 6);
    ctx.fillStyle = "rgba(180,190,200,0.25)";
    for (const [bx, by] of [[6, 6], [TILE - 8, 6], [6, TILE - 8], [TILE - 8, TILE - 8]]) {
      ctx.beginPath(); ctx.arc(bx, by, 1.6, 0, 7); ctx.fill();
    }
  }
  // трещины камня/пещеры
  if (g === G.CaveWall || g === G.Stone || g === G.SnowRock || g === G.HellRock || g === G.Obsidian || g === G.VoidFloor) {
    ctx.strokeStyle = "rgba(0,0,0,0.3)";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(hash2(g, variant, 1) * TILE, 0);
    ctx.lineTo(hash2(g, variant, 2) * TILE, TILE * 0.5);
    ctx.lineTo(hash2(g, variant, 3) * TILE, TILE);
    ctx.stroke();
  }
  // сезонный оттенок зелени
  if (isGreen(g) && season > 0) {
    const [tint, a] = SEASON_TINT[season];
    ctx.fillStyle = tint;
    ctx.globalAlpha = a;
    ctx.fillRect(0, 0, TILE, TILE);
    ctx.globalAlpha = 1;
  }
  if (season === 3 && isGreen(g)) {
    ctx.fillStyle = "#eef3f7";
    ctx.globalAlpha = 0.4;
    ctx.fillRect(0, 0, TILE, TILE);
    ctx.globalAlpha = 1;
  }
  cachePut(key, c);
  return c;
}

// Мягкая эллиптическая тень (общий спрайт)
let shadowSprite: HTMLCanvasElement | null = null;
export function getShadowSprite(): HTMLCanvasElement {
  if (shadowSprite) return shadowSprite;
  const [c, ctx] = cv(64, 32);
  const gr = ctx.createRadialGradient(32, 16, 2, 32, 16, 30);
  gr.addColorStop(0, "rgba(15,8,6,0.42)");
  gr.addColorStop(1, "rgba(15,8,6,0)");
  ctx.scale(1, 0.5);
  ctx.fillStyle = gr;
  ctx.beginPath();
  ctx.arc(32, 32, 30, 0, 7);
  ctx.fill();
  shadowSprite = c;
  return c;
}

export function objSprite(o: number, season: number, variant = 0): HTMLCanvasElement {
  const key = `o${o}_${season}_${variant}`;
  const hit = cache.get(key);
  if (hit) return hit;
  // рисуем во внутреннем разрешении ×S — при выводе даёт чёткие детали
  const big = objSpriteBig(o);
  const W = (big ? TILE * 2 : TILE) * S;
  const H = (big ? TILE * 2.4 : TILE) * S;
  const [c, ctx] = cv(W, H);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  drawObject(ctx, o, season, W, H, variant);
  cachePut(key, c);
  return c;
}

export function clearSpriteCache() { cache.clear(); shadowSprite = null; }
