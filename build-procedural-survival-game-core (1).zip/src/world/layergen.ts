import { G, O } from "../types";
import { fbm, hash2, clamp01 } from "../lib/noise";
import { objMaxHp, zoneAt } from "./worldgen";
import { L } from "../data/layers";

// ===== Генерация тайлов для слоёв 2..9 =====
export interface TileInfo { g: number; o: number; hp: number }

function mk(g: number, o: number): TileInfo { return { g, o, hp: objMaxHp(o as 0) }; }

/** Глубины: реки лавы, обсидиановые плато, адамантин */
function deepTile(seed: number, tx: number, ty: number): TileInfo {
  const cave = fbm(seed ^ 0xde37, tx / 34, ty / 34, 4);
  const lava = fbm(seed ^ 0x1a7a, tx / 22 + 40, ty / 22, 3);
  const r = hash2(seed ^ 0xd1, tx, ty);
  const zone = zoneAt(tx, ty);
  if (lava > 0.68) return mk(G.Lava, O.None);
  if (cave < 0.42) {
    // порода со вкраплениями
    if (r < 0.055) {
      const ore = hash2(seed ^ 0xd2, tx, ty);
      return mk(G.HellRock, ore < 0.4 ? O.Coal : ore < 0.68 ? O.Iron : ore < 0.88 ? O.Mithril : O.Adamant);
    }
    return mk(G.HellRock, O.None);
  }
  if (r < 0.012) return mk(G.Obsidian, O.LavaVent);
  if (r < 0.03) return mk(G.Obsidian, O.Crystal);
  if (r < 0.038 + zone * 0.002) return mk(G.Obsidian, O.RuinChest);
  if (r < 0.05) return mk(G.Obsidian, O.Bones);
  if (r < 0.058) return mk(G.Obsidian, O.Trap);
  if (r < 0.064) return mk(G.Obsidian, O.Mechanism);
  return mk(fbm(seed ^ 0x99, tx / 12, ty / 12, 2) > 0.5 ? G.Obsidian : G.HellRock, O.None);
}

/** Небо: летающие острова в пустоте */
function skyTile(seed: number, tx: number, ty: number): TileInfo {
  const island = fbm(seed ^ 0x5c7, tx / 26, ty / 26, 4);
  const r = hash2(seed ^ 0x5d, tx, ty);
  if (island < 0.46) return mk(G.Cloud, O.None);           // пустота между островами
  const edge = island < 0.52;
  if (edge) return mk(G.Cloud, r < 0.05 ? O.CloudTree : O.None);
  if (r < 0.035) return mk(G.SkyGrass, O.SkyCrystal);
  if (r < 0.07) return mk(G.SkyGrass, O.CloudTree);
  if (r < 0.1) return mk(G.SkyGrass, O.GrassTuft);
  if (r < 0.115) return mk(G.SkyGrass, O.FlowerY);
  if (r < 0.125) return mk(G.SkyGrass, O.RuinChest);
  if (r < 0.14) return mk(G.SkyGrass, O.Rock);
  return mk(G.SkyGrass, O.None);
}

/** Океан: дно, коралловые сады, затонувшие корабли */
function oceanTile(seed: number, tx: number, ty: number): TileInfo {
  const depth = fbm(seed ^ 0x0cea, tx / 40, ty / 40, 3);
  const r = hash2(seed ^ 0x0c, tx, ty);
  if (depth > 0.72) return mk(G.DeepWaterCol, r < 0.02 ? O.Wreck : O.None);
  const coral = fbm(seed ^ 0xc07a, tx / 18, ty / 18, 3) > 0.58;
  if (coral) {
    if (r < 0.1) return mk(G.CoralBed, O.CoralObj);
    if (r < 0.14) return mk(G.CoralBed, O.Pearl);
    if (r < 0.2) return mk(G.CoralBed, O.Seaweed);
    return mk(G.CoralBed, O.None);
  }
  if (r < 0.02) return mk(G.SeaFloor, O.Wreck);
  if (r < 0.035) return mk(G.SeaFloor, O.RuinChest);
  if (r < 0.06) return mk(G.SeaFloor, O.Pearl);
  if (r < 0.11) return mk(G.SeaFloor, O.Seaweed);
  if (r < 0.13) return mk(G.SeaFloor, O.Rock);
  return mk(G.SeaFloor, O.None);
}

/** Луна: кратеры, реголит, лунная руда */
function moonTile(seed: number, tx: number, ty: number): TileInfo {
  const crater = fbm(seed ^ 0x3100, tx / 20, ty / 20, 3);
  const r = hash2(seed ^ 0x31, tx, ty);
  if (crater > 0.74) return mk(G.VoidFloor, O.None);        // провал кратера
  if (r < 0.045) return mk(G.MoonDust, O.MoonOre);
  if (r < 0.06) return mk(G.MoonDust, O.Rock);
  if (r < 0.068) return mk(G.MoonDust, O.RuinChest);
  if (r < 0.076) return mk(G.MoonDust, O.AlienRelic);
  return mk(G.MoonDust, O.None);
}

/** Марс: рыжие пески, каналы, чужие руины */
function marsTile(seed: number, tx: number, ty: number): TileInfo {
  const canal = fbm(seed ^ 0x3200, tx / 30, ty / 30, 4);
  const r = hash2(seed ^ 0x32, tx, ty);
  if (canal < 0.34) return mk(G.VoidFloor, O.None);
  if (r < 0.05) return mk(G.MarsSand, O.MarsOre);
  if (r < 0.07) return mk(G.MarsSand, O.AlienRelic);
  if (r < 0.085) return mk(G.MarsSand, O.Mechanism);
  if (r < 0.095) return mk(G.MarsSand, O.RuinChest);
  if (r < 0.115) return mk(G.MarsSand, O.Rock);
  if (r < 0.125) return mk(G.MetalFloor, O.None);
  return mk(G.MarsSand, O.None);
}

/** Мир теней: выцветшая изнанка поверхности */
function shadowTile(seed: number, tx: number, ty: number): TileInfo {
  const n = fbm(seed ^ 0x5ad0, tx / 28, ty / 28, 4);
  const r = hash2(seed ^ 0x5a, tx, ty);
  if (n < 0.3) return mk(G.VoidFloor, O.None);
  if (r < 0.07) return mk(G.ShadowGround, O.ShadowTree);
  if (r < 0.1) return mk(G.ShadowGround, O.Bones);
  if (r < 0.115) return mk(G.ShadowGround, O.Crystal);
  if (r < 0.125) return mk(G.ShadowGround, O.RuinChest);
  if (r < 0.15) return mk(G.ShadowGround, O.DeadBush);
  return mk(G.ShadowGround, O.None);
}

/** Мир снов: мягкие холмы мысли */
function dreamTile(seed: number, tx: number, ty: number): TileInfo {
  const n = fbm(seed ^ 0xd7ea, tx / 24, ty / 24, 3);
  const r = hash2(seed ^ 0xd7, tx, ty);
  if (n < 0.28) return mk(G.Cloud, O.None);
  if (r < 0.08) return mk(G.DreamGround, O.DreamFlower);
  if (r < 0.12) return mk(G.DreamGround, O.CloudTree);
  if (r < 0.14) return mk(G.DreamGround, O.Crystal);
  if (r < 0.15) return mk(G.DreamGround, O.RuinChest);
  if (r < 0.19) return mk(G.DreamGround, O.GrassTuft);
  return mk(G.DreamGround, O.None);
}

/** Мир хаоса: правила меняются от координат */
function chaosTile(seed: number, tx: number, ty: number): TileInfo {
  // «правило» участка выбирается шумом — куски разных миров вперемешку
  const rule = Math.floor(fbm(seed ^ 0xc405, tx / 16, ty / 16, 2) * 5);
  const r = hash2(seed ^ 0xc4, tx, ty);
  if (r < 0.015) return mk(G.ChaosGround, O.ChaosOrb);
  if (r < 0.03) return mk(G.ChaosGround, O.RuinChest);
  switch (rule) {
    case 0: return mk(G.ChaosGround, r < 0.1 ? O.Crystal : O.None);
    case 1: return mk(G.Lava, O.None);
    case 2: return mk(G.DreamGround, r < 0.12 ? O.DreamFlower : O.None);
    case 3: return mk(G.ShadowGround, r < 0.1 ? O.ShadowTree : O.None);
    default: return mk(G.ChaosGround, r < 0.08 ? O.Adamant : O.None);
  }
}

export function layerTile(seed: number, tx: number, ty: number, z: number): TileInfo | null {
  switch (z) {
    case L.Deep: return deepTile(seed, tx, ty);
    case L.Sky: return skyTile(seed, tx, ty);
    case L.Ocean: return oceanTile(seed, tx, ty);
    case L.Moon: return moonTile(seed, tx, ty);
    case L.Mars: return marsTile(seed, tx, ty);
    case L.Shadow: return shadowTile(seed, tx, ty);
    case L.Dream: return dreamTile(seed, tx, ty);
    case L.Chaos: return chaosTile(seed, tx, ty);
    default: return null;
  }
}

/** Цвет слоя на миникарте */
export function layerMiniColor(seed: number, tx: number, ty: number, z: number): string | null {
  const t = layerTile(seed, tx, ty, z);
  if (!t) return null;
  switch (t.g) {
    case G.Lava: return "#e0662e";
    case G.Obsidian: return "#2e2635";
    case G.HellRock: return "#4a2820";
    case G.Cloud: return "#1d2b3d";
    case G.SkyGrass: return "#8fd0a0";
    case G.SeaFloor: return "#2f6a86";
    case G.CoralBed: return "#c9756a";
    case G.DeepWaterCol: return "#12405e";
    case G.MoonDust: return "#b8b2a4";
    case G.MarsSand: return "#b0563a";
    case G.VoidFloor: return "#14121c";
    case G.ShadowGround: return "#3a3048";
    case G.DreamGround: return "#a874c9";
    case G.ChaosGround: return "#8a3a7a";
    case G.MetalFloor: return "#7d8893";
    default: return "#555";
  }
}

/** Добыча с объектов слоёв */
export function layerDrop(o: number, r: (k: number) => number): { id: string; n: number }[] {
  const out: { id: string; n: number }[] = [];
  const n = (base: number, extra = 2) => base + Math.floor(r(1) * extra);
  switch (o) {
    case O.Mithril: out.push({ id: "mifril", n: n(1, 2) }, { id: "kamen", n: 1 }); break;
    case O.Adamant: out.push({ id: "adamantit", n: n(1, 2) }); break;
    case O.Crystal: out.push({ id: "kristall", n: n(1, 2) }); break;
    case O.LavaVent: out.push({ id: "obsidian", n: n(2, 3) }, { id: "ugol", n: n(1, 3) }); break;
    case O.SkyCrystal: out.push({ id: "nebesnyi_kristall", n: n(1, 2) }); break;
    case O.CloudTree: out.push({ id: "oblachnyi_hlopok", n: n(2, 3) }, { id: "brevno", n: 1 }); break;
    case O.Pearl: out.push({ id: "zhemchug", n: n(1, 2) }); break;
    case O.CoralObj: out.push({ id: "korall", n: n(2, 2) }); break;
    case O.Seaweed: out.push({ id: "nit", n: n(1, 2) }); break;
    case O.Wreck: out.push({ id: "doska", n: n(3, 4) }, { id: "zoloto", n: 20 + Math.floor(r(2) * 80) }); break;
    case O.MoonOre: out.push({ id: "lunnyi_kamen", n: n(2, 3) }); break;
    case O.MarsOre: out.push({ id: "marsianit", n: n(2, 3) }); break;
    case O.AlienRelic: out.push({ id: "alien_tech", n: 1 }, { id: "zoloto", n: 40 + Math.floor(r(3) * 120) }); break;
    case O.ShadowTree: out.push({ id: "tenevaya_sut", n: n(1, 2) }, { id: "brevno", n: 1 }); break;
    case O.DreamFlower: out.push({ id: "pyl_snov", n: n(1, 2) }); break;
    case O.ChaosOrb: out.push({ id: "oskolok_haosa", n: n(1, 2) }, { id: "zoloto", n: 60 + Math.floor(r(4) * 200) }); break;
    case O.Mechanism: out.push({ id: "instrument", n: 1 }, { id: "zhel_slitok", n: n(1, 2) }); break;
    default: break;
  }
  return out;
}

/** Опасность слоя в точке (для урона стихией) */
export function hazardStrength(z: number, tx: number, ty: number, seed: number): number {
  if (z === L.Deep) {
    const lava = fbm(seed ^ 0x1a7a, tx / 22 + 40, ty / 22, 3);
    return clamp01((lava - 0.45) * 2.2);
  }
  return 1;
}
